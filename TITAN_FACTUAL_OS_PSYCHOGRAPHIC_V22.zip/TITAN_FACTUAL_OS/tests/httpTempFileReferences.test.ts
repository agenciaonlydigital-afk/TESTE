import assert from 'node:assert/strict';
import test from 'node:test';
import { HttpTempFileReferenceTracker } from '../src/lakehouse/httpTempFileReferences.ts';

test('shared response file remains available until the last in-flight caller releases it', () => {
  const refs = new HttpTempFileReferenceTracker();
  const path = '/tmp/shared-response';
  refs.register(path, 3);
  assert.equal(refs.getConsumerCount(path), 3);
  assert.equal(refs.release(path), false);
  assert.equal(refs.getConsumerCount(path), 2);
  assert.equal(refs.release(path), false);
  assert.equal(refs.getConsumerCount(path), 1);
  assert.equal(refs.release(path), true);
  assert.equal(refs.getConsumerCount(path), null);
  assert.equal(refs.release(path), true);
});

test('invalid reference counts are rejected', () => {
  const refs = new HttpTempFileReferenceTracker();
  assert.throws(() => refs.register('/tmp/file', 0), RangeError);
  assert.throws(() => refs.register('/tmp/file', 1.5), RangeError);
});
