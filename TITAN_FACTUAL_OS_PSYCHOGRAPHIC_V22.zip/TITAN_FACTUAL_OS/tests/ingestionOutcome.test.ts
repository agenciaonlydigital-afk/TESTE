import test from 'node:test';
import assert from 'node:assert/strict';
import { classifyEmptyConnectorOutcome } from '../src/lakehouse/ingestionOutcome.ts';

test('only an explicit all-required HTTP 304 with zero raw rows is up-to-date', () => {
  const result = classifyEmptyConnectorOutcome({ rawRowCount: 0, notModified: true });
  assert.equal(result.status, 'UP_TO_DATE_304');
});

test('empty response, failed request or parser producing no Silver rows is a failure', () => {
  assert.equal(classifyEmptyConnectorOutcome({ rawRowCount: 0, notModified: false }).status, 'FAILED');
  assert.equal(classifyEmptyConnectorOutcome({ rawRowCount: 40, notModified: true }).status, 'FAILED');
  assert.equal(classifyEmptyConnectorOutcome({ rawRowCount: 40, notModified: false }).status, 'FAILED');
});

test('invalid raw row counts are rejected', () => {
  assert.throws(() => classifyEmptyConnectorOutcome({ rawRowCount: -1, notModified: false }));
  assert.throws(() => classifyEmptyConnectorOutcome({ rawRowCount: 1.5, notModified: false }));
});
