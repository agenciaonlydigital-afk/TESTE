import test from 'node:test';
import assert from 'node:assert/strict';
import { buildObservationIdentity } from '../src/lakehouse/observationIdentity.ts';

const base = {
  territory_id: 'BRA', indicator_id: 'PSY.TRUST.INSTITUTIONS', period_year: 2024,
  survey_id: 'wvs', survey_wave_id: 'wave-7', question_id: 'q1', response_category: 'high',
};

test('identical survey observations receive the same identity', () => {
  assert.equal(buildObservationIdentity(base), buildObservationIdentity({ ...base }));
});

test('different survey waves, questions, categories, age and sex strata stay distinct', () => {
  const keys = [
    buildObservationIdentity(base),
    buildObservationIdentity({ ...base, survey_wave_id: 'wave-8' }),
    buildObservationIdentity({ ...base, question_id: 'q2' }),
    buildObservationIdentity({ ...base, response_category: 'low' }),
    buildObservationIdentity({ ...base, age_group: '18-24' }),
    buildObservationIdentity({ ...base, sex: 'female' }),
  ];
  assert.equal(new Set(keys).size, keys.length);
});

test('identity encoding avoids delimiter collisions in categorical dimensions', () => {
  const a = buildObservationIdentity({ ...base, response_category: 'a|b' });
  const b = buildObservationIdentity({ ...base, response_category: 'a', sex: 'b' });
  assert.notEqual(a, b);
});
