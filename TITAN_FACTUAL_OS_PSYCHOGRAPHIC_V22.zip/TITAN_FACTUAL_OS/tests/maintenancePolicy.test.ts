import assert from 'node:assert/strict';
import test from 'node:test';
import { ORPHAN_FILE_GRACE_MS, isEligibleForOrphanCleanup } from '../src/lakehouse/maintenancePolicy.ts';

test('active and recently-created Parquet files are protected from orphan cleanup', () => {
  const now = Date.UTC(2026, 10, 22, 12, 0, 0);
  assert.equal(isEligibleForOrphanCleanup(now - 60_000, now), false);
  assert.equal(isEligibleForOrphanCleanup(now - ORPHAN_FILE_GRACE_MS + 1, now), false);
  assert.equal(isEligibleForOrphanCleanup(now - ORPHAN_FILE_GRACE_MS, now), true);
});

test('invalid file timestamps never qualify for cleanup', () => {
  assert.equal(isEligibleForOrphanCleanup(Number.NaN), false);
  assert.equal(isEligibleForOrphanCleanup(Infinity), false);
});
