import assert from 'node:assert/strict';
import test from 'node:test';
import { acceptsGzip } from '../src/server/middleware/compressionPolicy.ts';

test('gzip negotiation honors q-values and wildcards', () => {
  assert.equal(acceptsGzip('gzip'), true);
  assert.equal(acceptsGzip('br, gzip;q=0.8'), true);
  assert.equal(acceptsGzip('*'), true);
  assert.equal(acceptsGzip('gzip;q=0'), false);
  assert.equal(acceptsGzip('gzip;q=0, *;q=0.5'), false);
  assert.equal(acceptsGzip('br, identity'), false);
  assert.equal(acceptsGzip('gzip;q=invalid'), false);
});
