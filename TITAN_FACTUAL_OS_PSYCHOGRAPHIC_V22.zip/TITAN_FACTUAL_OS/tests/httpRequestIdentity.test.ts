import assert from 'node:assert/strict';
import test from 'node:test';
import { buildHttpRequestDedupKey } from '../src/lakehouse/httpRequestIdentity.ts';

const base = {
  method: 'GET',
  url: 'https://api.example.test/v1/data?year=2025',
  etag: 'etag-1',
  lastModified: 'Sun, 22 Nov 2026 12:00:00 GMT',
  bypassCache: false,
};

test('equivalent headers with different case and ordering coalesce', () => {
  const a = buildHttpRequestDedupKey({ ...base, headers: { Accept: 'application/json', Authorization: 'Bearer token' } });
  const b = buildHttpRequestDedupKey({ ...base, headers: { authorization: 'Bearer token', accept: 'application/json' } });
  assert.equal(a, b);
});

test('different credentials or representations never share an in-flight response', () => {
  const baseKey = buildHttpRequestDedupKey({ ...base, headers: { Authorization: 'Bearer user-a' } });
  const otherAuth = buildHttpRequestDedupKey({ ...base, headers: { Authorization: 'Bearer user-b' } });
  const otherAccept = buildHttpRequestDedupKey({ ...base, headers: { Authorization: 'Bearer user-a', Accept: 'text/csv' } });
  assert.notEqual(baseKey, otherAuth);
  assert.notEqual(baseKey, otherAccept);
});
