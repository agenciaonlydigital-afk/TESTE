import test from 'node:test';
import assert from 'node:assert/strict';
import { estimateImportedSurveyCsv, estimateImportedSurveyObservations, importHarmonizedSurveyCsv, toSurveyEstimationRecords } from '../src/lakehouse/surveyImport.ts';

const config = {
  survey_id: 'PUBLIC_SURVEY',
  wave_id: 'WAVE_1',
  delimiter: ';' as const,
  columns: { country_iso3: 'country', question_id: 'question', response: 'answer', final_weight: 'weight', stratum_id: 'stratum', psu_id: 'psu' },
  question_mappings: [
    { source_question_id: 'Q1', construct_id: 'TRUST_INSTITUTIONS', canonical_scale_id: 'TRUST_0_10', mapping_version: 'v1', transform: { kind: 'linear' as const, source_min: 1, source_max: 5, target_min: 0, target_max: 10, reverse: true } },
    { source_question_id: 'Q2', construct_id: 'CULTURAL_VALUE', canonical_scale_id: 'VALUE_0_2', mapping_version: 'v2', transform: { kind: 'categorical' as const, value_map: { low: 0, medium: 1, high: 2 }, missing_values: ['DK'] } },
  ],
};

test('imports explicit question mappings, transforms reverse-coded scales and strips respondent identifiers', () => {
  const csv = '\uFEFFcountry;question;answer;weight;stratum;psu;respondent_id\nBRA;Q1;1;1;S1;P1;person-1\nBRA;Q1;5;1;S1;P2;person-2\nBRA;Q2;high;2;S2;P3;person-3\nBRA;Q2;DK;1;S2;P4;person-4\nBRA;Q9;5;1;S2;P5;person-5\n';
  const imported = importHarmonizedSurveyCsv(csv, config);
  assert.equal(imported.input_rows, 5);
  assert.equal(imported.imported_rows, 3);
  assert.equal(imported.excluded_missing_response_rows, 1);
  assert.equal(imported.excluded_unmapped_question_rows, 1);
  assert.equal(imported.records[0]?.response_numeric, 10);
  assert.equal(imported.records[1]?.response_numeric, 0);
  assert.equal(imported.records.some((row) => 'respondent_id' in row), false);
  const estimate = estimateImportedSurveyCsv(imported, { minimumEffectiveSampleSize: 1 });
  assert.equal(estimate.length, 2);
  assert.ok(estimate.every((row) => row.estimate.sample_size > 0));
  assert.ok(estimate.every((row) => row.distribution.categories.length > 0));
  assert.ok(estimate.every((row) => row.canonical_scale_max > row.canonical_scale_min));
  assert.ok(estimate.every((row) => row.construct_label.length > 0 && row.construct_domain));
  assert.ok(estimate.every((row) => row.country_iso3 === 'BRA' && row.survey_id === 'PUBLIC_SURVEY' && row.wave_id === 'WAVE_1'));
  assert.ok(estimate.some((row) => row.construct_id === 'TRUST_INSTITUTIONS' && row.estimate.weighted_mean === 5));
  assert.equal(toSurveyEstimationRecords(imported.records).length, 3);
});

test('rejects unknown categorical values, out-of-range responses and invalid final weights', () => {
  assert.throws(() => importHarmonizedSurveyCsv('country;question;answer;weight;stratum;psu\nBRA;Q2;other;1;S1;P1', config), /not present in the explicit categorical/);
  assert.throws(() => importHarmonizedSurveyCsv('country;question;answer;weight;stratum;psu\nBRA;Q1;6;1;S1;P1', config), /outside the configured source scale/);
  assert.throws(() => importHarmonizedSurveyCsv('country;question;answer;weight;stratum;psu\nBRA;Q1;3;0;S1;P1', config), /must be positive/);
});

test('rejects malformed CSV, duplicate headers, inconsistent row widths and invalid question maps', () => {
  assert.throws(() => importHarmonizedSurveyCsv('country;question;answer;weight;stratum;psu\nBRA;Q1;"unterminated;1;S1;P1', config), /unterminated/);
  assert.throws(() => importHarmonizedSurveyCsv('country;country;answer;weight;stratum;psu\nBRA;Q1;3;1;S1;P1', config), /duplicate column/);
  assert.throws(() => importHarmonizedSurveyCsv('country;question;answer;weight;stratum;psu\nBRA;Q1;3;1;S1', config), /fields; expected/);
  assert.throws(() => importHarmonizedSurveyCsv('country;question;answer;weight;stratum;psu\nBRA;Q1;3;1;S1;P1', { ...config, question_mappings: [] }), /question harmonization mapping is required/);
});

test('enforces import size and row limits and requires paired design columns', () => {
  const csv = 'country;question;answer;weight;stratum;psu\nBRA;Q1;3;1;S1;P1';
  assert.throws(() => importHarmonizedSurveyCsv(csv, { ...config, maximum_bytes: 10 }), /maximum_bytes/);
  assert.throws(() => importHarmonizedSurveyCsv(csv, { ...config, maximum_rows: 0 }), /maximum_rows/);
  assert.throws(() => importHarmonizedSurveyCsv(csv, { ...config, columns: { ...config.columns, psu_id: undefined } }), /configured together/);
});


test('keeps national estimates separated and identifies each country explicitly', () => {
  const csv = 'country;question;answer;weight;stratum;psu\nBRA;Q1;1;1;S1;P1\nBRA;Q1;5;1;S1;P2\nARG;Q1;3;2;S1;P3\nARG;Q1;5;1;S1;P4';
  const imported = importHarmonizedSurveyCsv(csv, config);
  const estimates = estimateImportedSurveyCsv(imported, { minimumEffectiveSampleSize: 1 });
  assert.equal(estimates.length, 2);
  assert.deepEqual(estimates.map((row) => row.country_iso3), ['ARG', 'BRA']);
  assert.ok(estimates.every((row) => row.estimate.country_iso3 === row.country_iso3));
});


test('runs the complete survey CSV-to-Silver path and emits mean plus separate weighted categories', () => {
  const csv = 'country;question;answer;weight;stratum;psu\nBRA;Q1;1;1;S1;P1\nBRA;Q1;2;1;S1;P2\nBRA;Q1;4;1;S2;P3\nBRA;Q1;5;1;S2;P4';
  const imported = importHarmonizedSurveyCsv(csv, config);
  const observations = estimateImportedSurveyObservations(imported, (question) => ({
    territory_id: question.country_iso3, indicator_id: 'SURVEY_TRUST', indicator_name: 'Trust construct',
    module_id: 12, source_id: 'wvs', dataset_id: 'wvs_wave_7', period_year: 2024,
    unit: 'harmonized scale 0–10', valuation_basis: 'index_score', methodology_id: 'taylor_wr_v1',
    commercial_use_allowed: 'confirmed', asserted_at: '2026-11-22T00:00:00.000Z',
    population_scope: 'Adults aged 18+', weighting_method: 'Final calibrated survey weight',
  }), { minimumEffectiveSampleSize: 1 });
  assert.equal(observations.filter((item) => item.survey_statistic === 'weighted_mean').length, 1);
  assert.equal(observations.filter((item) => item.survey_statistic === 'weighted_share').length, 4);
  assert.ok(observations.every((item) => item.psychographic_construct_id === 'TRUST_INSTITUTIONS'));
  assert.ok(observations.every((item) => item.canonical_scale_min === 0 && item.canonical_scale_max === 10));
  assert.equal(observations.filter((item) => item.response_category_count !== undefined).length, 4);
});
