import test from 'node:test';
import assert from 'node:assert/strict';
import { buildAuditedSourceCatalog } from '../src/lakehouse/sourceInventory.ts';
import { buildAcquisitionPlan, planSourceAcquisition } from '../src/lakehouse/acquisitionPlanner.ts';

const catalog = buildAuditedSourceCatalog('2026-11-22T00:00:00.000Z');
const source = (id: string) => {
  const found = catalog.find((item) => item.source_id === id);
  assert.ok(found, `missing source ${id}`);
  return found;
};

test('acquisition planning honors each existing connector protocol', () => {
  assert.equal(planSourceAcquisition(source('world_bank_sdmx'), true).strategy, 'sdmx_api');
  assert.equal(planSourceAcquisition(source('who_gho_odata'), true).strategy, 'odata_api');
  assert.equal(planSourceAcquisition(source('wikidata_sparql'), true).strategy, 'sparql');
  assert.equal(planSourceAcquisition(source('faostat_bulk'), true).strategy, 'bulk_download');
});

test('catalog-only or missing connector sources are never treated as ready', () => {
  assert.equal(planSourceAcquisition(source('gdelt_doc_v2'), false).readiness, 'CATALOG_ONLY');
  const missing = planSourceAcquisition(source('world_bank_sdmx'), false);
  assert.equal(missing.readiness, 'CONNECTOR_MISSING');
});

test('Overture is accurately labelled as STAC discovery rather than complete GeoParquet ingestion', () => {
  const plan = planSourceAcquisition(source('overture_maps_geoparquet'), true);
  assert.equal(plan.strategy, 'catalog_discovery');
  assert.match(plan.reason, /not a full remote GeoParquet ingest/i);
});

test('complete plan has one item per catalog source and explicit readiness counts', () => {
  const plan = buildAcquisitionPlan(catalog, (id) => source(id).implemented_wave1 === 1);
  assert.equal(plan.length, 95);
  assert.equal(plan.filter((item) => item.readiness === 'READY').length, 79);
  assert.equal(plan.filter((item) => item.readiness === 'CATALOG_ONLY').length, 16);
});
