import test from 'node:test';
import assert from 'node:assert/strict';
import { assessTerritoryRegistryReadiness } from '../src/lakehouse/territoryRegistryReadiness.ts';

test('partial seed registry never qualifies as a global country baseline', () => {
  const readiness = assessTerritoryRegistryReadiness(34, false);
  assert.equal(readiness.status, 'BLOCKED');
  assert.equal(readiness.globalCountryCoverageReady, false);
  assert.match(readiness.reason, /34\/190 minimum enriched country entities/);
});

test('global readiness requires both a broad registry and a source-specific expected set', () => {
  assert.equal(assessTerritoryRegistryReadiness(249, false).status, 'BLOCKED');
  assert.equal(assessTerritoryRegistryReadiness(34, true).status, 'BLOCKED');
  assert.equal(assessTerritoryRegistryReadiness(249, true).status, 'READY');
});

test('negative or non-integer registry counts are rejected', () => {
  assert.throws(() => assessTerritoryRegistryReadiness(-1, false), RangeError);
  assert.throws(() => assessTerritoryRegistryReadiness(1.5, false), RangeError);
});
