import test from 'node:test';
import assert from 'node:assert/strict';
import {
  isRetryableFetchFailure,
  isRetryableHttpStatus,
  parseRetryAfter,
  retryBackoffMs,
  retryNetworkBackoffMs,
} from '../src/lakehouse/connectors/httpRetryPolicy.ts';

test('only transient HTTP statuses are retried', () => {
  for (const status of [408, 429, 500, 502, 503, 504, 599]) assert.equal(isRetryableHttpStatus(status), true);
  for (const status of [200, 301, 304, 400, 401, 403, 404, 422, 499, 600]) assert.equal(isRetryableHttpStatus(status), false);
});

test('Retry-After supports delta-seconds and HTTP dates with a bounded wait', () => {
  assert.equal(parseRetryAfter('2', 0), 2000);
  assert.equal(parseRetryAfter('120', 0), 30_000);
  assert.equal(parseRetryAfter('Wed, 21 Oct 2015 07:28:00 GMT', Date.parse('Wed, 21 Oct 2015 07:27:00 GMT')), 30_000);
  assert.equal(parseRetryAfter('not-a-date', 0), null);
  assert.equal(parseRetryAfter(null, 0), null);
});

test('exponential jitter backoff is bounded and deterministic for a fixed random value', () => {
  assert.equal(retryBackoffMs(0, 0.5), 300);
  assert.equal(retryBackoffMs(2, 0.5), 1200);
  assert.equal(retryBackoffMs(20, 0.999), 9990);
  assert.equal(retryNetworkBackoffMs(0, 0.5), 250);
  assert.equal(retryNetworkBackoffMs(20, 0.999), 7992);
  assert.throws(() => retryBackoffMs(-1, 0.5));
});

test('only transport errors and timeouts are transient fetch failures', () => {
  assert.equal(isRetryableFetchFailure(new TypeError('fetch failed')), true);
  assert.equal(isRetryableFetchFailure(new TypeError('Failed to parse URL from undefined')), false);
  const refused = Object.assign(new TypeError('fetch failed'), { cause: { code: 'ECONNREFUSED' } });
  assert.equal(isRetryableFetchFailure(refused), true);
  assert.equal(isRetryableFetchFailure(new DOMException('timed out', 'TimeoutError')), true);
  const reset = Object.assign(new Error('connection reset'), { code: 'ECONNRESET' });
  assert.equal(isRetryableFetchFailure(reset), true);
  assert.equal(isRetryableFetchFailure(Object.assign(new Error('disk full'), { code: 'ENOSPC' })), false);
  assert.equal(isRetryableFetchFailure(new Error('invalid configuration')), false);
  assert.equal(isRetryableFetchFailure('network down'), false);
});
