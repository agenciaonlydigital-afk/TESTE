import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { streamBodyToDiskWithHash } from '../src/lakehouse/connectors/httpStream.ts';

async function makeTempDirectory(): Promise<string> {
  return fs.mkdtemp(path.join(os.tmpdir(), 'titan-http-stream-'));
}

test('streams the full body to disk and returns a matching SHA-256 and byte count', async () => {
  const dir = await makeTempDirectory();
  try {
    const dest = path.join(dir, 'body', 'capture.bin');
    const payload = Buffer.from('TITAN response payload');
    const body = new ReadableStream<Uint8Array>({
      start(controller) {
        controller.enqueue(payload.subarray(0, 5));
        controller.enqueue(payload.subarray(5));
        controller.close();
      },
    });
    const result = await streamBodyToDiskWithHash(body, dest);
    assert.equal(result.byteSize, payload.length);
    assert.equal(result.sha256, crypto.createHash('sha256').update(payload).digest('hex'));
    assert.deepEqual(await fs.readFile(dest), payload);
  } finally {
    await fs.rm(dir, { recursive: true, force: true });
  }
});

test('aborts a stalled response body and removes the partial temporary file', async () => {
  const dir = await makeTempDirectory();
  const dest = path.join(dir, 'partial.bin');
  const controller = new AbortController();
  const body = new ReadableStream<Uint8Array>({
    start(streamController) {
      streamController.enqueue(Buffer.from('partial'));
    },
  });
  try {
    const transfer = streamBodyToDiskWithHash(body, dest, controller.signal);
    const timer = setTimeout(() => controller.abort(new DOMException('timeout', 'TimeoutError')), 25);
    await assert.rejects(transfer);
    clearTimeout(timer);
    await assert.rejects(fs.access(dest));
  } finally {
    await fs.rm(dir, { recursive: true, force: true });
  }
});

test('does not overwrite an existing destination file', async () => {
  const dir = await makeTempDirectory();
  const dest = path.join(dir, 'already-there.bin');
  try {
    await fs.writeFile(dest, 'original');
    const body = new ReadableStream<Uint8Array>({
      start(controller) { controller.enqueue(Buffer.from('replacement')); controller.close(); },
    });
    await assert.rejects(streamBodyToDiskWithHash(body, dest), { code: 'EEXIST' });
    assert.equal(await fs.readFile(dest, 'utf8'), 'original');
  } finally {
    await fs.rm(dir, { recursive: true, force: true });
  }
});
