import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateIndicatorCoverage } from '../src/lakehouse/coverageContracts.ts';

test('coverage threshold is computed per indicator against an explicit expected territory set', () => {
  const expected = Array.from({ length: 100 }, (_, i) => `T${String(i).padStart(3, '0')}`);
  const rows = [
    ...expected.slice(0, 98).map((territory_id) => ({ territory_id, indicator_id: 'A' })),
    ...expected.slice(0, 97).map((territory_id) => ({ territory_id, indicator_id: 'B' })),
  ];
  const result = evaluateIndicatorCoverage(rows, expected, 0.98);
  assert.equal(result.find((x) => x.indicator_id === 'A')?.meets_threshold, true);
  assert.equal(result.find((x) => x.indicator_id === 'A')?.coverage_ratio, 0.98);
  assert.equal(result.find((x) => x.indicator_id === 'B')?.meets_threshold, false);
  assert.equal(result.find((x) => x.indicator_id === 'B')?.missing_territories.length, 3);
});

test('coverage rejects invalid thresholds', () => {
  assert.throws(() => evaluateIndicatorCoverage([], ['BRA'], 0));
  assert.throws(() => evaluateIndicatorCoverage([], ['BRA'], 1.01));
});
