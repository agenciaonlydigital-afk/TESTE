import test from 'node:test';
import assert from 'node:assert/strict';
import { buildGeoBoundariesMetadataUrls, fetchGeoBoundariesCatalog } from '../src/lakehouse/spatial/geoBoundariesCatalog.ts';

test('builds current gbOpen metadata endpoints for ADM0, ADM1 and ADM2', () => {
  const urls = buildGeoBoundariesMetadataUrls('BRA');
  assert.deepEqual(urls.map((item) => item.level), ['ADM0', 'ADM1', 'ADM2']);
  assert.ok(urls.every((item) => item.url.startsWith('https://www.geoboundaries.org/api/current/gbOpen/BRA/')));
  assert.throws(() => buildGeoBoundariesMetadataUrls('bra'));
});

test('discovers metadata across admin levels without downloading geometries', async () => {
  const payloads = [
    { boundaryID: 'BRA-ADM0', boundaryISO: 'BRA', boundaryType: 'ADM0', boundaryName: 'Brazil', boundaryLicense: 'CC BY 4.0', gjDownloadURL: 'https://example.org/bra0.geojson' },
    { boundaryID: 'BRA-ADM1', boundaryISO: 'BRA', boundaryType: 'ADM1', boundaryName: 'States', boundaryLicense: 'CC BY 4.0', gjDownloadURL: 'https://example.org/bra1.geojson' },
    { boundaryID: 'BRA-ADM2', boundaryISO: 'BRA', boundaryType: 'ADM2', boundaryName: 'Municipalities', boundaryLicense: 'CC BY 4.0', gjDownloadURL: 'https://example.org/bra2.geojson' },
  ];
  let calls = 0;
  const fakeFetch = (async () => {
    const body = payloads[calls++];
    return new Response(JSON.stringify(body), { status: 200, headers: { 'content-type': 'application/json' } });
  }) as typeof fetch;
  const result = await fetchGeoBoundariesCatalog('BRA', fakeFetch);
  assert.equal(calls, 3);
  assert.equal(result.items.length, 3);
  assert.equal(result.metadata_only, true);
  assert.equal(result.geometry_downloaded, false);
  assert.equal(result.items[0]?.attribution_required, true);
});

test('treats missing administrative levels as unavailable and rejects insecure download urls', async () => {
  const fakeFetch = (async (url: string | URL | Request) => {
    const value = String(url);
    if (value.endsWith('/ADM1/')) return new Response('', { status: 404 });
    return new Response(JSON.stringify({ boundaryID: 'BRA-' + value.split('/').at(-2), boundaryISO: 'BRA', boundaryType: value.split('/').at(-2), gjDownloadURL: 'http://bad.example/file.geojson' }), { status: 200 });
  }) as typeof fetch;
  await assert.rejects(() => fetchGeoBoundariesCatalog('BRA', fakeFetch), /non-HTTPS/);
});


test('requires attribution conservatively even when license metadata is omitted', async () => {
  const fakeFetch = (async (url: string | URL | Request) => {
    const level = String(url).split('/').at(-2)!;
    return new Response(JSON.stringify({ boundaryID: `BRA-${level}`, boundaryISO: 'BRA', boundaryType: level }), { status: 200 });
  }) as typeof fetch;
  const result = await fetchGeoBoundariesCatalog('BRA', fakeFetch);
  assert.ok(result.items.every((item) => item.attribution_required));
});
