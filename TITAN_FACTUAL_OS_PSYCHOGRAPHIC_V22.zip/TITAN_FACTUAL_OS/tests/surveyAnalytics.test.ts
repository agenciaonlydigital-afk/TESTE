import test from 'node:test';
import assert from 'node:assert/strict';
import { estimateSurveyWeightedDistribution, estimateSurveyWeightedMean, surveyDistributionToObservations } from '../src/lakehouse/surveyAnalytics.ts';

function record(response_numeric: number, final_weight: number, psu_id?: string, stratum_id?: string) {
  return {
    survey_id: 'TEST_SURVEY', wave_id: 'W1', country_iso3: 'BRA', question_id: 'Q1',
    response_numeric, final_weight,
    ...(psu_id ? { psu_id, stratum_id } : {}),
  };
}

test('computes the final-weighted mean and Kish effective sample size', () => {
  const estimate = estimateSurveyWeightedMean([record(0, 1), record(10, 3)], { minimumEffectiveSampleSize: 1 });
  assert.equal(estimate.weighted_mean, 7.5);
  assert.ok(Math.abs(estimate.kish_effective_sample_size - 1.6) < 1e-12);
  assert.equal(estimate.standard_error, null);
  assert.equal(estimate.variance_status, 'unavailable_design_metadata');
  assert.equal(estimate.meets_effective_sample_threshold, true);
});

test('computes first-stage stratified PSU linearization when design identifiers are complete', () => {
  const rows = [
    record(1, 1, 'A', 'S1'), record(2, 1, 'B', 'S1'),
    record(3, 1, 'C', 'S2'), record(4, 1, 'D', 'S2'),
  ];
  const estimate = estimateSurveyWeightedMean(rows, { minimumEffectiveSampleSize: 1 });
  assert.equal(estimate.variance_status, 'available_taylor_linearization_wr_first_stage');
  assert.equal(estimate.strata_count, 2);
  assert.equal(estimate.psu_count, 4);
  assert.ok(estimate.standard_error !== null && estimate.standard_error > 0);
  assert.ok(estimate.confidence_interval_95 !== null);
});

test('withholds design variance for singleton strata and reports the reason', () => {
  const rows = [record(1, 1, 'A', 'S1'), record(2, 1, 'B', 'S1'), record(3, 1, 'C', 'S2')];
  const estimate = estimateSurveyWeightedMean(rows, { minimumEffectiveSampleSize: 1 });
  assert.equal(estimate.variance_status, 'unavailable_singleton_stratum');
  assert.equal(estimate.standard_error, null);
  assert.ok(estimate.warnings.some((warning) => warning.includes('fewer than two')));
});

test('rejects mixed survey waves, malformed weights and mismatched strata metadata', () => {
  assert.throws(() => estimateSurveyWeightedMean([record(1, 1), { ...record(2, 1), wave_id: 'W2' }]));
  assert.throws(() => estimateSurveyWeightedMean([record(1, 0)]));
  assert.throws(() => estimateSurveyWeightedMean([{ ...record(1, 1), stratum_id: 'S1' }]));
});

test('marks low effective sample sizes as below the release threshold by default', () => {
  const estimate = estimateSurveyWeightedMean([record(2, 1), record(4, 1)]);
  assert.equal(estimate.meets_effective_sample_threshold, false);
  assert.ok(estimate.warnings.some((warning) => warning.includes('below the configured minimum')));
});

test('converts only eligible survey estimates into the canonical observation shape', async () => {
  const { surveyMeanEstimateToObservation } = await import('../src/lakehouse/surveyAnalytics.ts');
  const estimate = estimateSurveyWeightedMean([
    record(1, 1, 'A', 'S1'), record(2, 1, 'B', 'S1'),
    record(3, 1, 'C', 'S2'), record(4, 1, 'D', 'S2'),
  ], { minimumEffectiveSampleSize: 1 });
  const observation = surveyMeanEstimateToObservation(estimate, {
    territory_id: 'BRA', indicator_id: 'WVS_Q1_INDEX', indicator_name: 'Survey construct', module_id: 12,
    source_id: 'wvs', dataset_id: 'wvs_wave_7', period_year: 2022, unit: 'index 0-10',
    valuation_basis: 'index_score', methodology_id: 'weighted_mean_v1', commercial_use_allowed: 'unknown',
    asserted_at: '2026-11-22T00:00:00.000Z', population_scope: 'Adults aged 18+', weighting_method: 'final calibrated weight',
  });
  assert.equal(observation.survey_id, 'TEST_SURVEY');
  assert.equal(observation.survey_wave_id, 'W1');
  assert.equal(observation.value_numeric, 2.5);
  assert.equal(observation.commercial_use_allowed, 'unknown');
  const notEligible = estimateSurveyWeightedMean([record(1, 1), record(2, 1)]);
  assert.throws(() => surveyMeanEstimateToObservation(notEligible, {
    territory_id: 'BRA', indicator_id: 'WVS_Q1_INDEX', indicator_name: 'Survey construct', module_id: 12,
    source_id: 'wvs', dataset_id: 'wvs_wave_7', period_year: 2022, unit: 'index 0-10',
    valuation_basis: 'index_score', methodology_id: 'weighted_mean_v1', commercial_use_allowed: 'unknown',
    asserted_at: '2026-11-22T00:00:00.000Z', population_scope: 'Adults aged 18+', weighting_method: 'final calibrated weight',
  }), /below its minimum/);
});


test('rejects numeric overflow and oversized survey identifiers', () => {
  assert.throws(() => estimateSurveyWeightedMean([record(1, 1e308), record(2, 1e308)]), /overflowed|not finite/);
  assert.throws(() => estimateSurveyWeightedMean([{ ...record(1, 1), question_id: 'Q'.repeat(161) }]), /exceeds 160/);
});

test('canonical observation conversion rejects blank units and inconsistent threshold flags', async () => {
  const { surveyMeanEstimateToObservation } = await import('../src/lakehouse/surveyAnalytics.ts');
  const estimate = estimateSurveyWeightedMean([record(1, 1)], { minimumEffectiveSampleSize: 1 });
  const context = {
    territory_id: 'BRA', indicator_id: 'WVS_Q1_INDEX', indicator_name: 'Survey construct', module_id: 12,
    source_id: 'wvs', dataset_id: 'wvs_wave_7', period_year: 2022, unit: 'index 0-10',
    valuation_basis: 'index_score' as const, methodology_id: 'weighted_mean_v1', commercial_use_allowed: 'unknown' as const,
    asserted_at: '2026-11-22T00:00:00.000Z', population_scope: 'Adults aged 18+', weighting_method: 'final calibrated weight',
  };
  assert.throws(() => surveyMeanEstimateToObservation(estimate, { ...context, unit: '   ' }), /identifiers and names/);
  assert.throws(() => surveyMeanEstimateToObservation(estimate, { ...context, territory_id: 'BRA-SP' }), /matching canonical country territory/);
  assert.throws(() => surveyMeanEstimateToObservation(estimate, { ...context, fieldwork_start: '2024-02-30' }), /valid ISO calendar date/);
  assert.throws(() => surveyMeanEstimateToObservation(estimate, { ...context, fieldwork_start: '2024-03-01', fieldwork_end: '2024-02-29' }), /on or before/);
  assert.throws(() => surveyMeanEstimateToObservation(estimate, { ...context, asserted_at: '2026-11-22T00:00:00' }), /explicit timezone/);
  assert.throws(() => surveyMeanEstimateToObservation({ ...estimate, meets_effective_sample_threshold: false }, context), /threshold flag is inconsistent/);
});


test('normalizes extreme weight scales without changing the weighted estimate', () => {
  const huge = estimateSurveyWeightedMean([record(0, 1e300), record(10, 3e300)], { minimumEffectiveSampleSize: 1 });
  const tiny = estimateSurveyWeightedMean([record(0, 1e-200), record(10, 3e-200)], { minimumEffectiveSampleSize: 1 });
  assert.equal(huge.weighted_mean, 7.5);
  assert.equal(tiny.weighted_mean, 7.5);
  assert.ok(Math.abs(huge.kish_effective_sample_size - 1.6) < 1e-12);
  assert.ok(Math.abs(tiny.kish_effective_sample_size - 1.6) < 1e-12);
});


test('estimates separate weighted response shares and retains design uncertainty', () => {
  const rows = [
    record(1, 1, 'A', 'S1'), record(3, 1, 'B', 'S1'),
    record(5, 1, 'C', 'S2'), record(5, 1, 'D', 'S2'),
  ];
  const estimate = estimateSurveyWeightedDistribution(rows, { minimumEffectiveSampleSize: 1 });
  assert.equal(estimate.variance_status, 'available_taylor_linearization_wr_first_stage');
  assert.deepEqual(estimate.categories.map((item) => item.response_value), [1, 3, 5]);
  assert.deepEqual(estimate.categories.map((item) => item.weighted_share_pct), [25, 25, 50]);
  assert.ok(Math.abs(estimate.categories.reduce((sum, item) => sum + item.weighted_share_pct, 0) - 100) < 1e-8);
  assert.ok(estimate.categories.every((item) => item.confidence_interval_95_pct !== null));
});

test('converts weighted response shares to separate Silver observations with category counts', () => {
  const rows = [
    record(1, 1, 'A', 'S1'), record(3, 1, 'B', 'S1'),
    record(5, 1, 'C', 'S2'), record(5, 1, 'D', 'S2'),
  ];
  const estimate = estimateSurveyWeightedDistribution(rows, { minimumEffectiveSampleSize: 1 });
  const observations = surveyDistributionToObservations(estimate, {
    territory_id: 'BRA', indicator_id: 'WVS_TRUST_DIST', indicator_name: 'Trust response distribution', module_id: 12,
    psychographic_construct_id: 'institutional_trust', psychographic_construct_label: 'Institutional trust',
    psychographic_construct_domain: 'attitudes', canonical_scale_id: 'trust_1_5', canonical_scale_min: 1,
    canonical_scale_max: 5, question_mapping_version: 'v1',
    source_id: 'wvs', dataset_id: 'wvs_wave_7', period_year: 2022, unit: '%', valuation_basis: 'percent',
    methodology_id: 'weighted_distribution_v1', commercial_use_allowed: 'unknown', asserted_at: '2026-11-22T00:00:00.000Z',
    population_scope: 'Adults aged 18+', weighting_method: 'Final calibrated weight',
  });
  assert.equal(observations.length, 3);
  assert.ok(observations.every((item) => item.survey_statistic === 'weighted_share'));
  assert.ok(observations.every((item) => item.response_category_count === 1 || item.response_category_count === 2));
  assert.equal(observations.reduce((sum, item) => sum + item.value_numeric, 0), 100);
});

test('rejects survey response distributions with category-count or interval inconsistencies', () => {
  const rows = [
    record(1, 1, 'A', 'S1'), record(3, 1, 'B', 'S1'),
    record(5, 1, 'C', 'S2'), record(5, 1, 'D', 'S2'),
  ];
  const estimate = estimateSurveyWeightedDistribution(rows, { minimumEffectiveSampleSize: 1 });
  const context = {
    territory_id: 'BRA', indicator_id: 'WVS_TRUST_DIST', indicator_name: 'Trust response distribution', module_id: 12,
    psychographic_construct_id: 'institutional_trust', psychographic_construct_label: 'Institutional trust',
    psychographic_construct_domain: 'attitudes' as const, canonical_scale_id: 'trust_1_5', canonical_scale_min: 1,
    canonical_scale_max: 5, question_mapping_version: 'v1',
    source_id: 'wvs', dataset_id: 'wvs_wave_7', period_year: 2022, unit: '%', valuation_basis: 'percent' as const,
    methodology_id: 'weighted_distribution_v1', commercial_use_allowed: 'unknown' as const, asserted_at: '2026-11-22T00:00:00.000Z',
    population_scope: 'Adults aged 18+', weighting_method: 'Final calibrated weight',
  };
  const badCounts = {
    ...estimate,
    categories: estimate.categories.map((item, index) => index === 0 ? { ...item, unweighted_count: item.unweighted_count + 1 } : item),
  };
  assert.throws(() => surveyDistributionToObservations(badCounts, context), /reconcile exactly/);
  const badInterval = {
    ...estimate,
    categories: estimate.categories.map((item, index) => index === 0 && item.confidence_interval_95_pct
      ? { ...item, confidence_interval_95_pct: { ...item.confidence_interval_95_pct, lower: -1 } }
      : item),
  };
  assert.throws(() => surveyDistributionToObservations(badInterval, context), /invalid categories/);
});
