import test from 'node:test';
import assert from 'node:assert/strict';
import { aggregateContinentalMacroRows } from '../src/lakehouse/territorialAggregation.ts';
import type { MacroEconomicRow } from '../src/lakehouse/types.ts';

function row(overrides: Partial<MacroEconomicRow>): MacroEconomicRow {
  return {
    territory_id: 'T1', iso3: 'AAA', iso2: 'AA', name_en: 'Country A', continent: 'Africa', region: 'Region',
    h3_res2: null, h3_res4: null, latest_year: 2025, gdp_nominal_usd: 100, gdp_nominal_usd_year: 2024,
    gdp_per_capita_ppp_2021: 100, gdp_per_capita_ppp_2021_year: 2024, population_total: 1, population_total_year: 2025,
    urbanization_pct: 50, urbanization_pct_year: 2023, internet_users_pct: 40, internet_users_pct_year: 2025,
    ...overrides,
  } as MacroEconomicRow;
}

test('continent population and nominal GDP are summed; per-capita and population rates are weighted', () => {
  const result = aggregateContinentalMacroRows([
    row({ population_total: 9, gdp_nominal_usd: 900, gdp_per_capita_ppp_2021: 100, urbanization_pct: 40, internet_users_pct: 30 }),
    row({ territory_id: 'T2', iso3: 'BBB', population_total: 1, population_total_year: 2024, gdp_nominal_usd: 100, gdp_nominal_usd_year: 2023, gdp_per_capita_ppp_2021: 1000, gdp_per_capita_ppp_2021_year: 2022, urbanization_pct: 100, urbanization_pct_year: 2024, internet_users_pct: 90, internet_users_pct_year: 2025 }),
  ]);
  assert.equal(result.length, 1);
  assert.equal(result[0].population_total, 10);
  assert.equal(result[0].gdp_nominal_usd, 1000);
  assert.equal(result[0].gdp_per_capita_ppp_2021, 190);
  assert.equal(result[0].urbanization_pct_population_weighted, 46);
  assert.equal(result[0].internet_users_pct_population_weighted, 36);
  assert.equal(result[0].metric_year_ranges.gdp_nominal_usd.year_min, 2023);
  assert.equal(result[0].metric_year_ranges.gdp_nominal_usd.year_max, 2024);
  assert.equal(result[0].metric_year_ranges.gdp_per_capita_ppp_2021.year_min, 2022);
  assert.equal(result[0].metric_year_ranges.gdp_per_capita_ppp_2021.contributing_countries, 2);
  assert.equal(result[0].metric_year_ranges.population_total.year_min, 2024);
  assert.equal(result[0].metric_year_ranges.population_total.year_max, 2025);
  assert.equal(result[0].methodology.non_additive_metrics_excluded.includes('gini_index'), true);
});

test('continental groups do not merge with missing continent labels', () => {
  const result = aggregateContinentalMacroRows([row({ continent: '' })]);
  assert.equal(result[0].continent, 'Unclassified');
});
