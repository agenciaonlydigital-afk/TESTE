import test from 'node:test';
import assert from 'node:assert/strict';
import { fetchGeoBoundariesCatalogBatch } from '../src/lakehouse/spatial/geoBoundariesCatalog.ts';

function makeBody(url: string) {
  const level = url.split('/').at(-2)!;
  const iso3 = url.split('/').at(-3)!;
  return { boundaryID: `${iso3}-${level}`, boundaryISO: iso3, boundaryType: level };
}

test('discovers batch countries in input order with bounded concurrency', async () => {
  let active = 0;
  let maximumActive = 0;
  const fakeFetch = (async (url: string | URL | Request) => {
    active++;
    maximumActive = Math.max(maximumActive, active);
    await new Promise((resolve) => setTimeout(resolve, 1));
    active--;
    return new Response(JSON.stringify(makeBody(String(url))), { status: 200 });
  }) as typeof fetch;
  const result = await fetchGeoBoundariesCatalogBatch(['BRA', 'USA', 'CAN', 'ARG'], { concurrency: 2, fetcher: fakeFetch });
  assert.deepEqual(result.results.map((country) => country.iso3), ['BRA', 'USA', 'CAN', 'ARG']);
  assert.equal(result.successful_countries, 4);
  assert.equal(result.failures.length, 0);
  assert.ok(maximumActive <= 2);
});

test('reports country failures without discarding other country results', async () => {
  const fakeFetch = (async (url: string | URL | Request) => {
    if (String(url).includes('/USA/ADM1/')) return new Response('temporary failure', { status: 503 });
    return new Response(JSON.stringify(makeBody(String(url))), { status: 200 });
  }) as typeof fetch;
  const result = await fetchGeoBoundariesCatalogBatch(['BRA', 'USA', 'ARG'], { concurrency: 2, fetcher: fakeFetch });
  assert.deepEqual(result.results.map((country) => country.iso3), ['BRA', 'ARG']);
  assert.deepEqual(result.failures.map((failure) => failure.iso3), ['USA']);
  assert.match(result.failures[0]!.error, /HTTP 503/);
});

test('rejects duplicate/invalid countries and invalid concurrency; supports cancellation', async () => {
  const fakeFetch = (async () => new Response('{}', { status: 200 })) as typeof fetch;
  await assert.rejects(() => fetchGeoBoundariesCatalogBatch(['BRA', 'BRA'], { fetcher: fakeFetch }), /unique/);
  await assert.rejects(() => fetchGeoBoundariesCatalogBatch(['bra'], { fetcher: fakeFetch }), /uppercase/);
  await assert.rejects(() => fetchGeoBoundariesCatalogBatch(['BRA'], { concurrency: 9, fetcher: fakeFetch }), /concurrency/);
  const controller = new AbortController();
  controller.abort(new Error('cancelled by test'));
  await assert.rejects(() => fetchGeoBoundariesCatalogBatch(['BRA'], { fetcher: fakeFetch, signal: controller.signal }), /cancelled by test/);
});
