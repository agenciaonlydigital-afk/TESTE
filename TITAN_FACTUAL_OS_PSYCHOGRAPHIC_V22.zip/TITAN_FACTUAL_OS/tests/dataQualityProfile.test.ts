import test from 'node:test';
import assert from 'node:assert/strict';
import { buildDataQualityProfile } from '../src/lakehouse/dataQualityProfile.ts';
import type { ObservationContract } from '../src/lakehouse/types.ts';

const row: ObservationContract = {
  territory_id: 'BRA', iso3: 'BRA', indicator_id: 'POP_TOTAL', indicator_name: 'Population', module_id: 1,
  source_id: 'test_source', dataset_id: 'test_dataset', period_year: 2025, value_numeric: 200,
  unit: 'people', valuation_basis: 'count', methodology_id: 'official', commercial_use_allowed: 'unknown',
  asserted_at: '2026-11-22T00:00:00.000Z',
};

test('builds descriptive quality checks without inventing geographic coverage', () => {
  const profile = buildDataQualityProfile({ rawRows: 10, validated: [row], schemaRejections: 1, licenseMismatches: 0, duplicateCollisions: 2, asOfYear: 2026 });
  assert.equal(profile.schema_acceptance_pct, 90);
  assert.equal(profile.territory_count, 1);
  assert.equal(profile.indicator_count, 1);
  assert.equal(profile.duplicate_collision_pct, 20);
  assert.equal(profile.period_year_max, 2025);
  assert.equal(profile.geographic_coverage_status, 'not_scored');
  assert.equal(profile.checks.find((check) => check.check_id === 'schema_acceptance')?.status, 'fail');
  assert.equal(profile.checks.find((check) => check.check_id === 'geographic_coverage')?.status, 'not_scored');
});

test('flags source-license mismatch and stale observation vintage', () => {
  const profile = buildDataQualityProfile({ rawRows: 3, validated: [row], schemaRejections: 0, licenseMismatches: 1, duplicateCollisions: 0, asOfYear: 2032 });
  assert.equal(profile.checks.find((check) => check.check_id === 'license_integrity')?.status, 'fail');
  assert.equal(profile.checks.find((check) => check.check_id === 'period_vintage')?.status, 'warning');
});

test('rejects invalid counts and inconsistent validation totals', () => {
  assert.throws(() => buildDataQualityProfile({ rawRows: -1, validated: [], schemaRejections: 0, licenseMismatches: 0, duplicateCollisions: 0 }));
  assert.throws(() => buildDataQualityProfile({ rawRows: 0, validated: [row], schemaRejections: 0, licenseMismatches: 0, duplicateCollisions: 0 }));
  assert.throws(() => buildDataQualityProfile({ rawRows: 3, validated: [row], schemaRejections: 1, licenseMismatches: 1, duplicateCollisions: 1 }), /validated rows cannot exceed/);
});

test('profiles large snapshots in one pass without argument-spread limits', () => {
  const rows = Array.from({ length: 120_000 }, (_, index) => ({
    ...row,
    territory_id: `T${index % 240}`,
    indicator_id: `I${index % 17}`,
    period_year: 1900 + (index % 127),
    survey_id: index % 2 === 0 ? 'survey-a' : undefined,
  }));
  const profile = buildDataQualityProfile({
    rawRows: rows.length,
    validated: rows,
    schemaRejections: 0,
    licenseMismatches: 0,
    duplicateCollisions: 0,
    asOfYear: 2026,
  });
  assert.equal(profile.validated_rows, 120_000);
  assert.equal(profile.territory_count, 240);
  assert.equal(profile.indicator_count, 17);
  assert.equal(profile.period_year_min, 1900);
  assert.equal(profile.period_year_max, 2026);
  assert.equal(profile.optional_field_completeness_pct.survey_id, 50);
});
