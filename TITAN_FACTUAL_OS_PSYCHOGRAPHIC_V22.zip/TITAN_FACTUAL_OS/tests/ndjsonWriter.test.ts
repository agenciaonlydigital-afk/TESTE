import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { writeNdjsonRecords } from '../src/lakehouse/connectors/ndjsonWriter.ts';

test('NDJSON writer respects stream completion and persists every record in order', async () => {
  const folder = await fs.mkdtemp(path.join(os.tmpdir(), 'titan-ndjson-'));
  const target = path.join(folder, 'rows.ndjson');
  try {
    const rows = Array.from({ length: 15_000 }, (_, i) => ({ value: i, payload: 'x'.repeat(100) }));
    const written = await writeNdjsonRecords(target, rows, (row, index) => ({ ...row, index }));
    const lines = (await fs.readFile(target, 'utf8')).trimEnd().split('\n');
    assert.equal(written, rows.length);
    assert.equal(lines.length, rows.length);
    assert.deepEqual(JSON.parse(lines[0]), { value: 0, payload: 'x'.repeat(100), index: 0 });
    assert.deepEqual(JSON.parse(lines.at(-1)!), { value: 14_999, payload: 'x'.repeat(100), index: 14_999 });
  } finally {
    await fs.rm(folder, { recursive: true, force: true });
  }
});

test('NDJSON writer creates a missing parent directory', async () => {
  const folder = await fs.mkdtemp(path.join(os.tmpdir(), 'titan-ndjson-dir-'));
  const target = path.join(folder, 'nested', 'new', 'rows.ndjson');
  try {
    const count = await writeNdjsonRecords(target, [{ ok: true }]);
    assert.equal(count, 1);
    assert.equal(await fs.readFile(target, 'utf8'), '{"ok":true}\n');
  } finally {
    await fs.rm(folder, { recursive: true, force: true });
  }
});

test('NDJSON writer consumes async iterables incrementally and preserves order', async () => {
  const folder = await fs.mkdtemp(path.join(os.tmpdir(), 'titan-ndjson-async-'));
  const target = path.join(folder, 'rows.ndjson');
  async function* rows() {
    for (let i = 0; i < 2_500; i++) yield { value: i };
  }
  try {
    const count = await writeNdjsonRecords(target, rows(), (row, index) => ({ ...row, index }));
    const lines = (await fs.readFile(target, 'utf8')).trimEnd().split('\n');
    assert.equal(count, 2_500);
    assert.deepEqual(JSON.parse(lines[0]), { value: 0, index: 0 });
    assert.deepEqual(JSON.parse(lines.at(-1)!), { value: 2_499, index: 2_499 });
  } finally {
    await fs.rm(folder, { recursive: true, force: true });
  }
});
