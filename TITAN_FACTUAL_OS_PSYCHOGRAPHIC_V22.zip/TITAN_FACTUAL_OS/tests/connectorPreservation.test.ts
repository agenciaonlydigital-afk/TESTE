import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const fixture = JSON.parse(fs.readFileSync(path.join(root, 'tests/fixtures/original-connector-contract.json'), 'utf8')) as {
  original_connector_ids: string[];
  original_connector_functions: string[];
  original_endpoint_literals: string[];
  original_handler_files_sha256: Array<{ path: string; sha256: string }>;
};
const connectorRoot = path.join(root, 'src/lakehouse/connectors');
function readConnectorFiles(directory: string): Array<{ file: string; text: string }> {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const target = path.join(directory, entry.name);
    if (entry.isDirectory()) return readConnectorFiles(target);
    return entry.isFile() && target.endsWith('.ts')
      ? [{ file: target, text: fs.readFileSync(target, 'utf8') }]
      : [];
  });
}
const files = readConnectorFiles(connectorRoot);
const allText = files.map((file) => file.text).join('\n');
const registryText = fs.readFileSync(path.join(connectorRoot, 'index.ts'), 'utf8');
const currentIds = [...registryText.matchAll(/\['([^']+)',\s*\w+\]/g)].map((match) => match[1]);

test('all original 79 registered connector IDs are preserved in the same order', () => {
  assert.equal(currentIds.length, 79);
  assert.deepEqual(currentIds, fixture.original_connector_ids);
});

test('all original source-specific ingest function names remain available', () => {
  const currentFunctions = new Set([...allText.matchAll(/export\s+(?:async\s+)?function\s+(ingest\w+)/g)].map((match) => match[1]));
  const missing = fixture.original_connector_functions.filter((name) => !currentFunctions.has(name));
  assert.deepEqual(missing, []);
});

test('no original connector endpoint literal was removed', () => {
  const missing = fixture.original_endpoint_literals.filter((literal) => !allText.includes(literal));
  assert.deepEqual(missing, []);
});


test('source-specific connector extraction/parser logic is unchanged from the original ZIP', () => {
  const filesWithHashes = fixture.original_handler_files_sha256;
  assert.equal(filesWithHashes.length, 6);
  for (const entry of filesWithHashes) {
    const currentPath = path.join(connectorRoot, entry.path);
    let normalized = fs.readFileSync(currentPath, 'utf8');
    // The only handler edits permitted here are explicit HTTP-304 outcome metadata.
    normalized = normalized.replace(/, notModified: [^\n]+(?= \};)/g, '');
    // India connector stores the second request status solely to prove an all-304 result.
    normalized = normalized.replace("  let ogdResStatus: string | null = null;\n", '');
    normalized = normalized.replace("      ogdResStatus = ogdRes.status;\n", '');
    const digest = crypto.createHash('sha256').update(normalized).digest('hex');
    assert.equal(digest, entry.sha256, `${entry.path} changed beyond 304 metadata`);
  }
});
