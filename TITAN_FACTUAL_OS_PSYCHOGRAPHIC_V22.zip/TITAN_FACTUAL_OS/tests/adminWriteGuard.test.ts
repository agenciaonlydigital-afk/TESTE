import assert from 'node:assert/strict';
import test from 'node:test';
import { validateAdminWriteRequest } from '../src/server/middleware/adminWriteGuard.ts';

const config = { token: 'a-very-long-test-admin-token-for-titan', production: true };
const base = {
  authorization: `Bearer ${config.token}`,
  origin: 'https://titan.example.test',
  host: 'titan.example.test',
  fetchSite: 'same-origin',
};

test('valid same-origin administrator token can perform state-changing requests', () => {
  assert.deepEqual(validateAdminWriteRequest(config, base), { allowed: true });
});

test('missing and incorrect tokens fail closed', () => {
  assert.equal(validateAdminWriteRequest(config, { ...base, authorization: undefined }).status, 401);
  assert.equal(validateAdminWriteRequest(config, { ...base, authorization: 'Bearer wrong' }).status, 401);
});

test('cross-origin fetch metadata and mismatched origins are rejected', () => {
  assert.equal(validateAdminWriteRequest(config, { ...base, fetchSite: 'cross-site' }).status, 403);
  assert.equal(validateAdminWriteRequest(config, { ...base, origin: 'https://attacker.example.test' }).status, 403);
  assert.equal(validateAdminWriteRequest(config, { ...base, origin: 'not a url' }).status, 403);
});

test('production without an admin token fails closed while development can remain local', () => {
  assert.equal(validateAdminWriteRequest({ token: undefined, production: true }, base).status, 503);
  assert.deepEqual(validateAdminWriteRequest({ token: undefined, production: false }, base), { allowed: true });
});

test('production startup rejects missing or short secrets and accepts a high-entropy-length secret', async () => {
  const { assertProductionAdminToken } = await import('../src/server/middleware/adminWriteGuard.ts');
  const previous = process.env.NODE_ENV;
  process.env.NODE_ENV = 'production';
  try {
    assert.throws(() => assertProductionAdminToken('short'), /at least 32 characters/);
    assert.throws(() => assertProductionAdminToken(''), /at least 32 characters/);
    assert.doesNotThrow(() => assertProductionAdminToken('x'.repeat(48)));
  } finally {
    if (previous === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = previous;
  }
});
