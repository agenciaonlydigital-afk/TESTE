import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import type { MacroEconomicRow } from '../src/lakehouse/types.ts';
import { buildPsychographicProfile } from '../src/lakehouse/psychographicProfiles.ts';

function row(overrides: Partial<MacroEconomicRow> & { median_age?: number | null; median_age_year?: number | null } = {}): MacroEconomicRow & { median_age: number | null; median_age_year: number | null } {
  return {
    territory_id: 'BRA', iso3: 'BRA', iso2: 'BR', name_en: 'Brazil', continent: 'South America',
    region: 'Latin America', h3_res2: null, h3_res4: null, latest_year: 2025, median_age: 34, median_age_year: 2024,
    gdp_nominal_usd: null, gdp_nominal_usd_year: null, gdp_per_capita_ppp_2021: 18000,
    gdp_per_capita_ppp_2021_year: 2023, imf_real_gdp_growth_pct: null, inflation_cpi_pct: 4.5, inflation_cpi_pct_year: 2025,
    gov_debt_pct_gdp: null, unemployment_pct: 7.5, unemployment_pct_year: 2024, gini_index: 52, gini_index_year: 2023, population_total: 200000000,
    population_total_year: 2025, urbanization_pct: 87, urbanization_pct_year: 2024,
    internet_users_pct: 84, internet_users_pct_year: 2024, life_expectancy_years: 75, life_expectancy_years_year: 2023,
    household_consumption_pct_gdp: null, gni_per_capita_usd: null, fdi_net_inflows_pct_gdp: null,
    trade_openness_pct_gdp: null, ilostat_lfpr_pct: null, imf_policy_rate_pct: null, imf_reer_index: null,
    oecd_cli_index: null, wits_exports_usd: null, wits_imports_usd: null, ember_clean_share_pct: null,
    ember_carbon_intensity: null, uis_gerd_pct_gdp: null, unicef_u5_mortality: null,
    unsdg_renewable_pct: null, unsdg_forest_pct: null, gbif_occurrences: null, wikidata_area_km2: null,
    abs_cpi_pct_yoy: null, eurostat3_hicp_pct: null, statcan_unemp_pct: null, ukons_cpih_yoy_pct: null,
    unsd_elec_prod_gwh: null, nasa_solar_kwh: null, obis_marine_species: null, geonames_pop: null,
    datacite_dataset_dois: null, eurostat_gov_debt_pct: null, unwpp_tfr: 1.7, unwpp_tfr_year: 2022, worldpop_datasets: null,
    nasa_cmr_collections: null, ne_adm1_divisions: null, openalex_works_2024: null, ukgov_open_datasets: null,
    overture_themes: null, faostat_kcal_day: null, uis_edu_exp_pct_gdp: null, worldpop_age_datasets: null,
    worldpop_density_datasets: null, eurostat_catalog_datasets: null, arcgis_open_datasets: null,
    stac_public_catalogs: null, listenbrainz_top100_listens: null, ecb_fx_per_eur: null, vdem_democracy_ix: null,
    unlocode_nodes: null, unhabitat_urban_datasets: null, ckan_portal_datasets: null, socrata_civic_datasets: null,
    osm_importance_score: null, musicbrainz_artists: null, uncomtrade_exports_usd: null, itu_mobile_per_100: 100, itu_mobile_per_100_year: 2024,
    gadm_adm1_features: null, wipo_patents_per_million: null, unodc_homicide_rate: null, wid_top10_share_pct: null,
    ghsl_pop_density_km2: null, pwt_real_gdp_cap: null, eurostat_gdp_meur: null, bis_total_credit_pct_gdp: null,
    ibge_ipca_pct: null, unhcr_refugees: null, usgs_seismic_events: null, gb_adm0_coverage: null,
    crossref_works_count: null, unctad_lsci: null, statfin_cpi_pct: null, undata_elec_access_pct: null,
    undrr_mortality_per_100k: null, usgov_datasets_total: null, pip_mean_daily_ppp: null, ct_ghg_co2e: null,
    wikimedia_enwiki_views: null, us_census_pop: null, undp_hdi: 0.76, undp_hdi_year: 2023, noaa_tavg_c: null, gfw_tree_loss_ha: null,
    eia_energy_prod_qbtu: null, india_iip_index: null, icao_scheduled_airports: null, wdpa_protected_pct: null,
    ...overrides,
  };
}

function signal(profile: ReturnType<typeof buildPsychographicProfile>, id: string) {
  const result = profile.signals.find((item) => item.signal_id === id);
  assert.ok(result, `missing signal ${id}`);
  return result;
}

test('builds six bounded market-context signals and explicitly marks proxy-only evidence', () => {
  const profile = buildPsychographicProfile(row());
  assert.equal(profile.signals.length, 6);
  assert.equal(profile.model_version, '2.2.0');
  assert.equal(profile.data_fields_available, 9);
  assert.equal(profile.temporal_status, 'aligned');
  assert.equal(profile.oldest_evidence_year, 2022);
  assert.equal(profile.newest_evidence_year, 2025);
  assert.equal(profile.evidence_type, 'aggregated_demographic_proxy');
  assert.equal(profile.validation_status, 'survey_validation_required');
  assert.equal(profile.survey_evidence_count, 0);
  assert.deepEqual(profile.measured_survey_measures, []);
  assert.equal(profile.population_share_estimated, false);
  for (const item of profile.signals) {
    assert.ok(item.score === null || (item.score >= 0 && item.score <= 100));
  }
});

test('higher internet, mobile subscriptions and urbanization raise digital access context', () => {
  const low = buildPsychographicProfile(row({ internet_users_pct: 30, itu_mobile_per_100: 35, urbanization_pct: 35 }));
  const high = buildPsychographicProfile(row({ internet_users_pct: 95, itu_mobile_per_100: 150, urbanization_pct: 95 }));
  assert.ok((signal(high, 'digital_discovery').score ?? -1) > (signal(low, 'digital_discovery').score ?? -1));
});

test('missing indicators are not imputed and reduce input coverage', () => {
  const profile = buildPsychographicProfile(row({
    median_age: null, gdp_per_capita_ppp_2021: null, gini_index: null,
    urbanization_pct: null, internet_users_pct: null, inflation_cpi_pct: null, unemployment_pct: null,
    itu_mobile_per_100: null, undp_hdi: null, unwpp_tfr: null,
  }));
  assert.equal(profile.data_fields_available, 0);
  assert.equal(profile.data_coverage_pct, 0);
  assert.equal(profile.temporal_status, 'unknown');
  assert.ok(profile.signals.every((item) => item.score === null && item.evidence.length === 0));
});

test('single-input coverage is shown but does not produce a composite signal score', () => {
  const profile = buildPsychographicProfile(row({
    median_age: null, gdp_per_capita_ppp_2021: null, gini_index: null,
    urbanization_pct: null, internet_users_pct: 80, inflation_cpi_pct: null, unemployment_pct: null,
    itu_mobile_per_100: null, undp_hdi: null, unwpp_tfr: null,
  }));
  const digital = signal(profile, 'digital_discovery');
  assert.equal(digital.score, null);
  assert.equal(digital.evidence_fields_available, 1);
  assert.equal(digital.evidence_fields_expected, 3);
  assert.deepEqual(digital.evidence.map((item) => item.metric), ['internet_users_pct']);
  assert.equal(digital.evidence[0].period_year, 2024);
});

test('two available metrics produce a transparent partial score with explicit 67% evidence coverage', () => {
  const profile = buildPsychographicProfile(row({
    median_age: null, gdp_per_capita_ppp_2021: null, gini_index: null,
    urbanization_pct: 60, internet_users_pct: 80, inflation_cpi_pct: null, unemployment_pct: null,
    itu_mobile_per_100: null, undp_hdi: null, unwpp_tfr: null,
  }));
  const digital = signal(profile, 'digital_discovery');
  assert.ok(digital.score !== null);
  assert.equal(digital.evidence_fields_available, 2);
  assert.equal(digital.evidence_fields_expected, 3);
  assert.equal(digital.data_coverage_pct, 66.7);
});

test('flags mixed, stale and missing observation years rather than hiding temporal quality', () => {
  const mixed = buildPsychographicProfile(row({ undp_hdi_year: 2018 }));
  assert.equal(mixed.temporal_status, 'mixed_periods');
  assert.equal(signal(mixed, 'human_development_context').score, null);
  assert.equal(signal(mixed, 'human_development_context').temporal_status, 'stale');

  const stale = buildPsychographicProfile(row({
    median_age_year: 2010, gdp_per_capita_ppp_2021_year: 2010, gini_index_year: 2010,
    urbanization_pct_year: 2010, internet_users_pct_year: 2010, inflation_cpi_pct_year: 2010,
    unemployment_pct_year: 2010, itu_mobile_per_100_year: 2010, undp_hdi_year: 2010, unwpp_tfr_year: 2010,
  }));
  assert.equal(stale.temporal_status, 'stale');
  assert.ok(stale.signals.every((item) => item.score === null));

  const incomplete = buildPsychographicProfile(row({ internet_users_pct_year: null }));
  assert.equal(incomplete.temporal_status, 'incomplete');
  assert.ok(incomplete.temporal_coverage_pct < 100);
  assert.equal(signal(incomplete, 'digital_discovery').score, null);
});

test('withholds a signal whose own evidence years are too far apart', () => {
  const profile = buildPsychographicProfile(row({
    internet_users_pct_year: 2019,
    itu_mobile_per_100_year: 2024,
    urbanization_pct_year: 2024,
  }));
  const digital = signal(profile, 'digital_discovery');
  assert.equal(digital.temporal_status, 'mixed_periods');
  assert.equal(digital.score, null);
});

test('rejects values outside source-specific plausibility ranges', () => {
  const profile = buildPsychographicProfile(row({
    internet_users_pct: 180,
    gdp_per_capita_ppp_2021: 0,
    undp_hdi: 4,
  }));
  assert.ok(profile.invalid_fields.includes('internet_users_pct'));
  assert.ok(profile.invalid_fields.includes('undp_hdi'));
  assert.ok(profile.invalid_fields.includes('gdp_per_capita_ppp_2021'));
  assert.equal(signal(profile, 'digital_discovery').evidence.some((item) => item.metric === 'internet_users_pct'), false);
  assert.equal(signal(profile, 'human_development_context').score, null);
  assert.equal(profile.temporal_status, 'incomplete');
});

test('commercial data gate is represented accurately in API type and UI', () => {
  const types = readFileSync(new URL('../src/types/lakehouse.ts', import.meta.url), 'utf8');
  const ui = readFileSync(new URL('../src/components/BrandMarketView.tsx', import.meta.url), 'utf8');
  assert.match(types, /license_clearance: 'confirmed' \| 'unknown'/);
  assert.match(ui, /p\.license_clearance === 'confirmed'/);
  assert.match(ui, /Unknown/);
  assert.match(ui, /Macro proxies are not measured psychographics/i);
  assert.match(ui, /question-level evidence/i);
  assert.match(ui, /period_year === null/);
  assert.match(ui, /temporal coverage/);
  assert.doesNotMatch(ui, /<span>Cleared<\/span>/);
});



test('Gini inequality is descriptive only and cannot change consumer price/value/pressure scores', () => {
  const lower = buildPsychographicProfile(row({ gini_index: 20, gini_index_year: 2024 }));
  const higher = buildPsychographicProfile(row({ gini_index: 80, gini_index_year: 2024 }));
  for (const id of ['value_sensitivity', 'economic_pressure']) {
    assert.equal(signal(lower, id).score, signal(higher, id).score);
    assert.equal(signal(lower, id).evidence.some((item) => item.metric === 'gini_index'), false);
  }
  assert.equal(lower.data_fields_available, 9);
  assert.ok(lower.limitations.some((item) => /Gini permanece.*descritivo/i.test(item)));
});

test('classifies an entirely invalid observed profile as incomplete rather than unknown', () => {
  const profile = buildPsychographicProfile(row({
    median_age: 90, gdp_per_capita_ppp_2021: 2_000_000,
    urbanization_pct: 120, internet_users_pct: 150, inflation_cpi_pct: 2_000,
    unemployment_pct: 101, itu_mobile_per_100: 600, undp_hdi: 1.5, unwpp_tfr: 20,
  }));
  assert.equal(profile.data_fields_available, 0);
  assert.equal(profile.invalid_fields.length, 9);
  assert.equal(profile.temporal_status, 'incomplete');
  assert.ok(profile.signals.every((item) => item.score === null));
});


test('attaches question-level weighted survey evidence without creating a synthetic persona', () => {
  const base = {
    territory_id: 'BRA', iso3: 'BRA', survey_id: 'WVS', wave_id: 'W7', question_id: 'Q_TRUST',
    construct_id: 'institutional_trust', construct_label: 'Confiança institucional', construct_domain: 'attitudes' as const,
    canonical_scale_id: 'trust_1_5', canonical_scale_min: 1, canonical_scale_max: 5, mapping_version: 'map-v3',
    period_year: 2024, sample_size: 100, effective_sample_size: 82.5, minimum_effective_sample_size: 30,
    variance_status: 'available_taylor_linearization_wr_first_stage' as const,
    population_scope: 'Adult residents aged 18+', weighting_method: 'Final calibrated survey weight',
    fieldwork_start: '2024-03-01', fieldwork_end: '2024-06-30', source_id: 'wvs', dataset_id: 'wvs-wave-7',
    methodology_id: 'taylor_wr_v1', commercial_use_allowed: 'unknown' as const,
    asserted_at: '2026-11-22T00:00:00.000Z',
  };
  const observations = [
    { ...base, statistic: 'weighted_mean' as const, response_category: null, response_category_count: null, value_numeric: 3.4, standard_error: 0.2, confidence_interval_lower: 3.0, confidence_interval_upper: 3.8 },
    { ...base, statistic: 'weighted_share' as const, response_category: '1', response_category_count: 10, value_numeric: 10, standard_error: 2, confidence_interval_lower: 6, confidence_interval_upper: 14 },
    { ...base, statistic: 'weighted_share' as const, response_category: '3', response_category_count: 60, value_numeric: 60, standard_error: 4, confidence_interval_lower: 52, confidence_interval_upper: 68 },
    { ...base, statistic: 'weighted_share' as const, response_category: '5', response_category_count: 30, value_numeric: 30, standard_error: 4, confidence_interval_lower: 22, confidence_interval_upper: 38 },
  ];
  const profile = buildPsychographicProfile(row(), observations);
  assert.equal(profile.survey_evidence_count, 1);
  assert.equal(profile.measured_survey_measures[0]?.score_0_100, 60);
  assert.deepEqual(profile.measured_survey_measures[0]?.response_distribution.map((item) => item.weighted_share_pct), [10, 60, 30]);
  assert.deepEqual(profile.measured_survey_measures[0]?.response_distribution.map((item) => item.unweighted_count), [10, 60, 30]);
  assert.ok(profile.measured_survey_measures[0]?.quality_flags.includes('license_unknown'));
  assert.equal(profile.population_share_estimated, false);
  assert.equal(profile.validation_status, 'survey_validation_required');
});

test('does not combine incomplete, incompatible or duplicate survey aggregates', () => {
  const base = {
    territory_id: 'BRA', iso3: 'BRA', survey_id: 'WVS', wave_id: 'W7', question_id: 'Q_TRUST',
    construct_id: 'institutional_trust', construct_label: 'Trust', construct_domain: 'attitudes' as const,
    canonical_scale_id: 'trust_1_5', canonical_scale_min: 1, canonical_scale_max: 5, mapping_version: 'map-v3',
    period_year: 2024, sample_size: 100, effective_sample_size: 90, minimum_effective_sample_size: 30,
    variance_status: 'unavailable_design_metadata' as const, standard_error: null, confidence_interval_lower: null, confidence_interval_upper: null,
    population_scope: 'Adult residents', weighting_method: 'Final weight', fieldwork_start: null, fieldwork_end: null,
    source_id: 'wvs', dataset_id: 'wave-7', methodology_id: 'm1', commercial_use_allowed: 'confirmed' as const,
    asserted_at: '2026-11-22T00:00:00.000Z',
  };
  const mean = { ...base, statistic: 'weighted_mean' as const, response_category: null, response_category_count: null, value_numeric: 3 };
  const duplicateMean = { ...mean };
  const invalidShare = { ...base, statistic: 'weighted_share' as const, response_category: '9', response_category_count: 20, value_numeric: 100 };
  const profile = buildPsychographicProfile(row(), [mean, duplicateMean, invalidShare]);
  assert.equal(profile.survey_evidence_count, 0);
  assert.deepEqual(profile.measured_survey_measures, []);
});
