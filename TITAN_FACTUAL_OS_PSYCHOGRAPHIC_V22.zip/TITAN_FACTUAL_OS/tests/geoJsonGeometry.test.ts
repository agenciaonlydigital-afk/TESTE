import test from 'node:test';
import assert from 'node:assert/strict';
import { pointInGeoJsonArea, validateAreaGeometry } from '../src/lakehouse/spatial/geoJsonGeometry.ts';

const square = { type: 'Polygon', coordinates: [[[-10, -10], [10, -10], [10, 10], [-10, 10], [-10, -10]]] } as const;

test('locates points inside, outside and on polygon boundaries', () => {
  assert.equal(pointInGeoJsonArea([0, 0], square), true);
  assert.equal(pointInGeoJsonArea([30, 0], square), false);
  assert.equal(pointInGeoJsonArea([10, 0], square), true);
});

test('respects holes in polygons and supports multipolygons', () => {
  const withHole = { type: 'Polygon', coordinates: [
    [[-10, -10], [10, -10], [10, 10], [-10, 10], [-10, -10]],
    [[-2, -2], [2, -2], [2, 2], [-2, 2], [-2, -2]],
  ] };
  assert.equal(pointInGeoJsonArea([5, 5], withHole), true);
  assert.equal(pointInGeoJsonArea([0, 0], withHole), false);
  const multi = { type: 'MultiPolygon', coordinates: [square.coordinates, [[[20, 20], [30, 20], [30, 30], [20, 30], [20, 20]]]] };
  assert.equal(pointInGeoJsonArea([25, 25], multi), true);
});

test('rejects unclosed, out-of-range and antimeridian-crossing rings', () => {
  assert.throws(() => validateAreaGeometry({ type: 'Polygon', coordinates: [[[0, 0], [1, 0], [1, 1], [0, 1]]] }));
  assert.throws(() => pointInGeoJsonArea([181, 0], square));
  assert.throws(() => validateAreaGeometry({ type: 'Polygon', coordinates: [[[170, 0], [-170, 0], [-170, 1], [170, 1], [170, 0]]] }));
});


test('rejects degenerate rings with no enclosed area', () => {
  assert.throws(() => validateAreaGeometry({ type: 'Polygon', coordinates: [[[1, 1], [2, 2], [3, 3], [1, 1]]] }), /non-zero area/);
});
