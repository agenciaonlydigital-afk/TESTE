import test from 'node:test';
import assert from 'node:assert/strict';
import { allocateThroughBoundaryCrosswalk, validateBoundaryCrosswalk, type BoundaryCrosswalkRow } from '../src/lakehouse/spatial/boundaryCrosswalk.ts';

const mappings: BoundaryCrosswalkRow[] = [
  { source_boundary_id: 'OLD_1', target_boundary_id: 'NEW_A', source_boundary_version: '2010', target_boundary_version: '2020', allocation_weight: 0.25, allocation_basis: 'population', valid_from_year: 2010, valid_to_year: 2020 },
  { source_boundary_id: 'OLD_1', target_boundary_id: 'NEW_B', source_boundary_version: '2010', target_boundary_version: '2020', allocation_weight: 0.75, allocation_basis: 'population', valid_from_year: 2010, valid_to_year: 2020 },
];

test('validates per-source weights, versions and unique pairs', () => {
  assert.equal(validateBoundaryCrosswalk(mappings).length, 2);
  assert.throws(() => validateBoundaryCrosswalk([{ ...mappings[0]!, allocation_weight: 0.4 }, mappings[1]!]), /sum to/);
  assert.throws(() => validateBoundaryCrosswalk([mappings[0]!, mappings[0]!]), /Overlapping validity intervals/);
});

test('allocates additive totals using supplied versioned weights', () => {
  const result = allocateThroughBoundaryCrosswalk(mappings, [{ source_boundary_id: 'OLD_1', source_boundary_version: '2010', period_year: 2015, value: 100, value_kind: 'additive' }]);
  assert.deepEqual(result.map((row) => row.value), [25, 75]);
  assert.ok(result.every((row) => row.target_boundary_version === '2020'));
});

test('allocates rates by numerator and denominator, never by a simple mean', () => {
  const result = allocateThroughBoundaryCrosswalk(mappings, [
    { source_boundary_id: 'OLD_1', source_boundary_version: '2010', period_year: 2015, value: 0.2, source_denominator: 100, value_kind: 'rate' },
  ]);
  assert.deepEqual(result.map((row) => row.value), [0.2, 0.2]);
  assert.deepEqual(result.map((row) => row.allocated_denominator), [25, 75]);
});

test('requires a denominator for rates and a matching boundary version', () => {
  assert.throws(() => allocateThroughBoundaryCrosswalk(mappings, [
    { source_boundary_id: 'OLD_1', source_boundary_version: '2010', period_year: 2015, value: 0.2, source_denominator: 0, value_kind: 'rate' },
  ]), /positive source_denominator/);
  assert.throws(() => allocateThroughBoundaryCrosswalk(mappings, [
    { source_boundary_id: 'OLD_1', source_boundary_version: '2000', period_year: 2015, value: 4, value_kind: 'additive' },
  ]), /No crosswalk mapping/);
  assert.throws(() => allocateThroughBoundaryCrosswalk(mappings, [
    { source_boundary_id: 'OLD_1', source_boundary_version: '2010', period_year: 2025, value: 4, value_kind: 'additive' },
  ]), /not valid for period/);
});


test('omits zero-share targets and rejects crosswalks mixing target boundary versions', () => {
  const withZeroShare: BoundaryCrosswalkRow[] = [
    { ...mappings[0]!, allocation_weight: 0 },
    { ...mappings[1]!, allocation_weight: 1 },
  ];
  const allocated = allocateThroughBoundaryCrosswalk(withZeroShare, [
    { source_boundary_id: 'OLD_1', source_boundary_version: '2010', period_year: 2015, value: 100, value_kind: 'additive' },
  ]);
  assert.deepEqual(allocated.map((row) => row.target_boundary_id), ['NEW_B']);
  assert.throws(() => validateBoundaryCrosswalk([
    mappings[0]!, { ...mappings[1]!, target_boundary_version: '2030' },
  ]), /multiple target boundary versions/);
});



test('supports successive non-overlapping allocation maps for different historical periods', () => {
  const temporal: BoundaryCrosswalkRow[] = [
    { source_boundary_id: 'OLD_1', target_boundary_id: 'NEW_A', source_boundary_version: '2010', target_boundary_version: '2020', allocation_weight: 0.4, allocation_basis: 'population', valid_from_year: 2000, valid_to_year: 2010 },
    { source_boundary_id: 'OLD_1', target_boundary_id: 'NEW_B', source_boundary_version: '2010', target_boundary_version: '2020', allocation_weight: 0.6, allocation_basis: 'population', valid_from_year: 2000, valid_to_year: 2010 },
    { source_boundary_id: 'OLD_1', target_boundary_id: 'NEW_A', source_boundary_version: '2010', target_boundary_version: '2020', allocation_weight: 0.25, allocation_basis: 'population', valid_from_year: 2011, valid_to_year: 2020 },
    { source_boundary_id: 'OLD_1', target_boundary_id: 'NEW_C', source_boundary_version: '2010', target_boundary_version: '2020', allocation_weight: 0.75, allocation_basis: 'population', valid_from_year: 2011, valid_to_year: 2020 },
  ];
  assert.equal(validateBoundaryCrosswalk(temporal).length, 4);
  const earlier = allocateThroughBoundaryCrosswalk(temporal, [{ source_boundary_id: 'OLD_1', source_boundary_version: '2010', period_year: 2005, value: 100, value_kind: 'additive' }]);
  const later = allocateThroughBoundaryCrosswalk(temporal, [{ source_boundary_id: 'OLD_1', source_boundary_version: '2010', period_year: 2015, value: 100, value_kind: 'additive' }]);
  assert.deepEqual(earlier.map((row) => [row.target_boundary_id, row.value]), [['NEW_A', 40], ['NEW_B', 60]]);
  assert.deepEqual(later.map((row) => [row.target_boundary_id, row.value]), [['NEW_A', 25], ['NEW_C', 75]]);
});

test('rejects overlapping repeated target mappings and incomplete temporal weight sets', () => {
  const duplicateOverlap: BoundaryCrosswalkRow[] = [
    { ...mappings[0]!, target_boundary_id: 'NEW_A', allocation_weight: 0.5 },
    { ...mappings[0]!, target_boundary_id: 'NEW_A', allocation_weight: 0.5 },
  ];
  assert.throws(() => validateBoundaryCrosswalk(duplicateOverlap), /Overlapping validity intervals/);
  const gap: BoundaryCrosswalkRow[] = [
    { ...mappings[0]!, allocation_weight: 1, valid_from_year: 2000, valid_to_year: 2010 },
    { ...mappings[1]!, allocation_weight: 0.5, valid_from_year: 2011, valid_to_year: 2020 },
  ];
  assert.throws(() => validateBoundaryCrosswalk(gap), /sum to 0.5 in 2011/);
  assert.throws(() => allocateThroughBoundaryCrosswalk([mappings[0]!, mappings[1]!], [
    { source_boundary_id: 'OLD_1', source_boundary_version: '2010', period_year: 2025, value: 1, value_kind: 'other' as 'additive' },
  ]), /value_kind/);
});


test('keeps different observation years separate instead of summing across time', () => {
  const result = allocateThroughBoundaryCrosswalk(mappings, [
    { source_boundary_id: 'OLD_1', source_boundary_version: '2010', period_year: 2015, value: 100, value_kind: 'additive' },
    { source_boundary_id: 'OLD_1', source_boundary_version: '2010', period_year: 2016, value: 200, value_kind: 'additive' },
  ]);
  assert.equal(result.length, 4);
  assert.deepEqual(result.map((row) => [row.period_year, row.target_boundary_id, row.value]), [
    [2015, 'NEW_A', 25], [2015, 'NEW_B', 75], [2016, 'NEW_A', 50], [2016, 'NEW_B', 150],
  ]);
});

test('rejects non-finite accumulation instead of returning infinite allocated values', () => {
  const twoSources: BoundaryCrosswalkRow[] = [
    { ...mappings[0]!, source_boundary_id: 'OLD_1', target_boundary_id: 'NEW_A', allocation_weight: 1 },
    { ...mappings[0]!, source_boundary_id: 'OLD_2', target_boundary_id: 'NEW_A', allocation_weight: 1 },
  ];
  assert.throws(() => allocateThroughBoundaryCrosswalk(twoSources, [
    { source_boundary_id: 'OLD_1', source_boundary_version: '2010', period_year: 2015, value: 1e308, value_kind: 'additive' },
    { source_boundary_id: 'OLD_2', source_boundary_version: '2010', period_year: 2015, value: 1e308, value_kind: 'additive' },
  ]), /overflowed/);
});
