import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const querySource = fs.readFileSync(path.join(root, 'src/lakehouse/queries.ts'), 'utf8');
const routesSource = fs.readFileSync(path.join(root, 'src/server/routes/controlPlaneRoutes.ts'), 'utf8');
const catalogUiSource = fs.readFileSync(path.join(root, 'src/components/SourceCatalogView.tsx'), 'utf8');
const brandUiSource = fs.readFileSync(path.join(root, 'src/components/BrandMarketView.tsx'), 'utf8');
const materializerSource = fs.readFileSync(path.join(root, 'src/lakehouse/goldMaterializer.ts'), 'utf8');
const lakehouseTypes = fs.readFileSync(path.join(root, 'src/lakehouse/types.ts'), 'utf8');

test('development Gold dashboards include observations regardless of commercial clearance', () => {
  assert.match(querySource, /WHERE period_year >= 1900[\s\S]*?period_year <= \$\{CURRENT_YEAR\}/);
  assert.match(querySource, /ORDER BY period_year DESC, asserted_at DESC, source_id ASC, dataset_id ASC/);
  assert.match(querySource, /WHERE indicator_id = 'OWID\.MEDIAN_AGE'[\s\S]*?period_year >= 1900[\s\S]*?value_numeric IS NOT NULL/);
  assert.match(querySource, /WHERE iso3 = \$1 AND period_year <= \$\{CURRENT_YEAR\}/);
  assert.doesNotMatch(querySource, /commercial_use_allowed\s*=\s*'confirmed'/);
  assert.doesNotMatch(querySource, /commercial_use_allowed\s*!=\s*'confirmed'/);
});

test('brand-market profile never treats data presence as commercial license clearance', () => {
  assert.match(querySource, /license_clearance: 'unknown'/);
  assert.doesNotMatch(querySource, /license_clearance: m\.latest_year/);
});

test('H3 rate and per-capita measures use population weights rather than simple averages', () => {
  assert.match(querySource, /SUM\(ppp \* pop\) \/ NULLIF\(SUM\(CASE WHEN ppp IS NOT NULL THEN pop END\), 0\)/);
  assert.match(querySource, /SUM\(urban \* pop\) \/ NULLIF\(SUM\(CASE WHEN urban IS NOT NULL THEN pop END\), 0\)/);
  assert.doesNotMatch(querySource, /AVG\(ppp\)|AVG\(urban\)/);
});

test('Gold pivot publishes the actual observation year for each continental aggregation metric', async () => {
  const {
    buildGoldPivotSelectSql,
    mapDuckRowToGoldMetricYears,
    mapEmptyGoldMetricYears,
  } = await import('../src/lakehouse/indicatorRegistry.ts');
  const sql = buildGoldPivotSelectSql();
  assert.match(sql, /AS gdp_nominal_usd_year/);
  assert.match(sql, /AS gdp_per_capita_ppp_2021_year/);
  assert.match(sql, /AS population_total_year/);
  assert.match(sql, /AS urbanization_pct_year/);
  assert.match(sql, /AS internet_users_pct_year/);
  assert.match(sql, /FIRST\(value_numeric ORDER BY period_year DESC NULLS LAST, asserted_at DESC NULLS LAST, CASE indicator_id/);
  assert.match(sql, /FILTER \(WHERE indicator_id IN \('FP\.CPI\.TOTL\.ZG', 'IMF\.PCPIPCH'\)\) AS inflation_cpi_pct/);
  const mapped = mapDuckRowToGoldMetricYears({
    gdp_nominal_usd_year: '2024',
    gdp_per_capita_ppp_2021_year: 2023,
    population_total_year: null,
    urbanization_pct_year: 'invalid',
    internet_users_pct_year: 2022,
    inflation_cpi_pct_year: null,
    unemployment_pct_year: null,
    gini_index_year: null,
    life_expectancy_years_year: null,
    unwpp_tfr_year: null,
    itu_mobile_per_100_year: null,
    undp_hdi_year: null,
  });
  assert.deepEqual(mapped, {
    gdp_nominal_usd_year: 2024,
    gdp_per_capita_ppp_2021_year: 2023,
    population_total_year: null,
    urbanization_pct_year: null,
    internet_users_pct_year: 2022,
    inflation_cpi_pct_year: null,
    unemployment_pct_year: null,
    gini_index_year: null,
    life_expectancy_years_year: null,
    unwpp_tfr_year: null,
    itu_mobile_per_100_year: null,
    undp_hdi_year: null,
  });
  assert.deepEqual(mapEmptyGoldMetricYears(), {
    gdp_nominal_usd_year: null,
    gdp_per_capita_ppp_2021_year: null,
    population_total_year: null,
    urbanization_pct_year: null,
    internet_users_pct_year: null,
    inflation_cpi_pct_year: null,
    unemployment_pct_year: null,
    gini_index_year: null,
    life_expectancy_years_year: null,
    unwpp_tfr_year: null,
    itu_mobile_per_100_year: null,
    undp_hdi_year: null,
  });
});

test('source Silver preview includes all stored rows and is explicitly marked as development-only', () => {
  assert.match(querySource, /DEVELOPMENT DASHBOARD MODE: show Silver observations for every catalogued/);
  assert.match(querySource, /gold:source_preview:\$\{cleanId\}/);
  assert.match(querySource, /COUNT\(\*\)::INTEGER AS total_rows/);
  assert.match(querySource, /accessStatus: 'development_preview_all_sources'/);
  assert.doesNotMatch(querySource, /restricted_license|commercially_eligible|eligible_rows/);
  assert.match(querySource, /AND value_numeric IS NOT NULL/);
  assert.doesNotMatch(querySource, /const eligibility|WHERE \$\{eligibility\}/);
});

test('commercial-only catalog filtering is opt-in and does not hide dashboard data by default', () => {
  assert.match(routesSource, /req\.query\.commercial_only === 'true'/);
  assert.match(routesSource, /if \(commercialOnly\)/);
  assert.match(catalogUiSource, /useState\(false\)/);
  assert.match(catalogUiSource, /if \(commercialOnly && s\.commercial_use_allowed !== 'confirmed'\)/);
  assert.match(catalogUiSource, /Development dashboard preview: includes stored observations regardless of commercial-license status/);
  assert.match(catalogUiSource, /Show only catalog entries marked commercial-use confirmed/);
  assert.doesNotMatch(catalogUiSource, /License & Commercial Gate/);
});


test('Brand Market preserves observation years through profile, Gold materialization and dashboard display', () => {
  const macroBackedFields = [
    'population_total_year', 'life_expectancy_years_year', 'gdp_per_capita_ppp_2021_year',
    'gini_index_year', 'urbanization_pct_year', 'internet_users_pct_year', 'inflation_cpi_pct_year',
  ];
  for (const field of macroBackedFields) {
    assert.ok(querySource.includes(`${field}: m.${field}`), `query does not populate ${field}`);
  }
  assert.match(querySource, /median_age_year: medianAgeMap\.get/);
  for (const field of ['population_total_year', 'median_age_year', 'life_expectancy_years_year', 'gdp_per_capita_ppp_2021_year', 'gini_index_year', 'urbanization_pct_year', 'internet_users_pct_year', 'inflation_cpi_pct_year']) {
    assert.ok(materializerSource.includes(`${field}: row.${field}`), `Gold materializer omits ${field}`);
    assert.ok(lakehouseTypes.includes(`${field}: number | null`), `Brand Market type omits ${field}`);
  }
  assert.match(querySource, /ppp <= 0 \|\| !isRecentYear/);
  assert.match(querySource, /validObservationYear !== null/);
  assert.match(brandUiSource, /p\.gdp_per_capita_ppp_2021_year/);
  assert.match(brandUiSource, /p\.life_expectancy_years_year/);
  assert.match(brandUiSource, /p\.urbanization_pct_year/);
});
