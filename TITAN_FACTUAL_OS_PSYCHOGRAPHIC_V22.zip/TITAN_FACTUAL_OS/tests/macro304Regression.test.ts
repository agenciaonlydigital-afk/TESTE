import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const macro = fs.readFileSync(path.join(root, 'src/lakehouse/connectors/domains/macroEconomics.ts'), 'utf8');

test('World Bank 304 aggregation reads the in-scope fetchedByIndicator collection', () => {
  const branch = macro.slice(macro.indexOf('const anyChanged = fetchedByIndicator'), macro.indexOf('for (const item of fetchedByIndicator)'));
  assert.match(branch, /fetchedByIndicator\.length > 0/);
  assert.match(branch, /fetchedByIndicator\.every\(\(item\) => item\.status === 'NOT_MODIFIED'\)/);
  assert.doesNotMatch(branch, /\bfetched\.every\(/);
});
