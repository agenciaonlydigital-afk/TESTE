import test from 'node:test';
import assert from 'node:assert/strict';
import { buildAuditedSourceCatalog, getImplementedWave1SourceIds } from '../src/lakehouse/sourceInventory.ts';
import {
  DOMAIN_MODULES,
  SOURCE_DOMAIN_MAP,
  applySourceDomainToObservations,
  getDomainModuleSummary,
} from '../src/lakehouse/domainRegistry.ts';

test('the authoritative domain registry contains exactly the 13 target modules', () => {
  assert.equal(DOMAIN_MODULES.length, 13);
  assert.deepEqual(DOMAIN_MODULES.map((item) => item.id), Array.from({ length: 13 }, (_, i) => i + 1));
  assert.equal(DOMAIN_MODULES[11].layer, 'derived_intelligence');
  assert.equal(DOMAIN_MODULES[12].layer, 'serving');
});

test('all 95 source inventory entries map exactly once to a canonical module', () => {
  const sources = buildAuditedSourceCatalog('2026-11-22T00:00:00.000Z');
  assert.equal(sources.length, 95);
  assert.equal(Object.keys(SOURCE_DOMAIN_MAP).length, 95);
  assert.equal(new Set(Object.keys(SOURCE_DOMAIN_MAP)).size, 95);
  for (const source of sources) {
    assert.ok(source.module_id >= 1 && source.module_id <= 13);
    assert.equal(source.module_name, DOMAIN_MODULES[source.module_id - 1].name);
    assert.equal(source.last_verified_at, null, 'catalog creation must not fabricate source verification');
  }
});

test('Wave-1 count remains 79 and source-domain mapping is applied only at ingestion boundary', () => {
  const ids = getImplementedWave1SourceIds();
  assert.equal(ids.length, 79);
  const [row] = applySourceDomainToObservations('faostat_bulk', 2, [{ module_id: 2, value_numeric: 12 }]);
  assert.equal(row.module_id, 8);
  assert.equal(row.value_numeric, 12);
});

test('source summary reports derived and serving modules without pretending they are source APIs', () => {
  const summary = getDomainModuleSummary();
  assert.equal(summary.length, 13);
  assert.equal(summary.find((x) => x.id === 12)?.catalogued_sources, 0);
  assert.equal(summary.find((x) => x.id === 13)?.catalogued_sources, 0);
});
