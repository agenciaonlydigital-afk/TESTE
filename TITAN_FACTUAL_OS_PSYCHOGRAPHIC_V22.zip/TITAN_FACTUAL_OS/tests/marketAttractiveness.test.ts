import assert from 'node:assert/strict';
import test from 'node:test';
import type { MacroEconomicRow } from '../src/lakehouse/types.ts';
import { computeMarketAttractiveness } from '../src/lakehouse/marketAttractiveness.ts';

function row(overrides: Partial<MacroEconomicRow> = {}): MacroEconomicRow {
  return {
    territory_id: 'BRA', iso3: 'BRA', iso2: 'BR', name_en: 'Brazil', continent: 'South America',
    region: 'Latin America', h3_res2: null, h3_res4: null, latest_year: 2025,
    gdp_nominal_usd: 2_000_000_000_000, gdp_nominal_usd_year: 2025,
    gdp_per_capita_ppp_2021: 18_000, gdp_per_capita_ppp_2021_year: 2025,
    imf_real_gdp_growth_pct: null, inflation_cpi_pct: 4, inflation_cpi_pct_year: 2025,
    gov_debt_pct_gdp: null, unemployment_pct: 7, unemployment_pct_year: 2025,
    gini_index: 52, gini_index_year: 2024, population_total: 200_000_000, population_total_year: 2025,
    urbanization_pct: 87, urbanization_pct_year: 2025, internet_users_pct: 84, internet_users_pct_year: 2025,
    life_expectancy_years: 75, life_expectancy_years_year: 2024, household_consumption_pct_gdp: null,
    gni_per_capita_usd: null, fdi_net_inflows_pct_gdp: null, trade_openness_pct_gdp: null,
    ilostat_lfpr_pct: null, imf_policy_rate_pct: null, imf_reer_index: null, oecd_cli_index: null,
    wits_exports_usd: null, wits_imports_usd: null, ember_clean_share_pct: null, ember_carbon_intensity: null,
    uis_gerd_pct_gdp: null, unicef_u5_mortality: null, unsdg_renewable_pct: null, unsdg_forest_pct: null,
    gbif_occurrences: null, wikidata_area_km2: null, abs_cpi_pct_yoy: null, eurostat3_hicp_pct: null,
    statcan_unemp_pct: null, ukons_cpih_yoy_pct: null, unsd_elec_prod_gwh: null, nasa_solar_kwh: null,
    obis_marine_species: null, geonames_pop: null, datacite_dataset_dois: null, eurostat_gov_debt_pct: null,
    unwpp_tfr: 1.7, unwpp_tfr_year: 2023, worldpop_datasets: null, nasa_cmr_collections: null,
    ne_adm1_divisions: null, openalex_works_2024: null, ukgov_open_datasets: null, overture_themes: null,
    faostat_kcal_day: null, uis_edu_exp_pct_gdp: null, worldpop_age_datasets: null, worldpop_density_datasets: null,
    eurostat_catalog_datasets: null, arcgis_open_datasets: null, stac_public_catalogs: null,
    listenbrainz_top100_listens: null, ecb_fx_per_eur: null, vdem_democracy_ix: null, unlocode_nodes: null,
    unhabitat_urban_datasets: null, ckan_portal_datasets: null, socrata_civic_datasets: null,
    osm_importance_score: null, musicbrainz_artists: null, uncomtrade_exports_usd: null,
    itu_mobile_per_100: 100, itu_mobile_per_100_year: 2024, gadm_adm1_features: null,
    wipo_patents_per_million: null, unodc_homicide_rate: null, wid_top10_share_pct: null,
    ghsl_pop_density_km2: null, pwt_real_gdp_cap: null, eurostat_gdp_meur: null, bis_total_credit_pct_gdp: null,
    ibge_ipca_pct: null, unhcr_refugees: null, usgs_seismic_events: null, gb_adm0_coverage: null,
    crossref_works_count: null, unctad_lsci: null, statfin_cpi_pct: null, undata_elec_access_pct: null,
    undrr_mortality_per_100k: null, usgov_datasets_total: null, pip_mean_daily_ppp: null, ct_ghg_co2e: null,
    wikimedia_enwiki_views: null, us_census_pop: null, undp_hdi: 0.76, undp_hdi_year: 2023,
    noaa_tavg_c: null, gfw_tree_loss_ha: null, eia_energy_prod_qbtu: null, india_iip_index: null,
    icao_scheduled_airports: null, wdpa_protected_pct: null,
    ...overrides,
  };
}

test('calculates bounded MAI only when all required fields have valid, aligned years', () => {
  const result = computeMarketAttractiveness(row(), 'mass_market');
  assert.equal(result.methodology_version, '2.1.0');
  assert.equal(result.data_fields_available, 5);
  assert.equal(result.data_coverage_pct, 100);
  assert.equal(result.temporal_status, 'aligned');
  assert.ok(result.market_attractiveness_score !== null);
  assert.ok(result.market_attractiveness_score >= 0 && result.market_attractiveness_score <= 100);
});

test('does not impute missing values or present a composite score for incomplete input', () => {
  const result = computeMarketAttractiveness(row({ gdp_per_capita_ppp_2021: null }), 'premium');
  assert.equal(result.purchasing_power_score, null);
  assert.equal(result.market_attractiveness_score, null);
  assert.equal(result.data_fields_available, 4);
  assert.ok(result.missing_or_invalid_fields.includes('gdp_per_capita_ppp_2021'));
});

test('withholds composite for mixed, stale or undated data periods', () => {
  const mixed = computeMarketAttractiveness(row({ inflation_cpi_pct_year: 2018 }), 'mass_market');
  assert.equal(mixed.temporal_status, 'mixed_periods');
  assert.equal(mixed.market_attractiveness_score, null);

  const undated = computeMarketAttractiveness(row({ population_total_year: null }), 'mass_market');
  assert.equal(undated.temporal_status, 'incomplete');
  assert.equal(undated.market_attractiveness_score, null);

  const noYears = computeMarketAttractiveness(row({
    population_total_year: null, urbanization_pct_year: null, internet_users_pct_year: null,
    gdp_per_capita_ppp_2021_year: null, inflation_cpi_pct_year: null,
  }), 'mass_market');
  assert.equal(noYears.temporal_status, 'incomplete');
  assert.equal(noYears.market_attractiveness_score, null);

  const stale = computeMarketAttractiveness(row({
    gdp_per_capita_ppp_2021_year: 2010, population_total_year: 2010, urbanization_pct_year: 2010,
    internet_users_pct_year: 2010, inflation_cpi_pct_year: 2010,
  }), 'mass_market');
  assert.equal(stale.temporal_status, 'stale');
  assert.equal(stale.market_attractiveness_score, null);
});

test('rejects out-of-range values instead of clamping them into valid observations', () => {
  const result = computeMarketAttractiveness(row({ internet_users_pct: 180 }), 'mass_market');
  assert.equal(result.demographic_score, null);
  assert.equal(result.market_attractiveness_score, null);
  assert.ok(result.missing_or_invalid_fields.includes('internet_users_pct'));
});


test('Gini inequality is retained as descriptive context but does not arbitrarily boost premium or penalize mass-market scores', () => {
  const lowInequality = computeMarketAttractiveness(row({ gini_index: 22 }), 'premium');
  const highInequality = computeMarketAttractiveness(row({ gini_index: 68 }), 'premium');
  assert.equal(lowInequality.market_attractiveness_score, highInequality.market_attractiveness_score);
  const noGiniYear = computeMarketAttractiveness(row({ gini_index_year: null }), 'premium');
  assert.equal(noGiniYear.market_attractiveness_score, lowInequality.market_attractiveness_score);
});

test('zero GDP-per-capita PPP is rejected as invalid instead of implying an observed market', () => {
  const result = computeMarketAttractiveness(row({ gdp_per_capita_ppp_2021: 0 }), 'mass_market');
  assert.equal(result.purchasing_power_score, null);
  assert.equal(result.market_attractiveness_score, null);
  assert.ok(result.missing_or_invalid_fields.includes('gdp_per_capita_ppp_2021'));
});
