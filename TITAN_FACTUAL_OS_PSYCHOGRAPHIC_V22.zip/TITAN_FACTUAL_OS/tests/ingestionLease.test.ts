import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import test from 'node:test';
import {
  INGESTION_LEASE_SCHEMA_SQL,
  acquireIngestionLease,
  listActiveIngestionLeases,
  releaseIngestionLease,
  renewIngestionLease,
} from '../src/lakehouse/ingestionLease.ts';

function setup() {
  const db = new DatabaseSync(':memory:');
  db.exec(INGESTION_LEASE_SCHEMA_SQL);
  return db;
}

test('a source lease is exclusive, renewable and owner-protected', () => {
  const db = setup();
  const start = Date.UTC(2026, 10, 22, 12, 0, 0);
  const first = { sourceId: 'world_bank_wdi', runId: 'run-1', ownerId: 'worker-a', nowMs: start, leaseMs: 60_000 };
  assert.equal(acquireIngestionLease(db, first), true);
  assert.equal(acquireIngestionLease(db, { ...first, runId: 'run-2', ownerId: 'worker-b' }), false);
  assert.equal(renewIngestionLease(db, { ...first, nowMs: start + 10_000 }), true);
  assert.equal(releaseIngestionLease(db, { ...first, ownerId: 'worker-b' }), false);
  assert.equal(listActiveIngestionLeases(db, start + 20_000).length, 1);
  assert.equal(releaseIngestionLease(db, first), true);
  assert.equal(listActiveIngestionLeases(db, start + 20_000).length, 0);
  db.close();
});

test('expired leases can be recovered but an expired owner cannot renew or release a replacement', () => {
  const db = setup();
  const start = Date.UTC(2026, 10, 22, 12, 0, 0);
  const oldLease = { sourceId: 'world_bank_wdi', runId: 'old-run', ownerId: 'old-worker', nowMs: start, leaseMs: 60_000 };
  assert.equal(acquireIngestionLease(db, oldLease), true);
  assert.equal(renewIngestionLease(db, { ...oldLease, nowMs: start + 60_000 }), false);

  const replacement = { ...oldLease, runId: 'new-run', ownerId: 'new-worker', nowMs: start + 60_001 };
  assert.equal(acquireIngestionLease(db, replacement), true);
  assert.equal(releaseIngestionLease(db, oldLease), false);
  assert.equal(renewIngestionLease(db, { ...oldLease, nowMs: start + 60_002 }), false);
  const active = listActiveIngestionLeases(db, start + 60_002);
  assert.equal(active.length, 1);
  assert.equal(active[0].run_id, 'new-run');
  db.close();
});

test('different source IDs can run concurrently', () => {
  const db = setup();
  const nowMs = Date.UTC(2026, 10, 22, 12, 0, 0);
  assert.equal(acquireIngestionLease(db, { sourceId: 'world_bank_wdi', runId: 'a', ownerId: 'worker', nowMs }), true);
  assert.equal(acquireIngestionLease(db, { sourceId: 'imf_datamapper', runId: 'b', ownerId: 'worker', nowMs }), true);
  assert.deepEqual(listActiveIngestionLeases(db, nowMs).map((item) => item.source_id), ['imf_datamapper', 'world_bank_wdi']);
  db.close();
});
