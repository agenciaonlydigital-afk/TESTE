import test from 'node:test';
import assert from 'node:assert/strict';
import { getDuckDBMetrics, recordDuckDBLatency } from '../src/lakehouse/duckdbMetrics.ts';

test('DuckDB latency metrics use a bounded rolling sample and ignore invalid values', () => {
  for (let i = 0; i < 300; i++) recordDuckDBLatency(i);
  recordDuckDBLatency(Number.NaN);
  recordDuckDBLatency(-1);
  const metrics = getDuckDBMetrics();
  assert.equal(metrics.queryCount, 256);
  assert.equal(metrics.avgMs, 172);
  assert.equal(metrics.p95Ms, 287);
});
