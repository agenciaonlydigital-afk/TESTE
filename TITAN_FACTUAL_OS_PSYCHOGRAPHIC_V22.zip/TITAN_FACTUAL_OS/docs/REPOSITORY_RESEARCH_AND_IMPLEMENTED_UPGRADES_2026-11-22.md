# Repository research and implemented upgrades — 2026-11-22

## Selection rule

Stars were used as a discovery signal, not as a substitute for fit, maintenance, correctness, methodology or license compatibility. The selected code stays TypeScript/Node/SQLite/DuckDB-first. No heavyweight Python, JVM, catalog server or orchestrator was added to this free-first application.

> **Review note (2026-11-22):** the exact star-count snapshots in this earlier research note are historical estimates and must not be used as current facts. The authoritative current repository comparison is `REPOSITORY_STAR_REVIEW_MATRIX.md`, which records GitHub `stars:>N` search floors verified on 2026-11-22 instead of pretending to have immutable exact counts. The latest adversarial findings and corrections are documented in `FINAL_REPOSITORY_REVIEW_2026-11-22.md`.

Firecrawl deep-research could not be executed during this run because the connected account had exhausted its credits. Repository metadata and project documentation were instead checked through GitHub and public GitHub pages on 2026-11-22. Star numbers below are approximate snapshots and will change.

## Repository alternatives reviewed

| Area | Better-fit reference | Approx. stars | Why selected | Application decision |
|---|---|---:|---|---|
| Geospatial operations in TypeScript | [Turf.js](https://github.com/Turfjs/turf) | 10.6k | Mature modular JS/TS GeoJSON engine; Node is a first-class runtime; MIT. | Use as the reference for narrow, modular GeoJSON operations. The current package implements a tested, explicitly limited point-in-area predicate without adding a package dependency before the full runtime install can be validated. For production topology/overlay operations, prefer a tested Turf module over extending custom geometry code. |
| Global administrative boundary data | [geoBoundaries](https://github.com/wmgeolab/geoBoundaries) | ~435 | Specialist maintained data project with per-boundary metadata, release versions and global ADM0–ADM2 products; repository explains the source and API. Data licensing/attribution still has to be checked at the boundary record level. | Chosen as a source/catalog reference, not a geometry runtime. Added country-level ADM0/ADM1/ADM2 metadata discovery. The existing original source-specific connector remains unchanged; the extension does not download geometry. |
| Data catalog, lineage and quality architecture | [OpenMetadata](https://github.com/open-metadata/OpenMetadata) | ~15.7k | Stronger adoption and broad data contracts, catalog, lineage, profiling and observability than small bespoke examples; Apache-2.0. | Adopted lightweight ideas for explicit quality checks and provenance. Did not import the platform/server stack because it would materially increase operational cost and complexity. |
| Data validation patterns | [Great Expectations](https://github.com/fivetran/great_expectations) | ~11.9k | Established expectation/checkpoint model; Apache-2.0. | Applied descriptive, separately named QA checks in the existing Silver gate. No Python service or duplicate validation framework added; Zod and TypeScript stay canonical. |
| Complex survey methodology | [R survey package mirror](https://github.com/cran/survey) | 27 | Specialist implementation for complex survey samples; more methodologically relevant than general ML/weighting packages despite its low-star read-only CRAN mirror. | The new estimator is deliberately a limited first-stage weighted-mean primitive, not a replacement for `survey`. Its limitations are exposed in every result and in this document. Full production estimates still require source-specific design metadata and validation against a specialist survey package. |
| Areal interpolation reference | [PySAL tobler](https://github.com/pysal/tobler) | ~169 | Directly relevant to area-weighted/dasymetric interpolation, but lower adoption and Python GIS dependency requirements. | Not introduced as a runtime. The crosswalk engine consumes externally derived, versioned allocation shares; it does not pretend to calculate population weights from geometry. A future polygon-overlay/interpolation stage should validate against specialist methods such as Tobler. |
| General-purpose geospatial stack alternative | [GeoPandas](https://github.com/geopandas/geopandas) | ~5.3k | Much higher adoption and a mature geometry/dataframe ecosystem, but Python-first and not an authoritative boundary catalogue. | Evaluated as a future offline geometry QA/interpolation tool; not added to the Node app because it creates a separate Python runtime. Turf remains the more direct JS/TS fit for application-side GeoJSON operations. |
| Complex-survey alternative with broader stars | [statsmodels](https://github.com/statsmodels/statsmodels) | ~11.7k | Broad statistical ecosystem and much higher adoption than the CRAN mirror, but generic weighted models are not a replacement for complex-sample variance, strata, PSUs and replicate-weight procedures. | Rejected as a substitute for design-based survey inference. `survey` remains the specialist methods reference; a production release should cross-check estimates against it or a validated equivalent. |
| High-adoption ingestion patterns | [Airbyte](https://github.com/airbytehq/airbyte) / [dlt](https://github.com/dlt-hub/dlt) | ~22.4k / ~6k | Airbyte has broader connector platform adoption; dlt provides a smaller state/checkpoint-oriented pipeline model. | Preserve the existing 79 connectors. Use checkpoint, state and retry patterns selectively rather than introducing a second connector platform. |
| Analytical engine | [DuckDB](https://github.com/duckdb/duckdb) | ~42.2k | High-adoption embedded analytical engine with Parquet and spatial extensions. | Remains the existing analytical engine; the new code does not replace it or add a second query engine. |
| Workflow orchestration alternative | [Dagster](https://github.com/dagster-io/dagster) | ~16k | More adoption and mature asset lineage, scheduling and observability. | Kept as a future reference only; WorkCoordinator and durable leases remain proportionate to the current single-app scale.

### Options deliberately not selected as runtime dependencies

- OpenMetadata and Great Expectations are significantly more adopted than the previous small project references, but both introduce service/runtime surface that is not justified for this application yet.
- Even higher-star orchestration/data platforms were considered: Apache Airflow (~47.5k), Prefect (~24k), and Airbyte (~22.4k); higher stars do not outweigh their separate Python/Java control planes and their operational cost for the current embedded Node application. Airbyte's core distribution is Elastic License 2.0/source-available rather than a permissive OSI license, so it is not a safe default for product embedding.
- ClickHouse (~50.4k) has more stars than DuckDB (~42.2k), but the current system needs embedded, in-process analysis over Parquet; ClickHouse would add a server/operations layer and is not the better fit at this stage.
- `cran/survey` has low GitHub stars because the repository is a read-only mirror; star count is not a valid reason to replace specialist complex-survey methodology with a general weighted-average package.
- PySAL/tobler is a specialist area-interpolation tool, but it is not equivalent to a coordinate predicate or a simple boundary crosswalk. No areal interpolation is claimed in this release.
- GeoBoundaries has fewer stars than general geospatial libraries because it is a domain data repository, not a general framework. It remains more fit for administrative-boundary catalogue discovery than a popular but unrelated GIS visualization repository. GeoPandas and Turf can process shapes; neither replaces the boundary source itself.
- The low-star `cran/survey` and `pysal/tobler` references are retained only for their specialist methods. `statsmodels` and `GeoPandas` have substantially more stars, but neither is a drop-in replacement for complex sample survey design or population-weighted areal interpolation respectively. Method equivalence matters more than popularity.

## Implemented improvements

### 1. Survey evidence foundation

Files:
- `src/lakehouse/surveyAnalytics.ts`
- `src/lakehouse/surveyContracts.ts`
- `tests/surveyAnalytics.test.ts`

Implemented:
- Strict input validation for one survey, wave, country and question at a time.
- Final-weighted mean and Kish effective sample size.
- First-stage Taylor linearization using PSU totals, stratified by explicit stratum IDs, with a with-replacement approximation.
- Approximate normal 95% interval only when complete PSU/stratum metadata exists and every stratum has at least two sampled PSUs.
- Variance is withheld for incomplete design metadata or singleton strata without certainty-PSU/FPC details.
- Configurable effective-sample-size release threshold (default 30); the field name indicates that this is only a sample-size threshold, not a full publishability approval.
- Conversion of an eligible aggregate estimate into the canonical Silver observation contract, preserving survey/wave/question, sample size, effective sample size, weighting method, population scope, fieldwork and rights metadata.
- Strict long-format CSV import with explicit versioned question mappings, numeric or categorical response harmonization, reverse coding, explicit missing-value codes, final weights, optional stratum/PSU design and import size/row limits.
- A helper groups imported responses by country/question and invokes the estimator. Respondent ID fields are never returned or persisted by this importer; harmonization metadata is retained for traceability.

Not implemented / must not be inferred:
- The CSV importer is an exchange-format ingestion path, not a live WVS, ESS, EVS, Afrobarometer, Latinobarómetro or ISSP connector. No provider portal is scraped and no real microdata is bundled.
- No real survey microdata is bundled or represented as acquired.
- The estimator does not implement FPCs, replicate weights, calibration/raking, nonresponse adjustments, multistage designs, domains or small-area estimation. The weighted response must already be harmonized to a numeric construct under a documented question map. It normalizes weights before computing the weighted mean, Kish effective sample size and first-stage PSU variance to reduce numeric overflow/underflow; the reported raw sum of weights must still fit a JavaScript finite number.
- `survey_evidence_count` remains zero for the existing Brand Market profiles until actual source microdata is acquired, mapped, licensed and materialized.

### 2. Global administrative-boundary foundation

Files:
- `src/lakehouse/spatial/geoBoundariesCatalog.ts`
- `src/lakehouse/spatial/geoJsonGeometry.ts`
- `src/lakehouse/spatial/boundaryCrosswalk.ts`
- `tests/geoBoundariesCatalog.test.ts`
- `tests/geoJsonGeometry.test.ts`
- `tests/boundaryCrosswalk.test.ts`

Implemented:
- geoBoundaries `gbOpen` catalog URL generation and metadata-only discovery for ADM0, ADM1 and ADM2.
- A bounded-concurrency batch helper processes a caller-supplied ISO3 universe (up to 300 countries), preserves input order, reports per-country failures without losing successful results, and supports cancellation.
- Country identity, admin-level, metadata and HTTPS download URL checks; missing levels are explicit.
- GeoJSON Polygon/MultiPolygon validation and a point-in-area predicate with hole support and boundary-point semantics.
- Explicit rejection of antimeridian-crossing rings from the lightweight predicate rather than returning guessed results.
- Versioned source-to-target administrative crosswalk validation, year applicability, non-overlapping temporal source-target intervals, allocation basis consistency and per-source weights validated within each active period.
- Additive values are allocated using supplied weights. Rates are transferred by separately allocating numerator and denominator; simple arithmetic averaging of rates is not used.
- Existing `geoboundaries_open` catalog metadata was corrected: the original connector currently ingests ADM0 catalog metadata only; it does not claim ADM1/ADM2 geometry acquisition.

Not implemented / must not be inferred:
- The new geoBoundaries helpers fetch metadata only; they do not download, unzip, persist or version the geometry assets. The ISO3 list is caller-supplied; this does not create a global ISO registry or assert 249-country availability.
- Existing 79 source-specific parser/connector files remain untouched to preserve original extraction behavior.
- The point-in-polygon helper is a small tested subset, not a topology engine. It does not perform polygon intersection/union, validate self-intersections, calculate area, clip boundaries or calculate population-weighted crosswalks. Prefer Turf modules for broad GeoJSON operations once dependency installation/build can be fully verified.
- Crosswalk weights must be independently sourced/calculated and carry their own provenance. Population-based weights must not be substituted with area weights without an explicit methodology label.
- The territorial dimension remains a partial seed registry; this work does not establish 190+ country coverage or 98% global indicator coverage.

### 3. Data-quality profile integrated with Silver QA

Files:
- `src/lakehouse/dataQualityProfile.ts`
- `src/lakehouse/qaContracts.ts`
- `tests/dataQualityProfile.test.ts`

Implemented:
- Silver QA now returns a structured quality profile in addition to validated rows and the human-readable note.
- Explicit checks for non-empty Silver output, schema acceptance, catalog/license metadata consistency, duplicate identity collisions, observation-period vintage and geographic coverage state.
- Counts of territories and indicators, period range, newest observation vintage and optional survey-field completeness.
- Geographic coverage stays `not_scored` until a source-specific expected-territory set is configured; a partial territory seed is never used to fabricate a coverage percentage. The duplicate collision rate is labelled explicitly as collisions/raw rows, not as a 'deduplication success' score.
- Failed checks and warnings are summarized in persisted QA notes. Existing dashboard visibility and source acquisition are unchanged.

## Regression and preservation guarantees

- All 79 original connector IDs and their order are still verified against the original extraction fixture.
- All original ingest function names and original endpoint literals remain present.
- Hashes for the six source-specific connector/parser files still match the original preservation fixture.
- The dashboard remains in internal development visibility mode; no commercial-only filter was activated on Silver, Gold, API or dashboard observations.
- No new runtime package was added.

## Validation limits

The 111 native Node tests pass. Full dependency installation, full TypeScript project type-check, Vite production build, runtime DuckDB/SQLite integration and live requests for the 79 original connectors still require a network-enabled target environment with source credentials and package installation. Do not interpret unit tests as live source validation or production approval.

## Primary references

- Turf: https://github.com/Turfjs/turf
- geoBoundaries repository: https://github.com/wmgeolab/geoBoundaries
- geoBoundaries API: https://www.geoboundaries.org/api.html
- OpenMetadata: https://github.com/open-metadata/OpenMetadata
- Great Expectations: https://github.com/fivetran/great_expectations
- CRAN `survey` mirror: https://github.com/cran/survey
- CRAN package documentation: https://cran.r-project.org/web/packages/survey/index.html
- PySAL/tobler: https://github.com/pysal/tobler


## Final adversarial code review — additional safeguards

- Survey weight moments are normalized by the largest final weight before computing the ratio, Kish effective sample size and first-stage variance. This avoids avoidable squaring underflow/overflow while retaining the raw finite sum of weights as provenance.
- Aggregate survey observations must target the matching country territory (a country-level survey aggregate cannot be relabelled as a state/city observation).
- Survey conversion validates calendar dates, timezone-bearing ISO timestamps, identifier lengths, units, estimator thresholds, design counts and paired standard-error/confidence-interval availability.
- Crosswalks reject multiple destination boundary versions for one source/version, omit zero-share destination rows, and fail on numeric accumulation overflow rather than emit `Infinity`/`NaN`.
- Data-quality count inputs must reconcile; duplicate-collision percentage is labelled as such rather than implying the proportion successfully deduplicated.
- geoBoundaries attribution is treated conservatively as required even when a metadata response omits its license label.


### Latest implementation increment — import and batch discovery

- `src/lakehouse/surveyImport.ts` now accepts a strict, long-format CSV exchange file and uses explicit question mappings. It does not infer response meaning, defaults, unweighted samples or respondent identity; it returns harmonized rows plus mapping/version metadata and can group them for the estimator.
- `fetchGeoBoundariesCatalogBatch` now performs country batch metadata discovery with maximum concurrency 8, per-country partial failure reporting and abort support. It still only fetches metadata; it does not acquire geometries.
- Additional regression suites cover import/mapping/scale conversions/row limits and batch ordering/concurrency/failure/cancellation.

- Grouped survey estimates preserve and expose `survey_id`, `wave_id` and `country_iso3` on each returned estimate, so national results cannot be confused after aggregation. Group keys use structured JSON tuples rather than delimiter concatenation, and source question counts use a Map before safe object serialization.
