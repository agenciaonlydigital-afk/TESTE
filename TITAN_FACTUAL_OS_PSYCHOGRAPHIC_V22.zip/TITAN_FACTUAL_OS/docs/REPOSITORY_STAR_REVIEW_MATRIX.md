# Repository review matrix — verified GitHub star floors — 2026-11-22

## Method

Repository discovery was performed through GitHub repository search. The `stars:>N` filters below returned the named repository on 2026-11-22. These are **verified lower bounds**, not exact star counts or quality scores; the number of stars changes over time. Search ranking is not a proxy for domain correctness, license fit, maintenance or integration cost. Repository READMEs were inspected for the selected technical roles. Firecrawl deep-research was unavailable because the connected account had exhausted its credits; no Firecrawl results are claimed.

## Best-fit and higher-adoption alternatives

| Area | Better / higher-adoption repository | GitHub search floor verified | What it does better | Decision in TITAN |
|---|---|---:|---|---|
| In-app GeoJSON operations | [Turf.js](https://github.com/Turfjs/turf) | >10,000 | Mature modular JavaScript GeoJSON operations; fits Node/TypeScript more directly than Python GIS libraries. | Preferred future geometry library. Do not expand the hand-written predicate into a topology engine; full install/build and an actual geometry consumer are prerequisites before adding it. |
| Geometry kernel / robust operations | [Shapely](https://github.com/shapely/shapely) | >3,000 | GEOS-backed geometry operations and topology validity. | Strong authoritative validation/overlay reference; Python runtime is not added to the app. Use an equivalent GEOS-backed stage if offline area allocation is implemented. |
| Vector dataframes / spatial joins | [GeoPandas](https://github.com/geopandas/geopandas) | >1,000 | Mature geospatial dataframe, spatial join and overlay workflows. | Preferred offline QA/processing reference, but not an in-app runtime dependency. |
| Embedded analytical engine | [DuckDB](https://github.com/duckdb/duckdb) | >10,000 | In-process analytics, SQL, CSV/JSON/Parquet and remote-file support. | Existing architecture choice retained. Verify the packaged Node client and persistent read/write path in CI before production. |
| Columnar interchange / compute | [Apache Arrow](https://github.com/apache/arrow) | >5,000 | Columnar formats and zero-copy/interoperability foundations across data systems. | Use as the Parquet/Arrow interoperability reference; no extra runtime until a measured need exists. |
| High-performance columnar dataframe | [Polars](https://github.com/pola-rs/polars) | >10,000 | Efficient lazy and streaming dataframe execution. | Better alternative to hand-written in-memory transformations for a future batch/offline worker; not added to the current TypeScript runtime. |
| Connector platform / API ingestion | [Airbyte](https://github.com/airbytehq/airbyte) | >10,000 | Mature connector lifecycle, catalog, incremental sync and state concepts. README documents a mixture of MIT and Elastic License 2.0 components. | Reference only; preserve the 79 original source-specific handlers. Do not embed the full platform or assume every component is permissively licensed. |
| Lightweight incremental loading | [dlt](https://github.com/dlt-hub/dlt) | >5,000 | State, incremental loading, normalization and idempotent pipeline patterns. | Reuse state/checkpoint concepts without adding another ingestion runtime. |
| Data-quality expectations | [Great Expectations](https://github.com/great-expectations/great_expectations) | >5,000 | Expectations, checkpoints and explicit data-quality outcomes. | Reuse profile/rule concepts; existing TypeScript/Zod quality gate stays the only runtime. |
| Typed dataframe validation | [Pandera](https://github.com/unionai-oss/pandera) | >3,000 | Dataset schema validation and statistical checks, including support for multiple dataframe engines. | Reference for richer data-quality contracts; not added as a Python dependency. |
| Data catalog / lineage | [OpenMetadata](https://github.com/open-metadata/OpenMetadata) | >10,000 | Broad data catalog, lineage, quality and metadata model. | Use small metadata/lineage ideas; a separate catalog service is not proportionate for the current deployment. |
| Asset-oriented orchestration | [Dagster](https://github.com/dagster-io/dagster) | >5,000 | Explicit asset dependencies, run observability and materialization model. | Reference only; current WorkCoordinator and run ledger remain simpler. |
| Scheduling alternative | [Prefect](https://github.com/PrefectHQ/prefect) | >10,000 | Python workflow scheduling and retry visibility. | Higher adoption does not justify introducing a second control plane while the modular app is still being validated. |
| Large-scale analytical server alternative | [ClickHouse](https://github.com/ClickHouse/ClickHouse) | >10,000 | Distributed OLAP and high-throughput analytical storage. | Not a drop-in replacement for an embedded free-first DuckDB app; reconsider only with demonstrated concurrency/scale limits. |
| General-purpose statistics | [statsmodels](https://github.com/statsmodels/statsmodels) | >10,000 | Broad classical statistical models and inference. | Useful complement, but not a replacement for complex-survey variance methods and sample-design metadata. |

## Specialized sources retained even though star count is lower

| Specialized source | Why it remains appropriate | Constraint |
|---|---|---|
| [R survey](https://github.com/cran/survey) and [srvyr](https://github.com/gergness/srvyr) | Directly implement complex-sample designs, strata/PSUs, replicate designs and design-based summaries; `srvyr` README states it builds on `survey`. | The current TypeScript estimator is explicitly limited to weighted means and first-stage with-replacement Taylor variance; it is not equivalent to a full survey package. |
| [geoBoundaries](https://github.com/wmgeolab/geoBoundaries) | Authoritative-domain project for global administrative boundary data and metadata, unlike general-purpose libraries. Its README describes global ADM boundary coverage and attribution requirements. | Metadata discovery is implemented; geometry download, full topology QA, persistence and population-weighted areal interpolation are not. Verify each dataset release's terms and required attribution. |
| [PySAL/tobler](https://github.com/pysal/tobler) | Specialist reference for area-weighted/dasymetric areal interpolation; higher-star generic geospatial libraries do not automatically supply the method. | No derived weights are fabricated. The TypeScript crosswalk consumes externally sourced weights and labels their basis. |


## Psychographic and survey-method alternatives — exact GitHub API snapshots

A second, task-specific review was performed on 2026-11-22. The counts below came from repository metadata reads, not `stars:>N` floors. They are exact at retrieval time and must not be treated as permanent counts.

| Repository | Stars | License | Relevance / decision |
|---|---:|---|---|
| [scikit-learn/scikit-learn](https://github.com/scikit-learn/scikit-learn) | 68,294 | BSD-3-Clause | Popular baseline for scaling, clustering and model validation. No country-level clustering used as psychographics. |
| [pandas-dev/pandas](https://github.com/pandas-dev/pandas) | 50,603 | BSD-3-Clause | Standard tabular data-analysis reference. |
| [pola-rs/polars](https://github.com/pola-rs/polars) | 40,438 | MIT | High-performance lazy dataframes; Node.js binding documented. Deferred until profiling proves microdata batch processing needs a native engine. |
| [scipy/scipy](https://github.com/scipy/scipy) | 15,241 | BSD-3-Clause | Numerical/statistical routines and foundations. |
| [statsmodels/statsmodels](https://github.com/statsmodels/statsmodels) | 11,763 | BSD-3-Clause | Classical inference/econometrics; useful but not a complete complex-survey design library. |
| [py-why/dowhy](https://github.com/py-why/dowhy) | 8,410 | MIT | Causal-inference discipline; no causal inference is claimed by proxy scores. |
| [lmcinnes/umap](https://github.com/lmcinnes/umap) | 8,339 | BSD-3-Clause | Exploratory dimensionality reduction; only suitable after aligned respondent-level feature construction. |
| [scikit-learn-contrib/hdbscan](https://github.com/scikit-learn-contrib/hdbscan) | 3,160 | BSD-3-Clause | Variable-density clustering with noise handling; deferred pending representative microdata and validation. |
| [raphaelvallat/pingouin](https://github.com/raphaelvallat/pingouin) | 1,947 | GPL-3.0 | Statistical package examined; no runtime adoption. |
| [MaxHalford/prince](https://github.com/MaxHalford/prince) | 1,490 | MIT | Strong specialist fit for MCA/FAMD on mixed/categorical survey matrices; supports observation/variable weights and supplementary variables. |
| [gergness/srvyr](https://github.com/gergness/srvyr) | 224 | License not surfaced by repository metadata | Tidy complex-survey interface; reference only. |
| [cran/survey](https://github.com/cran/survey) | 28 | GPL-2 or GPL-3 | Specialist methodology reference for complex designs, Taylor/replicate-weight variance, calibration/raking and multistage samples. Low GitHub star count does not diminish its methodological fit. |

Applied decision: preserve the TypeScript/Parquet architecture and avoid adding multiple overlapping Python/R analytics runtimes. The release adds a transparent, design-limited survey workflow; it does not claim equivalence to `survey`, and it defers MCA/FAMD/clustering until the source data include aligned respondent-level features with valid weights and rights.

## What this code review changed

1. Excluded Gini from the `value_sensitivity` and `economic_pressure` proxy scores. Gini remains descriptive macroeconomic context; it is not a direct measurement of an individual or population's price sensitivity or financial pressure. Psychographic profile model is now `2.2.0`: the six macro proxies remain distinct, and harmonized question-level survey measures can flow separately through Silver and Gold. There is still no automatic population segmentation or active external survey connector.
2. Corrected temporal crosswalk validation: non-overlapping source-target intervals are validated independently; different year allocations no longer collapse into a single output row; values outside the active interval are rejected.
3. Added a strict fieldwork interval check so `fieldwork_start` cannot be later than `fieldwork_end`.
4. Clarified that the lightweight GeoJSON helper checks structure and point-in-area behavior only. It is not a full OGC/GEOS topology validator and must not be used to claim self-intersection, hole topology or overlay correctness.
5. Kept commercial-use gating inactive for internal dashboard observations. Acquisition and internal visibility are separate from a future external commercial-serving policy.

## Explicitly not adopted

- No Airbyte, Prefect, Dagster, Polars, GeoPandas, Shapely, Great Expectations or OpenMetadata runtime was added. Their patterns were assessed against the current deployment shape; adding several overlapping frameworks would increase operational weight without making the present app more correct.
- `Turf.js` is the preferred in-app candidate for a real GeoJSON consumer, but the current lightweight predicate is still isolated and limited. Adding the package before dependency-resolved build verification would create an unverified runtime change.
- No higher-star general statistics package replaces the complex-survey method. The domain-specific method is retained even though the GitHub mirror has fewer stars.

## GitHub references

- https://github.com/Turfjs/turf
- https://github.com/shapely/shapely
- https://github.com/geopandas/geopandas
- https://github.com/duckdb/duckdb
- https://github.com/apache/arrow
- https://github.com/pola-rs/polars
- https://github.com/airbytehq/airbyte
- https://github.com/dlt-hub/dlt
- https://github.com/great-expectations/great_expectations
- https://github.com/unionai-oss/pandera
- https://github.com/open-metadata/OpenMetadata
- https://github.com/dagster-io/dagster
- https://github.com/PrefectHQ/prefect
- https://github.com/ClickHouse/ClickHouse
- https://github.com/statsmodels/statsmodels
- https://github.com/cran/survey
- https://github.com/gergness/srvyr
- https://github.com/wmgeolab/geoBoundaries
- https://github.com/pysal/tobler
