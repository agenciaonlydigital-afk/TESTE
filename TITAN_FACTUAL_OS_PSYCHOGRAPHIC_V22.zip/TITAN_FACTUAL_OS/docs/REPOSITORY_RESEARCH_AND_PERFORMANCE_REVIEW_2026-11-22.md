# TITAN FACTUAL OS — Repository Research & Performance Review

Date: 2026-11-22

## Scope and preservation rule

The original source connectors are the authoritative acquisition layer. This review does not replace their source endpoints, parsers, pagination, or extraction behavior. The existing connector preservation regression test remains mandatory and compares all 79 source IDs, ingest function names, endpoint literals, and source-specific extraction/parser sections with the original archive.

The repositories below are engineering references, not a mandate to import their full frameworks. Star counts are approximate GitHub UI observations collected during this review and change over time.

## Top repository references by capability

| Capability | Top references | Patterns adopted / decision |
|---|---|---|
| Columnar analytics and query execution | [DuckDB](https://github.com/duckdb/duckdb) (~43k stars), [Polars](https://github.com/pola-rs/polars) (~40.3k), [pandas](https://github.com/pandas-dev/pandas) (~49k) | Keep DuckDB as the embedded SQL/Parquet engine already used by TITAN. Adopt bounded runtime configuration and rolling latency metrics. Polars/pandas are not added as dependencies because they introduce another runtime and duplicate DuckDB's current analytical role. |
| Acquisition and connector reliability | [Airbyte](https://github.com/airbytehq/airbyte) (~22.4k), [dlt](https://github.com/dlt-hub/dlt) (~6k), [Dagster](https://github.com/dagster-io/dagster) (~16k) | Retain native connectors. Preserve checkpoint/lease, idempotence, retry and per-source failure semantics; do not import a heavyweight orchestration framework into the current modular-monolith control plane. |
| Spatial analysis | [H3](https://github.com/uber/h3) (~6.7k), [GeoPandas](https://github.com/geopandas/geopandas) (~5.3k), [Shapely](https://github.com/shapely/shapely) (~4.5k) | Keep H3 for indexing/rollups and clearly label centroid assignment. Use GeoPandas/Shapely concepts for future polygon validation/intersection; do not claim polygon overlay is implemented by centroid indexing. |
| Data quality and contracts | [Great Expectations](https://github.com/great-expectations/great_expectations) (~12k), [Evidently](https://github.com/evidentlyai/evidently) (~8k), [Pandera](https://github.com/unionai-oss/pandera) (~4.5k) | Keep lightweight native TypeScript contracts. Add a single-pass profile calculation and preserve separate quality dimensions instead of one opaque score. |
| Survey/statistical estimation | [statsmodels](https://github.com/statsmodels/statsmodels) (~11k), [Pew Research methods](https://github.com/pewresearch/pewmethods) (methodology references), [survey](https://cran.r-project.org/package=survey) (complex-sample reference implementation) | Preserve explicit weights, strata, PSU, effective sample size and variance caveats. Do not treat demographic proxies as measured psychographics. |

## Implemented in this review

1. **Single-pass data-quality profiling**
   - Replaced repeated array scans for each optional field with one pass.
   - Removed `Math.min(...years)` / `Math.max(...years)`, avoiding argument-limit failures on large snapshots.
   - Accumulates territory/indicator cardinality, year bounds and optional-field completeness in the same pass.
   - Rejects unsafe integer counts.

2. **Async-iterable NDJSON writer**
   - The writer now accepts both synchronous and asynchronous iterables.
   - Retains stream backpressure, deterministic row indexes, exclusive file creation, completion waiting and cleanup on errors.
   - Existing connector output contracts remain unchanged; this is a streaming-capable persistence primitive, not a claim that every connector is end-to-end streaming today.

3. **Bounded DuckDB latency metrics**
   - Replaced front-shifting latency sample maintenance with a fixed-size rolling buffer.
   - Ignores invalid latency samples and exposes stable count/average/p95 summaries.

4. **Tunable DuckDB runtime settings**
   - Added `TITAN_DUCKDB_THREADS`, `TITAN_DUCKDB_MEMORY_LIMIT` and `TITAN_DUCKDB_TEMP_DIRECTORY`.
   - Validates thread count and memory-size syntax before opening the instance.
   - Conservative defaults remain 2 threads and 1 GB; no machine-specific assumptions are forced.

## Deliberately not claimed as complete

- The original connectors were preserved, but this review did not execute all remote APIs live; credentials, quotas and source availability are external constraints.
- Async-iterable support does not by itself convert existing source parsers, which currently return materialized arrays, into end-to-end streaming ingestion.
- Global administrative geometry coverage, polygon overlay, and population-weighted areal interpolation still require real boundary datasets and validation against source-specific geography vintages.
- The build and full project type-check require dependencies; `npm install --ignore-scripts --no-audit --no-fund` timed out in this environment. Do not mark Vite build or full `tsc --noEmit` as passed.
- Dashboard data visibility remains unchanged: internal development views continue to expose stored observations irrespective of commercial clearance. Commercial distribution controls remain a separate future policy.

## Regression checks

- Original connector contract regression: unchanged and passing.
- NDJSON writer: sync + async iterable and backpressure tests.
- Data quality: 120,000-row stress regression.
- DuckDB latency metrics: bounded-window regression.
- Full Node test suite: see `VALIDATION_REPORT.md`.
