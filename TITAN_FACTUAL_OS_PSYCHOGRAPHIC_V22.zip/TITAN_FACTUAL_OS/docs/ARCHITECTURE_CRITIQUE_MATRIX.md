# TITAN FACTUAL OS — Architecture critique, repository matrix and implementation status

**Review date:** 2026-11-22  
**Scope:** the supplied original connector package plus the current TITAN FACTUAL OS codebase.  
**Decision rule:** adopt proven design patterns when they solve an evidenced problem; do not add a framework just because it is popular. Repository star counts are discovery snapshots, not quality scores.

## Executive review

The latest GitHub repository comparison (verified search floors, not stale exact counts) is recorded in `docs/REPOSITORY_STAR_REVIEW_MATRIX.md`; the final adversarial review is in `docs/FINAL_REPOSITORY_REVIEW_2026-11-22.md`.


The right direction is to keep the original source-specific acquisition handlers and improve the surrounding contracts, state, data quality, temporal lineage and analytical products. The present code protects the 79 original connector registrations and parser/endpoint behavior with regression tests. It also has a lightweight modular control plane, SQLite operational metadata, DuckDB analytics and Parquet snapshots. That is a better fit for a free-first data factory than immediately importing a distributed scheduler, message broker, lakehouse framework or Python ML stack.

The most consequential correctness changes in this review are:

1. **The Gold pivot now selects the newest observation among alternative source indicators**, using period year, assertion timestamp and deterministic indicator priority. The previous `COALESCE` over a fixed source list could select an older preferred-source value even when an alternative source had fresher evidence.
2. **The Brand Market calculation no longer invents default values.** Missing or out-of-range fields produce `null` components; missing, undated, stale or mixed-period data withhold the composite Market Attractiveness Index.
3. **Estimated internet-user population is withheld unless population and internet observations are recent and within three years of each other; it is not presented as an artist audience estimate.** Invalid percentages or population values are rejected.
4. **Market-context signals are not presented as measured psychographics.** The macro proxy model is retained inside profile `2.2.0`, uses six explicitly named contextual signals and nine validated aggregate indicators; Gini is excluded from price/value/pressure signals, exposes per-signal evidence coverage, rejects invalid input ranges and preserves the year of every evidence item.
5. **The dashboard remains in development visibility mode.** All stored data remains visible regardless of commercial rights metadata; no source or observation has been removed or filtered out. A future external-serving policy must be implemented separately.

The remaining critical work is not hidden by these improvements: the application still needs a real dependency-resolved production build and end-to-end runtime validation; connectors need controlled live verification; the territorial dimension is not yet a global high-coverage dataset; polygon-level spatial allocation and end-to-end streaming remain incomplete; and there are no actual representative survey connectors or validated psychographic profiles.

## Architecture critique matrix

Scores indicate the present maturity of the evidence-backed implementation, not the theoretical potential of the design. A low score can reflect an unverified dependency or missing real-world dataset rather than a poor architecture decision.

| Area | Reference projects reviewed | Current design / decision | Maturity | Finding and next action |
|---|---|---|---:|---|
| Original connector preservation | Airbyte, dlt | Keep original 79 connector handlers, function names, source IDs, parsers and endpoint literals; test against an original-package manifest | 9.5 | Strong regression contract. Still requires live execution per source; static preservation is not proof of successful capture |
| Connector lifecycle and readiness | Airbyte, dlt | Explicit protocol/access/readiness planner, source inventory and source-specific execution | 8.0 | No generic connector replacement. Add automated live health runs, per-source pagination fixtures, freshness and row-count QA |
| Incremental state and idempotence | dlt, Airbyte | Durable run ledger, observation identity, lease ownership, checkpoints and snapshot promotion | 8.0 | Unit-tested state semantics; application DB integration and crash/restart test remain open |
| Retry and HTTP reliability | Airbyte patterns, Node stream APIs | Bounded retry, jitter, `Retry-After`, timeout through body consumption, cancellation and request identity | 8.5 | Focused tests exist. Add controlled integration tests against slow, partial and throttling test servers in the packaged app |
| Operational Control Plane | Dagster, dbt | Modular TypeScript control plane with source/domain/territory registries, run state and policies | 8.0 | Avoids premature orchestration infrastructure. Need DB migration, restart and concurrency tests with the actual dependencies installed |
| Storage and analytics | DuckDB, GeoParquet | SQLite for operational metadata; DuckDB and Parquet for analytics and persistent snapshots | 8.0 | Good simplicity/performance fit. Runtime dependency and real read/write/migration validation remain unverified in this environment |
| Gold pivot freshness | dbt, DuckDB | Latest observation chosen across all candidate indicator IDs by period, assertion time and deterministic preference | 8.5 | Fixes a concrete stale-source precedence bug. Add DuckDB integration test when runtime package is available |
| Time-series provenance | dbt, Dagster | Per-indicator observation-year columns for key analytical indicators, plus temporal status in Brand Market | 8.0 | Added source-years to 12 Gold metrics and profile evidence. Other indicators can be extended as needed |
| Schema and runtime contracts | Zod, Pandera | Zod-based observation/source contracts and explicit TypeScript interfaces | 8.5 | Strong direction. Full compiler type-check remains blocked by missing installed dependencies |
| Data quality | Great Expectations, Pandera, scikit-learn | Bounded input validation, null handling, coverage contracts, deterministic tests and per-source QA | 8.0 | More source-specific distribution, outlier, cross-field and time-series rules are still required |
| Missing data and index integrity | scikit-learn, Pandera | No silent imputation in MAI or market-context signal inputs; composites require declared minimum evidence | 8.5 | Prevents invented scores. Normalization anchors and weights remain heuristic, not outcome-validated |
| Market Attractiveness Index | scikit-learn, DuckDB | MAI v2.1.0 uses five required inputs, freshness gates and transparent mass/premium weighting; Gini is descriptive only | 7.5 | No observed-outcome calibration. Explicitly removed the unsupported assumption that inequality increases premium opportunity or decreases mass-market opportunity; still a research-prioritization heuristic only |
| Market-context / psychographic evidence | scikit-learn, pandas, Polars, Prince, HDBSCAN, UMAP, R survey | Six macro proxies remain separate from harmonized question-level weighted survey measures, distributions, uncertainty, sample quality and license flags | 7.5 | Survey-to-Silver-to-query-to-UI path is connected and tested. No respondent-level persona clustering or psychographic validation is claimed; survey connectors/data coverage and out-of-sample validation remain open |
| Survey evidence | WVS, ESS, EVS, Afrobarometer, Latinobarómetro, ISSP; R survey methodology | Explicit question harmonization, weighted mean + answer distribution, sample/effective n, first-stage Taylor PSU intervals where supported, fieldwork/rights metadata | 5.5 | Import/estimation/Silver/Gold/UI path now exists. No provider connector or actual survey dataset is activated by default; current variance method is narrower than full complex-survey packages |
| Behavioral evidence | Umami, ListenBrainz | Separate behavior/acquisition signals from representative survey evidence | 4.0 | Existing source inventory includes some listening/digital context indicators, but no unified, population-representative behavior model. Add only after coverage and denominator definitions |
| Causal inference and explainability | DoWhy, SHAP | Do not infer causality; defer feature attribution until a predictive model and holdout set exist | 2.0 | Deliberately not implemented. A correlation or proxy index must not be presented as cause or explainable prediction |
| Geospatial indexing | H3 | H3 cells explicitly identify country-centroid assignment basis | 6.0 | Correctly avoids claiming polygon overlay. Add verified geometry and point/polygon operations before local allocation claims |
| Geographic harmonization | geosnap, GeoPandas | Current model preserves territorial identity and country/continent aggregates | 4.0 | Temporal boundary harmonization, crosswalks and subnational unit compatibility remain open because spatial inputs are incomplete |
| Global territorial coverage | ISO/M49 and country registry standards | Registry readiness blocks global-coverage claims until broad registry and per-source expected-territory manifests exist | 3.0 | README records 34 enriched seed countries, below a 190-country threshold. Expand canonical territories and configure expected sets source by source |
| GeoParquet / remote spatial ingestion | GeoParquet, DuckDB | Overture is labelled as STAC discovery rather than complete remote GeoParquet ingestion | 3.0 | Remote GeoParquet ingestion, geometry validation and object-store streaming remain incomplete |
| End-to-end streaming | Node streams, dlt | NDJSON writer respects backpressure and temp-file cleanup | 5.0 | Handlers still materialize raw and Silver arrays in memory. Move connector contracts to async iterables/batches only with per-handler compatibility tests |
| API access security | Express/Node security patterns, Zod | Admin write guard requires strong token in production and checks origin/fetch metadata | 7.0 | Policy unit tests pass. Shared bearer token is not identity/role management; add SSO/reverse proxy, rate limits, rotation and end-to-end authorization tests |
| Commercial data rights | Dataset-specific source terms | All data stays visible internally; rights metadata remains attached; composite license clearance is `unknown` | 5.0 | This is not legal certification. Do not turn on external serving until rights trace through sources, derivatives, APIs, exports, caches and downloads |
| Build and deployment verification | scikit-learn/TypeScript CI practice; GitHub Actions | Dependency-free tests and syntax transpilation are available | 5.0 | Full package install, `tsc --noEmit` and Vite build are still blocked by package-registry availability. Must pass in CI before production |
| Operations and recovery | Dagster, SQLite WAL/DuckDB docs | Durable leases, manifests, maintenance guards, retries and DLQ foundation | 6.5 | Need full backup/restore, persistent-volume, retention, monitoring and incident-recovery tests |

> **Current repository-star source of truth:** older exact star figures in this document are historical snapshots only. Use `REPOSITORY_STAR_REVIEW_MATRIX.md` for GitHub `stars:>N` search floors verified on 2026-11-22; star count is not a substitute for domain-method fit or license review.

## Repository shortlist — why these were used

Star counts below are the repository snapshots recorded during this review. Licenses are repository-level metadata and should be rechecked before copying code or redistributing any asset.

| Repository | Stars snapshot | License | Best-fit role | Applied decision |
|---|---:|---|---|---|
| [scikit-learn/scikit-learn](https://github.com/scikit-learn/scikit-learn) | 68,291 | BSD-3-Clause | Feature processing, scaling, clustering evaluation | Borrow explicit transforms/evaluation discipline; do not introduce a separate Python service for six deterministic indices |
| [colinhacks/zod](https://github.com/colinhacks/zod) | ~44,300 | MIT | Type-safe runtime validation | Keep as an existing lightweight TypeScript dependency |
| [duckdb/duckdb](https://github.com/duckdb/duckdb) | 43,241 | MIT | SQL analytics, Parquet and in-process query execution | Keep as the analytical engine; improve latest-indicator pivot semantics |
| [umami-software/umami](https://github.com/umami-software/umami) | 40,298 | MIT | Privacy-conscious web analytics/event modeling | Treat observed digital behavior as its own evidence class |
| [shap/shap](https://github.com/shap/shap) | 25,888 | MIT | Model explanation | Defer until a predictive model is supported by representative, held-out outcomes |
| [airbytehq/airbyte](https://github.com/airbytehq/airbyte) | 22,431 | NOASSERTION | Connector development, sync state and readiness | Use semantics as review criteria; preserve existing connector functions rather than importing its runtime |
| [dagster-io/dagster](https://github.com/dagster-io/dagster) | 16,457 | Apache-2.0 | Asset lineage, orchestration and observability | Adopt asset/lineage thinking; no scheduler added |
| [dbt-labs/dbt](https://github.com/dbt-labs/dbt) | 14,201 | Apache-2.0 | Transform models, tests and lineage | Adopt explicit transformation provenance; no dbt runtime added |
| [great-expectations/great_expectations](https://github.com/great-expectations/great_expectations) | 11,900 | Apache-2.0 | Data quality expectations/checkpoints | Applied as QA design reference, not a runtime dependency |
| [py-why/dowhy](https://github.com/py-why/dowhy) | 8,410 | MIT | Causal inference | Used as a guardrail: association is not causation; causal models deliberately not added |
| [uber/h3](https://github.com/uber/h3) | 6,759 | Apache-2.0 | Hierarchical spatial indexing | Keep explicit spatial basis; current H3 assignment is centroid based |
| [dlt-hub/dlt](https://github.com/dlt-hub/dlt) | 6,118 | Apache-2.0 | Ingestion state, incremental loading and normalization | Use idempotency/checkpoint patterns without adding framework overhead |
| [geopandas/geopandas](https://github.com/geopandas/geopandas) | not snapshotted | BSD-3-Clause | Vector geometry, overlays and spatial joins | Candidate after authoritative boundaries are present; no dependency in this release |
| [unionai-oss/pandera](https://github.com/unionai-oss/pandera) | 4,533 | MIT | Dataframe schemas and statistical data quality | Use validation concepts; Zod/TypeScript remains canonical |
| [scikit-learn-contrib/hdbscan](https://github.com/scikit-learn-contrib/hdbscan) | 3,160 | BSD-3-Clause | Density clustering with outlier handling | Defer; country macro rows are not valid psychographic micro-segmentation input |
| [opengeospatial/geoparquet](https://github.com/opengeospatial/geoparquet) | 1,110 | Apache-2.0 | Geospatial columnar interchange | Interoperability reference for a later geometry-complete spatial plane |
| [oturns/geosnap](https://github.com/oturns/geosnap) | 272 | BSD-3-Clause | Geodemographic harmonization and regionalization | Specialized reference for boundary/time harmonization; not a dependency |

## Implementation and regression checklist

- [x] Preserve the original 79 connector IDs and registered handlers in original order.
- [x] Preserve original source-specific parser/extraction logic and 103 original endpoint string literals using the preservation fixture.
- [x] Keep all Silver source previews and dashboard Gold queries visible regardless of `commercial_use_allowed`; do not activate the future serving gate.
- [x] Keep composite Brand Market `license_clearance=unknown` unless all contributing rights are actually verified.
- [x] Carry per-indicator years into the Gold macro feature row for twelve key indicators.
- [x] Choose newest value across alternative indicator IDs rather than a static `COALESCE` preference.
- [x] Reject invalid market index inputs; never impute a missing MAI component.
- [x] Withhold MAI v2.1.0 composite when any of its five inputs is missing/invalid or not recent and time-aligned; Gini is descriptive only and excluded from score weights.
- [x] Use six model-2.2.0 market-context signals; preserve evidence, period year, invalid-field list and temporal metadata.
- [x] Require at least two evidence inputs for multi-input signals and expose per-signal evidence coverage.
- [x] Add deterministic tests for missingness, invalid ranges, temporal status and MAI behavior.
- [x] Update README and model documentation to remove outdated five-signal and commercial-filter statements.
- [ ] Install dependencies and run full TypeScript compiler/type-check.
- [ ] Run Vite production build and browser smoke test.
- [ ] Run actual DuckDB SQL/materialization and SQLite migrations against the installed application dependencies.
- [ ] Execute and validate the 79 connectors in live controlled batches, preserving source pagination and capture completeness.
- [ ] Expand the enriched territory dimension and configure per-source expected territory manifests.
- [ ] Add real survey and representative behavior connector/data coverage with reviewed terms.
- [ ] Implement end-to-end asynchronous/batched connector streaming.
- [ ] Implement polygon and boundary harmonization with authoritative geometries.
- [ ] Add identity-aware external serving, commercial rights enforcement and operational restore/monitoring before public deployment.

## Final assessment

The code has materially improved correctness and auditability, especially around preserving connectors, showing all internally acquired data, choosing the freshest indicator source and preventing unsupported composite scores. It is **not** yet a fully verified production data factory or a validated psychographic segmentation product. Remaining blockers are listed explicitly above; they should not be hidden behind star counts, code volume or the current unit-test pass.
