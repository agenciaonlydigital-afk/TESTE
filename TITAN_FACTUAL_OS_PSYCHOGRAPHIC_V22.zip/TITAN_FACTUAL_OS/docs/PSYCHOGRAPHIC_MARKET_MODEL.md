# TITAN — Psychographic market evidence

## Purpose and non-claims

This feature keeps two distinct evidence layers: **measured question-level survey estimates**, when eligible harmonized survey aggregates have actually been ingested, and **market-context hypotheses** derived from aggregate demographic, socioeconomic and infrastructure indicators. It is not yet a validated psychographic segmentation system. It does not infer personality, beliefs, cultural taste, music preference, motivation, willingness to pay, individual behavior or the percentage of a population that belongs to a segment.

A question-level survey measure is not a latent persona, individual profile or population-segment share. When no qualifying survey observations exist for a territory, its profile remains proxy-only. Macro context signals are always labeled separately and are never presented as measured psychographics.

## Psychographic profile model version 2.2.0 — measured survey evidence + six macro context signals

| Signal | Inputs and weights | Normalization / direction | Minimum evidence | Intended use (hypothesis only) |
|---|---|---|---:|---|
| Digital connectivity and discovery context | Internet users 40%; mobile subscriptions per 100 people 35%; urbanization 25% | All normalized to 0–100; mobile subscriptions capped at scale reference 200 per 100 | 2/3 | Decide where digital distribution and mobile-first experiments are feasible; does not measure actual platform use or music discovery |
| Economic price/value context | GDP/capita PPP inverse 50%; CPI inflation 25%; unemployment 25% | PPP scale 0–80,000 Int$ (inverse); inflation 0–15%; unemployment 0–20% | 2/4 | Form hypotheses for entry price, bundles and value communication; not observed price elasticity or ability to pay |
| Urban and connected cultural-access context | Urbanization 55%; internet users 45% | Percent scales 0–100 | 2/2 | Assess distribution/access feasibility; does not measure cultural participation, venue availability or interest |
| Economic-pressure context | GDP/capita PPP inverse 40%; CPI inflation 30%; unemployment 30% | Same scales as above | 2/4 | Identify markets for tests with lower barriers to entry; not an individual financial diagnosis |
| Age structure and demographic-transition context | Median age inverse 65%; total fertility rate 35% | Median age scale 15–55 years (inverse); TFR 0–6 births/woman | 2/2 | Decide where detailed cohort and population studies are useful; does not infer age-based preferences |
| Human-development context | UNDP HDI 100% | Published index 0–1, mapped to 0–100 | 1/1 | Supply broad structural context; HDI is not a cultural or psychological measure |

All component scores use bounded, deterministic transforms. A weighted score is renormalized over available evidence only when it has at least the minimum number of inputs shown above. One input is not enough to publish a composite for a multi-input signal. Each signal returns its available/expected evidence count and coverage so partial scores are visible. Multi-input signals require at least two valid indicators; a signal score is withheld unless its own evidence dates are complete, no more than five years old and span at most three years.

Signal score bands: 0–33 = low, 34–66 = moderate, 67–100 = high. These are descriptive buckets for the normalized index, not statistical confidence bands, population percentiles or segment sizes. The MAI weights, price-stability overlay and scale anchors are **heuristic product rules**, not empirically estimated coefficients. They should be recalibrated only against independent, representative outcome data, with a documented evaluation set and change history.

## Market Attractiveness Index (MAI) methodology v2.1.0

The MAI is a bounded research-prioritization heuristic, not an expected-sales, market-share or revenue prediction. It uses five mandatory inputs: total population, urbanization rate, internet-use rate, GDP per capita PPP (2021 international dollars) and CPI inflation. All five must be in range, have valid observation years, be no more than five years old and span no more than three years. GDP per capita PPP must be greater than zero. Gini is displayed separately as descriptive inequality context and does not affect the score or any price/value/pressure proxy signal.

- Demographic/access component: population scale is transformed on a log10 scale from 10,000 to 1 billion people and combined additively with urbanization (25%) and internet use (30%); population scale weight is 45%. The additive construction avoids assuming the same people are simultaneously represented by the urban and internet percentages.
- Purchasing-power component: GDP per capita PPP is linearly normalized against a fixed reference of 80,000 2021 international dollars and bounded to 0–100.
- Inflation overlay: CPI inflation up to 3% receives a neutral multiplier of 1. Values above 3% progressively reduce the heuristic score using the documented reciprocal penalty. It is a macro stability proxy, not a causal estimate.
- Mass-market mode: 45% demographic/access and 55% purchasing power before the inflation overlay.
- Premium mode: 25% demographic/access and 75% purchasing power before the inflation overlay.

Weights, anchors and the 3% inflation reference are judgmental product assumptions; they are not inferred from customer outcomes or established as universal economics. They must be recalibrated against independent, representative market outcomes before the score is used for investment, spend allocation or commercial forecasting. The score is withheld, not imputed, when required data is incomplete or temporally incomparable.

## Input validation, missingness and temporal quality

The model uses nine indicators: median age, GDP per capita PPP, urbanization, internet access, CPI inflation, unemployment, mobile subscriptions per 100 people, HDI and total fertility rate. Gini remains visible as descriptive macroeconomic context but is deliberately excluded from consumer price/value/pressure signals because inequality does not measure individual price sensitivity or purchasing behavior.

- Every input has a broad plausibility range. Values outside the range are excluded and listed in `invalid_fields`; they are not clipped into apparently valid observations.
- Missing values are never imputed. `data_coverage_pct` is the fraction of the nine indicators with valid observed values; it is not population coverage or model confidence.
- Every observation carries `period_year`. The profile exposes temporal coverage, oldest/newest year, and span.
- Temporal status is `incomplete` when dates are missing or values were rejected, `stale` when the newest observation is more than five years old, `mixed_periods` when valid observations span more than three years, `aligned` when all available values have dates within a three-year range and the newest is no more than five years old, and `unknown` when there is no evidence.
- A status describes period metadata, not source quality, representativeness, accuracy, or causal validity.
- Market Attractiveness Index (MAI v2.1.0) uses five required fields (population, urbanization, internet access, PPP and CPI inflation). Gini remains visible as descriptive inequality context but is deliberately excluded from the score: a national inequality statistic does not justify assuming either greater premium opportunity or lower mass-market opportunity. The composite is withheld unless all five fields are valid and dated, all are within the recency limit, and the period range is at most three years. Component fields and missing-year diagnostics remain available.
- The MAI demographic component combines population scale, urbanization and internet-use rate additively. It deliberately does not multiply urbanization by internet penetration, which would imply an unobserved joint distribution/independence assumption.
- The `digital_addressable_pop` field (shown as estimated internet users in the dashboard for backward-compatible API naming) is emitted only when population and internet-use observations have valid recent years within three years of each other. It is population multiplied by internet penetration: an estimate of internet-using residents, not an observed audience count, music audience or addressable customer market.

## Evidence classes and validation

`evidence_type=aggregated_demographic_proxy` identifies the macro-proxy layer. `survey_evidence_count` is the number of independently validated question-level survey measures attached to a territory (zero when none qualify), while `validation_status=survey_validation_required` remains explicit until representative, comparable evidence passes validation. Behavioral evidence (platform analytics, listening, event attendance, page views, transactions) must have its own source type, population definition, observation window and sampling/coverage metadata. It must never be silently relabelled as representative survey evidence.

### Measured survey evidence path

The CSV path requires explicit question-to-construct mappings with a versioned canonical scale, final respondent weights, and source/methodology/license context supplied by the caller. It transforms reverse-coded and categorical answers only through the explicit mapping; respondent identifiers are not retained. The estimator emits one final-weighted mean and a separate weighted response-share row for each answer category. When stratum and PSU identifiers are available, first-stage Taylor linearization uses a with-replacement PSU approximation; intervals are withheld for missing design metadata and singleton strata. This is deliberately not presented as equivalent to the full `survey` R package, and does not implement FPC, replicate weights, multistage corrections, nonresponse adjustment, calibration/raking, or domain estimation.

The query layer reads only complete survey schemas from Silver Parquet, deduplicates snapshots deterministically, and attaches only observations that share survey, wave, question, construct, scale, mapping version, source, dataset and methodology. A question appears only if its single weighted-mean row and response categories are compatible; weighted shares must sum to 100% and reproduce the weighted mean within rounding tolerance. Survey scores are normalized to 0–100 solely within the declared canonical scale. The UI displays weighted mean, normalized index, confidence interval, sample/effective sample size, response distribution, fieldwork, methodology, source and license flags. The six aggregate proxies remain a visibly separate section.

No respondent-level clustering or persona generation is executed: the importer intentionally removes respondent identifiers and only retains aggregate question evidence. This avoids pretending that a handful of national aggregates identify latent population segments. The next methodological step, when licensed respondent-level files are available, is MCA/FAMD or other design-aware latent-structure exploration with held-out validation—not running HDBSCAN/UMAP on country-level macro rows.

Potential future survey sources include [World Values Survey](https://www.worldvaluessurvey.org/), [European Social Survey](https://www.europeansocialsurvey.org/), [European Values Study](https://europeanvaluesstudy.eu/), [Afrobarometer](https://www.afrobarometer.org/), [Latinobarómetro](https://www.latinobarometro.org/) and [ISSP](https://www.issp.org/). They are not active survey connectors in this package. Before implementing each connector, verify the current access route, wave/question dictionary, country coverage, fieldwork, target population, sampling, weights, missingness, license, retention and redistribution terms. WVS data access and redistribution are subject to its own conditions; a public website or downloadable dataset is not evidence of commercial redistribution permission. Do not bundle survey microdata unless the specific terms permit it.

For a future measured segmentation layer:

1. Use harmonized, comparable constructs/questions; do not combine semantically different questions because labels look similar.
2. Preserve wave, questionnaire version, target population, sampling frame, fieldwork dates, weights, strata/clusters and effective sample size.
3. Estimate uncertainty and design effects; do not treat survey counts as simple population counts.
4. Test calibration and subgroup/territory error on held-out waves/countries; document nonresponse and missing-data handling.
5. Measure temporal drift before carrying a profile forward.
6. Validate segment stability and interpretability before naming personas.
7. Keep ecological aggregates separate from person-level records; prohibit inference of sensitive traits and individual-level targeting from country averages.
8. Apply clustering only when sufficiently granular and comparable survey/behavior observations exist. Do not cluster a handful of country-level macro rows and call the clusters psychographic personas.

> **Current repository-star source of truth:** older exact star figures in this document are historical snapshots only. Use `REPOSITORY_STAR_REVIEW_MATRIX.md` for GitHub `stars:>N` search floors verified on 2026-11-22; star count is not a substitute for domain-method fit or license review.

## Repository research and applied decisions

Repository metadata were fetched from the GitHub repository API and selected READMEs/package metadata were inspected on 2026-11-22. Star counts are exact snapshots at retrieval time and change over time. The shortlist records popular general tools and smaller domain-specialist references; popularity is not treated as methodological proof.

| Repository | Stars at review | License | What was adopted / decision |
|---|---:|---|---|
| [scikit-learn/scikit-learn](https://github.com/scikit-learn/scikit-learn) | 68,294 | BSD-3-Clause | Highest-adoption general ML baseline for explicit transforms, model validation and future segmentation evaluation. No clustering is run on country aggregates. |
| [pandas-dev/pandas](https://github.com/pandas-dev/pandas) | 50,603 | BSD-3-Clause | Mainstream data-table/reference implementation; the app's TypeScript contracts remain canonical. |
| [pola-rs/polars](https://github.com/pola-rs/polars) | 40,438 | MIT | Stronger high-performance/lazy dataframe candidate, with Node.js bindings documented upstream. Not added because the current output is small aggregate survey data and a native dependency/build path is not justified yet. |
| [scipy/scipy](https://github.com/scipy/scipy) | 15,241 | BSD-3-Clause | Numerical/statistical foundations reference; existing bounded deterministic TypeScript estimators stay in the current runtime. |
| [statsmodels/statsmodels](https://github.com/statsmodels/statsmodels) | 11,763 | BSD-3-Clause | Statistical inference/econometrics reference, but not a substitute for complex-sample design handling. |
| [py-why/dowhy](https://github.com/py-why/dowhy) | 8,410 | MIT | Guardrail to keep association separate from causality; no causal claims/model added. |
| [lmcinnes/umap](https://github.com/lmcinnes/umap) | 8,339 | BSD-3-Clause | Visualization/dimensional-reduction candidate only after comparable respondent-level features exist; not used on territory macro rows. |
| [scikit-learn-contrib/hdbscan](https://github.com/scikit-learn-contrib/hdbscan) | 3,160 | BSD-3-Clause | Strong density clustering option for variable-density groups and noise; deferred until suitable microdata, survey design and stability evaluation exist. |
| [raphaelvallat/pingouin](https://github.com/raphaelvallat/pingouin) | 1,947 | GPL-3.0 | Reviewed as a compact statistical package; not adopted due to GPL license considerations and no need for a Python runtime. |
| [MaxHalford/prince](https://github.com/MaxHalford/prince) | 1,490 | MIT | Best-fit specialist reference in this set for MCA/FAMD/PCA on categorical/mixed survey data; supports row/column weights and supplementary variables. Use only when respondent-level harmonized matrices and validation data are actually available. |
| [gergness/srvyr](https://github.com/gergness/srvyr) | 224 | R package / GPL-2+ | Tidy front end to complex-survey summaries; useful workflow reference, not a TypeScript dependency. |
| [cran/survey](https://github.com/cran/survey) | 28 | GPL-2 or GPL-3 | Specialist methodology benchmark, not a popularity contest: complex survey samples, Taylor and replicate-weight variance, post-stratification, calibration/raking and multistage designs. Current TypeScript first-stage approximation is explicitly narrower. |

No new third-party runtime dependency was added. Popularity informed discovery, but method fit, license, runtime cost and the current absence of respondent-level microdata determined what was actually used. Polars is the strongest faster dataframe candidate for a future Node batch worker; Prince is the more targeted mixed-categorical survey-analysis reference; `survey` remains the domain specialist for complex-design estimation. HDBSCAN and UMAP are deferred until individual-level, comparable survey/behavior variables are available.

## Known limitations and release criteria

- This release implements the harmonized survey import, weighted-mean/distribution estimation, Silver observation conversion, Parquet query path and UI rendering, but does not ship an activated external survey connector or survey microdata. Territories without qualifying Silver survey rows correctly keep survey evidence count at zero.
- Available macro indicators are country-level and uneven in geographic/temporal coverage. Country averages hide within-country heterogeneity.
- Demographic proxies cannot establish music taste, values, attitudes, preferences, event participation, purchase intent or price elasticity.
- Data coverage is not the same as evidence quality. Each source still requires source-specific freshness, sample, methodology and license review.
- `license_clearance` for a composite profile remains `unknown`. Current development dashboards and exports show all captured data; this is not permission for commercial redistribution.
- Before customer-facing commercial release, a separate policy must trace source/dataset rights through API responses, materialized Gold marts, exports, downloads and caches. Do not block internal ingestion or dashboard visibility to achieve this.

A measured psychographic feature should not be declared complete until the required survey/behavior sources are actually ingested, licensing is reviewed, geographic and temporal coverage is documented, out-of-sample evaluation is passed, and subgroup uncertainty is visible.
