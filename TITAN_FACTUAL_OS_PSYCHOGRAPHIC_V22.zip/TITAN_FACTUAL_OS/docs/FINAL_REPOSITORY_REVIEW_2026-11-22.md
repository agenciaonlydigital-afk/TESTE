# Final repository review — TITAN FACTUAL OS — 2026-11-22

## Scope and repository selection

Reviewed the latest TITAN_FACTUAL_OS package against high-adoption repositories with directly relevant capabilities. The current repository-star evidence is in `REPOSITORY_STAR_REVIEW_MATRIX.md`: GitHub Search `stars:>N` filters returned each listed higher-adoption repo on 2026-11-22. The floors are not exact counts. The specialist `survey`, `geoBoundaries` and `tobler` projects remain for domain relevance where general-purpose repositories cannot replace their methods or source data.

Firecrawl deep-research was attempted but could not run because the connected account had exhausted its credits. GitHub repository search and README inspection were used instead; this audit does not claim a Firecrawl crawl or a complete web deepsearch.

## Corrections made during adversarial review

### 1. Psychographic proxy scoring

- Removed Gini from `value_sensitivity` and `economic_pressure` inputs and scores.
- Gini stays in macroeconomic data as descriptive inequality context; it is not a direct measurement of purchasing behavior, price sensitivity or financial pressure.
- Retained the six signal names, but these remain contextual hypotheses based on nine aggregate demographic/economic indicators, not measured attitudes or validated personas.
- Model version remains `2.1.0`; missing indicators remain visible and are not imputed.

### 2. Historical geographic crosswalk correctness

- Validated allocation weights by active year intervals, rather than summing mutually exclusive historical mappings together.
- Allows the same source-target pair to be reused in non-overlapping intervals; overlapping intervals are rejected.
- Filters mapping rows by the observation's `period_year` and rejects years with no active mapping.
- Includes `period_year` in the allocation output identity, so distinct years never collapse into a single result.
- Retains strict finite-number, denominator and allocation-basis checks. Weights are externally supplied/provenanced; the helper does not derive population shares from geometry.

### 3. Survey fieldwork interval

- Both fieldwork dates must be valid ISO calendar dates.
- `fieldwork_start` must be on or before `fieldwork_end`; malformed or reversed intervals are rejected before the canonical observation is returned.

### 4. Geometry correctness boundary

- `validateAreaGeometry` is documented as a lightweight structural validator for the tested point-in-area predicate.
- It does not claim OGC topology validity: ring self-intersections, hole containment/overlap and polygon topology are not validated.
- The helper does not calculate overlays, area or population-weighted allocation, and is not currently wired into an end-user spatial analysis route. The preferred TypeScript library candidate for future actual geometry consumers is Turf; GEOS-backed Shapely/GeoPandas are strong offline QA/processing references.

## Integration status — do not overclaim

| Capability | Code status | App/runtime status |
|---|---|---|
| Survey weighted estimates and CSV harmonization | Domain helpers + tests | Not connected to active WVS/ESS/EVS/Afrobarometer/ISSP acquisition; no real microdata bundled |
| geoBoundaries catalog batch discovery | Metadata helper + tests | Not a geometry downloader; not yet wired to the dashboard/acquisition workflow |
| GeoJSON point-in-area | Lightweight predicate + tests | No robust topology validation/overlay and no current UI route consumer |
| Versioned boundary crosswalk allocation | Helper + tests | Requires externally sourced weights; not an area-intersection/population-weight derivation engine |
| Market-context proxy profiles | Used by Brand Market query | Six contextual proxies only; no measured psychographic segments |
| Internal dashboard/source visibility | Existing route/query behavior | Continues to display all internal observations regardless of commercial-rights metadata |

## Tests and verification

- Native Node test suite: **111 passed, 0 failed, 0 skipped**.
- Focused tests for survey analytics/import, proxy profiles, geometry, GeoBoundaries metadata/batch and crosswalks pass.
- The survey suite now includes a regression for reversed fieldwork dates.
- The crosswalk suite now covers historical non-overlapping periods, overlap rejection and separate output rows by year.
- The psychographic suite ensures Gini changes cannot alter the price/value or economic-pressure proxy scores.
- TypeScript syntax transpilation and import-resolution scans must be rerun after packaging; full app type-check and Vite build remain blocked when declared dependencies are not installed.

## Remaining release gates

1. Install exact declared dependencies and pass full `tsc --noEmit`, Vite production build and browser smoke test.
2. Run actual packaged DuckDB/SQLite integration, migrations, restart, recovery and persistent-volume tests.
3. Run all 79 existing connectors in controlled live batches with required credentials, recording pagination, completeness, freshness and parser outcomes.
4. Connect survey import and geoBoundaries helpers to deliberate acquisition workflows only after source access/terms, data dictionary, design weights and geographic coverage are verified.
5. Acquire geometry assets and implement robust topology, polygon overlay and population-weighted spatial harmonization using Turf/GEOS-backed tooling with reproducible tests.
6. Expand beyond the current 34 enriched country seed dimension and configure a source-specific expected-territory manifest before reporting global coverage.
7. Complete async iterable/batch processing end-to-end; connector handlers currently materialize arrays.
8. Before external commercial distribution, add a separate rights policy across derived data, APIs, caches, exports and downloads. Internal dashboard visibility remains unfiltered by design.

This review improves correctness and reduces overclaiming. It does not certify production readiness, live connector health, global representativeness or commercial redistribution rights.
