import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { createServer as createViteServer } from 'vite';
import { getActiveIngestionLocks, runCoreBatchIngestion } from './src/lakehouse/connectors.ts';
import {
  closeControlPlaneDb,
  getControlPlaneDb,
  listTerritories,
  updateTerritoryH3Cells,
} from './src/lakehouse/controlPlane.ts';
import {
  closeDuckDBInstance,
  computeTerritoryH3Cells,
  probeDuckDBCapabilities,
} from './src/lakehouse/duckdbEngine.ts';
import { ensureGoldMartsIfEmpty } from './src/lakehouse/goldMaterializer.ts';
import { invalidateQueryCache } from './src/lakehouse/queries.ts';
import { syncContinentHierarchyH3Cells } from './src/lakehouse/spatial/adminHierarchy.ts';
import { errorHandler, notFoundApiHandler } from './src/server/middleware/errorHandler.ts';
import { adminWriteGuardMiddleware, assertProductionAdminToken } from './src/server/middleware/adminWriteGuard.ts';
import {
  apiGzipCompressionMiddleware,
  securityHeadersMiddleware,
} from './src/server/middleware/securityAndCompression.ts';
import { createControlPlaneRouter } from './src/server/routes/controlPlaneRoutes.ts';
import { createGoldRouter } from './src/server/routes/goldRoutes.ts';
import { createIngestRouter } from './src/server/routes/ingestRoutes.ts';

const PORT = Number(process.env.PORT ?? 3000);
const IS_PROD = process.env.NODE_ENV === 'production';

async function bootstrapServer() {
  assertProductionAdminToken();
  const app = express();
  app.disable('x-powered-by');
  app.use(securityHeadersMiddleware);
  app.use(express.json({ limit: '2mb' }));

  let isShuttingDown = false;
  app.use('/api', (_req, res, next) => {
    if (isShuttingDown) {
      res.setHeader('Connection', 'close');
      res.status(503).json({ error: 'Server shutting down gracefully' });
      return;
    }
    next();
  });

  // Initialize SQLite WAL Control Plane synchronously on startup
  getControlPlaneDb();

  // Warm-up DuckDB probe + compute missing H3 Res 2/4 cells + materialize Gold marts non-blocking
  let duckdbVersion = 'initializing';
  probeDuckDBCapabilities()
    .then(async (info) => {
      duckdbVersion = info.version;
      if (info.h3) {
        const territories = listTerritories();
        const needsH3 = territories.filter((t) => !t.h3_res2 || !t.h3_res4);
        if (needsH3.length > 0) {
          const cells = await computeTerritoryH3Cells(needsH3);
          if (cells.length > 0) {
            updateTerritoryH3Cells(cells);
            invalidateQueryCache();
          }
        }
        await syncContinentHierarchyH3Cells();
      }
      await ensureGoldMartsIfEmpty().catch((err) => {
        console.error('Startup Gold Parquet materialization skipped:', err);
      });
    })
    .catch(() => {
      duckdbVersion = 'error';
    });

  // Optional overlap-safe background sync cron when ENABLE_CRON_SYNC=true
  let cronTimer: NodeJS.Timeout | null = null;
  if (process.env.ENABLE_CRON_SYNC === 'true') {
    const SIX_HOURS_MS = 6 * 60 * 60 * 1000;
    cronTimer = setInterval(() => {
      if (isShuttingDown || getActiveIngestionLocks().length > 0) return;
      void runCoreBatchIngestion().catch((err) => {
        console.error('Background Tier-0 core sync error:', err);
      });
    }, SIX_HOURS_MS);
    cronTimer.unref();
  }

  // --- API v1 Modular Routers (with native gzip compression) ---
  app.use('/api/v1', apiGzipCompressionMiddleware);
  app.use('/api/v1', adminWriteGuardMiddleware);
  app.use(
    '/api/v1',
    createControlPlaneRouter({
      getDuckdbVersion: () => duckdbVersion,
      isShuttingDown: () => isShuttingDown,
    })
  );
  app.use('/api/v1', createIngestRouter());
  app.use('/api/v1', createGoldRouter());
  app.use('/api', notFoundApiHandler);

  // --- Vite Dev Middleware or Static Production ---
  if (!IS_PROD) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    if (fs.existsSync(distDir)) {
      app.use(express.static(distDir));
      app.get('*', (_req, res) => {
        res.sendFile(path.join(distDir, 'index.html'));
      });
    }
  }

  app.use(errorHandler);

  const httpServer = app.listen(PORT, '0.0.0.0', () => {
    console.log(`TITAN FACTUAL OS listening on http://0.0.0.0:${PORT}`);
  });

  const gracefulShutdown = async (signal: string) => {
    if (isShuttingDown) return;
    isShuttingDown = true;
    console.log(`Received ${signal}; draining active lakehouse operations...`);

    if (cronTimer) clearInterval(cronTimer);

    httpServer.close(async () => {
      const deadline = Date.now() + 15_000;
      while (getActiveIngestionLocks().length > 0 && Date.now() < deadline) {
        await new Promise((r) => setTimeout(r, 250));
      }
      await closeDuckDBInstance();
      closeControlPlaneDb();
      process.exit(0);
    });

    setTimeout(async () => {
      await closeDuckDBInstance();
      closeControlPlaneDb();
      process.exit(0);
    }, 16_000).unref();
  };

  process.on('SIGTERM', () => {
    void gracefulShutdown('SIGTERM');
  });
  process.on('SIGINT', () => {
    void gracefulShutdown('SIGINT');
  });
  process.on('unhandledRejection', (reason) => {
    console.error('Unhandled Promise Rejection:', reason);
  });
  process.on('uncaughtException', (err) => {
    console.error('Uncaught Exception:', err);
  });
}

bootstrapServer().catch((err) => {
  console.error('Failed to start TITAN FACTUAL OS server:', err);
  process.exit(1);
});
