# TITAN FACTUAL OS — Arquitetura Enxuta de Alta Performance (Deep Search Ampliado, Runtime Único e Zero Superengenharia)

Este documento consolida a **revisão definitiva sem superengenharia**, incorporando novas descobertas técnicas sobre `@duckdb/node-api`, extensões nativas `httpfs`/`spatial`/`h3` no DuckDB, armadilhas reais de autenticação e paginação de APIs globais e simplificação espacial dinâmica. O resultado elimina infraestrutura redundante na **Wave 1** mantendo o caminho evolutivo limpo para **Wave 2**.

---

## Descoberta Arquitetural Central: Eliminando o Dual-Runtime na Wave 1

> [!IMPORTANT]
> **Corte Mais Importante Deste Ciclo**: A arquitetura anterior propunha manter **dois runtimes simultâneos** (Node.js/Express para API + Worker Python com Polars/PyArrow/Pandera). O *deep search* técnico confirmou que o cliente oficial **`@duckdb/node-api` (Neo)** em Node.js/TypeScript já carrega nativamente as extensões **`httpfs`**, **`spatial`** (`ST_Simplify`, `ST_AsGeoJSON`, `ST_Intersects`, `GeoParquet`) e a extensão comunitária **`h3`** (`h3_latlng_to_cell` com inteiros `UBIGINT`).

Com isso, na **Wave 1**, o DuckDB embarcado no próprio processo Node.js atua simultaneamente como:
1. **Motor de ETL Colunar e Espacial** (lendo CSVs/JSONs em *streaming*, agregando H3 e gravando Parquet `ZSTD` direto no disco/storage sem copiar tudo para a RAM do V8);
2. **Motor Analítico CQRS de Leitura** (consultando Parquet com *row-group pruning* e entregando JSON/`ST_AsGeoJSON` simplificado por zoom).

**Resultado Prático**: Zero Python, zero Redis, zero Spark, zero Iceberg JVM e zero servidor de tiles na Wave 1 — apenas **1 runtime (`Node.js + TypeScript`), 1 banco transacional embarcado (`SQLite WAL`) e 1 motor analítico vetorizado (`DuckDB` + arquivos `Parquet/GeoParquet`)**.

---

## 1. Autocrítica Severa Anti-Superengenharia (Wave 1 vs. Wave 2)

| Armadilha Identificada | Por que é Superengenharia Agora | Solução Enxuta — **Wave 1 (Núcleo Imediato)** | Gatilho Objetivo para **Wave 2 (Escala)** |
| :--- | :--- | :--- | :--- |
| **1. Dual-Runtime (Node.js + Python)** | Dois gerenciadores de pacote, dois containers e ponte de IPC antes de validar o núcleo econômico/demográfico. | **Runtime Único TypeScript/Node.js** com `@duckdb/node-api` + `zod` (contratos) + `SQLite WAL` (estado). | Adicionar sidecar Python (`rasterio`/`pypopRF`) **apenas** quando ingerir rasters GeoTIFF brutos pixel-a-pixel em escala. |
| **2. PMTiles + FlatGeobuf + TopoJSON** | Manter 3 pipelines de exportação de mapa antes mesmo da interface visual existir. | Armazenar geometrias em **GeoParquet 1.1** e servir recortes dinâmicos via **`ST_Simplify` + `ST_AsGeoJSON`** direto do DuckDB conforme o zoom. | Gerar arquivo **PMTiles** único **apenas** quando a UI WebGL ultrapassar 50.000 polígonos simultâneos no viewport. |
| **3. H3 Res 8 Planetário + Zarr v3** | Indexar ~690M de hexágonos globais no Dia 1 gera >100 GB sem demanda imediata por quarteirão. | **H3 Res 2 (Global) e Res 4/5 (Regional)** pré-agregados via `UBIGINT` no DuckDB; Res 7/8 sob demanda por país/cidade selecionada. | Ativar pipeline contínuo `COG/Zarr v3 -> H3 Res 8` apenas para mercados com tráfego pago hiperlocal ativo. |
| **4. Iceberg + Redis + OpenLineage Server** | Três serviços extras de infraestrutura para gerenciar poucos GBs de séries públicas. | **Manifesto de Snapshots no SQLite WAL** (ponteiro atômico `current_snapshot_id` + tabela `lineage_runs`) + Cache LRU em memória. | Migrar para **PostgreSQL + Redis + Iceberg/DuckLake** somente com múltiplos workers distribuídos ou >100 GB. |
| **5. GCRA Distribuído + Compaction de 1 GB** | Lua scripts no Redis e arquivos de 1 GB em tabelas nacionais de 20 MB quebram *partition pruning*. | **Token Bucket + Semáforo por Host** em memória com persistência de `cooldown_until`/`ETag` no SQLite; partições Parquet de **10–128 MB**. | Subir para GCRA em Redis e compaction de 256 MB–1 GB apenas em tabelas >10M de linhas (ex.: GDELT/Crossref completo). |
| **6. Custom ETL vs. Boilerplate Frágil** | Escrever parsers manuais de paginação e coerção de tipos em TypeScript sem schema gera código frágil. | Usar **DuckDB `read_csv_auto` / `read_json`** para inferência vetorizada + validação declarativa com **`zod`** antes da promoção. | Adotar orquestrador dedicado (`dlt` / Dagster) se o número de conectores heterogêneos passar de 30 fontes ativas. |

---

## 2. Matriz Consolidada das 26 Categorias Arquiteturais

| # | Categoria | Padrão Definido no TITAN FACTUAL OS | Regra Chave de Implementação |
| :--- | :--- | :--- | :--- |
| **01** | **Arquitetura de Software** | **Monólito Modular Hexagonal** | Domínios isolados por *Ports & Adapters* (`Catalog`, `Ingestion`, `Lakehouse`, `Geo`, `Economics`, `Branding`) no mesmo processo. |
| **02** | **Separação de Carga (CQRS)** | **Write-Side SQLite WAL / Read-Side DuckDB RO** | Escritas de estado/filas nunca travam leituras analíticas; API consulta arquivos Parquet imutáveis sem ORM. |
| **03** | **Formato de Lakehouse** | **Catálogo SQL + Parquet Imutável (Estilo DuckLake)** | Metadados e versões no SQLite WAL apontando para diretórios Parquet por `snapshot_id`, sem JVM/Avro. |
| **04** | **Armazenamento Tabular** | **Apache Parquet (`ZSTD`, Dictionary Encoding)** | Compressão `ZSTD` nível 3; ordenação por `(indicator_id, territory_id, period_start)` maximiza *Zone Map skipping*. |
| **05** | **Controle de Small Files** | **Particionamento por Módulo/Fonte (10–128 MB na W1)** | Nunca gravar 1 arquivo por país; consolidar lotes inteiros via `COPY (...) TO ... (FORMAT PARQUET, COMPRESSION ZSTD)`. |
| **06** | **Vetores Espaciais** | **GeoParquet 1.1 (`WKB` + `bbox` covering)** | Ordenação espacial por Hilbert/centróide permite que `ST_Intersects` pule *row groups* inteiros fora do viewport. |
| **07** | **Entrega Cartográfica Macro** | **DuckDB `ST_Simplify` + `ST_AsGeoJSON` (W1) → `PMTiles` (W2)** | Tolerância de simplificação proporcional ao nível de zoom reduz payload de 80 MB para <300 KB sem pré-gerar tiles. |
| **08** | **Entrega Cartográfica Micro** | **GeoJSON filtrado por `bbox` (W1) → `FlatGeobuf` (W2)** | Consultas locais retornam apenas polígonos dentro da caixa delimitadora do usuário. |
| **09** | **Rasters Demográficos** | **Bulk GeoTIFF/COG (W2) / Resumos CSV por ADM & Grade (W1)** | Evita baixar rasters de dezenas de GB na W1 usando tabelas pré-agregadas; COG via HTTP Range entra na W2. |
| **10** | **Cubos Climáticos** | **NASA POWER por Centroide H3 (W1) → `Zarr v3` (W2)** | Reduz chamadas climáticas em 99% consultando centroides H3 Res 4 representativos em vez de grades globais. |
| **11** | **Grade Global (DGGS)** | **Uber H3 via extensão nativa DuckDB (`UBIGINT`)** | Regra crítica: sempre agrupar por `UBIGINT` e só converter com `h3_h3_to_string()` na resposta; atenção à ordem **`(lat, lon)`** no `h3_latlng_to_cell`! |
| **12** | **Tuning DuckDB & Memória** | **Cap explícito de RAM e Threads** | Configurar `memory_limit` em **70% do container**, `threads` = vCPUs, `temp_directory` em disco e `preserve_insertion_order = false` em cargas pesadas. |
| **13** | **Control Plane** | **SQLite em modo `WAL` (`better-sqlite3`)** | ACID rápido para catálogo de fontes, ponteiro de snapshots, *watermarks*, `ETag` e estado de *Circuit Breakers*. |
| **14** | **Layout de Armazenamento** | **Hierarquia `bronze/` → `silver/` → `gold/` por `snapshot_id`** | Wave 1 usa disco/volume local estruturado; Wave 2 adiciona *prefix hashing* (`hash_prefix=xx/`) ao migrar para S3/R2. |
| **15** | **Ingestão Sem OOM** | **Stream HTTP para arquivo temporário + DuckDB `COPY`** | Node.js apenas transmite chunks via `stream.pipeline` para disco temporário; DuckDB lê e converte para Parquet em C++ fora do heap V8. |
| **16** | **Rate Limiting & Cidadania** | **Token Bucket + Semáforo por Host + `Retry-After`** | `Undici`/`fetch` com *keep-alive*, `Accept-Encoding: gzip, deflate`, backoff exponencial com *full jitter* e `User-Agent` identificável. |
| **17** | **Tolerância a Falhas** | **In-Flight Dedup + Circuit Breaker + SWR + DLQ** | Promessas idênticas concorrentes compartilham a mesma requisição; 3 falhas seguidas abrem o disjuntor e mantêm o snapshot anterior no ar. |
| **18** | **Sync Incremental** | **`If-None-Match` (`ETag`) + `If-Modified-Since` + `SHA-256`** | `304 Not Modified` aborta ETL imediatamente; arquivos idênticos pelo `SHA-256` não criam novo snapshot duplicado. |
| **19** | **Resolução de Entidades** | **Tabela Crosswalk `dim_territories` + Quarentena DLQ** | Mapeamento determinístico (`ISO2`, `ISO3`, `UN M49`, `Wikidata QID`, aliases); códigos órfãos vão para tabela de quarentena sem abortar o lote. |
| **20** | **Qualidade e Contratos** | **Contratos `zod` + QA Gate SQL no DuckDB** | Bloqueia promoção se contagem de linhas cair >20%, se cobertura territorial <98% ou se houver valores físicos inválidos. |
| **21** | **Linhagem e Versionamento** | **Snapshots Imutáveis + SCD-2 apenas em Séries Revisáveis** | Histórico garantido via `snapshot_id` no manifesto; bitemporalidade linha-a-linha (`asserted_at`) aplicada só onde há revisão retroativa (FMI/World Bank). |
| **22** | **Governança de Licenças** | **Policy Filter Obrigatório na Gold** | Coluna `commercial_use_allowed` (`confirmed`, `denied`, `unknown`) bloqueia automaticamente `GADM`, `Protected Planet` e `WTO TDF` em views comerciais. |
| **23** | **Cache e Latência** | **Cache L1 LRU em Memória + HTTP `stale-while-revalidate`** | Endpoints Macro servidos do L1 em <5 ms; consultas Micro vão ao DuckDB `READ_ONLY` com *row-group pruning* em <50 ms. |
| **24** | **Modelagem Econômica (P2)** | **Separação `Nominal` vs `Constant USD` vs `PPP`** | Proíbe soma entre bases monetárias distintas; calcula crescimento YoY, CAGR 5y, inflação acumulada, juros reais e índice Gini (WIID/PIP). |
| **25** | **Demografia Dasimétrica (P3)** | **UN WPP Bulk + Pirâmide Etária + Urbanização** | Preserva `methodology_id` separando projeções oficiais de estimativas espaciais; resolve a falha histórica do conector UN WPP sem token usando **Bulk CSV**. |
| **26** | **Ponte Branding, Ads & Social** | **Gold Feature Store `gold_market_profiles`** | Consolida poder de compra PPP, faixa etária dominante, idioma, fuso, moeda e estabilidade como semente pronta para futuras integrações OAuth (Meta/Google/TikTok Ads). |

---

## 3. Descobertas Críticas de APIs Keyless (Armadilhas Reais Resolvidas no Deep Search)

> [!CAUTION]
> **Descoberta Crítica sobre a ONU (UN WPP)**: O *deep search* confirmou que a API REST `population.un.org/dataportalapi` **exige token Bearer obrigatório** (motivo exato pelo qual conectores sem token retornam zero registros). **Solução Keyless**: Ingerir os pacotes oficiais **CSV Bulk Download** do *World Population Prospects (WPP)* e *World Urbanization Prospects (WUP)* diretamente via HTTP com `ETag` — zero autenticação e cobertura completa de 1950 a 2100.

Mapa tático verificado dos conectores **Tier 0 (100% utilizáveis agora sem chave paga ou cadastro bloqueante)**:

| Fonte (Módulo) | Endpoint / Modo de Coleta | Armadilha Oculta Descoberta | Regra Exata de Código |
| :--- | :--- | :--- | :--- |
| **World Bank WDI** (Econ/Demo/Saúde) | `api.worldbank.org/v2/country/all/indicator/{id}?format=json&per_page=1000` | **Retorna XML por padrão** se omitir `format=json`; resposta vem como array `[metadata, rows]` (não objeto); teto de `per_page=1000`; `per_page=50` se omitido. | Usar `mrnev=10` ou janela temporal, checar `metadata.pages`, manter `< 80 req/min` com *Token Bucket*. |
| **IMF DataMapper** (Economia) | `imf.org/external/datamapper/api/v1/{indicator}/{iso3}?periods=...` | Mais simples e leve que SDMX 3.0 para séries WEO; teto cortês `~10 req / 5s`. | Buscar por lista de indicadores WEO (`NGDP_RPCH`, `PCPIPCH`, `GGXWDG_NGDP`) em lotes de países; usar `1.5 req/s`. |
| **Eurostat** (Econ/Demo/Energia/Saúde) | `ec.europa.eu/eurostat/api/dissemination/...` (SDMX-CSV / JSON-stat) | Retorna `413 EXTRACTION_TOO_BIG` sem filtro temporal; atualiza 2×/dia. | Sempre enviar `c[TIME_PERIOD]=ge:2015` + `Accept-Encoding: gzip` + `If-None-Match` (`ETag`). |
| **UN WPP / WUP** (Demografia) | **CSV Bulk Download** (`population.un.org/wpp/` e `/wup/`) | API REST exige token; CSVs zipados têm centenas de MBs e quebram RAM se lidos em JS. | Baixar ZIP via *stream* para disco temporário, extrair e ingerir direto no DuckDB via `read_csv_auto(..., compression='gzip')`. |
| **Our World in Data (OWID)** (Multi) | `ourworldindata.org/grapher/{slug}.csv` + `.metadata.json` | Cada gráfico tem slug próprio; `.metadata.json` traz unidade e licença originais. | Usar como acelerador de séries já harmonizadas (energia, pobreza, Gini, alfabetização) com `ETag`. |
| **FAOSTAT** (Agro/Preços/Terra) | Open REST / Bulk ZIPs por domínio | Gateway bloqueia rajadas acima de 2 req/s. | Limitar a **2 req/s** na API ou baixar *Bulk CSV* por domínio via `ETag`. |
| **ILOSTAT** (Trabalho/Salários) | SDMX REST (`sdmx.ilo.org/rest`) | Payloads gigantes sem filtro de dimensão. | Filtrar por `startPeriod` e consultar *data constraints* antes da extração. |
| **WHO GHO** (Saúde) | OData REST (`$top=1000&$skip=N`) | Sem `$select`, traz dezenas de colunas nulas inflando JSON. | Sempre usar `$select=SpatialDim,TimeDim,NumericValue,Dim1` + GCRA/Token Bucket `2 req/s`. |
| **geoBoundaries** (Território) | REST API + GeoJSON (`ADM0`, `ADM1`, `ADM2`) | Polígonos brutos de alta resolução pesam >500 MB no navegador. | Ingerir uma vez no Silver como `GeoParquet 1.1`; no serving aplicar `ST_Simplify(geom, tol)` conforme zoom. |
| **Wikidata SPARQL** (Entidades) | `query.wikidata.org/sparql` | **Bloqueia HTTP 403 sem header `User-Agent` descritivo**; timeout rígido 60s. | Enviar `User-Agent` válido com contato; batches `VALUES` de 200 entidades; máx 2 conexões simultâneas. |
| **Crossref** (Ciência) | REST Works API (`cursor=*`) | Pool público cai para 1 req/s com concorrência 1. | Passar `mailto=...` no header/query para entrar no **Polite Pool** (3–10 req/s sem chave). |
| **Climate TRACE v7 & NASA POWER** | REST Público | NASA POWER pode limitar IPs que varrem grades pixel-a-pixel. | Consultar apenas centroides de `ADM1` ou `H3 Res 4` já filtrados para áreas povoadas. |
| **GDELT DOC/GEO 2.0** (Risco/Mídia) | REST API | Bloqueio `429` agressivo acima de 1 chamada a cada 5 segundos. | Travar conector em `0.2 req/s` (1 req / 5s) ou ler arquivos de 15 min via stream. |

---

## 4. Arquitetura Técnica e Estratégia de Código (Single-Runtime Wave 1)

### Diagrama da Arquitetura Definitiva (Zero Overengineering)

```text
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                       FONTES TIER 0 KEYLESS (REST + BULK CSV/ZIP)                      │
│  [World Bank ?format=json] [IMF DataMapper] [Eurostat SDMX-CSV] [UN WPP Bulk CSV]      │
│  [OWID Grapher .csv]       [FAOSTAT / ILOSTAT / WHO OData]      [geoBoundaries / Wiki] │
└───────────────────────────────────────────┬────────────────────────────────────────────┘
                                            │
                                            ▼
┌────────────────────────────────────────────────────────────────────────────────────────┐
│               NODE.JS / TYPESCRIPT — CAMADA DE INGESTÃO E PROTEÇÃO                     │
│  • Scheduler Cron + Jitter (±15%) + In-Flight Dedup Map (SHA-256 Promise Sharing)      │
│  • Per-Host Token Bucket + Semaphore + Retry-After Backoff + Circuit Breaker           │
│  • Conditional GET (If-None-Match / 304) + Stream Pipeline para Disco Temp (Zero RAM)  │
└───────────────────────────────────────────┬────────────────────────────────────────────┘
                                            │
               ┌────────────────────────────┴────────────────────────────┐
               ▼                                                         ▼
┌───────────────────────────────────────────┐ ┌──────────────────────────────────────────┐
│    CONTROL PLANE (SQLite em modo WAL)     │ │    DATA PLANE — DUCKDB + PARQUET LOCAL   │
│                                           │ │                                          │
│ • dim_data_sources (Tier, Rate, Licença)  │ │ [BRONZE] Raw Stream → Parquet ZSTD       │
│ • snapshot_manifest (UUIDv7, SHA256, Ptr) │ │          (DuckDB read_csv/read_json)     │
│ • circuit_breaker_state (cooldown, ETag)  │ │                 │ (Zod + SQL QA Gate)    │
│ • dim_territories (ISO/M49/QID Crosswalk) │ │                 ▼                        │
│ • lineage_runs (OpenLineage-ready JSON)   │ │ [SILVER] Fatos Normalizados (PPP/Nominal)│
└──────────────────────┬────────────────────┘ │          + GeoParquet 1.1 + H3 UBIGINT   │
                       │                      │                 │                        │
                       │                      │                 ▼                        │
                       └──────────────────────► [GOLD] Views Protegidas por Licença      │
                                              │        + gold_brand_market_profiles      │
                                              └─────────────────┬────────────────────────┘
                                                                │
                                                                ▼
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                     SERVING PLANE CQRS (EXPRESS + DUCKDB READ-ONLY)                    │
│  • Cache L1 LRU (<5 ms Macro) + DuckDB ST_Simplify/ST_AsGeoJSON (<50 ms Micro)         │
│  • Hooks Wave 2: PMTiles (WebGL >50k polys), COG/Zarr v3 (H3 Res 8), OAuth Social/Ads  │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

### Detalhamento Técnico do Código de Alta Performance (Wave 1)

1. **Zero Cópia no Heap do Node.js (Streaming → DuckDB C++)**:
   - Arquivos grandes (ex.: `UN WPP Bulk CSV`, `OWID`, `geoBoundaries`) nunca passam por `JSON.parse()` ou `csv-parse` em JavaScript. O Node.js faz apenas `Readable.fromWeb(res.body)` → `fs.createWriteStream(tmpPath)` calculando `SHA-256` em trânsito, e em seguida passa o caminho do arquivo para o DuckDB executar conversão multi-thread em C++ direto para Parquet `ZSTD`.
2. **Conexão Singleton `@duckdb/node-api` com Limites Travados**:
   - Instanciar com `threads` limitado às vCPUs físicas e `memory_limit` em **70% da RAM disponível**, carregando `httpfs`, `spatial` e `h3 FROM community` na inicialização, além de `SET http_proxy` explícito caso haja proxy de rede (já que `httpfs` ignora variáveis de ambiente HTTP padrão).
   - Manter `preserve_insertion_order = false` em jobs de ETL/compactação para reduzir pressão de memória.
3. **Resolução H3 Correta e Enxuta**:
   - Sempre armazenar células H3 como **`UBIGINT` (64 bits)** nas tabelas Silver/Gold; converter com `h3_h3_to_string()` apenas na borda JSON da API.
   - Validar em teste unitário a assinatura `h3_latlng_to_cell(lat, lon, res)` (**latitude primeiro, longitude depois**), evitando inversão silenciosa de coordenadas no globo.
4. **SCD-2 Seletivo e Governança de Licenças na Camada Gold**:
   - O versionamento de diretórios por `snapshot_id` no SQLite WAL cobre 90% das auditorias históricas sem inflar queries. Apenas a tabela `silver_economic_series` guarda `asserted_at` e `is_current` para rastrear revisões retroativas do FMI/World Bank.
   - Toda consulta servida para o futuro módulo de *branding*/comercial passa obrigatoriamente por views com `WHERE commercial_use_allowed = 'confirmed'`.
5. **Ponte Pronta para Branding, Tráfego Pago e Automação**:
   - O produto final da camada Gold (`gold_brand_market_profiles`) entrega por `territory_id` e `h3_res5`: PIB per capita PPP, faixa de renda disponível, pirâmide etária (coortes 18–24, 25–34, 35–54), taxa de urbanização, idioma oficial (`ISO-639`), moeda (`ISO-4217`) e fuso horário — chaves exatas para segmentação futura em Meta Ads, Google Ads, TikTok Ads e agendadores sociais via OAuth.

---

## 5. Experiência do Usuário e Direção Visual (Blueprint da Camada Futura)

Quando o projeto avançar da arquitetura para a camada visual, o console seguirá padrões de inteligência analítica de alta densidade:
- **Fluxo Macro → Micro**: Visão global por país/H3 Res 2 com transição fluida para H3 Res 4/5 e fronteiras `ADM1` via `ST_Simplify` dinâmico.
- **Estética e Tipografia**: Tema escuro/claro de alto contraste (`#0F172A` / `#FFFFFF`), regra de cor `60-30-10`, profundidade única com bordas de `1px`, fontes `Plus Jakarta Sans` + `DM Sans` + `JetBrains Mono` (`tabular-nums` obrigatório em todas as cifras), sem pílulas decorativas em metadados estáticos nem barras falsas de telemetria.

---

## 6. Plano de Execução Recomendado (Após Aprovação)

1. **Etapa 1 — Fundação do Control Plane & Crosswalk Territorial**: Criar schema SQLite WAL (`dim_data_sources`, `snapshot_manifest`, `circuit_breaker_state`, `lineage_runs`, `dim_territories`) e singleton `@duckdb/node-api` com `spatial` + `h3`.
2. **Etapa 2 — Motor HTTP Resiliente & Primeiros Conectores Tier 0**: Implementar `TokenBucket`, `In-Flight Dedup`, `ETag`, `Circuit Breaker` e *streaming* para disco; conectar `World Bank (?format=json)`, `IMF DataMapper`, `Eurostat (SDMX-CSV)`, `UN WPP (Bulk CSV)`, `OWID` e `geoBoundaries`.
3. **Etapa 3 — Lakehouse Bronze/Silver/Gold & QA Gate**: Automatizar transformação vetorizada em DuckDB (`Nominal/Constant/PPP`, `H3 UBIGINT`, `GeoParquet 1.1`), validação `zod` + asserções de queda/cobertura, e views filtradas por licença.
4. **Etapa 4 — API CQRS Macro-Micro & Feature Store de Branding**: Expor endpoints cacheados de economia, demografia e perfis prontos de mercado (`gold_brand_market_profiles`), deixando os ganchos preparados para visualização e futuros conectores sociais/tráfego pago.
