# TITAN FACTUAL OS — Global Data & Territorial Intelligence

TITAN is a free-first platform for acquiring, validating, harmonizing and serving public territorial, economic, demographic and sector data. This codebase preserves the original source-specific ingestion handlers and grows the platform around them; it does not replace the original API endpoints with generic connectors.

## Commercial licensing — development dashboard mode

**Current behavior is intentionally permissive for internal development and analysis.** Ingestion, Silver source previews, macro/territory/H3 Gold queries and Brand Market profiles include all stored observations, including sources whose `commercial_use_allowed` metadata is `denied` or `unknown`. The dashboard must be able to inspect the complete acquired dataset while the product is being developed.

The source catalogue continues to preserve `commercial_use_allowed`, `redistribution_allowed` and license identifiers as provenance/policy metadata. The optional `commercial_only=true` catalogue filter is an inspection filter only; it does not alter ingestion or suppress dashboard analytics by default. Brand Market `license_clearance` stays `unknown` because the derived profile combines multiple sources and the presence of observations does not establish commercial permission.

**Before any external commercial launch or customer-facing redistribution**, implement and test an explicit commercial-serving mode that filters every API, Gold mart, export, cache, download and dashboard response to records whose source and dataset rights are verified for the intended use. Keep ingestion and archival capture separate from serving eligibility. Until that release gate exists, treat dashboard outputs as internal development previews, not as cleared-for-commercial-use data.

## Preservation baseline

- **95 catalogued source records** from the supplied project ZIP.
- **79 Wave-1 keyless sources marked implemented** and **79 registered connector handlers**.
- Connector IDs, order, source-specific ingestion function names and original endpoint string literals are regression-tested against a manifest extracted from the supplied original ZIP.
- The remaining 16 catalogue entries are not represented as ready connectors merely because they exist in the source registry.
- No Airbyte, Dagster, Python service, Kafka, Temporal, Spark or Redis runtime has been added.

A catalogue entry or handler registration is not proof of successful live ingestion. Actual connector health is determined by runtime capture and snapshot promotion.

## Canonical 13-module taxonomy

| ID | Module | Responsibility |
|---:|---|---|
| 1 | Cadastro Territorial Global | Countries, administrative entities, aliases, boundaries, gazetteers and territorial crosswalks |
| 2 | Economia Global | Macroeconomics, finance, prices, income, labor and economic inequality |
| 3 | Demografia Mundial | Population, age structure, migration, urbanization, households and population distribution |
| 4 | Meio Ambiente e Clima | Climate, ecosystems, biodiversity, land cover and natural hazards |
| 5 | Energia | Energy production, consumption, capacity, matrix and transition |
| 6 | Comércio Internacional | Bilateral trade, external commerce, industry and trade integration |
| 7 | Transporte e Logística | Aviation, maritime, logistics locations, transport networks and physical connectivity |
| 8 | Agricultura e Recursos Naturais | Agriculture, food production, land use and natural resources |
| 9 | Saúde Global | Public health, epidemiology, mortality and health systems |
| 10 | Educação, Ciência e Tecnologia | Education, research, innovation, IP, ICT and supporting digital/cultural signals |
| 11 | Governança e Desenvolvimento | Institutions, human development, security, conflicts and public-government data |
| 12 | Feature Engineering e Inteligência Territorial | Harmonization, derived variables, composite indices and territorial intelligence |
| 13 | Data Warehouse, APIs e Dashboards | Analytical products, storage, APIs, dashboards, distribution and observability |

Every one of the 95 original catalogue records has an explicit mapping to a canonical module. Modules 12 and 13 are derived/serving layers, so they do not pretend to be raw third-party source categories. Legacy connector payloads are normalized to the canonical module only at the ingestion boundary; source-specific endpoint/parser logic is kept intact.

## Architecture

```text
Control Plane (existing modular Node/TypeScript application)
  Source + Domain Registry | Territory Registry | Run Ledger | Policies
  HTTP Cache / ETag | Circuit Breaker | Snapshot Manifest | Acquisition Plan
                         |
                         v
Data Plane (79 original source-specific connector handlers)
  Economy | Demography | Environment | Energy | Trade | Transport | ...
                         |
                         v
Lakehouse
  Bronze = immutable source envelopes
  Silver = validated canonical observations
  Gold   = territory, market and continental analytical products
  SQLite WAL = operational state / DuckDB = analytical query engine
  Parquet = persistent columnar snapshots
                         |
                         v
Quality, Lineage & Serving
  Zod contracts | Dimensional dedup | Coverage diagnostics | License metadata / future serving policy
  Gold marts | Global/continent/country API | Dashboard
```

### Acquisition planning

`src/lakehouse/acquisitionPlanner.ts` produces an explainable plan based on the existing source metadata and connector registry. It distinguishes REST, SDMX, OData, SPARQL, GraphQL, bulk and catalog discovery, along with `READY`, `CREDENTIALS_REQUIRED`, `CATALOG_ONLY` and `CONNECTOR_MISSING` states. This is a planning endpoint, not a replacement execution engine: all real captures continue through their original source-specific handlers.

The Overture entry is explicitly labelled as STAC catalog discovery, not full remote GeoParquet ingestion. Connector registry parity is checked against the original 79 IDs.

### Empty and conditional responses

An empty Silver result is not considered a successful 304 unless the connector explicitly confirms that every required request returned HTTP 304 and no raw rows were returned. Empty downloads, parse failures, partial errors and zero-valid-row outcomes now fail visibly instead of being reported as `UP_TO_DATE_304`.

### Survey and psychographic readiness

Observation contracts preserve survey ID, wave, question, response category/count, demographic strata, sample size, effective sample size, survey weight, sampling stratum/cluster, target population, weighting method, fieldwork dates, standard error, confidence intervals and versioned psychographic construct/scale mappings. Deduplication includes survey and response dimensions, so distinct waves, questions, response categories, age groups and sex strata are not collapsed.

The Brand Market profile `2.2.0` now has two intentionally separate evidence layers. First, six macro-context hypotheses from nine aggregate indicators: digital connectivity/discovery, economic price/value, urban/connected cultural access, economic pressure, age structure/demographic transition and human-development context. These remain proxy signals, not measured traits. Second, when qualifying Silver survey aggregates exist, the profile displays question-level weighted means and separate response distributions with normalized score, confidence intervals, sample/effective sample size, fieldwork, source, methodology and license flags. This is measured survey evidence for the mapped question—not an inferred person-level trait, validated latent segment or population share. The CSV pipeline performs explicit versioned question harmonization and emits a mean plus category-share observations; source/license/methodology context is supplied explicitly by the caller. It does not add WVS, ESS, Afrobarometer, Arab Barometer, Latinobarómetro, ISSP or EVS production connectors. Music listening, pageviews and news volume remain contextual behavioral signals, not representative psychological surveys.

The Market Attractiveness Index (MAI v2.1.0) withholds its composite when any of its five required inputs is missing/invalid or their observation periods are not sufficiently aligned. Gini is retained as descriptive context, not used to assume premium or mass-market opportunity.

### Market-context model safeguards

- Psychographic profile `2.2.0` keeps the six macro proxies separate from harmonized survey measures; Gini remains descriptive in macro data and is excluded from consumer price/value/pressure scores.
- No single-input partial score is emitted for multi-input signals. Missing indicators are never imputed; invalid values are excluded and surfaced.
- Every evidence item includes its period year. Temporal status is exposed as aligned, mixed-period, stale, incomplete or unknown.
- MAI v2.1.0 requires five valid inputs and recent/period-aligned data before releasing a composite score; it excludes Gini from the score rather than assuming inequality has a consistent directional effect on market attractiveness. The demographic component avoids assuming an unobserved overlap between urbanization and internet access.
- The dashboard presents measured survey question results separately when present and labels the six macro indicators as context proxies. No respondent-level personas, sensitive-trait inference or population-segment shares are generated. See `docs/PSYCHOGRAPHIC_MARKET_MODEL.md` and `docs/ARCHITECTURE_CRITIQUE_MATRIX.md` for model details and the repository-based critique.

### Commercial licensing and dashboard visibility

The current development dashboard intentionally exposes all ingested Silver observations in Gold analytics and source previews, regardless of whether `commercial_use_allowed` is `confirmed`, `denied` or `unknown`. This preserves complete visibility while the dataset is being assembled and evaluated. License status remains visible in the source catalogue as metadata and can be used for an optional catalogue-only filter, but it does not currently suppress analytics. Derived Brand Market profiles keep `license_clearance = unknown` because the combined profile does not independently prove the rights of every contributing source.

This is **not** authorization for commercial redistribution. Before customer-facing or external commercial distribution, add a dedicated, tested commercial-serving mode that checks source- and dataset-level rights across every API, export, cache, Gold mart and dashboard response. Do not change ingestion retention as a side effect of that serving policy.

### Geographic aggregation

- Global → continent → country is supported by the current country-level analytical data.
- Continental population and nominal USD GDP are summed.
- GDP per capita PPP, urbanization and internet-use rates are population-weighted; non-additive indicators such as Gini, unemployment, life expectancy and index scores are not averaged.
- H3 measures are population-weighted and explicitly labelled as **country-centroid assignments**. H3 cells are not administrative polygons or population-grid allocations.
- Geographic coverage is not scored automatically until each source has an explicit expected-country manifest. The current enriched territorial dimension contains 34 enriched seed countries (below the 190-country minimum readiness check), so using it as a global denominator would be misleading. `GET /api/v1/catalog/coverage` exposes this readiness block.

### Storage and streaming limits

- SQLite WAL remains the operational metadata/state store.
- DuckDB remains the embedded analytical engine.
- Parquet snapshots remain persistent and immutable after promotion.
- NDJSON writing now creates missing temp directories and honours writable-stream backpressure/completion.
- Existing connector handlers still materialize `rawRows` and Silver observations in memory. The write path is safer, but extraction is **not yet end-to-end streaming**.

## New API endpoints

- `GET /api/v1/catalog/modules` — canonical 13-module registry and per-module source counts.
- `GET /api/v1/catalog/coverage` — catalogue-to-connector registry reconciliation plus territorial-registry readiness; currently reports global coverage as blocked because only 34/190 minimum enriched country entities and no source-specific expected-country manifest are present.
- `GET /api/v1/acquisition/plan` — acquisition strategy/readiness for every catalogue source.
- `GET /api/v1/gold/continents` — continent totals and population-weighted indicators.

Existing endpoints and connector identifiers remain present.

## GitHub repositories used as engineering references

These projects informed patterns only; they are not imported as runtime dependencies and their code has not replaced the original connector handlers.

| Repository | Reference used |
|---|---|
| [dlt-hub/dlt](https://github.com/dlt-hub/dlt) | Source contracts, incremental state, append/merge/replace semantics and pipeline boundaries |
| [airbytehq/airbyte](https://github.com/airbytehq/airbyte) | Source-specific connector lifecycle and explicit connector readiness/error handling |
| [duckdb/duckdb](https://github.com/duckdb/duckdb) | In-process analytics, Parquet transforms and columnar query patterns |
| [unionai-oss/pandera](https://github.com/unionai-oss/pandera) | Data contracts and dataset-quality validation concepts; runtime validation remains Zod |
| [uber/h3](https://github.com/uber/h3) | Hierarchical hexagonal indexing; not an administrative-boundary substitute |
| [opengeospatial/geoparquet](https://github.com/opengeospatial/geoparquet) | Interoperable vector geometry in Parquet |
| [dagster-io/dagster](https://github.com/dagster-io/dagster) | Asset lineage and observability concepts; not adopted as a new orchestration dependency |
| [dbt-labs/dbt](https://github.com/dbt-labs/dbt) | Transformation/model lineage patterns; not adopted as a runtime engine |
| [great-expectations/great_expectations](https://github.com/great-expectations/great_expectations) | Schema expectations and checkpoint validation patterns |

## Validation commands

```bash
npm install
npm test
npm run lint
npm run build
```

`npm test` runs the dependency-free contract/regression suite under Node 22's native TypeScript stripping. The source files that require Zod, Express, DuckDB and React still need the full dependency installation and app build for complete compile/runtime validation. Live source captures must be checked in the deployment environment with real network access; registry tests do not replace API integration tests.


Continental rollups expose a separate observation-year range and contributing-country count for nominal GDP, PPP GDP per capita, population, urbanization and internet use. Do not interpret these as a same-year snapshot unless the ranges align.

## Administrative write security

All state-changing `/api/v1` requests (connector ingestion, batch ingestion, maintenance and circuit-breaker reset) pass through `adminWriteGuardMiddleware`.

- In production, startup refuses to run unless `ADMIN_API_TOKEN` is configured with at least 32 characters. Generate one with `openssl rand -base64 48` and keep it in the deployment secret manager; never commit it.
- The browser dashboard accepts the token in its Administrator API token field and retains it only in the current tab's `sessionStorage`. It is sent as an explicit `Authorization: Bearer` header; it is not embedded in the frontend bundle.
- Requests with cross-site Fetch Metadata or a mismatched `Origin` are rejected. Read-only `GET`/`HEAD`/`OPTIONS` requests do not require the token.
- Development without a token remains available for local work. Do not expose an unauthenticated development server to a public network.
- The bearer token is a shared administrative secret, not a user identity/session system. For multi-user public deployment, put the app behind an identity-aware reverse proxy/SSO and rotate the token; protect the dashboard against XSS and restrict who can access the deployment.

### November 22 repository review and implemented foundations

A repository re-evaluation selected better-fit references for geospatial TypeScript operations ([Turf.js](https://github.com/Turfjs/turf)), global administrative boundary data ([geoBoundaries](https://github.com/wmgeolab/geoBoundaries)), metadata/lineage and quality architecture ([OpenMetadata](https://github.com/open-metadata/OpenMetadata), [Great Expectations](https://github.com/fivetran/great_expectations)) and complex survey methods ([R survey](https://github.com/cran/survey)). Only focused, low-overhead application code was implemented; no heavyweight external runtime was added.

The package contains a survey pipeline with normalized final weights, Kish effective sample size, weighted mean and separate response-distribution estimates, a limited/caveated first-stage Taylor PSU variance estimator, explicit CSV question harmonization and canonical Silver observation conversion. Eligible survey aggregates flow into Brand Market profile queries, Gold materialization and the measured-evidence UI; `survey_evidence_count` remains zero in territories without valid imported Silver observations. Separately, bounded-concurrency metadata discovery covers geoBoundaries ADM0–ADM2; a lightweight GeoJSON point-in-area predicate is tested; administrative crosswalks are version-validated with period-separated outputs and denominator-weighted rate allocation; and structured quality metrics are integrated into the Silver QA gate. These foundations do not prove that live survey sources or all administrative geometries have been acquired. A profile only gains measured survey evidence after actual observations pass the harmonization, quality, uncertainty and licensing checks.

The crosswalk engine consumes externally sourced/provenanced allocation weights; it does not calculate overlay-derived population shares. The lightweight GeoJSON checker is not a full OGC topology validator, and neither spatial helper is currently wired to a customer-facing spatial workflow. See `docs/FINAL_REPOSITORY_REVIEW_2026-11-22.md` for the latest adversarial findings, corrected defects and integration boundaries; `docs/REPOSITORY_STAR_REVIEW_MATRIX.md` contains current GitHub star-threshold comparisons.


### Performance improvements — November 22, 2026

- Silver quality profiling uses a single pass for year bounds, territory/indicator cardinality and optional-field completeness, avoiding repeated scans and spread-argument limits on large datasets.
- NDJSON writing supports synchronous and asynchronous iterables with stream backpressure. Existing source handlers are preserved and still materialize their returned arrays; full end-to-end streaming remains a future gate.
- DuckDB latency metrics use a bounded rolling sample. Runtime threads, memory limit and spill directory are configurable through `TITAN_DUCKDB_THREADS`, `TITAN_DUCKDB_MEMORY_LIMIT` and `TITAN_DUCKDB_TEMP_DIRECTORY`.
- Repository selection and implementation decisions are documented in `docs/REPOSITORY_RESEARCH_AND_PERFORMANCE_REVIEW_2026-11-22.md`.
