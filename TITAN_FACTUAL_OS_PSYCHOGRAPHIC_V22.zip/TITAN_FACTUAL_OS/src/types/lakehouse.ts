export type AccessTier =
  | 'tier0_keyless'
  | 'tier1_free_key'
  | 'tier2_registration'
  | 'tier3_paid'
  | 'oauth_user_authorized';

export type CommercialStatus = 'confirmed' | 'denied' | 'unknown';
export type CircuitState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';
export type ResourceKind = 'data_source' | 'api' | 'bulk' | 'catalog' | 'protocol' | 'platform';

export interface SourceCatalogEntry {
  source_id: string;
  catalog_index: number | null;
  dataset_id: string;
  source_name: string;
  module_id: number;
  module_name: string;
  domain_group: string;
  resource_kind: ResourceKind;
  api_version: string;
  access_tier: AccessTier;
  license_id: string;
  commercial_use_allowed: CommercialStatus;
  redistribution_allowed: CommercialStatus;
  geographic_coverage: string;
  geographic_level: string;
  rate_limit_rpm: number;
  max_concurrency: number;
  preferred_mode: string;
  host: string;
  endpoint_url: string;
  update_frequency: string;
  incremental_value: string;
  known_block_reason: string | null;
  duplicity_audit_note: string | null;
  is_expansion: number;
  last_successful_ingestion: string | null;
  last_verified_at: string | null;
  implemented_wave1: number;
}

export interface SnapshotManifest {
  snapshot_id: string;
  source_id: string;
  dataset_id: string;
  layer: 'bronze' | 'silver' | 'gold';
  parquet_path: string;
  sha256: string;
  row_count: number;
  byte_size: number;
  qa_status: 'PASSED' | 'FAILED' | 'QUARANTINED';
  qa_notes: string | null;
  is_active: number;
  created_at: string;
}

export interface CircuitBreakerRecord {
  host: string;
  state: CircuitState;
  error_streak: number;
  cooldown_until: string | null;
  last_etag: string | null;
  last_modified: string | null;
  last_error: string | null;
  updated_at: string;
}

export interface LineageRun {
  run_id: string;
  source_id: string;
  job_name: string;
  status: 'RUNNING' | 'COMPLETED' | 'UP_TO_DATE_304' | 'SKIPPED_304' | 'BLOCKED_CB' | 'FAILED';
  input_etag: string | null;
  output_snapshot_id: string | null;
  rows_in: number;
  rows_out: number;
  duration_ms: number;
  details_json: string;
  started_at: string;
  finished_at: string | null;
}

export interface MacroEconomicRow {
  territory_id: string;
  iso3: string;
  iso2: string;
  name_en: string;
  continent: string;
  region: string;
  h3_res2: string | null;
  h3_res4: string | null;
  latest_year: number | null;
  gdp_nominal_usd: number | null;
  gdp_nominal_usd_year: number | null;
  gdp_per_capita_ppp_2021: number | null;
  gdp_per_capita_ppp_2021_year: number | null;
  imf_real_gdp_growth_pct: number | null;
  inflation_cpi_pct: number | null;
  inflation_cpi_pct_year: number | null;
  gov_debt_pct_gdp: number | null;
  unemployment_pct: number | null;
  unemployment_pct_year: number | null;
  gini_index: number | null;
  gini_index_year: number | null;
  population_total: number | null;
  population_total_year: number | null;
  urbanization_pct: number | null;
  urbanization_pct_year: number | null;
  internet_users_pct: number | null;
  internet_users_pct_year: number | null;
  life_expectancy_years: number | null;
  life_expectancy_years_year: number | null;
  household_consumption_pct_gdp: number | null;
  gni_per_capita_usd: number | null;
  fdi_net_inflows_pct_gdp: number | null;
  trade_openness_pct_gdp: number | null;
  ilostat_lfpr_pct: number | null;
  imf_policy_rate_pct: number | null;
  imf_reer_index: number | null;
  oecd_cli_index: number | null;
  wits_exports_usd: number | null;
  wits_imports_usd: number | null;
  ember_clean_share_pct: number | null;
  ember_carbon_intensity: number | null;
  uis_gerd_pct_gdp: number | null;
  unicef_u5_mortality: number | null;
  unsdg_renewable_pct: number | null;
  unsdg_forest_pct: number | null;
  gbif_occurrences: number | null;
  wikidata_area_km2: number | null;
  abs_cpi_pct_yoy: number | null;
  eurostat3_hicp_pct: number | null;
  statcan_unemp_pct: number | null;
  ukons_cpih_yoy_pct: number | null;
  unsd_elec_prod_gwh: number | null;
  nasa_solar_kwh: number | null;
  obis_marine_species: number | null;
  geonames_pop: number | null;
  datacite_dataset_dois: number | null;
  eurostat_gov_debt_pct: number | null;
  unwpp_tfr: number | null;
  unwpp_tfr_year: number | null;
  worldpop_datasets: number | null;
  nasa_cmr_collections: number | null;
  ne_adm1_divisions: number | null;
  openalex_works_2024: number | null;
  ukgov_open_datasets: number | null;
  overture_themes: number | null;
  faostat_kcal_day: number | null;
  uis_edu_exp_pct_gdp: number | null;
  worldpop_age_datasets: number | null;
  worldpop_density_datasets: number | null;
  eurostat_catalog_datasets: number | null;
  arcgis_open_datasets: number | null;
  stac_public_catalogs: number | null;
  listenbrainz_top100_listens: number | null;
  ecb_fx_per_eur: number | null;
  vdem_democracy_ix: number | null;
  unlocode_nodes: number | null;
  unhabitat_urban_datasets: number | null;
  ckan_portal_datasets: number | null;
  socrata_civic_datasets: number | null;
  osm_importance_score: number | null;
  musicbrainz_artists: number | null;
  uncomtrade_exports_usd: number | null;
  itu_mobile_per_100: number | null;
  itu_mobile_per_100_year: number | null;
  gadm_adm1_features: number | null;
  wipo_patents_per_million: number | null;
  unodc_homicide_rate: number | null;
  wid_top10_share_pct: number | null;
  ghsl_pop_density_km2: number | null;
  pwt_real_gdp_cap: number | null;
  eurostat_gdp_meur: number | null;
  bis_total_credit_pct_gdp: number | null;
  ibge_ipca_pct: number | null;
  unhcr_refugees: number | null;
  usgs_seismic_events: number | null;
  gb_adm0_coverage: number | null;
  crossref_works_count: number | null;
  unctad_lsci: number | null;
  statfin_cpi_pct: number | null;
  undata_elec_access_pct: number | null;
  undrr_mortality_per_100k: number | null;
  usgov_datasets_total: number | null;
  pip_mean_daily_ppp: number | null;
  ct_ghg_co2e: number | null;
  wikimedia_enwiki_views: number | null;
  us_census_pop: number | null;
  undp_hdi: number | null;
  undp_hdi_year: number | null;
  noaa_tavg_c: number | null;
  gfw_tree_loss_ha: number | null;
  eia_energy_prod_qbtu: number | null;
  india_iip_index: number | null;
  icao_scheduled_airports: number | null;
  wdpa_protected_pct: number | null;
}

export type AdminLevel = 'global' | 'continent' | 'country' | 'state' | 'city' | 'neighborhood';

export interface SpatialAdminNode {
  node_id: string;
  parent_id: string | null;
  level: AdminLevel;
  code: string;
  iso3: string | null;
  territory_id: string | null;
  name_en: string;
  name_local: string | null;
  centroid_lat: number | null;
  centroid_lon: number | null;
  h3_index: string | null;
  h3_resolution: number;
  wikidata_qid: string | null;
  geoname_id: number | null;
  population_est: number | null;
  area_km2: number | null;
  child_count?: number;
}

export interface H3MacroCellRow {
  h3_res2: string;
  spatial_basis: 'country_centroid_assignment';
  territory_count: number;
  territories_csv: string;
  total_population: number | null;
  population_weighted_gdp_per_capita_ppp_2021: number | null;
  population_weighted_urbanization_pct: number | null;
}

export interface MarketAttractivenessBreakdown {
  methodology_version: '2.1.0';
  demographic_score: number | null;
  purchasing_power_score: number | null;
  inflation_risk_multiplier: number | null;
  market_attractiveness_score: number | null;
  data_fields_available: number;
  data_fields_expected: number;
  data_coverage_pct: number;
  temporal_status: PsychographicTemporalStatus;
  oldest_data_year: number | null;
  newest_data_year: number | null;
  missing_or_invalid_fields: string[];
  interpretation: string;
}

export type PsychographicSignalLevel = 'low' | 'moderate' | 'high' | 'insufficient_data';
export type PsychographicTemporalStatus = 'aligned' | 'mixed_periods' | 'stale' | 'incomplete' | 'unknown';
export type PsychographicConstructDomain = 'values' | 'attitudes' | 'interests' | 'lifestyle' | 'motivations' | 'identity' | 'media_use' | 'music_engagement' | 'social_orientation' | 'other';
export type PsychographicSurveyVarianceStatus = 'available_taylor_linearization_wr_first_stage' | 'unavailable_design_metadata' | 'unavailable_singleton_stratum';
export type PsychographicSurveyQualityFlag = 'stale' | 'small_effective_sample' | 'variance_unavailable' | 'license_unknown' | 'license_denied';

export interface PsychographicSurveyDistributionValue {
  response_value: number;
  weighted_share_pct: number;
  confidence_interval_95: { lower: number; upper: number } | null;
  unweighted_count: number | null;
}

export interface PsychographicSurveyMeasure {
  measure_id: string;
  construct_id: string;
  construct_label: string;
  construct_domain: PsychographicConstructDomain;
  survey_id: string;
  wave_id: string;
  question_id: string;
  canonical_scale_id: string;
  canonical_scale_min: number;
  canonical_scale_max: number;
  mapping_version: string;
  period_year: number;
  weighted_mean: number;
  score_0_100: number;
  confidence_interval_95_score: { lower: number; upper: number } | null;
  sample_size: number;
  effective_sample_size: number;
  minimum_effective_sample_size: number;
  standard_error: number | null;
  variance_status: PsychographicSurveyVarianceStatus;
  response_distribution: PsychographicSurveyDistributionValue[];
  population_scope: string;
  weighting_method: string;
  fieldwork_start: string | null;
  fieldwork_end: string | null;
  source_id: string;
  dataset_id: string;
  methodology_id: string;
  commercial_use_allowed: 'confirmed' | 'denied' | 'unknown';
  quality_flags: PsychographicSurveyQualityFlag[];
}

export interface PsychographicSignal {
  signal_id: 'digital_discovery' | 'value_sensitivity' | 'urban_cultural_access' | 'economic_pressure' | 'age_structure_context' | 'human_development_context';
  label: string;
  score: number | null;
  level: PsychographicSignalLevel;
  evidence_fields_available: number;
  evidence_fields_expected: number;
  data_coverage_pct: number;
  temporal_status: PsychographicTemporalStatus;
  interpretation: string;
  evidence: Array<{ metric: string; value: number; unit: string; period_year: number | null }>;
  research_hypothesis: string;
  validation_action: string;
}

export interface PsychographicProfile {
  model_version: '2.2.0';
  evidence_type: 'aggregated_demographic_proxy';
  validation_status: 'survey_validation_required';
  data_coverage_pct: number;
  data_fields_available: number;
  data_fields_expected: number;
  invalid_fields: string[];
  temporal_coverage_pct: number;
  temporal_status: PsychographicTemporalStatus;
  oldest_evidence_year: number | null;
  newest_evidence_year: number | null;
  temporal_span_years: number | null;
  survey_evidence_count: number;
  measured_survey_measures: PsychographicSurveyMeasure[];
  population_share_estimated: false;
  signals: PsychographicSignal[];
  limitations: string[];
}

export interface BrandMarketProfile {
  territory_id: string;
  iso3: string;
  name_en: string;
  continent: string;
  region: string;
  h3_res2: string | null;
  currency_iso4217: string;
  primary_language_iso639: string;
  timezone: string;
  population_total_year: number | null;
  median_age: number | null;
  median_age_year: number | null;
  life_expectancy_years: number | null;
  life_expectancy_years_year: number | null;
  gdp_per_capita_ppp_2021: number | null;
  gdp_per_capita_ppp_2021_year: number | null;
  gini_index: number | null;
  gini_index_year: number | null;
  urbanization_pct: number | null;
  urbanization_pct_year: number | null;
  internet_users_pct: number | null;
  internet_users_pct_year: number | null;
  inflation_cpi_pct: number | null;
  inflation_cpi_pct_year: number | null;
  purchasing_power_tier: 'Tier A (High PPP)' | 'Tier B (Mid PPP)' | 'Tier C (Lower PPP)' | 'Insufficient data';
  digital_addressable_pop: number | null;
  mai: MarketAttractivenessBreakdown;
  psychographics: PsychographicProfile;
  license_clearance: 'confirmed' | 'unknown';
}

export interface IngestionExecutionResult {
  run_id: string;
  source_id: string;
  status: 'COMPLETED' | 'UP_TO_DATE_304' | 'SKIPPED_304' | 'BLOCKED_CB' | 'FAILED';
  snapshot_id: string | null;
  rows_in: number;
  rows_out: number;
  duration_ms: number;
  dedup_hit: boolean;
  qa_notes: string;
}

export interface ControlPlaneOverview {
  snapshots: SnapshotManifest[];
  breakers: CircuitBreakerRecord[];
  lineage: LineageRun[];
  dlqCount: number;
  recentDlq: Array<{
    id: number;
    source_id: string;
    raw_entity_code: string;
    raw_entity_name: string | null;
    reason: string;
    created_at: string;
  }>;
  walBytes: number;
  territoryCount: number;
  duckdbVersion: string;
  extensions: {
    spatial: boolean;
    h3: boolean;
    httpfs: boolean;
  };
  duckdbMetrics: {
    queryCount: number;
    avgMs: number;
    p95Ms: number;
  };
  cacheStats: {
    hits: number;
    misses: number;
    hitRatePct: number;
    keys: number;
  };
  activeIngestionLocks: string[];
  httpMetrics: Array<{
    host: string;
    sampleCount: number;
    avgMs: number;
    p95Ms: number;
  }>;
  hierarchyCounts?: Record<AdminLevel, number>;
}
