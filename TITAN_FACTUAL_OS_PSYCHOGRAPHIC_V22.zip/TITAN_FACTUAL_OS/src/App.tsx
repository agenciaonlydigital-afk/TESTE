import { Moon, RefreshCw, Sun } from 'lucide-react';
import { useCallback, useEffect, useRef, useState } from 'react';
import { BrandMarketView } from './components/BrandMarketView.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import { MacroEconomyView } from './components/MacroEconomyView.tsx';
import { SnapshotsLineageView } from './components/SnapshotsLineageView.tsx';
import { SourceCatalogView } from './components/SourceCatalogView.tsx';
import type {
  BrandMarketProfile,
  ControlPlaneOverview,
  H3MacroCellRow,
  IngestionExecutionResult,
  MacroEconomicRow,
  SourceCatalogEntry,
} from './types/lakehouse.ts';

type ActiveTab = 'economy' | 'catalog' | 'branding' | 'snapshots';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('economy');
  const [darkMode, setDarkMode] = useState<boolean>(true);
  const [brandMode, setBrandMode] = useState<'mass_market' | 'premium'>('mass_market');
  const [adminToken, setAdminToken] = useState<string>(() => {
    try { return window.sessionStorage.getItem('titan_admin_token') ?? ''; } catch { return ''; }
  });

  const [sources, setSources] = useState<SourceCatalogEntry[]>([]);
  const [overview, setOverview] = useState<ControlPlaneOverview | null>(null);
  const [macroRows, setMacroRows] = useState<MacroEconomicRow[]>([]);
  const [h3Rows, setH3Rows] = useState<H3MacroCellRow[]>([]);
  const [macroCache, setMacroCache] = useState<string>('MISS');
  const [macroSnapshots, setMacroSnapshots] = useState<number>(0);
  const [brandProfiles, setBrandProfiles] = useState<BrandMarketProfile[]>([]);

  const [loading, setLoading] = useState<boolean>(true);
  const hasLoadedOnce = useRef<boolean>(false);
  const [ingestingId, setIngestingId] = useState<string | null>(null);
  const [syncingCore, setSyncingCore] = useState<boolean>(false);
  const [runningMaintenance, setRunningMaintenance] = useState<boolean>(false);
  const [resettingBreakers, setResettingBreakers] = useState<boolean>(false);
  const [bannerMessage, setBannerMessage] = useState<{ type: 'info' | 'error'; text: string } | null>(null);

  useEffect(() => {
    try {
      if (adminToken) window.sessionStorage.setItem('titan_admin_token', adminToken);
      else window.sessionStorage.removeItem('titan_admin_token');
    } catch { /* session storage may be disabled by the browser */ }
  }, [adminToken]);

  const adminWriteHeaders = useCallback((): Record<string, string> =>
    adminToken ? { Authorization: `Bearer ${adminToken}` } : {}, [adminToken]);

  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [darkMode]);

  const loadAll = useCallback(
    async (signal?: AbortSignal) => {
      if (!hasLoadedOnce.current) {
        setLoading(true);
      }
      try {
        const results = await Promise.allSettled([
          fetch('/api/v1/catalog/sources', { signal }).then(async (r) => {
            if (!r.ok) throw new Error(`Catalog HTTP ${r.status}`);
            return (await r.json()) as { sources: SourceCatalogEntry[] };
          }),
          fetch('/api/v1/control-plane/status', { signal }).then(async (r) => {
            if (!r.ok) throw new Error(`Control Plane HTTP ${r.status}`);
            return (await r.json()) as ControlPlaneOverview;
          }),
          fetch('/api/v1/gold/macro-economics', { signal }).then(async (r) => {
            if (!r.ok) throw new Error(`Macro Gold HTTP ${r.status}`);
            return (await r.json()) as {
              data: MacroEconomicRow[];
              cacheStatus: string;
              snapshotCount: number;
            };
          }),
          fetch(`/api/v1/gold/brand-profiles?mode=${brandMode}`, { signal }).then(async (r) => {
            if (!r.ok) throw new Error(`Brand Gold HTTP ${r.status}`);
            return (await r.json()) as { data: BrandMarketProfile[] };
          }),
          fetch('/api/v1/gold/h3-macro', { signal }).then(async (r) => {
            if (!r.ok) throw new Error(`H3 Gold HTTP ${r.status}`);
            return (await r.json()) as { data: H3MacroCellRow[] };
          }),
        ]);

        if (signal?.aborted) return;

        const failures: string[] = [];
        if (results[0].status === 'fulfilled') setSources(results[0].value.sources);
        else if (!(results[0].reason instanceof DOMException && results[0].reason.name === 'AbortError')) {
          failures.push(String(results[0].reason));
        }

        if (results[1].status === 'fulfilled') setOverview(results[1].value);
        else if (!(results[1].reason instanceof DOMException && results[1].reason.name === 'AbortError')) {
          failures.push(String(results[1].reason));
        }

        if (results[2].status === 'fulfilled') {
          setMacroRows(results[2].value.data);
          setMacroCache(results[2].value.cacheStatus);
          setMacroSnapshots(results[2].value.snapshotCount);
        } else if (!(results[2].reason instanceof DOMException && results[2].reason.name === 'AbortError')) {
          failures.push(String(results[2].reason));
        }

        if (results[3].status === 'fulfilled') setBrandProfiles(results[3].value.data);
        else if (!(results[3].reason instanceof DOMException && results[3].reason.name === 'AbortError')) {
          failures.push(String(results[3].reason));
        }

        if (results[4].status === 'fulfilled') setH3Rows(results[4].value.data);
        else if (!(results[4].reason instanceof DOMException && results[4].reason.name === 'AbortError')) {
          failures.push(String(results[4].reason));
        }

        if (failures.length > 0 && failures.length === 5) {
          setBannerMessage({
            type: 'error',
            text: `Unable to reach TITAN FACTUAL OS API (${failures[0]}).`,
          });
        }
        hasLoadedOnce.current = true;
      } finally {
        if (!signal?.aborted) {
          setLoading(false);
        }
      }
    },
    [brandMode]
  );

  useEffect(() => {
    const controller = new AbortController();
    void loadAll(controller.signal);
    return () => controller.abort();
  }, [loadAll]);

  async function handleIngestSource(sourceId: string, force = false) {
    setIngestingId(sourceId);
    setBannerMessage(null);
    try {
      const res = await fetch(`/api/v1/ingest/${sourceId}${force ? '?force=true' : ''}`, {
        method: 'POST',
        headers: adminWriteHeaders(),
      });
      const result = (await res.json()) as IngestionExecutionResult & { error?: string };
      if (!res.ok) {
        throw new Error(result.error ?? result.qa_notes ?? `Ingestion failed for ${sourceId}`);
      }
      setBannerMessage({
        type: result.status === 'FAILED' || result.status === 'BLOCKED_CB' ? 'error' : 'info',
        text: `${sourceId}${force ? ' [force]' : ''}: ${result.status} (${result.rows_out} rows in ${result.duration_ms} ms) — ${result.qa_notes}`,
      });
      await loadAll();
    } catch (err) {
      setBannerMessage({
        type: 'error',
        text: err instanceof Error ? err.message : `Ingestion error on ${sourceId}`,
      });
    } finally {
      setIngestingId(null);
    }
  }

  async function handleSyncCore(force = false) {
    setSyncingCore(true);
    setBannerMessage(null);
    try {
      const res = await fetch(`/api/v1/ingest-core${force ? '?force=true' : ''}`, {
        method: 'POST',
        headers: adminWriteHeaders(),
      });
      const json = (await res.json()) as { results?: IngestionExecutionResult[]; error?: string };
      if (!res.ok || !json.results) {
        throw new Error(json.error ?? 'Core batch ingestion failed');
      }
      const totalRows = json.results.reduce((acc, r) => acc + r.rows_out, 0);
      const updated = json.results.filter((r) => r.status === 'COMPLETED').length;
      const upToDate = json.results.filter(
        (r) => r.status === 'UP_TO_DATE_304' || r.status === 'SKIPPED_304'
      ).length;
      const failed = json.results.filter((r) => r.status === 'FAILED' || r.status === 'BLOCKED_CB');
      const healthy = updated + upToDate;
      const failedSummary =
        failed.length > 0 ? ` Degraded: ${failed.map((f) => `${f.source_id} (${f.status})`).join(', ')}.` : '';
      setBannerMessage({
        type: failed.length > 0 ? 'error' : 'info',
        text: `Wave-1 sync${force ? ' (forced)' : ''}: ${healthy}/${json.results.length} healthy — ${updated} updated (${totalRows.toLocaleString()} Silver rows), ${upToDate} unchanged (HTTP 304 cache).${failedSummary}`,
      });
      await loadAll();
    } catch (err) {
      setBannerMessage({
        type: 'error',
        text: err instanceof Error ? err.message : 'All Wave-1 APIs batch ingestion error',
      });
    } finally {
      setSyncingCore(false);
    }
  }

  async function handleRunMaintenance() {
    setRunningMaintenance(true);
    setBannerMessage(null);
    try {
      const res = await fetch('/api/v1/control-plane/maintenance', { method: 'POST', headers: adminWriteHeaders() });
      const json = (await res.json()) as {
        ok?: boolean;
        prunedSnapshots?: number;
        orphansRemoved?: number;
        reclaimedBytes?: number;
        sweptTmpFiles?: number;
        goldRebuilt?: boolean;
        walCheckpointed?: boolean;
        error?: string;
      };
      if (!res.ok || !json.ok) {
        throw new Error(json.error ?? 'Control Plane maintenance failed');
      }
      setBannerMessage({
        type: 'info',
        text: `Maintenance complete: pruned ${json.prunedSnapshots ?? 0} snapshots, removed ${json.orphansRemoved ?? 0} orphan Parquet (${((json.reclaimedBytes ?? 0) / 1024).toFixed(1)} KB), swept ${json.sweptTmpFiles ?? 0} tmp files, Gold rebuilt=${String(Boolean(json.goldRebuilt))}, WAL checkpoint=${String(json.walCheckpointed)}.`,
      });
      await loadAll();
    } catch (err) {
      setBannerMessage({
        type: 'error',
        text: err instanceof Error ? err.message : 'Maintenance error',
      });
    } finally {
      setRunningMaintenance(false);
    }
  }

  async function handleResetBreakers() {
    setResettingBreakers(true);
    setBannerMessage(null);
    try {
      const res = await fetch('/api/v1/control-plane/breakers/reset', { method: 'POST', headers: adminWriteHeaders() });
      const json = (await res.json()) as { ok?: boolean; resetCount?: number; error?: string };
      if (!res.ok || !json.ok) {
        throw new Error(json.error ?? 'Failed to reset circuit breakers');
      }
      setBannerMessage({
        type: 'info',
        text: `Reset ${json.resetCount ?? 0} host circuit breaker(s) to CLOSED.`,
      });
      await loadAll();
    } catch (err) {
      setBannerMessage({
        type: 'error',
        text: err instanceof Error ? err.message : 'Circuit breaker reset error',
      });
    } finally {
      setResettingBreakers(false);
    }
  }

  const activeGoldCount =
    overview?.snapshots.filter((s) => s.layer === 'gold' && s.is_active === 1).length ?? 0;
  const activeSilverCount =
    overview?.snapshots.filter((s) => s.layer === 'silver' && s.is_active === 1).length ?? 0;
  const wave1ApiCount =
    sources.filter((s) => s.implemented_wave1 === 1 && s.access_tier === 'tier0_keyless').length || 79;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100 flex flex-col">
      {/* Strict 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-30 flex items-center justify-between gap-8 border-b border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-950/95 backdrop-blur-xs px-6 py-3.5">
        <a
          href="#dashboard"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('economy');
          }}
          className="text-base font-bold tracking-tight text-slate-900 dark:text-slate-100 whitespace-nowrap shrink-0"
        >
          TITAN FACTUAL OS
        </a>

        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600 dark:text-slate-400">
          <button
            type="button"
            onClick={() => setActiveTab('economy')}
            className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
              activeTab === 'economy'
                ? 'border-slate-900 dark:border-slate-100 text-slate-900 dark:text-slate-100'
                : 'border-transparent hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            Dashboard
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('catalog')}
            className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
              activeTab === 'catalog'
                ? 'border-slate-900 dark:border-slate-100 text-slate-900 dark:text-slate-100'
                : 'border-transparent hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            Source Catalog
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('branding')}
            className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
              activeTab === 'branding'
                ? 'border-slate-900 dark:border-slate-100 text-slate-900 dark:text-slate-100'
                : 'border-transparent hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            Brand Readiness
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('snapshots')}
            className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
              activeTab === 'snapshots'
                ? 'border-slate-900 dark:border-slate-100 text-slate-900 dark:text-slate-100'
                : 'border-transparent hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            Snapshots
          </button>
        </nav>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            disabled={syncingCore || ingestingId !== null}
            onClick={() => void handleSyncCore(false)}
            className="inline-flex items-center gap-2 rounded-lg bg-slate-900 dark:bg-slate-100 px-4 py-2 text-xs font-medium text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-white disabled:opacity-50 transition-colors whitespace-nowrap shrink-0"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${syncingCore ? 'animate-spin' : ''}`} />
            <span>
              {syncingCore ? `Syncing All ${wave1ApiCount} APIs...` : `Sync All APIs (${wave1ApiCount})`}
            </span>
          </button>
          <button
            type="button"
            disabled={syncingCore || ingestingId !== null}
            onClick={() => void handleSyncCore(true)}
            title="Force re-fetch all APIs bypassing HTTP 304 ETag/Last-Modified cache"
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-50 transition-colors whitespace-nowrap shrink-0"
          >
            <span>Force</span>
          </button>
        </div>
      </header>

      {/* Mobile Nav Strip */}
      <div className="flex md:hidden items-center gap-2 overflow-x-auto border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 px-4 py-2">
        {(['economy', 'catalog', 'branding', 'snapshots'] as const).map((tab) => (
          <button
            key={tab}
            type="button"
            onClick={() => setActiveTab(tab)}
            className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap shrink-0 ${
              activeTab === tab
                ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            {tab === 'economy'
              ? 'Dashboard'
              : tab === 'catalog'
                ? 'Catalog'
                : tab === 'branding'
                  ? 'Branding'
                  : 'Snapshots'}
          </button>
        ))}
      </div>

      {/* Workspace Body: 256px Sidebar + Main Viewport */}
      <div className="flex flex-1">
        <aside className="hidden lg:flex w-64 shrink-0 flex-col justify-between border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 p-5">
          <div className="space-y-6">
            <div>
              <h2 className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                Wave 1 Architecture
              </h2>
              <dl className="mt-3 space-y-2.5 text-xs">
                <div className="flex items-center justify-between">
                  <dt className="text-slate-500 dark:text-slate-400">Runtime</dt>
                  <dd className="font-mono text-slate-900 dark:text-slate-100">Node.js + TS</dd>
                </div>
                <div className="flex items-center justify-between">
                  <dt className="text-slate-500 dark:text-slate-400">Control Plane</dt>
                  <dd className="font-mono text-slate-900 dark:text-slate-100">SQLite WAL</dd>
                </div>
                <div className="flex items-center justify-between">
                  <dt className="text-slate-500 dark:text-slate-400">Analytical Engine</dt>
                  <dd className="font-mono text-slate-900 dark:text-slate-100">
                    DuckDB {overview?.duckdbVersion ?? '—'}
                  </dd>
                </div>
                <div className="flex items-center justify-between">
                  <dt className="text-slate-500 dark:text-slate-400">Storage Format</dt>
                  <dd className="font-mono text-slate-900 dark:text-slate-100">Parquet ZSTD</dd>
                </div>
              </dl>
            </div>

            <div className="border-t border-slate-200 dark:border-slate-800 pt-5">
              <h2 className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                Lakehouse Inventory
              </h2>
              <dl className="mt-3 space-y-2.5 text-xs tabular-nums">
                <div className="flex items-center justify-between">
                  <dt className="text-slate-500 dark:text-slate-400">Registered Sources</dt>
                  <dd className="font-mono text-slate-900 dark:text-slate-100">{sources.length}</dd>
                </div>
                <div className="flex items-center justify-between">
                  <dt className="text-slate-500 dark:text-slate-400">Active Gold / Silver</dt>
                  <dd className="font-mono text-slate-900 dark:text-slate-100">
                    {activeGoldCount} / {activeSilverCount}
                  </dd>
                </div>
                <div className="flex items-center justify-between">
                  <dt className="text-slate-500 dark:text-slate-400">Canonical Territories</dt>
                  <dd className="font-mono text-slate-900 dark:text-slate-100">
                    {overview?.territoryCount ?? 0}
                  </dd>
                </div>
                <div className="flex items-center justify-between">
                  <dt className="text-slate-500 dark:text-slate-400">H3 Res-2 Cells</dt>
                  <dd className="font-mono text-slate-900 dark:text-slate-100">{h3Rows.length}</dd>
                </div>
                <div className="flex items-center justify-between gap-2">
                  <dt className="text-slate-500 dark:text-slate-400" title="Global / Continente / País / Estado / Cidade / Bairro">
                    Spatial Tree
                  </dt>
                  <dd className="font-mono text-slate-900 dark:text-slate-100 text-[11px]">
                    {overview?.hierarchyCounts
                      ? `${overview.hierarchyCounts.global}/${overview.hierarchyCounts.continent}/${overview.hierarchyCounts.country}/${overview.hierarchyCounts.state}/${overview.hierarchyCounts.city}/${overview.hierarchyCounts.neighborhood}`
                      : '1/6/33/0/0/0'}
                  </dd>
                </div>
                <div className="flex items-center justify-between">
                  <dt className="text-slate-500 dark:text-slate-400">Unresolved DLQ</dt>
                  <dd className="font-mono text-slate-900 dark:text-slate-100">
                    {overview?.dlqCount ?? 0}
                  </dd>
                </div>
              </dl>
            </div>
          </div>

          <div className="border-t border-slate-200 dark:border-slate-800 pt-4">
            <button
              type="button"
              onClick={() => setDarkMode((prev) => !prev)}
              className="flex w-full items-center justify-between rounded-lg border border-slate-200 dark:border-slate-800 px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors"
            >
              <span>{darkMode ? 'Dark Surface' : 'Light Surface'}</span>
              {darkMode ? <Sun className="h-3.5 w-3.5" /> : <Moon className="h-3.5 w-3.5" />}
            </button>
          </div>
        </aside>

        <main className="flex-1 min-w-0 p-6 lg:p-8 max-w-[1440px] w-full mx-auto space-y-6">
          <section className="flex flex-wrap items-center gap-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 px-4 py-3">
            <label className="flex flex-wrap items-center gap-2 text-xs font-medium text-slate-600 dark:text-slate-300">
              Administrator API token
              <input
                type="password"
                autoComplete="off"
                aria-label="Administrator API token"
                value={adminToken}
                onChange={(event) => setAdminToken(event.target.value)}
                placeholder="Enter token for write actions"
                className="w-60 max-w-full rounded-md border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-3 py-2 text-xs text-slate-800 dark:text-slate-100 outline-none focus:border-slate-400 dark:focus:border-slate-500"
              />
            </label>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Required when the server has ADMIN_API_TOKEN configured. Kept in this tab's session only.
            </p>
          </section>
          {bannerMessage && (
            <div
              role="status"
              className={`rounded-lg border px-4 py-3 text-xs flex items-center justify-between gap-4 ${
                bannerMessage.type === 'error'
                  ? 'border-rose-300 dark:border-rose-800 bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-200'
                  : 'border-emerald-300 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200'
              }`}
            >
              <span className="font-mono">{bannerMessage.text}</span>
              <button
                type="button"
                onClick={() => setBannerMessage(null)}
                className="text-xs underline shrink-0"
              >
                Dismiss
              </button>
            </div>
          )}

          {activeTab === 'economy' && (
            <ErrorBoundary onRetry={() => void loadAll()}>
              <MacroEconomyView
                rows={macroRows}
                h3Cells={h3Rows}
                cacheStatus={macroCache}
                snapshotCount={macroSnapshots}
                loading={loading}
                syncingCore={syncingCore}
                onSyncCore={(force) => void handleSyncCore(Boolean(force))}
                totalApiCount={wave1ApiCount}
                hierarchyCounts={overview?.hierarchyCounts}
              />
            </ErrorBoundary>
          )}

          {activeTab === 'catalog' && (
            <ErrorBoundary onRetry={() => void loadAll()}>
              <SourceCatalogView
                sources={sources}
                breakers={overview?.breakers ?? []}
                snapshots={overview?.snapshots ?? []}
                ingestingId={ingestingId}
                onIngestSource={(sourceId, force) => void handleIngestSource(sourceId, Boolean(force))}
              />
            </ErrorBoundary>
          )}

          {activeTab === 'branding' && (
            <ErrorBoundary onRetry={() => void loadAll()}>
              <BrandMarketView
                profiles={brandProfiles}
                snapshotCount={macroSnapshots}
                loading={loading}
                mode={brandMode}
                onModeChange={setBrandMode}
              />
            </ErrorBoundary>
          )}

          {activeTab === 'snapshots' && (
            <ErrorBoundary onRetry={() => void loadAll()}>
              <SnapshotsLineageView
                overview={overview}
                runningMaintenance={runningMaintenance}
                resettingBreakers={resettingBreakers}
                onRunMaintenance={() => void handleRunMaintenance()}
                onResetBreakers={() => void handleResetBreakers()}
              />
            </ErrorBoundary>
          )}
        </main>
      </div>
    </div>
  );
}
