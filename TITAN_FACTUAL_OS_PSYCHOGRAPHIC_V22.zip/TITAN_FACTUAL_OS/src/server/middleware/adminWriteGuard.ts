import { createHash, timingSafeEqual } from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';

export interface AdminWriteGuardConfig {
  token: string | undefined;
  production: boolean;
}

export interface AdminWriteRequestFacts {
  authorization: string | undefined;
  origin: string | undefined;
  host: string | undefined;
  fetchSite: string | undefined;
}

export type AdminWriteDecision =
  | { allowed: true }
  | { allowed: false; status: 401 | 403 | 503; code: string; message: string };

function sameSecret(candidate: string, expected: string): boolean {
  const candidateDigest = createHash('sha256').update(candidate).digest();
  const expectedDigest = createHash('sha256').update(expected).digest();
  return timingSafeEqual(candidateDigest, expectedDigest);
}

export function validateAdminWriteRequest(
  config: AdminWriteGuardConfig,
  facts: AdminWriteRequestFacts,
): AdminWriteDecision {
  const expected = config.token?.trim() ?? '';
  if (!expected) {
    return config.production
      ? { allowed: false, status: 503, code: 'ADMIN_AUTH_NOT_CONFIGURED', message: 'ADMIN_API_TOKEN is not configured.' }
      : { allowed: true };
  }

  const match = /^Bearer\s+(.+)$/i.exec(facts.authorization ?? '');
  if (!match || !sameSecret(match[1].trim(), expected)) {
    return { allowed: false, status: 401, code: 'ADMIN_AUTH_REQUIRED', message: 'A valid administrator bearer token is required.' };
  }

  const fetchSite = facts.fetchSite?.trim().toLowerCase();
  if (fetchSite && fetchSite !== 'same-origin' && fetchSite !== 'none') {
    return { allowed: false, status: 403, code: 'CROSS_ORIGIN_WRITE_BLOCKED', message: 'Cross-origin state-changing requests are not allowed.' };
  }

  if (facts.origin) {
    try {
      const origin = new URL(facts.origin);
      if (!facts.host || origin.host.toLowerCase() !== facts.host.toLowerCase() || !['http:', 'https:'].includes(origin.protocol)) {
        return { allowed: false, status: 403, code: 'ORIGIN_MISMATCH', message: 'State-changing requests must originate from this application.' };
      }
    } catch {
      return { allowed: false, status: 403, code: 'INVALID_ORIGIN', message: 'The request origin is invalid.' };
    }
  }

  return { allowed: true };
}

export function adminWriteGuardMiddleware(
  req: Request,
  res: Response,
  next: NextFunction,
): void {
  if (req.method === 'GET' || req.method === 'HEAD' || req.method === 'OPTIONS') {
    next();
    return;
  }

  const decision = validateAdminWriteRequest(
    { token: process.env.ADMIN_API_TOKEN, production: process.env.NODE_ENV === 'production' },
    {
      authorization: req.header('authorization'),
      origin: req.header('origin'),
      host: req.header('host'),
      fetchSite: req.header('sec-fetch-site'),
    },
  );

  if (!decision.allowed) {
    res.status(decision.status).json({ error: decision.message, code: decision.code });
    return;
  }
  next();
}

export function assertProductionAdminToken(token = process.env.ADMIN_API_TOKEN): void {
  if (process.env.NODE_ENV !== 'production') return;
  if (!token || token.trim().length < 32) {
    throw new Error('Production startup blocked: configure ADMIN_API_TOKEN with at least 32 characters (use a cryptographically random secret).');
  }
}
