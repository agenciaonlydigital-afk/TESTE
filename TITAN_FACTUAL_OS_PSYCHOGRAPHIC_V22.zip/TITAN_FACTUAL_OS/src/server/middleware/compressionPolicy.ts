/** Correctly handles explicit gzip q=0 and wildcard Accept-Encoding values. */
export function acceptsGzip(acceptEncoding: string): boolean {
  let wildcardQuality: number | null = null;
  let gzipQuality: number | null = null;

  for (const token of acceptEncoding.split(',')) {
    const [rawName, ...parameters] = token.trim().toLowerCase().split(';');
    const name = rawName?.trim();
    if (!name) continue;

    let quality = 1;
    for (const parameter of parameters) {
      const match = /^\s*q\s*=\s*(0(?:\.\d{0,3})?|1(?:\.0{0,3})?)\s*$/.exec(parameter);
      if (parameter.trim().startsWith('q=') || parameter.trim().startsWith('q =')) {
        quality = match ? Number(match[1]) : 0;
      }
    }

    if (name === 'gzip') gzipQuality = quality;
    else if (name === '*') wildcardQuality = quality;
  }

  return (gzipQuality ?? wildcardQuality ?? 0) > 0;
}
