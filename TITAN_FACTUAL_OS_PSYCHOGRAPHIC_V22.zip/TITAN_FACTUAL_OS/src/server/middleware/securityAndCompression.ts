import type { NextFunction, Request, Response } from 'express';
import zlib from 'node:zlib';
import { acceptsGzip } from './compressionPolicy.ts';

/**
 * Iframe-safe security headers:
 * Deliberately omits X-Frame-Options and restrictive frame-ancestors
 * so the AI Studio preview iframe embeds seamlessly.
 */
export function securityHeadersMiddleware(_req: Request, res: Response, next: NextFunction): void {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-DNS-Prefetch-Control', 'off');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  next();
}

/**
 * Native node:zlib gzip compression for /api/v1 JSON responses >= 1 KB.
 */
export function apiGzipCompressionMiddleware(req: Request, res: Response, next: NextFunction): void {
  // Vary must also be present on uncompressed responses so shared caches
  // never reuse identity bytes for a gzip-capable client (or vice versa).
  res.vary('Accept-Encoding');
  const acceptEncoding = String(req.headers['accept-encoding'] ?? '');
  if (!acceptsGzip(acceptEncoding)) {
    next();
    return;
  }

  const originalJson = res.json.bind(res);
  res.json = ((body: unknown): Response => {
    if (res.headersSent || res.getHeader('Content-Encoding')) {
      return originalJson(body);
    }

    const serialized = JSON.stringify(body);
    if (typeof serialized !== 'string' || Buffer.byteLength(serialized, 'utf-8') < 1024) {
      return originalJson(body);
    }

    const compressed = zlib.gzipSync(Buffer.from(serialized, 'utf-8'), { level: 6 });
    res.setHeader('Content-Encoding', 'gzip');
    res.setHeader('Vary', 'Accept-Encoding');
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Content-Length', compressed.length);
    return res.send(compressed);
  }) as Response['json'];

  next();
}
