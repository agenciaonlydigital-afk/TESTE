import { Router } from 'express';
import { z } from 'zod';
import { materializeAllGoldMarts } from '../../lakehouse/goldMaterializer.ts';
import {
  getBrandMarketProfiles,
  getContinentalMacroOverview,
  getH3MacroRollup,
  getMacroEconomicOverview,
  getSourceSilverPreview,
  getTerritoryDeepDive,
} from '../../lakehouse/queries.ts';
import { ApiError, asyncHandler } from '../middleware/errorHandler.ts';

const Iso3ParamSchema = z.object({
  iso3: z
    .string()
    .trim()
    .regex(/^[A-Za-z]{3}$/, 'ISO-3 code must be exactly 3 ASCII letters (e.g., BRA, USA)'),
});

const SourceIdParamSchema = z.object({
  sourceId: z
    .string()
    .trim()
    .regex(/^[a-z0-9_]{2,64}$/, 'Invalid source_id format'),
});

const BrandModeQuerySchema = z.object({
  mode: z.enum(['mass_market', 'premium']).optional(),
});

export function createGoldRouter(): Router {
  const router = Router();

  router.get(
    '/gold/macro-economics',
    asyncHandler(async (_req, res) => {
      const result = await getMacroEconomicOverview();
      res.setHeader('X-Cache', result.cacheStatus);
      res.setHeader('Cache-Control', 'public, max-age=300, stale-while-revalidate=86400');
      res.json(result);
    })
  );

  router.get(
    '/gold/continents',
    asyncHandler(async (_req, res) => {
      const result = await getContinentalMacroOverview();
      res.setHeader('X-Cache', result.cacheStatus);
      res.setHeader('Cache-Control', 'public, max-age=300, stale-while-revalidate=86400');
      res.json(result);
    })
  );

  router.get(
    '/gold/brand-profiles',
    asyncHandler(async (req, res) => {
      const parsed = BrandModeQuerySchema.parse({
        mode: typeof req.query.mode === 'string' ? req.query.mode : undefined,
      });
      const mode = parsed.mode ?? 'mass_market';
      const result = await getBrandMarketProfiles(mode);
      res.setHeader('X-Cache', result.cacheStatus);
      res.setHeader('Cache-Control', 'public, max-age=300, stale-while-revalidate=86400');
      res.json(result);
    })
  );

  router.get(
    '/gold/h3-macro',
    asyncHandler(async (_req, res) => {
      const result = await getH3MacroRollup();
      res.setHeader('X-Cache', result.cacheStatus);
      res.setHeader('Cache-Control', 'public, max-age=300, stale-while-revalidate=86400');
      res.json(result);
    })
  );

  router.post(
    '/gold/materialize',
    asyncHandler(async (_req, res) => {
      const report = await materializeAllGoldMarts();
      res.json({ ok: true, ...report });
    })
  );

  router.get(
    '/gold/territory/:iso3',
    asyncHandler(async (req, res) => {
      const { iso3 } = Iso3ParamSchema.parse(req.params);
      const payload = await getTerritoryDeepDive(iso3);
      if (!payload) {
        throw new ApiError(404, `Territory ${iso3.toUpperCase()} not found in canonical crosswalk`, 'TERRITORY_NOT_FOUND');
      }
      res.setHeader('X-Cache', String(payload.cacheStatus ?? 'MISS'));
      res.json(payload);
    })
  );

  router.get(
    '/gold/source/:sourceId',
    asyncHandler(async (req, res) => {
      const { sourceId } = SourceIdParamSchema.parse(req.params);
      const payload = await getSourceSilverPreview(sourceId);
      if (!payload) {
        throw new ApiError(404, `Source ${sourceId} not found in catalog`, 'SOURCE_NOT_FOUND');
      }
      res.setHeader('X-Cache', String(payload.cacheStatus ?? 'MISS'));
      res.json(payload);
    })
  );

  return router;
}
