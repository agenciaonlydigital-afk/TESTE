import { Router } from 'express';
import { z } from 'zod';
import {
  getControlPlaneOverview,
  listDataSources,
  listTerritories,
  resetCircuitBreaker,
  runControlPlaneMaintenance,
} from '../../lakehouse/controlPlane.ts';
import { CONNECTOR_REGISTRY, getActiveIngestionLocks, getConnectorRegistryCoverage } from '../../lakehouse/connectors.ts';
import { buildAcquisitionPlan } from '../../lakehouse/acquisitionPlanner.ts';
import { getDomainModuleSummary } from '../../lakehouse/domainRegistry.ts';
import { assessTerritoryRegistryReadiness } from '../../lakehouse/territoryRegistryReadiness.ts';
import { getDuckDBMetrics, getExtensionStatus } from '../../lakehouse/duckdbEngine.ts';
import { ensureGoldMartsIfEmpty } from '../../lakehouse/goldMaterializer.ts';
import { getHostHttpMetrics } from '../../lakehouse/httpCitizenship.ts';
import { getCacheStats, invalidateQueryCache } from '../../lakehouse/queries.ts';
import { ADMIN_LEVEL_ORDER, getAdminHierarchyTree } from '../../lakehouse/spatial/adminHierarchy.ts';
import type { AdminLevel } from '../../lakehouse/types.ts';
import { asyncHandler } from '../middleware/errorHandler.ts';

const HierarchyTreeQuerySchema = z.object({
  parentId: z
    .string()
    .trim()
    .regex(/^[A-Za-z0-9_.:-]{1,64}$/, 'Invalid parentId format')
    .optional(),
  level: z.enum(ADMIN_LEVEL_ORDER as [AdminLevel, ...AdminLevel[]]).optional(),
});

const ResetBreakerInputSchema = z.object({
  host: z
    .string()
    .trim()
    .regex(/^[a-zA-Z0-9.-]{1,120}$/, 'Invalid host format')
    .optional(),
});

export function createControlPlaneRouter(deps: {
  getDuckdbVersion: () => string;
  isShuttingDown: () => boolean;
}): Router {
  const router = Router();

  router.get('/health', (_req, res) => {
    res.json({
      ok: !deps.isShuttingDown(),
      service: 'TITAN FACTUAL OS',
      duckdbVersion: deps.getDuckdbVersion(),
      extensions: getExtensionStatus(),
      duckdbMetrics: getDuckDBMetrics(),
      cacheStats: getCacheStats(),
      activeIngestionLocks: getActiveIngestionLocks(),
      httpMetrics: getHostHttpMetrics(),
      timestamp: new Date().toISOString(),
    });
  });

  router.get('/catalog/sources', (req, res) => {
    const tier = typeof req.query.tier === 'string' ? req.query.tier : null;
    const commercialOnly = req.query.commercial_only === 'true';
    let sources = listDataSources();
    if (tier) {
      sources = sources.filter((s) => s.access_tier === tier);
    }
    if (commercialOnly) {
      sources = sources.filter((s) => s.commercial_use_allowed === 'confirmed');
    }
    res.json({ sources, total: sources.length });
  });

  router.get('/catalog/modules', (_req, res) => {
    const modules = getDomainModuleSummary();
    res.json({ modules, total: modules.length });
  });

  router.get('/catalog/coverage', (_req, res) => {
    const sources = listDataSources();
    const connectorRegistry = getConnectorRegistryCoverage();
    const territories = listTerritories();
    const territoryRegistry = assessTerritoryRegistryReadiness(territories.length, false);
    res.json({
      source_catalog_total: sources.length,
      source_catalog_implemented: sources.filter((source) => source.implemented_wave1 === 1).length,
      connector_registry: connectorRegistry,
      territory_registry: territoryRegistry,
    });
  });

  router.get('/acquisition/plan', (_req, res) => {
    const plan = buildAcquisitionPlan(listDataSources(), (sourceId) => CONNECTOR_REGISTRY.has(sourceId));
    const counts = plan.reduce<Record<string, number>>((acc, item) => { acc[item.readiness] = (acc[item.readiness] ?? 0) + 1; return acc; }, {});
    res.json({ plan, total: plan.length, counts, execution_note: 'Explainable plan only; execution remains inside the original source-specific connector handlers.' });
  });

  router.get('/control-plane/status', (_req, res) => {
    const overview = getControlPlaneOverview();
    const territories = listTerritories();
    const hierarchy = getAdminHierarchyTree();
    res.json({
      ...overview,
      territoryCount: territories.length,
      hierarchyCounts: hierarchy.countsByLevel,
      duckdbVersion: deps.getDuckdbVersion(),
      extensions: getExtensionStatus(),
      duckdbMetrics: getDuckDBMetrics(),
      cacheStats: getCacheStats(),
      activeIngestionLocks: getActiveIngestionLocks(),
      httpMetrics: getHostHttpMetrics(),
    });
  });

  router.get(
    '/hierarchy/tree',
    asyncHandler(async (req, res) => {
      const parsed = HierarchyTreeQuerySchema.parse({
        parentId:
          typeof req.query.parentId === 'string' && req.query.parentId.trim()
            ? req.query.parentId.trim()
            : undefined,
        level:
          typeof req.query.level === 'string' && req.query.level.trim()
            ? req.query.level.trim()
            : undefined,
      });

      res.json(
        getAdminHierarchyTree({
          parentId: parsed.parentId,
          level: parsed.level,
        })
      );
    })
  );

  router.post(
    '/control-plane/maintenance',
    asyncHandler(async (_req, res) => {
      const result = runControlPlaneMaintenance(2);
      invalidateQueryCache();
      const goldRebuilt = await ensureGoldMartsIfEmpty().catch(() => false);
      res.json({ ok: true, ...result, goldRebuilt });
    })
  );

  router.post(
    '/control-plane/breakers/reset',
    asyncHandler(async (req, res) => {
      const rawHost =
        typeof req.body?.host === 'string' && req.body.host.trim()
          ? req.body.host.trim()
          : typeof req.query.host === 'string' && req.query.host.trim()
            ? req.query.host.trim()
            : undefined;
      const { host } = ResetBreakerInputSchema.parse({ host: rawHost });
      const resetCount = resetCircuitBreaker(host);
      res.json({
        ok: true,
        host: host ?? 'ALL',
        resetCount,
        breakers: getControlPlaneOverview().breakers,
      });
    })
  );

  return router;
}
