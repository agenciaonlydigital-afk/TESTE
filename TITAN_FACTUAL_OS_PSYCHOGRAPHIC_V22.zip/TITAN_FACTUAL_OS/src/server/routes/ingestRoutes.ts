import { Router } from 'express';
import { z } from 'zod';
import { runConnectorIngestion, runCoreBatchIngestion } from '../../lakehouse/connectors.ts';
import { ApiError, asyncHandler } from '../middleware/errorHandler.ts';

const SourceIdParamSchema = z.object({
  sourceId: z
    .string()
    .trim()
    .regex(/^[a-z0-9_]{2,64}$/, 'Invalid sourceId format'),
});

function parseForceFlag(req: { query: Record<string, unknown>; body?: Record<string, unknown> }): boolean {
  return req.query.force === 'true' || req.body?.force === true;
}

export function createIngestRouter(): Router {
  const router = Router();

  router.post(
    '/ingest/:sourceId',
    asyncHandler(async (req, res) => {
      const { sourceId } = SourceIdParamSchema.parse(req.params);
      const force = parseForceFlag(req);
      try {
        const result = await runConnectorIngestion(sourceId, { force });
        res.status(result.status === 'FAILED' ? 502 : 200).json(result);
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        if (message.includes('already in progress')) {
          throw new ApiError(409, message, 'INGESTION_LOCK_CONFLICT');
        }
        throw new ApiError(400, message, 'INGESTION_REQUEST_ERROR');
      }
    })
  );

  router.post(
    ['/ingest-core', '/ingest-all'],
    asyncHandler(async (req, res) => {
      const force = parseForceFlag(req);
      try {
        const results = await runCoreBatchIngestion({ force });
        res.json({ results, force });
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        if (message.includes('already in progress')) {
          throw new ApiError(409, message, 'BATCH_LOCK_CONFLICT');
        }
        throw err;
      }
    })
  );

  return router;
}
