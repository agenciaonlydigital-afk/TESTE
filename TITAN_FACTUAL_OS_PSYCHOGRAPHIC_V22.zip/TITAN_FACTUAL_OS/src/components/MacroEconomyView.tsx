import { Database, Layers, Search, X } from 'lucide-react';
import { useEffect, useMemo, useRef, useState } from 'react';
import type { AdminLevel, H3MacroCellRow, MacroEconomicRow } from '../types/lakehouse.ts';
import { AdminHierarchyExplorer } from './macro/AdminHierarchyExplorer.tsx';
import { H3RollupTable } from './macro/H3RollupTable.tsx';
import { MacroChartsSection } from './macro/MacroChartsSection.tsx';
import {
  CHART_METRICS,
  COLUMNS,
  hasAnyMacroMetric,
  type ChartMetricKey,
  type ColumnLens,
  type SortKey,
  type TerritoryDetailPayload,
} from './macro/macroColumnsConfig.ts';
import { fmtCompactUsd, fmtNum, fmtPct, hasNum, median } from './macro/macroFormatters.ts';
import { MacroTerritoriesTable } from './macro/MacroTerritoriesTable.tsx';
import { TerritoryInspectorPanel } from './macro/TerritoryInspectorPanel.tsx';

interface MacroEconomyViewProps {
  rows: MacroEconomicRow[];
  h3Cells: H3MacroCellRow[];
  cacheStatus: string;
  snapshotCount: number;
  loading: boolean;
  syncingCore: boolean;
  onSyncCore: (force?: boolean) => void;
  totalApiCount?: number;
  hierarchyCounts?: Record<AdminLevel, number>;
}

export function MacroEconomyView({
  rows,
  h3Cells,
  cacheStatus,
  snapshotCount,
  loading,
  syncingCore,
  onSyncCore,
  totalApiCount = 79,
  hierarchyCounts,
}: MacroEconomyViewProps) {
  const apiTarget = totalApiCount > 0 ? totalApiCount : 79;
  const [viewMode, setViewMode] = useState<'territories' | 'h3' | 'hierarchy'>('territories');
  const [columnLens, setColumnLens] = useState<ColumnLens>('sdmx_macro');
  const [chartMetric, setChartMetric] = useState<ChartMetricKey>('gdp_per_capita_ppp_2021');
  const [search, setSearch] = useState('');
  const [hierarchySearch, setHierarchySearch] = useState('');
  const [continent, setContinent] = useState('All');
  const [sortBy, setSortBy] = useState<SortKey>('gdp_per_capita_ppp_2021');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');

  const [selectedIso3, setSelectedIso3] = useState<string | null>(null);
  const [detail, setDetail] = useState<TerritoryDetailPayload | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailError, setDetailError] = useState<string | null>(null);
  const detailAbortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    return () => {
      detailAbortRef.current?.abort();
    };
  }, []);

  const continents = useMemo(() => {
    const set = new Set(rows.map((r) => r.continent));
    return ['All', ...Array.from(set).sort()];
  }, [rows]);

  const populatedCount = useMemo(() => rows.filter(hasAnyMacroMetric).length, [rows]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    const list = rows.filter((r) => {
      if (continent !== 'All' && r.continent !== continent) return false;
      if (!q) return true;
      return (
        r.name_en.toLowerCase().includes(q) ||
        r.iso3.toLowerCase().includes(q) ||
        r.region.toLowerCase().includes(q) ||
        (r.h3_res2?.toLowerCase().includes(q) ?? false)
      );
    });

    return [...list].sort((a, b) => {
      if (sortBy === 'name_en') {
        const cmp = a.name_en.localeCompare(b.name_en);
        return sortDir === 'asc' ? cmp : -cmp;
      }
      const va = a[sortBy];
      const vb = b[sortBy];
      const hasA = typeof va === 'number' && Number.isFinite(va);
      const hasB = typeof vb === 'number' && Number.isFinite(vb);
      if (!hasA && !hasB) return a.name_en.localeCompare(b.name_en);
      if (!hasA) return 1;
      if (!hasB) return -1;
      return sortDir === 'asc' ? va - vb : vb - va;
    });
  }, [rows, search, continent, sortBy, sortDir]);

  const kpis = useMemo(() => {
    const populatedFiltered = filtered.filter(hasAnyMacroMetric).length;
    const gdpPppVals = filtered.map((r) => r.gdp_per_capita_ppp_2021).filter(hasNum);
    const gdpNominalSum = filtered.reduce((acc, r) => acc + (r.gdp_nominal_usd ?? 0), 0);
    const cpiVals = filtered.map((r) => r.inflation_cpi_pct).filter(hasNum);
    const rateVals = filtered.map((r) => r.imf_policy_rate_pct).filter(hasNum);
    const lfprVals = filtered.map((r) => r.ilostat_lfpr_pct).filter(hasNum);
    const unempVals = filtered.map((r) => r.unemployment_pct).filter(hasNum);
    const cliVals = filtered.map((r) => r.oecd_cli_index).filter(hasNum);
    const reerVals = filtered.map((r) => r.imf_reer_index).filter(hasNum);

    return {
      populatedFiltered,
      medianGdpPpp: median(gdpPppVals),
      gdpObsCount: gdpPppVals.length,
      gdpNominalSum: gdpNominalSum > 0 ? gdpNominalSum : null,
      medianCpi: median(cpiVals),
      medianRate: median(rateVals),
      rateCount: rateVals.length,
      medianLfpr: median(lfprVals),
      medianUnemp: median(unempVals),
      medianCli: median(cliVals),
      medianReer: median(reerVals),
    };
  }, [filtered]);

  const chartMeta = useMemo(
    () => CHART_METRICS.find((m) => m.key === chartMetric) ?? CHART_METRICS[0],
    [chartMetric]
  );

  const topMetricRows = useMemo(() => {
    return filtered
      .filter((r) => hasNum(r[chartMetric]))
      .sort((a, b) => (b[chartMetric] as number) - (a[chartMetric] as number))
      .slice(0, 10);
  }, [filtered, chartMetric]);

  const cycleDivergence = useMemo(() => {
    const cliRows = filtered.filter((r) => hasNum(r.oecd_cli_index));
    if (cliRows.length > 0) {
      const ranked = [...cliRows]
        .sort(
          (a, b) =>
            Math.abs((b.oecd_cli_index as number) - 100) -
            Math.abs((a.oecd_cli_index as number) - 100)
        )
        .slice(0, 10)
        .sort((a, b) => (b.oecd_cli_index as number) - (a.oecd_cli_index as number));
      return {
        mode: 'cli' as const,
        anchor: 100,
        title: 'OECD Business Cycle Dispersion (CLI 100 = Trend)',
        subtitle: `${cliRows.length} OECD-covered economies · click any territory to inspect SDMX history`,
        items: ranked.map((r) => ({
          iso3: r.iso3,
          name: r.name_en,
          value: r.oecd_cli_index as number,
          delta: (r.oecd_cli_index as number) - 100,
          label: (r.oecd_cli_index as number).toFixed(2),
        })),
      };
    }

    const growthRows = filtered.filter((r) => hasNum(r.imf_real_gdp_growth_pct));
    const rankedGrowth = [...growthRows]
      .sort(
        (a, b) =>
          Math.abs(b.imf_real_gdp_growth_pct as number) -
          Math.abs(a.imf_real_gdp_growth_pct as number)
      )
      .slice(0, 10)
      .sort((a, b) => (b.imf_real_gdp_growth_pct as number) - (a.imf_real_gdp_growth_pct as number));

    return {
      mode: 'growth' as const,
      anchor: 0,
      title: 'IMF WEO Real GDP Growth Dispersion',
      subtitle: `${growthRows.length} IMF-covered economies · click any territory to inspect`,
      items: rankedGrowth.map((r) => ({
        iso3: r.iso3,
        name: r.name_en,
        value: r.imf_real_gdp_growth_pct as number,
        delta: r.imf_real_gdp_growth_pct as number,
        label: `${(r.imf_real_gdp_growth_pct as number).toFixed(1)}%`,
      })),
    };
  }, [filtered]);

  const visibleColumns = useMemo(
    () => COLUMNS.filter((c) => c.lenses.includes(columnLens)),
    [columnLens]
  );

  function handleSort(key: SortKey) {
    if (sortBy === key) {
      setSortDir((prev) => (prev === 'desc' ? 'asc' : 'desc'));
    } else {
      setSortBy(key);
      setSortDir(key === 'name_en' ? 'asc' : 'desc');
    }
  }

  async function handleSelectTerritory(iso3: string) {
    detailAbortRef.current?.abort();
    const controller = new AbortController();
    detailAbortRef.current = controller;

    setSelectedIso3(iso3);
    setDetail(null);
    setDetailError(null);
    setDetailLoading(true);
    try {
      const res = await fetch(`/api/v1/gold/territory/${encodeURIComponent(iso3)}`, {
        signal: controller.signal,
      });
      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }
      const payload = (await res.json()) as TerritoryDetailPayload;
      if (!controller.signal.aborted) {
        setDetail(payload);
      }
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') return;
      if (!controller.signal.aborted) {
        setDetailError(err instanceof Error ? err.message : 'Failed to load territory observations');
      }
    } finally {
      if (!controller.signal.aborted) {
        setDetailLoading(false);
      }
    }
  }

  return (
    <div className="space-y-6">
      {/* Section Header */}
      <div className="flex flex-col gap-2 md:flex-row md:items-end md:justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-100">
            Macro-Micro Economic & SDMX Dashboard
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            DuckDB vectorized analytics over ZSTD Parquet snapshots unifying {apiTarget} active Wave-1 feeds across Global → Continente → País → Estado → Cidade spatial levels (U.S. Census, UNDP HDI, NOAA NCEI, Global Forest Watch, U.S. EIA, India MoSPI, ICAO Aviation, WDPA, UN Comtrade, PWT, WID.world, ITU, WIPO, UNODC, GHSL, GADM, ECB, IMF SDMX 2.1/3.0, World Bank, WITS, ILOSTAT, OECD, Eurostat, V-Dem, UN/LOCODE, CKAN, OSM, FAOSTAT, NASA, OpenAlex &amp; Wikidata).
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
          <span>{snapshotCount}/{apiTarget} Active Silver</span>
          <span aria-hidden="true">·</span>
          <span>{populatedCount}/{rows.length} Territories</span>
          <span aria-hidden="true">·</span>
          <span>L1 Cache: {cacheStatus}</span>
          {!loading && snapshotCount > 0 && snapshotCount < apiTarget && (
            <>
              <span aria-hidden="true">·</span>
              <button
                type="button"
                disabled={syncingCore}
                onClick={() => onSyncCore(false)}
                className="font-sans font-medium text-slate-900 dark:text-slate-100 underline hover:no-underline disabled:opacity-50 whitespace-nowrap shrink-0"
              >
                {syncingCore ? `Syncing All ${apiTarget}...` : 'Sync All APIs'}
              </button>
            </>
          )}
        </div>
      </div>

      {/* Cold-Start Recovery Banner */}
      {!loading && snapshotCount === 0 && (
        <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-start gap-3">
            <Database className="h-5 w-5 text-slate-500 mt-0.5 shrink-0" />
            <div>
              <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                No Silver Parquet Snapshots Promoted Yet
              </h2>
              <p className="mt-1 text-xs text-slate-600 dark:text-slate-400 max-w-xl">
                The canonical territory crosswalk is loaded and zero mock figures are fabricated. Run the batch sync to fetch all {apiTarget} live macro, trade, SDMX, governance, logistics, urban, R&amp;D, energy, and spatial feeds.
              </p>
            </div>
          </div>
          <button
            type="button"
            disabled={syncingCore}
            onClick={() => onSyncCore(false)}
            className="rounded-lg bg-slate-900 dark:bg-slate-100 px-4 py-2 text-xs font-medium text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-white disabled:opacity-50 transition-colors whitespace-nowrap shrink-0"
          >
            {syncingCore ? `Syncing All ${apiTarget} APIs...` : `Sync All APIs (${apiTarget})`}
          </button>
        </div>
      )}

      {/* 4-Card KPI Summary Strip */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
          <div className="text-xs text-slate-500 dark:text-slate-400">Territories & Active Feeds</div>
          <div className="mt-1 text-lg font-semibold font-mono tabular-nums text-slate-900 dark:text-slate-100">
            {kpis.populatedFiltered}/{filtered.length}
          </div>
          <div className="mt-0.5 text-[11px] font-mono text-slate-500 dark:text-slate-400 tabular-nums">
            {snapshotCount}/{apiTarget} Wave-1 Silver · {continent}
          </div>
        </div>

        <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
          <div className="text-xs text-slate-500 dark:text-slate-400">Median GDP / Cap PPP</div>
          <div className="mt-1 text-lg font-semibold font-mono tabular-nums text-slate-900 dark:text-slate-100">
            {fmtCompactUsd(kpis.medianGdpPpp)}
          </div>
          <div className="mt-0.5 text-[11px] font-mono text-slate-500 dark:text-slate-400 tabular-nums">
            Sum GDP {fmtCompactUsd(kpis.gdpNominalSum)} · {kpis.gdpObsCount} obs
          </div>
        </div>

        <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
          <div className="text-xs text-slate-500 dark:text-slate-400">Median CPI · IMF Rate</div>
          <div className="mt-1 text-lg font-semibold font-mono tabular-nums text-slate-900 dark:text-slate-100">
            {fmtPct(kpis.medianCpi)} · {fmtNum(kpis.medianRate, 2, '%')}
          </div>
          <div className="mt-0.5 text-[11px] font-mono text-slate-500 dark:text-slate-400 tabular-nums">
            IMF WEO + MFS_IR SDMX · {kpis.rateCount} rates
          </div>
        </div>

        <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
          <div className="text-xs text-slate-500 dark:text-slate-400">Labor LFPR · OECD CLI</div>
          <div className="mt-1 text-lg font-semibold font-mono tabular-nums text-slate-900 dark:text-slate-100">
            {fmtPct(kpis.medianLfpr)} · {fmtNum(kpis.medianCli, 2)}
          </div>
          <div className="mt-0.5 text-[11px] font-mono text-slate-500 dark:text-slate-400 tabular-nums">
            Unemp {fmtPct(kpis.medianUnemp)} · REER {fmtNum(kpis.medianReer, 1)}
          </div>
        </div>
      </section>

      {/* Search, View Mode, Column Lens & Continent Controls */}
      <div className="flex flex-col gap-3">
        <div className="flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1 rounded-lg bg-slate-100 dark:bg-slate-900 p-1 border border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setViewMode('territories')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  viewMode === 'territories'
                    ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                Territories ({rows.length})
              </button>
              <button
                type="button"
                onClick={() => setViewMode('hierarchy')}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  viewMode === 'hierarchy'
                    ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                <Layers className="h-3.5 w-3.5" />
                <span>Global → City</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('h3')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  viewMode === 'h3'
                    ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                H3 Res-2 Rollup ({h3Cells.length})
              </button>
            </div>

            {viewMode === 'territories' && (
              <div className="relative w-full sm:w-64">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search country, ISO3, or H3..."
                  className="w-full rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 py-2 pl-9 pr-7 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-900 dark:focus:ring-slate-400"
                />
                {search && (
                  <button
                    type="button"
                    aria-label="Clear search"
                    onClick={() => setSearch('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>
            )}

            {viewMode === 'hierarchy' && (
              <div className="relative w-full sm:w-72">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={hierarchySearch}
                  onChange={(e) => setHierarchySearch(e.target.value)}
                  placeholder="Filter continent, country, state, city..."
                  className="w-full rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 py-2 pl-9 pr-7 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-900 dark:focus:ring-slate-400"
                />
                {hierarchySearch && (
                  <button
                    type="button"
                    aria-label="Clear hierarchy filter"
                    onClick={() => setHierarchySearch('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>
            )}

            {viewMode === 'territories' && (
              <div className="flex items-center gap-1 rounded-lg bg-slate-100 dark:bg-slate-900 p-1 border border-slate-200 dark:border-slate-800">
                {(
                  [
                    { id: 'sdmx_macro', label: 'SDMX & Macro' },
                    { id: 'energy_rnd', label: 'Energy, R&D & SDG' },
                    { id: 'structural', label: 'Structural' },
                    { id: 'all', label: `All ${COLUMNS.length}` },
                  ] as const
                ).map((lens) => (
                  <button
                    key={lens.id}
                    type="button"
                    onClick={() => setColumnLens(lens.id)}
                    className={`px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                      columnLens === lens.id
                        ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                    }`}
                  >
                    {lens.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {viewMode === 'territories' && (
            <div className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-100 dark:bg-slate-900 p-1 border border-slate-200 dark:border-slate-800">
              {continents.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setContinent(c)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    continent === c
                      ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Interactive SVG Dashboard Visualizations */}
      {viewMode === 'territories' && kpis.populatedFiltered > 0 && (
        <MacroChartsSection
          chartMetric={chartMetric}
          onChartMetricChange={setChartMetric}
          chartMeta={chartMeta}
          topMetricRows={topMetricRows}
          cycleDivergence={cycleDivergence}
          selectedIso3={selectedIso3}
          onSelectTerritory={(iso3) => void handleSelectTerritory(iso3)}
        />
      )}

      {viewMode === 'h3' ? (
        <H3RollupTable
          h3Cells={h3Cells}
          onSelectCell={(h3Index) => {
            setSearch(h3Index);
            setViewMode('territories');
          }}
        />
      ) : (
        <div className="grid grid-cols-1 gap-6 xl:grid-cols-12 items-start">
          <div className={selectedIso3 ? 'xl:col-span-8' : 'xl:col-span-12'}>
            {viewMode === 'hierarchy' ? (
              <AdminHierarchyExplorer
                hierarchyCounts={hierarchyCounts}
                search={hierarchySearch}
                onClearSearch={() => setHierarchySearch('')}
                onSelectTerritory={(iso3) => void handleSelectTerritory(iso3)}
              />
            ) : (
              <MacroTerritoriesTable
                rows={filtered}
                visibleColumns={visibleColumns}
                sortBy={sortBy}
                sortDir={sortDir}
                loading={loading}
                selectedIso3={selectedIso3}
                onSort={handleSort}
                onSelectTerritory={(iso3) => void handleSelectTerritory(iso3)}
              />
            )}
          </div>

          {selectedIso3 && (
            <TerritoryInspectorPanel
              selectedIso3={selectedIso3}
              detail={detail}
              detailLoading={detailLoading}
              detailError={detailError}
              onClose={() => {
                detailAbortRef.current?.abort();
                setSelectedIso3(null);
                setDetail(null);
                setDetailError(null);
              }}
            />
          )}
        </div>
      )}
    </div>
  );
}
