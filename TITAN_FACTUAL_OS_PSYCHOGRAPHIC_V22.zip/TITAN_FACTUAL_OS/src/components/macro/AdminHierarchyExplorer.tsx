import { ChevronRight, Globe } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import type { AdminLevel, SpatialAdminNode } from '../../types/lakehouse.ts';
import { fmtPop, hasNum } from './macroFormatters.ts';

interface AdminHierarchyExplorerProps {
  hierarchyCounts?: Record<AdminLevel, number>;
  search: string;
  onClearSearch: () => void;
  onSelectTerritory: (iso3: string) => void;
}

const HIERARCHY_LEVELS: ReadonlyArray<{ level: AdminLevel; label: string; sub: string }> = [
  { level: 'global', label: 'Global', sub: 'H3 R0' },
  { level: 'continent', label: 'Continente', sub: 'H3 R1' },
  { level: 'country', label: 'País', sub: 'ADM0 · H3 R2' },
  { level: 'state', label: 'Estado / UF', sub: 'ADM1 · H3 R4' },
  { level: 'city', label: 'Cidade', sub: 'ADM2 · H3 R6' },
  { level: 'neighborhood', label: 'Bairro', sub: 'ADM3 · H3 R8' },
];

export function AdminHierarchyExplorer({
  hierarchyCounts,
  search,
  onClearSearch,
  onSelectTerritory,
}: AdminHierarchyExplorerProps) {
  const [trail, setTrail] = useState<Array<{ node_id: string; name: string; level: AdminLevel }>>([
    { node_id: 'GLOBAL', name: 'Global', level: 'global' },
  ]);
  const [levelJump, setLevelJump] = useState<AdminLevel | null>(null);
  const [nodes, setNodes] = useState<SpatialAdminNode[]>([]);
  const [counts, setCounts] = useState<Record<AdminLevel, number> | null>(hierarchyCounts ?? null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (hierarchyCounts) {
      setCounts(hierarchyCounts);
    }
  }, [hierarchyCounts]);

  const currentParentId = trail[trail.length - 1]?.node_id ?? 'GLOBAL';

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    const query = levelJump
      ? `level=${encodeURIComponent(levelJump)}`
      : `parentId=${encodeURIComponent(currentParentId)}`;
    fetch(`/api/v1/hierarchy/tree?${query}`, { signal: controller.signal })
      .then(async (r) => {
        if (!r.ok) throw new Error(`Hierarchy HTTP ${r.status}`);
        return (await r.json()) as {
          nodes: SpatialAdminNode[];
          ancestors?: Array<{ node_id: string; name_en: string; level: AdminLevel }>;
          countsByLevel: Record<AdminLevel, number>;
        };
      })
      .then((payload) => {
        if (controller.signal.aborted) return;
        setNodes(payload.nodes ?? []);
        if (payload.countsByLevel) {
          setCounts(payload.countsByLevel);
        }
        if (!levelJump && Array.isArray(payload.ancestors) && payload.ancestors.length > 0) {
          const nextTrail = payload.ancestors.map((a) => ({
            node_id: a.node_id,
            name: a.name_en,
            level: a.level,
          }));
          setTrail((prev) => {
            const prevKey = prev.map((p) => p.node_id).join('/');
            const nextKey = nextTrail.map((n) => n.node_id).join('/');
            return prevKey === nextKey ? prev : nextTrail;
          });
        }
      })
      .catch((err) => {
        if (err instanceof DOMException && err.name === 'AbortError') return;
        setNodes([]);
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });

    return () => {
      controller.abort();
    };
  }, [currentParentId, levelJump]);

  const filteredNodes = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return nodes;
    return nodes.filter(
      (n) =>
        n.name_en.toLowerCase().includes(q) ||
        n.code.toLowerCase().includes(q) ||
        (n.iso3?.toLowerCase().includes(q) ?? false) ||
        (n.h3_index?.toLowerCase().includes(q) ?? false)
    );
  }, [nodes, search]);

  const lastTrailLevel = trail[trail.length - 1]?.level ?? 'global';
  const displayedLevel: AdminLevel =
    levelJump ??
    (lastTrailLevel === 'global'
      ? 'continent'
      : lastTrailLevel === 'continent'
        ? 'country'
        : lastTrailLevel === 'country'
          ? 'state'
          : lastTrailLevel === 'state'
            ? 'city'
            : 'neighborhood');

  return (
    <div className="space-y-4">
      {/* 6-Level Hierarchy Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
        {HIERARCHY_LEVELS.map((item) => {
          const count = counts ? counts[item.level] : 0;
          const isActive = displayedLevel === item.level;
          return (
            <button
              key={item.level}
              type="button"
              onClick={() => {
                onClearSearch();
                setLevelJump(item.level);
              }}
              className={`rounded-lg border p-3 text-left transition-colors ${
                isActive
                  ? 'border-slate-900 dark:border-slate-200 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/60'
              }`}
            >
              <div className="text-xs font-medium">{item.label}</div>
              <div className="mt-1 text-base font-semibold font-mono tabular-nums">
                {count.toLocaleString('en-US')}
              </div>
              <div
                className={`text-[10px] font-mono ${
                  isActive ? 'text-slate-300 dark:text-slate-600' : 'text-slate-400'
                }`}
              >
                {item.sub}
              </div>
            </button>
          );
        })}
      </div>

      {/* Breadcrumb Drill-Down Trail */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-2.5 text-xs">
        <div className="flex flex-wrap items-center gap-1.5">
          <Globe className="h-3.5 w-3.5 text-slate-400 mr-1" />
          {levelJump ? (
            <>
              <button
                type="button"
                onClick={() => {
                  setLevelJump(null);
                  setTrail([{ node_id: 'GLOBAL', name: 'Global', level: 'global' }]);
                }}
                className="font-medium text-sky-700 dark:text-sky-400 hover:underline"
              >
                Back to Tree Drill-Down
              </button>
              <ChevronRight className="h-3.5 w-3.5 text-slate-400" />
              <span className="font-mono font-semibold text-slate-900 dark:text-slate-100 uppercase">
                All {levelJump} ({filteredNodes.length})
              </span>
            </>
          ) : (
            trail.map((crumb, idx) => {
              const isLast = idx === trail.length - 1;
              return (
                <div key={crumb.node_id} className="inline-flex items-center gap-1.5">
                  {idx > 0 && <ChevronRight className="h-3.5 w-3.5 text-slate-400" />}
                  <button
                    type="button"
                    onClick={() => {
                      onClearSearch();
                      setLevelJump(null);
                      setTrail((prev) => prev.slice(0, idx + 1));
                    }}
                    className={
                      isLast
                        ? 'font-semibold text-slate-900 dark:text-slate-100'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 hover:underline'
                    }
                  >
                    {crumb.name}
                  </button>
                </div>
              );
            })
          )}
        </div>
        <span className="font-mono text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
          {filteredNodes.length} nodes shown
        </span>
      </div>

      {/* Hierarchy Table */}
      <div className="overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
        <table className="w-full border-collapse text-left text-xs">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-medium text-slate-500 dark:text-slate-400">
              <th className="px-4 py-3">Admin Name</th>
              <th className="px-3 py-3">Level</th>
              <th className="px-3 py-3">Code / ISO3</th>
              <th className="px-3 py-3">H3 Index</th>
              <th className="px-3 py-3 text-right">Lat / Lon</th>
              <th className="px-3 py-3 text-right">Population Est.</th>
              <th className="px-4 py-3 text-right">Sub-Units & Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
            {loading ? (
              Array.from({ length: 6 }).map((_, idx) => (
                <tr key={idx}>
                  <td colSpan={7} className="px-4 py-3">
                    <div className="h-4 w-full rounded bg-slate-100 dark:bg-slate-800" />
                  </td>
                </tr>
              ))
            ) : filteredNodes.length === 0 ? (
              <tr>
                <td colSpan={7} className="px-4 py-8 text-center text-slate-500 dark:text-slate-400">
                  {search.trim()
                    ? 'No spatial nodes match this filter at the selected hierarchy level.'
                    : 'No sub-units indexed at this level yet.'}
                </td>
              </tr>
            ) : (
              filteredNodes.map((node) => {
                const canDrill = (node.child_count ?? 0) > 0;
                return (
                  <tr
                    key={node.node_id}
                    onClick={() => {
                      if (!canDrill) return;
                      onClearSearch();
                      setLevelJump(null);
                      if (levelJump) {
                        setTrail([{ node_id: node.node_id, name: node.name_en, level: node.level }]);
                      } else {
                        setTrail((prev) => [
                          ...prev,
                          { node_id: node.node_id, name: node.name_en, level: node.level },
                        ]);
                      }
                    }}
                    className={
                      canDrill
                        ? 'cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/40'
                        : 'hover:bg-slate-50/50 dark:hover:bg-slate-800/20'
                    }
                  >
                    <td className="px-4 py-2.5 font-medium text-slate-900 dark:text-slate-100">
                      <div className="flex items-center gap-1.5">
                        <span>{node.name_en}</span>
                        {canDrill && <ChevronRight className="h-3.5 w-3.5 text-slate-400" />}
                      </div>
                      {node.name_local && node.name_local !== node.name_en && (
                        <div className="text-[11px] text-slate-500 dark:text-slate-400">
                          {node.name_local}
                        </div>
                      )}
                    </td>
                    <td className="px-3 py-2.5 font-mono text-[11px] uppercase text-slate-600 dark:text-slate-400">
                      {node.level}
                    </td>
                    <td className="px-3 py-2.5 font-mono text-slate-700 dark:text-slate-300">
                      {node.iso3 ? `${node.iso3} · ` : ''}
                      {node.code}
                    </td>
                    <td className="px-3 py-2.5 font-mono text-[11px] text-slate-600 dark:text-slate-400">
                      {node.h3_index ? `${node.h3_index} (R${node.h3_resolution})` : `R${node.h3_resolution}`}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-600 dark:text-slate-400 whitespace-nowrap">
                      {hasNum(node.centroid_lat) && hasNum(node.centroid_lon)
                        ? `${node.centroid_lat.toFixed(2)}, ${node.centroid_lon.toFixed(2)}`
                        : '—'}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-800 dark:text-slate-200">
                      {fmtPop(node.population_est)}
                    </td>
                    <td className="px-4 py-2.5 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-2">
                        <span className="font-mono tabular-nums text-slate-700 dark:text-slate-300">
                          {hasNum(node.child_count) ? `${node.child_count} children` : '—'}
                        </span>
                        {node.iso3 && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onSelectTerritory(node.iso3!);
                            }}
                            className="rounded border border-slate-200 dark:border-slate-700 px-2 py-0.5 text-[11px] font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                          >
                            Macro
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
