import { ArrowDown, ArrowUp, ArrowUpRight } from 'lucide-react';
import type { MacroEconomicRow } from '../../types/lakehouse.ts';
import type { ColumnDef, SortKey } from './macroColumnsConfig.ts';

interface MacroTerritoriesTableProps {
  rows: MacroEconomicRow[];
  visibleColumns: ColumnDef[];
  sortBy: SortKey;
  sortDir: 'asc' | 'desc';
  loading: boolean;
  selectedIso3: string | null;
  onSort: (key: SortKey) => void;
  onSelectTerritory: (iso3: string) => void;
}

export function MacroTerritoriesTable({
  rows,
  visibleColumns,
  sortBy,
  sortDir,
  loading,
  selectedIso3,
  onSort,
  onSelectTerritory,
}: MacroTerritoriesTableProps) {
  return (
    <div className="overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
      <table className="w-full border-collapse text-left text-xs">
        <thead>
          <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-medium text-slate-500 dark:text-slate-400">
            <th
              scope="col"
              aria-sort={sortBy === 'name_en' ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
              className="sticky left-0 z-10 bg-slate-50 dark:bg-slate-950 border-r border-slate-200 dark:border-slate-800 px-3.5 py-3 whitespace-nowrap"
            >
              <button
                type="button"
                onClick={() => onSort('name_en')}
                className="inline-flex items-center gap-1 hover:text-slate-900 dark:hover:text-slate-100"
              >
                <span>Territory</span>
                {sortBy === 'name_en' &&
                  (sortDir === 'asc' ? (
                    <ArrowUp className="h-3 w-3" />
                  ) : (
                    <ArrowDown className="h-3 w-3" />
                  ))}
              </button>
            </th>
            {visibleColumns.map((col) => {
              const activeSort = sortBy === col.key;
              return (
                <th
                  key={col.key}
                  scope="col"
                  title={col.title}
                  aria-sort={activeSort ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'}
                  className="px-3 py-3 text-right whitespace-nowrap"
                >
                  <button
                    type="button"
                    onClick={() => onSort(col.key)}
                    className={`inline-flex items-center justify-end gap-1 hover:text-slate-900 dark:hover:text-slate-100 ${
                      activeSort ? 'text-slate-900 dark:text-slate-100 font-semibold' : ''
                    }`}
                  >
                    <span>{col.label}</span>
                    {activeSort &&
                      (sortDir === 'asc' ? (
                        <ArrowUp className="h-3 w-3" />
                      ) : (
                        <ArrowDown className="h-3 w-3" />
                      ))}
                  </button>
                </th>
              );
            })}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
          {loading ? (
            Array.from({ length: 8 }).map((_, idx) => (
              <tr key={idx}>
                <td colSpan={visibleColumns.length + 1} className="px-4 py-3">
                  <div className="h-4 w-full rounded bg-slate-100 dark:bg-slate-800" />
                </td>
              </tr>
            ))
          ) : rows.length === 0 ? (
            <tr>
              <td
                colSpan={visibleColumns.length + 1}
                className="px-4 py-8 text-center text-slate-500 dark:text-slate-400"
              >
                No territories match the active search or continent filter.
              </td>
            </tr>
          ) : (
            rows.map((r) => {
              const isSelected = selectedIso3 === r.iso3;
              return (
                <tr
                  key={r.territory_id}
                  tabIndex={0}
                  role="button"
                  aria-pressed={isSelected}
                  onClick={() => onSelectTerritory(r.iso3)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      onSelectTerritory(r.iso3);
                    }
                  }}
                  className={`cursor-pointer transition-colors focus:outline-none focus:ring-2 focus:ring-inset focus:ring-slate-900 dark:focus:ring-slate-400 ${
                    isSelected
                      ? 'bg-slate-100 dark:bg-slate-800/80'
                      : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
                  }`}
                >
                  <td
                    className={`sticky left-0 z-10 border-r border-slate-200 dark:border-slate-800 px-3.5 py-2.5 whitespace-nowrap ${
                      isSelected ? 'bg-slate-100 dark:bg-slate-800' : 'bg-white dark:bg-slate-900'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 font-medium text-slate-900 dark:text-slate-100">
                      <span>{r.name_en}</span>
                      <ArrowUpRight className="h-3 w-3 text-slate-400" />
                    </div>
                    <div className="font-mono text-[11px] text-slate-500 dark:text-slate-400">
                      {r.iso3} · {r.continent}
                    </div>
                  </td>
                  {visibleColumns.map((col) => (
                    <td
                      key={col.key}
                      className={`px-3 py-2.5 text-right font-mono tabular-nums whitespace-nowrap ${
                        col.tone ? col.tone(r) : 'text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {col.format(r)}
                    </td>
                  ))}
                </tr>
              );
            })
          )}
        </tbody>
      </table>
    </div>
  );
}
