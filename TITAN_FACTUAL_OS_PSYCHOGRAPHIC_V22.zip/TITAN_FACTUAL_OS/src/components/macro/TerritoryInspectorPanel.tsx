import { Search, X } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import type { TerritoryDetailPayload } from './macroColumnsConfig.ts';
import { hasNum } from './macroFormatters.ts';

interface TerritoryInspectorPanelProps {
  selectedIso3: string;
  detail: TerritoryDetailPayload | null;
  detailLoading: boolean;
  detailError?: string | null;
  onClose: () => void;
}

export function TerritoryInspectorPanel({
  selectedIso3,
  detail,
  detailLoading,
  detailError = null,
  onClose,
}: TerritoryInspectorPanelProps) {
  const [sourceFilter, setSourceFilter] = useState<string>('all');
  const [indicatorQuery, setIndicatorQuery] = useState<string>('');
  const [selectedIndicatorId, setSelectedIndicatorId] = useState<string>('');
  const [hoveredPointIdx, setHoveredPointIdx] = useState<number | null>(null);

  useEffect(() => {
    setSourceFilter('all');
    setIndicatorQuery('');
    setSelectedIndicatorId('');
    setHoveredPointIdx(null);
  }, [selectedIso3]);

  const detailSources = useMemo(() => {
    if (!detail) return [];
    const unique = new Set<string>();
    for (const obs of detail.series) {
      unique.add(obs.source_id);
    }
    return Array.from(unique).sort();
  }, [detail]);

  const filteredDetailSeries = useMemo(() => {
    if (!detail) return [];
    const q = indicatorQuery.trim().toLowerCase();
    return detail.series.filter((obs) => {
      if (sourceFilter !== 'all' && obs.source_id !== sourceFilter) return false;
      if (!q) return true;
      return (
        obs.indicator_name.toLowerCase().includes(q) ||
        obs.indicator_id.toLowerCase().includes(q) ||
        obs.source_id.toLowerCase().includes(q)
      );
    });
  }, [detail, sourceFilter, indicatorQuery]);

  const detailIndicators = useMemo(() => {
    const map = new Map<
      string,
      {
        indicator_id: string;
        indicator_name: string;
        source_id: string;
        unit: string;
        count: number;
      }
    >();
    for (const obs of filteredDetailSeries) {
      const existing = map.get(obs.indicator_id);
      if (existing) {
        existing.count += 1;
      } else {
        map.set(obs.indicator_id, {
          indicator_id: obs.indicator_id,
          indicator_name: obs.indicator_name,
          source_id: obs.source_id,
          unit: obs.unit,
          count: 1,
        });
      }
    }
    return Array.from(map.values()).sort(
      (a, b) => b.count - a.count || a.indicator_name.localeCompare(b.indicator_name)
    );
  }, [filteredDetailSeries]);

  useEffect(() => {
    if (detailIndicators.length === 0) {
      setSelectedIndicatorId('');
      return;
    }
    if (!detailIndicators.some((ind) => ind.indicator_id === selectedIndicatorId)) {
      setSelectedIndicatorId(detailIndicators[0].indicator_id);
    }
    setHoveredPointIdx(null);
  }, [detailIndicators, selectedIndicatorId]);

  const activeTimeSeries = useMemo(() => {
    if (!selectedIndicatorId) return [];
    return filteredDetailSeries
      .filter((obs) => obs.indicator_id === selectedIndicatorId && hasNum(obs.value_numeric))
      .sort((a, b) => a.period_year - b.period_year);
  }, [filteredDetailSeries, selectedIndicatorId]);

  const displayedSeries = filteredDetailSeries.slice(0, 150);

  return (
    <div className="xl:col-span-4 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-4">
      <div className="flex items-start justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
        <div>
          <h2 className="text-base font-semibold text-slate-900 dark:text-slate-100">
            {detail?.territory.name_en ?? selectedIso3}
          </h2>
          {detail && (
            <div className="mt-1 space-y-0.5 text-xs font-mono text-slate-500 dark:text-slate-400">
              <p>
                {detail.territory.territory_id} · {detail.territory.currency_iso4217} ·{' '}
                {detail.territory.primary_language_iso639} · {detail.territory.timezone}
              </p>
              {(detail.territory.h3_res2 || detail.territory.h3_res4) && (
                <p>
                  H3 R2: {detail.territory.h3_res2 ?? '—'} · R4: {detail.territory.h3_res4 ?? '—'}
                </p>
              )}
            </div>
          )}
        </div>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close territory inspector"
          className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {detailLoading ? (
        <div className="space-y-2 py-4">
          <div className="h-28 w-full rounded bg-slate-100 dark:bg-slate-800" />
          <div className="h-4 w-3/4 rounded bg-slate-100 dark:bg-slate-800" />
          <div className="h-4 w-full rounded bg-slate-100 dark:bg-slate-800" />
        </div>
      ) : detailError ? (
        <div className="rounded-lg border border-rose-300 dark:border-rose-800 bg-rose-50 dark:bg-rose-950/40 p-3 text-xs font-mono text-rose-800 dark:text-rose-200">
          Failed to load observations for {selectedIso3}: {detailError}
        </div>
      ) : detail && detail.series.length > 0 ? (
        <div className="space-y-3">
          <div className="space-y-2">
            <div className="relative">
              <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={indicatorQuery}
                onChange={(e) => setIndicatorQuery(e.target.value)}
                placeholder="Filter indicators or sources..."
                className="w-full rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 py-1.5 pl-8 pr-7 text-xs text-slate-800 dark:text-slate-200 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-900 dark:focus:ring-slate-400"
              />
              {indicatorQuery && (
                <button
                  type="button"
                  aria-label="Clear indicator filter"
                  onClick={() => setIndicatorQuery('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </div>

            <select
              aria-label="Filter territory observations by source"
              value={sourceFilter}
              onChange={(e) => setSourceFilter(e.target.value)}
              className="w-full rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 px-2.5 py-1.5 text-xs font-mono text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-slate-900 dark:focus:ring-slate-400"
            >
              <option value="all">All Sources ({detail.series.length} obs)</option>
              {detailSources.map((src) => (
                <option key={src} value={src}>
                  {src}
                </option>
              ))}
            </select>

            {detailIndicators.length > 0 && (
              <select
                aria-label="Select indicator time series chart"
                value={selectedIndicatorId}
                onChange={(e) => {
                  setSelectedIndicatorId(e.target.value);
                  setHoveredPointIdx(null);
                }}
                className="w-full rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 px-2.5 py-1.5 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-slate-900 dark:focus:ring-slate-400"
              >
                {detailIndicators.map((ind) => (
                  <option key={ind.indicator_id} value={ind.indicator_id}>
                    {ind.indicator_name} ({ind.source_id} · {ind.count}y)
                  </option>
                ))}
              </select>
            )}
          </div>

          {/* Interactive SVG Time-Series Trend Chart */}
          {activeTimeSeries.length > 0 && (
            <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60 p-3 space-y-2">
              {(() => {
                const activePoint =
                  hoveredPointIdx !== null && activeTimeSeries[hoveredPointIdx]
                    ? activeTimeSeries[hoveredPointIdx]
                    : activeTimeSeries[activeTimeSeries.length - 1];
                const vals = activeTimeSeries.map((p) => p.value_numeric);
                const minV = Math.min(...vals);
                const maxV = Math.max(...vals);
                const isFlat = maxV === minV;
                const spanV = maxV - minV;
                const w = 320;
                const h = 92;
                const padX = 14;
                const padY = 12;

                const coords = activeTimeSeries.map((p, idx) => {
                  const x =
                    activeTimeSeries.length === 1
                      ? w / 2
                      : padX + (idx / (activeTimeSeries.length - 1)) * (w - padX * 2);
                  const y = isFlat
                    ? h / 2
                    : h - padY - ((p.value_numeric - minV) / spanV) * (h - padY * 2);
                  return { x, y, obs: p };
                });

                const polylinePoints = coords.map((c) => `${c.x},${c.y}`).join(' ');

                return (
                  <>
                    <div className="flex items-baseline justify-between gap-2 text-xs">
                      <span className="font-mono text-slate-500 dark:text-slate-400">
                        {activePoint.period_year} · {activePoint.source_id}
                      </span>
                      <span className="font-mono tabular-nums font-semibold text-slate-900 dark:text-slate-100">
                        {hasNum(activePoint.value_numeric)
                          ? activePoint.value_numeric.toLocaleString('en-US', {
                              maximumFractionDigits: 2,
                            })
                          : '—'}{' '}
                        <span className="font-normal text-slate-500 dark:text-slate-400">
                          {activePoint.unit}
                        </span>
                      </span>
                    </div>
                    <svg
                      viewBox={`0 0 ${w} ${h}`}
                      className="w-full h-24 overflow-visible"
                      role="img"
                      aria-label={`${activePoint.indicator_name} trend`}
                    >
                      <line
                        x1={padX}
                        y1={padY}
                        x2={w - padX}
                        y2={padY}
                        strokeWidth={1}
                        className="stroke-slate-200 dark:stroke-slate-800"
                      />
                      <line
                        x1={padX}
                        y1={h - padY}
                        x2={w - padX}
                        y2={h - padY}
                        strokeWidth={1}
                        className="stroke-slate-200 dark:stroke-slate-800"
                      />
                      {coords.length > 1 && (
                        <polyline
                          fill="none"
                          strokeWidth={2}
                          points={polylinePoints}
                          className="stroke-sky-600 dark:stroke-sky-400"
                        />
                      )}
                      {coords.map((c, idx) => (
                        <circle
                          key={`${c.obs.period_year}-${idx}`}
                          cx={c.x}
                          cy={c.y}
                          r={hoveredPointIdx === idx ? 4.5 : 3}
                          onMouseEnter={() => setHoveredPointIdx(idx)}
                          onClick={() => setHoveredPointIdx(idx)}
                          className={`cursor-pointer transition-all ${
                            hoveredPointIdx === idx ||
                            (hoveredPointIdx === null && idx === coords.length - 1)
                              ? 'fill-sky-600 dark:fill-sky-300'
                              : 'fill-slate-700 dark:fill-slate-400'
                          }`}
                        />
                      ))}
                    </svg>
                    <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 dark:text-slate-400 tabular-nums">
                      <span>{activeTimeSeries[0].period_year}</span>
                      <span>
                        range {minV.toLocaleString('en-US', { maximumFractionDigits: 2 })}–
                        {maxV.toLocaleString('en-US', { maximumFractionDigits: 2 })}
                      </span>
                      <span>{activeTimeSeries[activeTimeSeries.length - 1].period_year}</span>
                    </div>
                  </>
                );
              })()}
            </div>
          )}

          <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 dark:text-slate-400 tabular-nums">
            <span>
              Showing {displayedSeries.length} of {filteredDetailSeries.length} observations
            </span>
          </div>

          <div className="max-h-[380px] overflow-y-auto divide-y divide-slate-200 dark:divide-slate-800">
            {displayedSeries.map((obs, idx) => (
              <div key={`${obs.indicator_id}-${obs.period_year}-${idx}`} className="py-2.5 text-xs">
                <div className="flex items-baseline justify-between gap-2">
                  <span className="font-medium text-slate-800 dark:text-slate-200 truncate">
                    {obs.indicator_name}
                  </span>
                  <span className="font-mono tabular-nums font-semibold text-slate-900 dark:text-slate-100 shrink-0">
                    {hasNum(obs.value_numeric)
                      ? obs.value_numeric.toLocaleString('en-US', { maximumFractionDigits: 2 })
                      : '—'}
                  </span>
                </div>
                <div className="mt-0.5 flex items-center justify-between text-[11px] font-mono text-slate-500 dark:text-slate-400">
                  <span>
                    {obs.period_year} · {obs.valuation_basis} · {obs.source_id}
                  </span>
                  <span>{obs.unit}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <p className="text-xs text-slate-500 dark:text-slate-400 py-4">
          No Silver Parquet series synced for {selectedIso3} yet. Run Tier-0 ingestion to populate historical observations.
        </p>
      )}
    </div>
  );
}
