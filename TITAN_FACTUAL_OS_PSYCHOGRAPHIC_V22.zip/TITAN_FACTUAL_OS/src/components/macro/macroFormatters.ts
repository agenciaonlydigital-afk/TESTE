export function hasNum(val: number | null | undefined): val is number {
  return typeof val === 'number' && Number.isFinite(val);
}

export function fmtCompactUsd(val: number | null | undefined): string {
  if (!hasNum(val)) return '—';
  if (val >= 1e12) return `$${(val / 1e12).toFixed(2)}T`;
  if (val >= 1e9) return `$${(val / 1e9).toFixed(1)}B`;
  if (val >= 1e6) return `$${(val / 1e6).toFixed(1)}M`;
  return `$${val.toLocaleString('en-US', { maximumFractionDigits: 0 })}`;
}

export function fmtPop(val: number | null | undefined): string {
  if (!hasNum(val)) return '—';
  if (val >= 1e9) return `${(val / 1e9).toFixed(2)}B`;
  if (val >= 1e6) return `${(val / 1e6).toFixed(1)}M`;
  if (val >= 1e3) return `${(val / 1e3).toFixed(1)}K`;
  return val.toLocaleString('en-US', { maximumFractionDigits: 0 });
}

export function fmtPct(val: number | null | undefined): string {
  if (!hasNum(val)) return '—';
  return `${val.toFixed(1)}%`;
}

export function fmtNum(val: number | null | undefined, digits = 1, suffix = ''): string {
  if (!hasNum(val)) return '—';
  return `${val.toFixed(digits)}${suffix}`;
}

export function median(values: number[]): number | null {
  if (values.length === 0) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}
