import type { MacroEconomicRow } from '../../types/lakehouse.ts';
import { fmtCompactUsd, fmtNum, fmtPct, fmtPop, hasNum } from './macroFormatters.ts';

export interface TerritoryDetailPayload {
  territory: {
    territory_id: string;
    iso3: string;
    name_en: string;
    name_pt: string;
    continent: string;
    region: string;
    currency_iso4217: string;
    primary_language_iso639: string;
    timezone: string;
    centroid_lat: number;
    centroid_lon: number;
    h3_res2?: string | null;
    h3_res4?: string | null;
  };
  series: Array<{
    indicator_id: string;
    indicator_name: string;
    source_id: string;
    period_year: number;
    value_numeric: number;
    unit: string;
    valuation_basis: string;
    methodology_id: string;
    asserted_at: string;
  }>;
  cacheStatus: string;
}

export type ColumnLens = 'sdmx_macro' | 'energy_rnd' | 'structural' | 'all';

export type ChartMetricKey =
  | 'gdp_per_capita_ppp_2021'
  | 'imf_policy_rate_pct'
  | 'ilostat_lfpr_pct'
  | 'unemployment_pct'
  | 'imf_reer_index'
  | 'oecd_cli_index'
  | 'ember_clean_share_pct'
  | 'uis_gerd_pct_gdp'
  | 'unsdg_forest_pct'
  | 'gbif_occurrences'
  | 'wits_exports_usd'
  | 'unicef_u5_mortality'
  | 'nasa_solar_kwh'
  | 'obis_marine_species'
  | 'unsd_elec_prod_gwh'
  | 'datacite_dataset_dois'
  | 'unwpp_tfr'
  | 'openalex_works_2024'
  | 'nasa_cmr_collections'
  | 'ne_adm1_divisions'
  | 'faostat_kcal_day'
  | 'uis_edu_exp_pct_gdp'
  | 'worldpop_density_datasets'
  | 'worldpop_age_datasets'
  | 'vdem_democracy_ix'
  | 'ecb_fx_per_eur'
  | 'unlocode_nodes'
  | 'ckan_portal_datasets'
  | 'musicbrainz_artists'
  | 'osm_importance_score'
  | 'uncomtrade_exports_usd'
  | 'itu_mobile_per_100'
  | 'gadm_adm1_features'
  | 'wipo_patents_per_million'
  | 'unodc_homicide_rate'
  | 'wid_top10_share_pct'
  | 'ghsl_pop_density_km2'
  | 'pwt_real_gdp_cap'
  | 'bis_total_credit_pct_gdp'
  | 'unhcr_refugees'
  | 'usgs_seismic_events'
  | 'unctad_lsci'
  | 'undata_elec_access_pct'
  | 'undrr_mortality_per_100k'
  | 'pip_mean_daily_ppp'
  | 'ct_ghg_co2e'
  | 'wikimedia_enwiki_views'
  | 'undp_hdi'
  | 'noaa_tavg_c'
  | 'gfw_tree_loss_ha'
  | 'icao_scheduled_airports'
  | 'wdpa_protected_pct';

export type SortKey =
  | 'name_en'
  | 'gdp_nominal_usd'
  | 'gdp_per_capita_ppp_2021'
  | 'imf_real_gdp_growth_pct'
  | 'inflation_cpi_pct'
  | 'gov_debt_pct_gdp'
  | 'unemployment_pct'
  | 'ilostat_lfpr_pct'
  | 'imf_policy_rate_pct'
  | 'imf_reer_index'
  | 'oecd_cli_index'
  | 'household_consumption_pct_gdp'
  | 'gni_per_capita_usd'
  | 'fdi_net_inflows_pct_gdp'
  | 'trade_openness_pct_gdp'
  | 'wits_exports_usd'
  | 'wits_imports_usd'
  | 'ember_clean_share_pct'
  | 'ember_carbon_intensity'
  | 'unsdg_renewable_pct'
  | 'unsdg_forest_pct'
  | 'uis_gerd_pct_gdp'
  | 'unicef_u5_mortality'
  | 'gbif_occurrences'
  | 'wikidata_area_km2'
  | 'abs_cpi_pct_yoy'
  | 'eurostat3_hicp_pct'
  | 'eurostat_gov_debt_pct'
  | 'statcan_unemp_pct'
  | 'ukons_cpih_yoy_pct'
  | 'ukgov_open_datasets'
  | 'unsd_elec_prod_gwh'
  | 'nasa_solar_kwh'
  | 'nasa_cmr_collections'
  | 'obis_marine_species'
  | 'geonames_pop'
  | 'ne_adm1_divisions'
  | 'overture_themes'
  | 'datacite_dataset_dois'
  | 'openalex_works_2024'
  | 'unwpp_tfr'
  | 'worldpop_datasets'
  | 'worldpop_age_datasets'
  | 'worldpop_density_datasets'
  | 'faostat_kcal_day'
  | 'uis_edu_exp_pct_gdp'
  | 'eurostat_catalog_datasets'
  | 'arcgis_open_datasets'
  | 'stac_public_catalogs'
  | 'listenbrainz_top100_listens'
  | 'ecb_fx_per_eur'
  | 'vdem_democracy_ix'
  | 'unlocode_nodes'
  | 'unhabitat_urban_datasets'
  | 'ckan_portal_datasets'
  | 'socrata_civic_datasets'
  | 'osm_importance_score'
  | 'musicbrainz_artists'
  | 'uncomtrade_exports_usd'
  | 'itu_mobile_per_100'
  | 'gadm_adm1_features'
  | 'wipo_patents_per_million'
  | 'unodc_homicide_rate'
  | 'wid_top10_share_pct'
  | 'ghsl_pop_density_km2'
  | 'pwt_real_gdp_cap'
  | 'eurostat_gdp_meur'
  | 'bis_total_credit_pct_gdp'
  | 'ibge_ipca_pct'
  | 'unhcr_refugees'
  | 'usgs_seismic_events'
  | 'gb_adm0_coverage'
  | 'crossref_works_count'
  | 'unctad_lsci'
  | 'statfin_cpi_pct'
  | 'undata_elec_access_pct'
  | 'undrr_mortality_per_100k'
  | 'usgov_datasets_total'
  | 'pip_mean_daily_ppp'
  | 'ct_ghg_co2e'
  | 'wikimedia_enwiki_views'
  | 'us_census_pop'
  | 'undp_hdi'
  | 'noaa_tavg_c'
  | 'gfw_tree_loss_ha'
  | 'eia_energy_prod_qbtu'
  | 'india_iip_index'
  | 'icao_scheduled_airports'
  | 'wdpa_protected_pct'
  | 'gini_index'
  | 'life_expectancy_years'
  | 'population_total'
  | 'urbanization_pct'
  | 'internet_users_pct';

export interface ColumnDef {
  key: SortKey;
  label: string;
  title?: string;
  align: 'left' | 'right';
  lenses: ColumnLens[];
  format: (r: MacroEconomicRow) => string;
  tone?: (r: MacroEconomicRow) => string;
}

export const CHART_METRICS: Array<{
  key: ChartMetricKey;
  label: string;
  subtitle: string;
  format: (v: number) => string;
}> = [
  {
    key: 'gdp_per_capita_ppp_2021',
    label: 'GDP/Cap PPP',
    subtitle: 'Constant 2021 Int$ (World Bank WDI)',
    format: (v) => fmtCompactUsd(v),
  },
  {
    key: 'imf_policy_rate_pct',
    label: 'IMF Rate %',
    subtitle: 'Central Bank Policy / T-Bill Rate % p.a. (IMF MFS_IR SDMX)',
    format: (v) => `${v.toFixed(2)}%`,
  },
  {
    key: 'ilostat_lfpr_pct',
    label: 'LFPR %',
    subtitle: 'Labor Force Participation Rate 15+ (ILOSTAT SDMX)',
    format: (v) => `${v.toFixed(1)}%`,
  },
  {
    key: 'unemployment_pct',
    label: 'Unemp %',
    subtitle: 'Unemployment Rate % (ILOSTAT / WB / OECD)',
    format: (v) => `${v.toFixed(1)}%`,
  },
  {
    key: 'imf_reer_index',
    label: 'IMF REER',
    subtitle: 'Real Effective Exchange Rate Index 2010=100 (IMF EER SDMX)',
    format: (v) => v.toFixed(1),
  },
  {
    key: 'oecd_cli_index',
    label: 'OECD CLI',
    subtitle: 'Composite Leading Indicator 100=Trend (OECD SDMX)',
    format: (v) => v.toFixed(2),
  },
  {
    key: 'ember_clean_share_pct',
    label: 'Ember Clean %',
    subtitle: 'Clean Electricity Share of Generation % (Ember CC-BY-4.0)',
    format: (v) => `${v.toFixed(1)}%`,
  },
  {
    key: 'uis_gerd_pct_gdp',
    label: 'R&D % GDP',
    subtitle: 'Gross Domestic Expenditure on R&D % GDP (UNESCO UIS)',
    format: (v) => `${v.toFixed(2)}%`,
  },
  {
    key: 'unsdg_forest_pct',
    label: 'UN Forest %',
    subtitle: 'Forest Area as Proportion of Land Area % (UN SDG 15.1.1)',
    format: (v) => `${v.toFixed(1)}%`,
  },
  {
    key: 'gbif_occurrences',
    label: 'GBIF Bio',
    subtitle: 'Georeferenced Species Occurrence Records (GBIF Facets)',
    format: (v) => fmtPop(v),
  },
  {
    key: 'wits_exports_usd',
    label: 'WITS Exports',
    subtitle: 'Merchandise Exports to World Current US$ (WB WITS REST)',
    format: (v) => fmtCompactUsd(v),
  },
  {
    key: 'unicef_u5_mortality',
    label: 'U5 Mort.',
    subtitle: 'Under-5 Mortality Rate per 1,000 Live Births (UNICEF SDMX)',
    format: (v) => v.toFixed(1),
  },
  {
    key: 'nasa_solar_kwh',
    label: 'NASA Solar',
    subtitle: 'Annual Mean All-Sky Solar Irradiance kWh/m²/day (NASA POWER)',
    format: (v) => `${v.toFixed(2)} kWh`,
  },
  {
    key: 'obis_marine_species',
    label: 'OBIS Marine',
    subtitle: 'Distinct Marine Species Recorded in EEZ (OBIS API v3)',
    format: (v) => fmtPop(v),
  },
  {
    key: 'unsd_elec_prod_gwh',
    label: 'UNSD Elec',
    subtitle: 'Electricity Gross Production GWh (UNSD Energy SDMX)',
    format: (v) => fmtPop(v),
  },
  {
    key: 'datacite_dataset_dois',
    label: 'DataCite DOI',
    subtitle: 'Registered Research Dataset DOIs by Provider Country (DataCite v2)',
    format: (v) => fmtPop(v),
  },
  {
    key: 'unwpp_tfr',
    label: 'UN WPP TFR',
    subtitle: 'Total Fertility Rate, Births per Woman (UN WPP 2024 Medium)',
    format: (v) => v.toFixed(2),
  },
  {
    key: 'openalex_works_2024',
    label: 'OpenAlex 24',
    subtitle: '2024 Scholarly Research Works Count by Country (OpenAlex REST)',
    format: (v) => fmtPop(v),
  },
  {
    key: 'nasa_cmr_collections',
    label: 'NASA EO',
    subtitle: 'Earth Observation Collections Overlapping Territory Centroid (NASA CMR)',
    format: (v) => fmtPop(v),
  },
  {
    key: 'ne_adm1_divisions',
    label: 'ADM1 States',
    subtitle: 'First-Level Subnational Administrative Divisions Indexed (Natural Earth 10m)',
    format: (v) => v.toFixed(0),
  },
  {
    key: 'faostat_kcal_day',
    label: 'FAO kcal',
    subtitle: 'Dietary Energy Supply kcal/capita/day (FAOSTAT Food Security Bulk)',
    format: (v) => v.toFixed(0),
  },
  {
    key: 'uis_edu_exp_pct_gdp',
    label: 'Edu % GDP',
    subtitle: 'Government Expenditure on Education % GDP (UNESCO UIS)',
    format: (v) => `${v.toFixed(1)}%`,
  },
  {
    key: 'worldpop_density_datasets',
    label: 'WP Dens 1km',
    subtitle: '1km Gridded Population Density Raster Series Count (WorldPop)',
    format: (v) => fmtPop(v),
  },
  {
    key: 'worldpop_age_datasets',
    label: 'WP Age/Sex',
    subtitle: '100m Age/Sex Cohort Raster Datasets (WorldPop 2020)',
    format: (v) => fmtPop(v),
  },
  {
    key: 'vdem_democracy_ix',
    label: 'V-Dem Polyarchy',
    subtitle: 'Electoral Democracy Polyarchy Index 0-1 (V-Dem v15/v16)',
    format: (v) => v.toFixed(3),
  },
  {
    key: 'ecb_fx_per_eur',
    label: 'ECB FX/EUR',
    subtitle: 'ECB Annual Reference Exchange Rate Local Currency per EUR',
    format: (v) => v.toFixed(3),
  },
  {
    key: 'unlocode_nodes',
    label: 'UN/LOCODE',
    subtitle: 'Registered Trade & Logistics Nodes: Ports, Airports, Rail (UN/LOCODE)',
    format: (v) => fmtPop(v),
  },
  {
    key: 'ckan_portal_datasets',
    label: 'CKAN Open',
    subtitle: 'Federated National Open-Data Portal Catalogs (CKAN Action v3)',
    format: (v) => fmtPop(v),
  },
  {
    key: 'musicbrainz_artists',
    label: 'MusicBrainz',
    subtitle: 'Registered Cultural Creators & Music Artists by Country (MusicBrainz)',
    format: (v) => fmtPop(v),
  },
  {
    key: 'osm_importance_score',
    label: 'OSM Rank',
    subtitle: 'OpenStreetMap Geospatial Boundary Importance Score (Nominatim)',
    format: (v) => v.toFixed(3),
  },
  {
    key: 'uncomtrade_exports_usd',
    label: 'Comtrade Exp',
    subtitle: 'Merchandise Exports to World HS TOTAL Current US$ (UN Comtrade Public v1)',
    format: (v) => fmtCompactUsd(v),
  },
  {
    key: 'pwt_real_gdp_cap',
    label: 'PWT GDP/Cap',
    subtitle: 'Real Expenditure-Side GDP per Capita Chained PPP (Penn World Table 10.01)',
    format: (v) => fmtCompactUsd(v),
  },
  {
    key: 'wid_top10_share_pct',
    label: 'WID Top10%',
    subtitle: 'Pre-Tax National Income Share Held by Richest 10% (WID.world)',
    format: (v) => `${v.toFixed(1)}%`,
  },
  {
    key: 'itu_mobile_per_100',
    label: 'ITU Mobile',
    subtitle: 'Mobile Cellular Subscriptions per 100 People (ITU DataHub)',
    format: (v) => v.toFixed(1),
  },
  {
    key: 'wipo_patents_per_million',
    label: 'WIPO Patents',
    subtitle: 'Patent Applications per Million Inhabitants (WIPO IP Statistics)',
    format: (v) => fmtPop(v),
  },
  {
    key: 'unodc_homicide_rate',
    label: 'UNODC Hom.',
    subtitle: 'Intentional Homicide Rate per 100,000 Population (UNODC / SDG 16.1.1)',
    format: (v) => v.toFixed(2),
  },
  {
    key: 'ghsl_pop_density_km2',
    label: 'Density/km²',
    subtitle: 'Population Density per km² of Land Area (GHSL / UN WPP)',
    format: (v) => v.toFixed(1),
  },
  {
    key: 'gadm_adm1_features',
    label: 'GADM ADM1',
    subtitle: 'GADM 4.1 First-Level Administrative Polygon Divisions (Reference)',
    format: (v) => v.toFixed(0),
  },
  {
    key: 'bis_total_credit_pct_gdp',
    label: 'BIS Credit',
    subtitle: 'Total Credit to Private Non-Financial Sector % GDP (BIS SDMX v2)',
    format: (v) => `${v.toFixed(1)}%`,
  },
  {
    key: 'unctad_lsci',
    label: 'UNCTAD LSCI',
    subtitle: 'Maritime Liner Shipping Connectivity Index 2004=100 (UNCTAD)',
    format: (v) => v.toFixed(1),
  },
  {
    key: 'unhcr_refugees',
    label: 'UNHCR Refug.',
    subtitle: 'Refugees Under UNHCR Mandate by Country of Asylum (UNHCR API v1)',
    format: (v) => fmtPop(v),
  },
  {
    key: 'usgs_seismic_events',
    label: 'USGS M5.5+',
    subtitle: 'Recent Significant Seismic Events M>=5.5 Matched to Territory (USGS FDSN)',
    format: (v) => v.toFixed(0),
  },
  {
    key: 'undata_elec_access_pct',
    label: 'UN Elec %',
    subtitle: 'Proportion of Population with Access to Electricity % (UNdata SDMX-RI SDG 7.1.1)',
    format: (v) => `${v.toFixed(1)}%`,
  },
  {
    key: 'undrr_mortality_per_100k',
    label: 'UNDRR Mort.',
    subtitle: 'Disaster Mortality & Missing Persons per 100k Pop (UNDRR Sendai)',
    format: (v) => v.toFixed(2),
  },
  {
    key: 'pip_mean_daily_ppp',
    label: 'PIP $/Day',
    subtitle: 'Mean Daily Per-Capita Income/Consumption 2017 PPP $ (World Bank PIP)',
    format: (v) => `$${v.toFixed(2)}`,
  },
  {
    key: 'ct_ghg_co2e',
    label: 'CT GHG CO2e',
    subtitle: 'Annual Total Greenhouse Gas Emissions Tonnes CO2e 100yr (Climate TRACE v7)',
    format: (v) => fmtPop(v),
  },
  {
    key: 'wikimedia_enwiki_views',
    label: 'Wiki Views',
    subtitle: 'Monthly English Wikipedia Country Article Pageviews (Wikimedia REST)',
    format: (v) => fmtPop(v),
  },
  {
    key: 'undp_hdi',
    label: 'UNDP HDI',
    subtitle: 'Human Development Index 0-1 (UNDP HDR Composite Time Series)',
    format: (v) => v.toFixed(3),
  },
  {
    key: 'noaa_tavg_c',
    label: 'NOAA Temp',
    subtitle: 'GHCN Weather Station Mean Annual Temperature °C (NOAA NCEI)',
    format: (v) => `${v.toFixed(1)}°C`,
  },
  {
    key: 'gfw_tree_loss_ha',
    label: 'GFW Loss ha',
    subtitle: 'Annual Tree Cover Loss Area in Hectares (Hansen/UMD/GFW)',
    format: (v) => fmtPop(v),
  },
  {
    key: 'icao_scheduled_airports',
    label: 'ICAO Airports',
    subtitle: 'Scheduled Commercial Service Airports (ICAO / OurAirports)',
    format: (v) => fmtPop(v),
  },
  {
    key: 'wdpa_protected_pct',
    label: 'WDPA Prot %',
    subtitle: 'Terrestrial Protected Areas % of Land Area (UNEP-WCMC WDPA)',
    format: (v) => `${v.toFixed(1)}%`,
  },
];

export const COLUMNS: ColumnDef[] = [
  {
    key: 'gdp_per_capita_ppp_2021',
    label: 'GDP/Cap PPP',
    title: 'GDP per capita, PPP (constant 2021 international $)',
    align: 'right',
    lenses: ['sdmx_macro', 'all'],
    format: (r) => fmtCompactUsd(r.gdp_per_capita_ppp_2021),
  },
  {
    key: 'gdp_nominal_usd',
    label: 'GDP Nominal',
    title: 'GDP (current US$)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtCompactUsd(r.gdp_nominal_usd),
  },
  {
    key: 'gni_per_capita_usd',
    label: 'GNI/Cap',
    title: 'GNI per capita, Atlas method (current US$)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtCompactUsd(r.gni_per_capita_usd),
  },
  {
    key: 'imf_real_gdp_growth_pct',
    label: 'IMF Growth',
    title: 'IMF WEO Real GDP Growth %',
    align: 'right',
    lenses: ['sdmx_macro', 'all'],
    format: (r) => fmtPct(r.imf_real_gdp_growth_pct),
    tone: (r) =>
      !hasNum(r.imf_real_gdp_growth_pct)
        ? 'text-slate-400'
        : r.imf_real_gdp_growth_pct >= 0
          ? 'text-emerald-700 dark:text-emerald-400'
          : 'text-rose-700 dark:text-rose-400',
  },
  {
    key: 'inflation_cpi_pct',
    label: 'CPI %',
    title: 'Consumer Price Index Inflation %',
    align: 'right',
    lenses: ['sdmx_macro', 'all'],
    format: (r) => fmtPct(r.inflation_cpi_pct),
  },
  {
    key: 'unemployment_pct',
    label: 'Unemp %',
    title: 'Unemployment Rate 15+ (ILOSTAT / WB / OECD)',
    align: 'right',
    lenses: ['sdmx_macro', 'all'],
    format: (r) => fmtPct(r.unemployment_pct),
  },
  {
    key: 'ilostat_lfpr_pct',
    label: 'LFPR %',
    title: 'Labor Force Participation Rate 15+ (ILOSTAT SDMX)',
    align: 'right',
    lenses: ['sdmx_macro', 'all'],
    format: (r) => fmtPct(r.ilostat_lfpr_pct),
  },
  {
    key: 'imf_policy_rate_pct',
    label: 'Rate %',
    title: 'Policy / Money Market / T-Bill Rate % p.a. (IMF MFS_IR SDMX 3.0)',
    align: 'right',
    lenses: ['sdmx_macro', 'all'],
    format: (r) => fmtNum(r.imf_policy_rate_pct, 2, '%'),
  },
  {
    key: 'imf_reer_index',
    label: 'REER',
    title: 'Real Effective Exchange Rate Index 2010=100 (IMF EER SDMX 3.0)',
    align: 'right',
    lenses: ['sdmx_macro', 'all'],
    format: (r) => fmtNum(r.imf_reer_index, 1),
  },
  {
    key: 'oecd_cli_index',
    label: 'CLI',
    title: 'Composite Leading Indicator 100=Trend (OECD SDMX CLI)',
    align: 'right',
    lenses: ['sdmx_macro', 'all'],
    format: (r) => fmtNum(r.oecd_cli_index, 2),
    tone: (r) =>
      !hasNum(r.oecd_cli_index)
        ? 'text-slate-400'
        : r.oecd_cli_index >= 100
          ? 'text-emerald-700 dark:text-emerald-400'
          : 'text-amber-700 dark:text-amber-400',
  },
  {
    key: 'household_consumption_pct_gdp',
    label: 'HH Cons %',
    title: 'Household Final Consumption % GDP (World Bank SDMX)',
    align: 'right',
    lenses: ['sdmx_macro', 'all'],
    format: (r) => fmtPct(r.household_consumption_pct_gdp),
  },
  {
    key: 'gov_debt_pct_gdp',
    label: 'Debt % GDP',
    title: 'General Government Gross Debt % GDP (IMF WEO)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtPct(r.gov_debt_pct_gdp),
  },
  {
    key: 'fdi_net_inflows_pct_gdp',
    label: 'FDI % GDP',
    title: 'Foreign Direct Investment Net Inflows % GDP (World Bank SDMX)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtPct(r.fdi_net_inflows_pct_gdp),
  },
  {
    key: 'trade_openness_pct_gdp',
    label: 'Trade %',
    title: 'Trade Openness % GDP (World Bank SDMX)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtPct(r.trade_openness_pct_gdp),
  },
  {
    key: 'wits_exports_usd',
    label: 'WITS Exp.',
    title: 'Merchandise Exports to World Current US$ (WB WITS REST)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtCompactUsd(r.wits_exports_usd),
  },
  {
    key: 'wits_imports_usd',
    label: 'WITS Imp.',
    title: 'Merchandise Imports from World Current US$ (WB WITS REST)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtCompactUsd(r.wits_imports_usd),
  },
  {
    key: 'ember_clean_share_pct',
    label: 'Clean Elec %',
    title: 'Clean Electricity Share of Generation % (Ember CC-BY-4.0)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtPct(r.ember_clean_share_pct),
    tone: (r) =>
      !hasNum(r.ember_clean_share_pct)
        ? 'text-slate-400'
        : r.ember_clean_share_pct >= 50
          ? 'text-emerald-700 dark:text-emerald-400'
          : 'text-slate-700 dark:text-slate-300',
  },
  {
    key: 'ember_carbon_intensity',
    label: 'Grid gCO2',
    title: 'Electricity Grid Carbon Intensity gCO2e/kWh (Ember CC-BY-4.0)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtNum(r.ember_carbon_intensity, 0),
  },
  {
    key: 'unsdg_renewable_pct',
    label: 'SDG Renew %',
    title: 'Renewable Energy Share in Total Final Energy Consumption % (UN SDG 7.2.1)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtPct(r.unsdg_renewable_pct),
  },
  {
    key: 'unsdg_forest_pct',
    label: 'Forest %',
    title: 'Forest Area as Proportion of Land Area % (UN SDG 15.1.1)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtPct(r.unsdg_forest_pct),
  },
  {
    key: 'uis_gerd_pct_gdp',
    label: 'R&D % GDP',
    title: 'Gross Domestic Expenditure on R&D % GDP (UNESCO UIS)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtNum(r.uis_gerd_pct_gdp, 2, '%'),
  },
  {
    key: 'unicef_u5_mortality',
    label: 'U5 Mort.',
    title: 'Under-5 Mortality Rate per 1,000 Live Births (UNICEF CME SDMX)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtNum(r.unicef_u5_mortality, 1),
  },
  {
    key: 'gbif_occurrences',
    label: 'GBIF Bio',
    title: 'Georeferenced Species Occurrence Records (GBIF Facet API)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtPop(r.gbif_occurrences),
  },
  {
    key: 'wikidata_area_km2',
    label: 'Area km²',
    title: 'Official Territory Area km² (Wikidata SPARQL P2046)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtPop(r.wikidata_area_km2),
  },
  {
    key: 'abs_cpi_pct_yoy',
    label: 'ABS CPI %',
    title: 'Australia CPI Annual Percentage Change YoY (ABS SDMX)',
    align: 'right',
    lenses: ['sdmx_macro', 'all'],
    format: (r) => fmtPct(r.abs_cpi_pct_yoy),
  },
  {
    key: 'eurostat3_hicp_pct',
    label: 'EU HICP %',
    title: 'Eurostat SDMX 3.0 All-Items HICP Inflation Annual Average %',
    align: 'right',
    lenses: ['sdmx_macro', 'all'],
    format: (r) => fmtPct(r.eurostat3_hicp_pct),
  },
  {
    key: 'statcan_unemp_pct',
    label: 'CA Unemp %',
    title: 'Canada Monthly SA Unemployment Rate % (StatCan WDS)',
    align: 'right',
    lenses: ['sdmx_macro', 'all'],
    format: (r) => fmtPct(r.statcan_unemp_pct),
  },
  {
    key: 'ukons_cpih_yoy_pct',
    label: 'UK CPIH %',
    title: 'UK CPIH Overall Index YoY % (UK ONS API v1)',
    align: 'right',
    lenses: ['sdmx_macro', 'all'],
    format: (r) => fmtPct(r.ukons_cpih_yoy_pct),
  },
  {
    key: 'eurostat_gov_debt_pct',
    label: 'EU Debt %',
    title: 'Eurostat General Government Gross Debt % GDP (Stats 1.0)',
    align: 'right',
    lenses: ['sdmx_macro', 'all'],
    format: (r) => fmtPct(r.eurostat_gov_debt_pct),
  },
  {
    key: 'unsd_elec_prod_gwh',
    label: 'UNSD GWh',
    title: 'Electricity Gross Production GWh (UNSD Energy SDMX)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtPop(r.unsd_elec_prod_gwh),
  },
  {
    key: 'nasa_solar_kwh',
    label: 'Solar kWh',
    title: 'Annual Mean Surface Solar Irradiance kWh/m2/day (NASA POWER Climatology)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtNum(r.nasa_solar_kwh, 2),
  },
  {
    key: 'nasa_cmr_collections',
    label: 'NASA EO Cols',
    title: 'Earth Observation Collections Covering Centroid (NASA CMR)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtPop(r.nasa_cmr_collections),
  },
  {
    key: 'obis_marine_species',
    label: 'OBIS Spp.',
    title: 'Distinct Marine Species Recorded (OBIS v3 EEZ)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtPop(r.obis_marine_species),
  },
  {
    key: 'datacite_dataset_dois',
    label: 'DataCite DOIs',
    title: 'Registered Research Dataset DOIs by Provider Country (DataCite REST v2)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtPop(r.datacite_dataset_dois),
  },
  {
    key: 'openalex_works_2024',
    label: 'OpenAlex 24',
    title: 'Scholarly Research Works Published in 2024 (OpenAlex REST)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtPop(r.openalex_works_2024),
  },
  {
    key: 'unwpp_tfr',
    label: 'UN WPP TFR',
    title: 'Total Fertility Rate, Births/Woman (UN WPP 2024)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtNum(r.unwpp_tfr, 2),
  },
  {
    key: 'worldpop_datasets',
    label: 'WorldPop Grids',
    title: '100m/1km Gridded Population Datasets Cataloged (WorldPop WPGP)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtPop(r.worldpop_datasets),
  },
  {
    key: 'ne_adm1_divisions',
    label: 'ADM1 States',
    title: 'Subnational ADM1 Divisions Indexed (Natural Earth 10m)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtNum(r.ne_adm1_divisions, 0),
  },
  {
    key: 'ukgov_open_datasets',
    label: 'UK OpenData',
    title: 'Public Open Datasets Cataloged (UK data.gov.uk CKAN v3)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtPop(r.ukgov_open_datasets),
  },
  {
    key: 'overture_themes',
    label: 'Overture Themes',
    title: 'Overture Maps GeoParquet Theme Collections (STAC Catalog)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtNum(r.overture_themes, 0),
  },
  {
    key: 'geonames_pop',
    label: 'GeoNames Pop',
    title: 'GeoNames Official Gazetteer Country Population',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtPop(r.geonames_pop),
  },
  {
    key: 'faostat_kcal_day',
    label: 'FAO kcal',
    title: 'Dietary Energy Supply kcal/cap/day (FAOSTAT Food Security Bulk)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtNum(r.faostat_kcal_day, 0),
  },
  {
    key: 'uis_edu_exp_pct_gdp',
    label: 'Edu % GDP',
    title: 'Government Expenditure on Education % of GDP (UNESCO UIS)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtPct(r.uis_edu_exp_pct_gdp),
  },
  {
    key: 'worldpop_age_datasets',
    label: 'WP Age',
    title: 'WorldPop 100m Age/Sex Cohort Datasets (2020)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtPop(r.worldpop_age_datasets),
  },
  {
    key: 'worldpop_density_datasets',
    label: 'WP 1km Dens',
    title: 'WorldPop 1km Gridded Population Density Datasets',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtPop(r.worldpop_density_datasets),
  },
  {
    key: 'eurostat_catalog_datasets',
    label: 'EU TOC Sets',
    title: 'Eurostat Full Statistical Catalogue Datasets & Tables (TOC)',
    align: 'right',
    lenses: ['sdmx_macro', 'all'],
    format: (r) => fmtPop(r.eurostat_catalog_datasets),
  },
  {
    key: 'arcgis_open_datasets',
    label: 'ArcGIS Open',
    title: 'Public Open Geospatial Datasets Indexed (ArcGIS Hub v3)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtPop(r.arcgis_open_datasets),
  },
  {
    key: 'stac_public_catalogs',
    label: 'STAC Cats',
    title: 'Public OGC STAC Spatio-Temporal Catalogs (stacindex.org)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtNum(r.stac_public_catalogs, 0),
  },
  {
    key: 'listenbrainz_top100_listens',
    label: 'LB Top100',
    title: 'ListenBrainz Monthly Sitewide Plays Across Top-100 Artists',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtPop(r.listenbrainz_top100_listens),
  },
  {
    key: 'ecb_fx_per_eur',
    label: 'ECB FX/EUR',
    title: 'ECB Official Annual Reference FX Rate (Local Currency per EUR)',
    align: 'right',
    lenses: ['sdmx_macro', 'all'],
    format: (r) => fmtNum(r.ecb_fx_per_eur, 3),
  },
  {
    key: 'vdem_democracy_ix',
    label: 'V-Dem Poly',
    title: 'V-Dem Electoral Democracy Polyarchy Index (0-1)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtNum(r.vdem_democracy_ix, 3),
  },
  {
    key: 'unlocode_nodes',
    label: 'UN/LOCODE',
    title: 'Registered UN/LOCODE Ports, Airports & Logistics Nodes',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtPop(r.unlocode_nodes),
  },
  {
    key: 'unhabitat_urban_datasets',
    label: 'UN-Habitat',
    title: 'UN-Habitat Urban & SDG 11 Public Datasets',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtPop(r.unhabitat_urban_datasets),
  },
  {
    key: 'ckan_portal_datasets',
    label: 'CKAN Fed',
    title: 'Federated National Open-Data Catalog Datasets (CKAN v3)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtPop(r.ckan_portal_datasets),
  },
  {
    key: 'socrata_civic_datasets',
    label: 'Socrata US',
    title: 'US Municipal & Civic Datasets Indexed (Socrata SODA)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtPop(r.socrata_civic_datasets),
  },
  {
    key: 'osm_importance_score',
    label: 'OSM Rank',
    title: 'OpenStreetMap Geospatial Boundary Importance Score',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtNum(r.osm_importance_score, 3),
  },
  {
    key: 'musicbrainz_artists',
    label: 'MB Artists',
    title: 'Registered Music Artists by Country (MusicBrainz ws/2)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtPop(r.musicbrainz_artists),
  },
  {
    key: 'uncomtrade_exports_usd',
    label: 'Comtrade Exp',
    title: 'UN Comtrade HS TOTAL Merchandise Exports US$ (Public Preview v1)',
    align: 'right',
    lenses: ['sdmx_macro', 'all'],
    format: (r) => fmtCompactUsd(r.uncomtrade_exports_usd),
  },
  {
    key: 'pwt_real_gdp_cap',
    label: 'PWT GDP/Cap',
    title: 'Penn World Table 10.01 Chained PPP Real GDP per Capita',
    align: 'right',
    lenses: ['sdmx_macro', 'all'],
    format: (r) => fmtCompactUsd(r.pwt_real_gdp_cap),
  },
  {
    key: 'wid_top10_share_pct',
    label: 'WID Top10%',
    title: 'Income Share Held by Richest 10% (WID.world)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtPct(r.wid_top10_share_pct),
  },
  {
    key: 'itu_mobile_per_100',
    label: 'ITU Mobile',
    title: 'Mobile Cellular Subscriptions per 100 People (ITU DataHub)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtNum(r.itu_mobile_per_100, 1),
  },
  {
    key: 'wipo_patents_per_million',
    label: 'WIPO Pat/M',
    title: 'Patent Applications per Million Inhabitants (WIPO IP Stats)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtNum(r.wipo_patents_per_million, 1),
  },
  {
    key: 'unodc_homicide_rate',
    label: 'UNODC Hom',
    title: 'Intentional Homicide Rate per 100k Population (UNODC)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtNum(r.unodc_homicide_rate, 2),
  },
  {
    key: 'ghsl_pop_density_km2',
    label: 'Pop/km²',
    title: 'Population Density per km² (GHSL / UN WPP)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtNum(r.ghsl_pop_density_km2, 1),
  },
  {
    key: 'gadm_adm1_features',
    label: 'GADM ADM1',
    title: 'GADM 4.1 ADM1 Polygon Divisions Count (Non-Commercial Reference)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtNum(r.gadm_adm1_features, 0),
  },
  {
    key: 'eurostat_gdp_meur',
    label: 'EU GDP M€',
    title: 'Eurostat GDP at Current Market Prices Million EUR (nama_10_gdp)',
    align: 'right',
    lenses: ['sdmx_macro', 'all'],
    format: (r) => fmtPop(r.eurostat_gdp_meur),
  },
  {
    key: 'bis_total_credit_pct_gdp',
    label: 'BIS Credit %',
    title: 'Total Credit to Private Non-Financial Sector % GDP (BIS SDMX v2)',
    align: 'right',
    lenses: ['sdmx_macro', 'all'],
    format: (r) => fmtPct(r.bis_total_credit_pct_gdp),
  },
  {
    key: 'ibge_ipca_pct',
    label: 'IBGE IPCA %',
    title: 'Brazil Official IBGE IPCA 12-Month Accumulated Inflation %',
    align: 'right',
    lenses: ['sdmx_macro', 'all'],
    format: (r) => fmtPct(r.ibge_ipca_pct),
  },
  {
    key: 'statfin_cpi_pct',
    label: 'StatFin CPI %',
    title: 'Finland Official CPI Inflation Annual Change % (StatFin PxWeb)',
    align: 'right',
    lenses: ['sdmx_macro', 'all'],
    format: (r) => fmtPct(r.statfin_cpi_pct),
  },
  {
    key: 'unctad_lsci',
    label: 'UNCTAD LSCI',
    title: 'Maritime Liner Shipping Connectivity Index 2004=100 (UNCTAD)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtNum(r.unctad_lsci, 1),
  },
  {
    key: 'unhcr_refugees',
    label: 'UNHCR Refug.',
    title: 'Refugees Under UNHCR Mandate by Country of Asylum (UNHCR API v1)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtPop(r.unhcr_refugees),
  },
  {
    key: 'usgs_seismic_events',
    label: 'USGS M5.5+',
    title: 'Recent Significant Seismic Events M>=5.5 Matched to Territory (USGS FDSN)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtNum(r.usgs_seismic_events, 0),
  },
  {
    key: 'gb_adm0_coverage',
    label: 'geoBound ADM0',
    title: 'geoBoundaries Open ADM0 Release Availability Flag (CC-BY-4.0)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtNum(r.gb_adm0_coverage, 0),
  },
  {
    key: 'crossref_works_count',
    label: 'Crossref DOIs',
    title: 'Global Scholarly DOI Works Indexed by Crossref REST (Polite Pool)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtPop(r.crossref_works_count),
  },
  {
    key: 'undata_elec_access_pct',
    label: 'UN Elec %',
    title: 'Proportion of Population with Access to Electricity % (UNdata SDMX-RI SDG 7.1.1)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtPct(r.undata_elec_access_pct),
  },
  {
    key: 'undrr_mortality_per_100k',
    label: 'UNDRR Mort.',
    title: 'Disaster Mortality & Missing Persons per 100k Population (UNDRR Sendai)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtNum(r.undrr_mortality_per_100k, 2),
  },
  {
    key: 'usgov_datasets_total',
    label: 'US Data.gov',
    title: 'Total U.S. Data.gov Federated Datasets (catalog.data.gov API v1)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtPop(r.usgov_datasets_total),
  },
  {
    key: 'pip_mean_daily_ppp',
    label: 'PIP $/Day',
    title: 'Mean Daily Per-Capita Income/Consumption 2017 PPP $ (World Bank PIP)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtNum(r.pip_mean_daily_ppp, 2),
  },
  {
    key: 'ct_ghg_co2e',
    label: 'CT GHG CO2e',
    title: 'Annual Total Greenhouse Gas Emissions Tonnes CO2e 100yr (Climate TRACE v7)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtPop(r.ct_ghg_co2e),
  },
  {
    key: 'wikimedia_enwiki_views',
    label: 'Wiki Views',
    title: 'Monthly English Wikipedia Country Article Pageviews (Wikimedia REST)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtPop(r.wikimedia_enwiki_views),
  },
  {
    key: 'undp_hdi',
    label: 'UNDP HDI',
    title: 'Human Development Index 0-1 (UNDP HDR)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtNum(r.undp_hdi, 3),
  },
  {
    key: 'us_census_pop',
    label: 'US Census Pop',
    title: 'U.S. Resident Population Vintage Estimate (U.S. Census Bureau)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtPop(r.us_census_pop),
  },
  {
    key: 'india_iip_index',
    label: 'India IIP',
    title: 'India Index of Industrial Production General (Base 2022-23=100, MoSPI)',
    align: 'right',
    lenses: ['sdmx_macro', 'all'],
    format: (r) => fmtNum(r.india_iip_index, 1),
  },
  {
    key: 'eia_energy_prod_qbtu',
    label: 'US EIA QBtu',
    title: 'U.S. Primary Energy Production Quadrillion Btu (EIA MER)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtNum(r.eia_energy_prod_qbtu, 1),
  },
  {
    key: 'noaa_tavg_c',
    label: 'NOAA Temp °C',
    title: 'GHCN Station Mean Annual Temperature °C (NOAA NCEI)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtNum(r.noaa_tavg_c, 1, '°C'),
  },
  {
    key: 'gfw_tree_loss_ha',
    label: 'GFW Loss ha',
    title: 'Annual Tree Cover Loss Area Hectares (Hansen/UMD/GFW)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtPop(r.gfw_tree_loss_ha),
  },
  {
    key: 'icao_scheduled_airports',
    label: 'ICAO Airports',
    title: 'Scheduled Commercial Service Airports (ICAO / OurAirports)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtNum(r.icao_scheduled_airports, 0),
  },
  {
    key: 'wdpa_protected_pct',
    label: 'WDPA Prot %',
    title: 'Terrestrial Protected Areas % of Total Land Area (WDPA Non-Commercial)',
    align: 'right',
    lenses: ['energy_rnd', 'all'],
    format: (r) => fmtPct(r.wdpa_protected_pct),
  },
  {
    key: 'gini_index',
    label: 'Gini',
    title: 'World Bank / OWID Gini Index',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtNum(r.gini_index, 1),
  },
  {
    key: 'life_expectancy_years',
    label: 'Life Exp.',
    title: 'WHO Life Expectancy at Birth (Years)',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtNum(r.life_expectancy_years, 1, 'y'),
  },
  {
    key: 'population_total',
    label: 'Population',
    title: 'Total Population',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtPop(r.population_total),
  },
  {
    key: 'urbanization_pct',
    label: 'Urban %',
    title: 'Urban Population %',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtPct(r.urbanization_pct),
  },
  {
    key: 'internet_users_pct',
    label: 'Net %',
    title: 'Individuals Using the Internet %',
    align: 'right',
    lenses: ['structural', 'all'],
    format: (r) => fmtPct(r.internet_users_pct),
  },
];

export function hasAnyMacroMetric(r: MacroEconomicRow): boolean {
  return COLUMNS.some((col) => {
    const v = r[col.key];
    return typeof v === 'number' && Number.isFinite(v);
  });
}
