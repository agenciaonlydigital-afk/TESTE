import type { H3MacroCellRow } from '../../types/lakehouse.ts';
import { fmtCompactUsd, fmtPct, fmtPop } from './macroFormatters.ts';

interface H3RollupTableProps {
  h3Cells: H3MacroCellRow[];
  onSelectCell: (h3Index: string) => void;
}

export function H3RollupTable({ h3Cells, onSelectCell }: H3RollupTableProps) {
  return (
    <div className="space-y-2">
      <p className="px-1 text-[11px] text-amber-700 dark:text-amber-300">Country centroid assignment only: H3 cells group country representatives by centroid; they are not polygon intersections or population-grid allocations. Per-capita and urbanization values are population-weighted.</p>
      <div className="overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
      <table className="w-full border-collapse text-left text-xs">
        <thead>
          <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 font-medium text-slate-500 dark:text-slate-400">
            <th className="px-4 py-3">H3 Res-2 Hex Cell</th>
            <th className="px-4 py-3 text-right">Territories</th>
            <th className="px-4 py-3">ISO3 Members</th>
            <th className="px-4 py-3 text-right">Aggregated Population</th>
            <th className="px-4 py-3 text-right">Pop.-weighted GDP/Cap PPP (2021)</th>
            <th className="px-4 py-3 text-right">Pop.-weighted Urbanization %</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
          {h3Cells.length === 0 ? (
            <tr>
              <td colSpan={6} className="px-4 py-8 text-center text-slate-500 dark:text-slate-400">
                DuckDB H3 spatial cells are still indexing or no cells available.
              </td>
            </tr>
          ) : (
            h3Cells.map((cell) => (
              <tr
                key={cell.h3_res2}
                tabIndex={0}
                role="button"
                onClick={() => onSelectCell(cell.h3_res2)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    onSelectCell(cell.h3_res2);
                  }
                }}
                title="Filter countries whose representative centroid falls in this H3 Res-2 cell"
                className="cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/40 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-slate-900 dark:focus:ring-slate-400"
              >
                <td className="px-4 py-2.5 font-mono text-slate-900 dark:text-slate-100">
                  {cell.h3_res2}
                </td>
                <td className="px-4 py-2.5 text-right font-mono tabular-nums text-slate-800 dark:text-slate-200">
                  {cell.territory_count}
                </td>
                <td className="px-4 py-2.5 font-mono text-slate-600 dark:text-slate-400">
                  {cell.territories_csv}
                </td>
                <td className="px-4 py-2.5 text-right font-mono tabular-nums text-slate-800 dark:text-slate-200">
                  {fmtPop(cell.total_population)}
                </td>
                <td className="px-4 py-2.5 text-right font-mono tabular-nums text-slate-800 dark:text-slate-200">
                  {fmtCompactUsd(cell.population_weighted_gdp_per_capita_ppp_2021)}
                </td>
                <td className="px-4 py-2.5 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                  {fmtPct(cell.population_weighted_urbanization_pct)}
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
      </div>
    </div>
  );
}
