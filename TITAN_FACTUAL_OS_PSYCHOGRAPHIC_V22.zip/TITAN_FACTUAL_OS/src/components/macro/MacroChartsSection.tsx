import type { MacroEconomicRow } from '../../types/lakehouse.ts';
import { CHART_METRICS, type ChartMetricKey } from './macroColumnsConfig.ts';

export interface CycleDivergenceItem {
  iso3: string;
  name: string;
  value: number;
  delta: number;
  label: string;
}

export interface CycleDivergenceModel {
  mode: 'cli' | 'growth';
  anchor: number;
  title: string;
  subtitle: string;
  items: CycleDivergenceItem[];
}

interface MacroChartsSectionProps {
  chartMetric: ChartMetricKey;
  onChartMetricChange: (metric: ChartMetricKey) => void;
  chartMeta: (typeof CHART_METRICS)[number];
  topMetricRows: MacroEconomicRow[];
  cycleDivergence: CycleDivergenceModel;
  selectedIso3: string | null;
  onSelectTerritory: (iso3: string) => void;
}

export function MacroChartsSection({
  chartMetric,
  onChartMetricChange,
  chartMeta,
  topMetricRows,
  cycleDivergence,
  selectedIso3,
  onSelectTerritory,
}: MacroChartsSectionProps) {
  return (
    <section className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      {/* Chart 1: Cross-Country Leaders */}
      <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-3">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Cross-Country {chartMeta.label} Leaders
            </h2>
            <p className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
              {chartMeta.subtitle}
            </p>
          </div>
          <div className="flex flex-wrap gap-1">
            {CHART_METRICS.map((m) => (
              <button
                key={m.key}
                type="button"
                onClick={() => onChartMetricChange(m.key)}
                className={`px-2 py-1 text-[11px] font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
                  chartMetric === m.key
                    ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>
        </div>

        {topMetricRows.length === 0 ? (
          <div className="py-10 text-center text-xs text-slate-500 dark:text-slate-400">
            No {chartMeta.label} observations in the active filter yet.
          </div>
        ) : (
          <svg
            viewBox={`0 0 480 ${topMetricRows.length * 26 + 8}`}
            className="w-full h-auto overflow-visible"
            role="img"
            aria-label={`Top territories by ${chartMeta.label}`}
          >
            {(() => {
              const maxVal = Math.max(
                ...topMetricRows.map((r) => Math.abs(r[chartMetric] as number)),
                1e-6
              );
              return topMetricRows.map((r, idx) => {
                const val = r[chartMetric] as number;
                const barWidth = Math.max(4, (Math.max(0, val) / maxVal) * 240);
                const y = idx * 26 + 4;
                const isSelected = selectedIso3 === r.iso3;
                return (
                  <g
                    key={r.iso3}
                    onClick={() => onSelectTerritory(r.iso3)}
                    className="cursor-pointer group"
                  >
                    <rect
                      x={0}
                      y={y}
                      width={480}
                      height={22}
                      rx={4}
                      className={
                        isSelected
                          ? 'fill-slate-100 dark:fill-slate-800/80'
                          : 'fill-transparent group-hover:fill-slate-50 dark:group-hover:fill-slate-800/40'
                      }
                    />
                    <text
                      x={8}
                      y={y + 15}
                      className="fill-slate-500 dark:fill-slate-400 font-mono text-[10px]"
                    >
                      {r.iso3}
                    </text>
                    <text
                      x={42}
                      y={y + 15}
                      className="fill-slate-800 dark:fill-slate-200 text-[11px] font-medium"
                    >
                      {r.name_en.length > 16 ? `${r.name_en.slice(0, 15)}…` : r.name_en}
                    </text>
                    <rect
                      x={160}
                      y={y + 5}
                      width={240}
                      height={12}
                      rx={3}
                      className="fill-slate-100 dark:fill-slate-800"
                    />
                    <rect
                      x={160}
                      y={y + 5}
                      width={barWidth}
                      height={12}
                      rx={3}
                      className={
                        isSelected
                          ? 'fill-sky-600 dark:fill-sky-400'
                          : 'fill-slate-800 dark:fill-slate-200 group-hover:fill-sky-600 dark:group-hover:fill-sky-400 transition-colors'
                      }
                    />
                    <text
                      x={472}
                      y={y + 15}
                      textAnchor="end"
                      className="fill-slate-900 dark:fill-slate-100 font-mono text-[11px] tabular-nums"
                    >
                      {chartMeta.format(val)}
                    </text>
                  </g>
                );
              });
            })()}
          </svg>
        )}
      </div>

      {/* Chart 2: OECD CLI Cycle or IMF Growth Dispersion */}
      <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-3">
        <div>
          <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            {cycleDivergence.title}
          </h2>
          <p className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
            {cycleDivergence.subtitle}
          </p>
        </div>

        {cycleDivergence.items.length === 0 ? (
          <div className="py-10 text-center text-xs text-slate-500 dark:text-slate-400">
            No cycle dispersion observations in the active filter yet.
          </div>
        ) : (
          <svg
            viewBox={`0 0 480 ${cycleDivergence.items.length * 26 + 8}`}
            className="w-full h-auto overflow-visible"
            role="img"
            aria-label={cycleDivergence.title}
          >
            {(() => {
              const maxDelta = Math.max(
                ...cycleDivergence.items.map((i) => Math.abs(i.delta)),
                0.5
              );
              const centerX = 285;
              const halfSpan = 105;
              return (
                <>
                  <line
                    x1={centerX}
                    y1={2}
                    x2={centerX}
                    y2={cycleDivergence.items.length * 26 + 4}
                    strokeWidth={1}
                    className="stroke-slate-300 dark:stroke-slate-700"
                    strokeDasharray="3 3"
                  />
                  {cycleDivergence.items.map((item, idx) => {
                    const y = idx * 26 + 4;
                    const w = Math.max(3, (Math.abs(item.delta) / maxDelta) * halfSpan);
                    const x = item.delta >= 0 ? centerX : centerX - w;
                    const isSelected = selectedIso3 === item.iso3;
                    return (
                      <g
                        key={item.iso3}
                        onClick={() => onSelectTerritory(item.iso3)}
                        className="cursor-pointer group"
                      >
                        <rect
                          x={0}
                          y={y}
                          width={480}
                          height={22}
                          rx={4}
                          className={
                            isSelected
                              ? 'fill-slate-100 dark:fill-slate-800/80'
                              : 'fill-transparent group-hover:fill-slate-50 dark:group-hover:fill-slate-800/40'
                          }
                        />
                        <text
                          x={8}
                          y={y + 15}
                          className="fill-slate-500 dark:fill-slate-400 font-mono text-[10px]"
                        >
                          {item.iso3}
                        </text>
                        <text
                          x={42}
                          y={y + 15}
                          className="fill-slate-800 dark:fill-slate-200 text-[11px] font-medium"
                        >
                          {item.name.length > 17 ? `${item.name.slice(0, 16)}…` : item.name}
                        </text>
                        <rect
                          x={x}
                          y={y + 5}
                          width={w}
                          height={12}
                          rx={3}
                          className={
                            item.delta >= 0
                              ? 'fill-emerald-600 dark:fill-emerald-500'
                              : 'fill-amber-600 dark:fill-amber-500'
                          }
                        />
                        <text
                          x={472}
                          y={y + 15}
                          textAnchor="end"
                          className="fill-slate-900 dark:fill-slate-100 font-mono text-[11px] tabular-nums"
                        >
                          {item.label}
                        </text>
                      </g>
                    );
                  })}
                </>
              );
            })()}
          </svg>
        )}
      </div>
    </section>
  );
}
