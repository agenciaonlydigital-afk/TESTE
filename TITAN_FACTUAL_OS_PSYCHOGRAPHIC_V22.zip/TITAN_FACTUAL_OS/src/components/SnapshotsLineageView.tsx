import { RotateCcw, Wrench } from 'lucide-react';
import type { ControlPlaneOverview } from '../types/lakehouse.ts';

interface SnapshotsLineageViewProps {
  overview: ControlPlaneOverview | null;
  runningMaintenance: boolean;
  resettingBreakers?: boolean;
  onRunMaintenance: () => void;
  onResetBreakers?: () => void;
}

function fmtBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export function SnapshotsLineageView({
  overview,
  runningMaintenance,
  resettingBreakers = false,
  onRunMaintenance,
  onResetBreakers,
}: SnapshotsLineageViewProps) {
  if (!overview) {
    return (
      <div className="py-12 text-center text-sm text-slate-500 dark:text-slate-400">
        Loading Control Plane ledger...
      </div>
    );
  }

  const activeGoldCount = overview.snapshots.filter((s) => s.layer === 'gold' && s.is_active === 1).length;
  const activeSilverCount = overview.snapshots.filter((s) => s.layer === 'silver' && s.is_active === 1).length;
  const activeBronzeCount = overview.snapshots.filter((s) => s.layer === 'bronze' && s.is_active === 1).length;
  const hasOpenBreakers = overview.breakers.some((b) => b.state !== 'CLOSED');

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-100">
            Lakehouse Snapshots, Lineage & Resilience
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            Immutable Bronze/Silver/Gold ZSTD Parquet manifests, per-host circuit breakers, measured DuckDB/L1 latency, SQLite WAL maintenance, and OpenLineage runs.
          </p>
        </div>

        <button
          type="button"
          disabled={runningMaintenance}
          onClick={onRunMaintenance}
          className="inline-flex items-center gap-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2 text-xs font-medium text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-40 transition-colors whitespace-nowrap shrink-0"
        >
          <Wrench className="h-3.5 w-3.5" />
          <span>{runningMaintenance ? 'Running Maintenance...' : 'Run Maintenance'}</span>
        </button>
      </div>

      {/* Measured Engine & Storage Telemetry Strip (no fake numbers) */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
          <div className="text-xs text-slate-500 dark:text-slate-400">DuckDB p95 Latency</div>
          <div className="mt-1 text-lg font-semibold font-mono tabular-nums text-slate-900 dark:text-slate-100">
            {overview.duckdbMetrics?.p95Ms ?? 0} ms
          </div>
          <div className="mt-0.5 text-[11px] font-mono text-slate-500 dark:text-slate-400 tabular-nums">
            {overview.duckdbMetrics?.queryCount ?? 0} queries · avg {overview.duckdbMetrics?.avgMs ?? 0} ms
          </div>
        </div>

        <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
          <div className="text-xs text-slate-500 dark:text-slate-400">L1 LRU Cache Hit Rate</div>
          <div className="mt-1 text-lg font-semibold font-mono tabular-nums text-slate-900 dark:text-slate-100">
            {overview.cacheStats?.hitRatePct ?? 0}%
          </div>
          <div className="mt-0.5 text-[11px] font-mono text-slate-500 dark:text-slate-400 tabular-nums">
            {overview.cacheStats?.hits ?? 0} hits · {overview.cacheStats?.misses ?? 0} misses
          </div>
        </div>

        <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
          <div className="text-xs text-slate-500 dark:text-slate-400">SQLite Control Plane WAL</div>
          <div className="mt-1 text-lg font-semibold font-mono tabular-nums text-slate-900 dark:text-slate-100">
            {fmtBytes(overview.walBytes ?? 0)}
          </div>
          <div className="mt-0.5 text-[11px] font-mono text-slate-500 dark:text-slate-400 tabular-nums">
            {overview.territoryCount} territories · {overview.dlqCount} DLQ
          </div>
        </div>

        <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
          <div className="text-xs text-slate-500 dark:text-slate-400">Active Ingestion Locks</div>
          <div className="mt-1 text-lg font-semibold font-mono tabular-nums text-slate-900 dark:text-slate-100">
            {overview.activeIngestionLocks?.length ?? 0}
          </div>
          <div className="mt-0.5 text-[11px] font-mono text-slate-500 dark:text-slate-400 truncate">
            {overview.activeIngestionLocks && overview.activeIngestionLocks.length > 0
              ? overview.activeIngestionLocks.join(', ')
              : `DuckDB ${overview.duckdbVersion}`}
          </div>
        </div>
      </section>

      {/* Circuit Breakers */}
      <section className="space-y-3">
        <div className="flex items-center justify-between gap-4">
          <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            Per-Host Circuit Breakers & HTTP Latency
          </h2>
          {onResetBreakers && hasOpenBreakers && (
            <button
              type="button"
              disabled={resettingBreakers}
              onClick={onResetBreakers}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-40 transition-colors whitespace-nowrap shrink-0"
            >
              <RotateCcw className="h-3 w-3" />
              <span>{resettingBreakers ? 'Resetting...' : 'Reset Open Breakers'}</span>
            </button>
          )}
        </div>
        <div className="overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
          <table className="w-full border-collapse text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 font-medium text-slate-500 dark:text-slate-400">
                <th className="px-4 py-2.5">Host</th>
                <th className="px-4 py-2.5">State</th>
                <th className="px-4 py-2.5 text-right">Error Streak</th>
                <th className="px-4 py-2.5 text-right">HTTP Avg / p95</th>
                <th className="px-4 py-2.5">Last ETag</th>
                <th className="px-4 py-2.5">Last Error / Cooldown</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
              {overview.breakers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-6 text-center text-slate-500">
                    No host calls recorded yet. Trigger any Tier-0 ingestion to initialize host circuit state.
                  </td>
                </tr>
              ) : (
                overview.breakers.map((b) => {
                  const httpMetric = overview.httpMetrics?.find((m) => m.host === b.host);
                  return (
                    <tr key={b.host}>
                      <td className="px-4 py-2.5 font-mono text-slate-900 dark:text-slate-100">{b.host}</td>
                      <td
                        className={`px-4 py-2.5 font-mono font-medium ${
                          b.state === 'OPEN'
                            ? 'text-rose-700 dark:text-rose-400'
                            : b.state === 'HALF_OPEN'
                              ? 'text-amber-700 dark:text-amber-400'
                              : 'text-emerald-700 dark:text-emerald-400'
                        }`}
                      >
                        {b.state}
                      </td>
                      <td className="px-4 py-2.5 text-right font-mono tabular-nums">{b.error_streak}</td>
                      <td className="px-4 py-2.5 text-right font-mono tabular-nums text-slate-600 dark:text-slate-400">
                        {httpMetric ? `${httpMetric.avgMs} / ${httpMetric.p95Ms} ms` : '—'}
                      </td>
                      <td className="px-4 py-2.5 font-mono text-slate-500 dark:text-slate-400 truncate max-w-[180px]">
                        {b.last_etag ?? '—'}
                      </td>
                      <td className="px-4 py-2.5 text-slate-600 dark:text-slate-400 truncate max-w-xs">
                        {b.last_error ?? (b.cooldown_until ? `Cooldown until ${b.cooldown_until}` : 'Nominal')}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* Snapshot Manifest Ledger */}
      <section className="space-y-3">
        <div className="flex items-center justify-between gap-4">
          <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            Parquet Snapshot Manifest Ledger
          </h2>
          <span className="font-mono text-xs text-slate-500 dark:text-slate-400 tabular-nums">
            Active: {activeGoldCount} Gold · {activeSilverCount} Silver · {activeBronzeCount} Bronze
          </span>
        </div>
        <div className="overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
          <table className="w-full border-collapse text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 font-medium text-slate-500 dark:text-slate-400">
                <th className="px-4 py-2.5">Snapshot ID</th>
                <th className="px-4 py-2.5">Layer</th>
                <th className="px-4 py-2.5">QA Gate</th>
                <th className="px-4 py-2.5 text-right">Rows</th>
                <th className="px-4 py-2.5 text-right">ZSTD Size</th>
                <th className="px-4 py-2.5">SHA-256</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
              {overview.snapshots.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-6 text-center text-slate-500">
                    No immutable Parquet snapshots created yet.
                  </td>
                </tr>
              ) : (
                overview.snapshots.map((s) => (
                  <tr key={s.snapshot_id}>
                    <td className="px-4 py-2.5 font-mono text-slate-900 dark:text-slate-100">
                      {s.snapshot_id}
                      {s.is_active === 1 && (
                        <span className="ml-2 text-emerald-700 dark:text-emerald-400 font-semibold">ACTIVE</span>
                      )}
                    </td>
                    <td className="px-4 py-2.5 font-mono text-slate-700 dark:text-slate-300">{s.layer}</td>
                    <td className="px-4 py-2.5 font-mono text-emerald-700 dark:text-emerald-400">{s.qa_status}</td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums">{s.row_count.toLocaleString()}</td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums">{fmtBytes(s.byte_size)}</td>
                    <td className="px-4 py-2.5 font-mono text-slate-500 dark:text-slate-400">
                      {s.sha256.slice(0, 14)}…
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* Lineage Runs */}
      <section className="space-y-3">
        <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
          Lineage Execution History
        </h2>
        <div className="overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
          <table className="w-full border-collapse text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 font-medium text-slate-500 dark:text-slate-400">
                <th className="px-4 py-2.5">Run ID</th>
                <th className="px-4 py-2.5">Source</th>
                <th className="px-4 py-2.5">Status</th>
                <th className="px-4 py-2.5 text-right">Rows In / Out</th>
                <th className="px-4 py-2.5 text-right">Duration</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
              {overview.lineage.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-4 py-6 text-center text-slate-500">
                    No lineage runs recorded yet.
                  </td>
                </tr>
              ) : (
                overview.lineage.map((r) => (
                  <tr key={r.run_id}>
                    <td className="px-4 py-2.5 font-mono text-slate-800 dark:text-slate-200">{r.run_id}</td>
                    <td className="px-4 py-2.5 font-mono text-slate-600 dark:text-slate-400">{r.source_id}</td>
                    <td
                      className={`px-4 py-2.5 font-mono font-medium ${
                        r.status === 'COMPLETED'
                          ? 'text-emerald-700 dark:text-emerald-400'
                          : r.status === 'UP_TO_DATE_304'
                            ? 'text-sky-700 dark:text-sky-400'
                            : r.status === 'SKIPPED_304'
                              ? 'text-slate-600 dark:text-slate-400'
                              : r.status === 'FAILED' || r.status === 'BLOCKED_CB'
                                ? 'text-rose-700 dark:text-rose-400'
                                : 'text-amber-700 dark:text-amber-400'
                      }`}
                    >
                      {r.status === 'UP_TO_DATE_304'
                        ? 'UP_TO_DATE (304)'
                        : r.status === 'SKIPPED_304'
                          ? 'SKIPPED (304)'
                          : r.status}
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums">
                      {r.rows_in.toLocaleString()} / {r.rows_out.toLocaleString()}
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums">{r.duration_ms} ms</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
