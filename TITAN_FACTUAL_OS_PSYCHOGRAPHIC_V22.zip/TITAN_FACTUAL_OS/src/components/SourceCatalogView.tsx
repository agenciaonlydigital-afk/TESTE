import { Eye, Play, RotateCw, Search, ShieldAlert, ShieldCheck, X } from 'lucide-react';
import { useMemo, useState } from 'react';
import type {
  CircuitBreakerRecord,
  ResourceKind,
  SnapshotManifest,
  SourceCatalogEntry,
} from '../types/lakehouse.ts';
import { hasNum } from './macro/macroFormatters.ts';

interface SourcePreviewPayload {
  source: SourceCatalogEntry;
  snapshotId: string | null;
  totalRows: number;
  indicators: Array<{
    indicator_id: string;
    indicator_name: string;
    unit: string;
    valuation_basis: string;
    methodology_id: string;
    obs_count: number;
    territory_count: number;
    min_year: number;
    max_year: number;
  }>;
  rows: Array<{
    iso3: string;
    indicator_id: string;
    indicator_name: string;
    period_year: number;
    value_numeric: number;
    unit: string;
    valuation_basis: string;
    methodology_id: string;
  }>;
}

interface SourceCatalogViewProps {
  sources: SourceCatalogEntry[];
  breakers: CircuitBreakerRecord[];
  snapshots?: SnapshotManifest[];
  ingestingId: string | null;
  onIngestSource: (sourceId: string, force?: boolean) => void;
}

const RESOURCE_KIND_LABELS: Record<ResourceKind, string> = {
  api: 'API',
  bulk: 'Bulk File',
  data_source: 'Data Source',
  catalog: 'Catalog',
  protocol: 'Protocol',
  platform: 'Platform',
};

export function SourceCatalogView({
  sources,
  breakers,
  snapshots = [],
  ingestingId,
  onIngestSource,
}: SourceCatalogViewProps) {
  const [search, setSearch] = useState('');
  const [originFilter, setOriginFilter] = useState<'all' | 'canonical' | 'expansion'>('all');
  const [tierFilter, setTierFilter] = useState<'all' | 'tier0' | 'restricted'>('all');
  const [kindFilter, setKindFilter] = useState<'all' | ResourceKind>('all');
  const [domainFilter, setDomainFilter] = useState<string>('all');
  const [commercialOnly, setCommercialOnly] = useState(false);
  const [preview, setPreview] = useState<SourcePreviewPayload | null>(null);
  const [previewLoading, setPreviewLoading] = useState<string | null>(null);

  async function handleInspectSource(sourceId: string) {
    if (preview?.source.source_id === sourceId) {
      setPreview(null);
      return;
    }
    setPreviewLoading(sourceId);
    try {
      const res = await fetch(`/api/v1/gold/source/${sourceId}`);
      if (res.ok) {
        const data = (await res.json()) as SourcePreviewPayload;
        setPreview(data);
      }
    } finally {
      setPreviewLoading(null);
    }
  }

  const breakerByHost = useMemo(() => {
    return new Map(breakers.map((b) => [b.host, b]));
  }, [breakers]);

  const activeSilverBySource = useMemo(() => {
    const map = new Map<string, SnapshotManifest>();
    for (const snap of snapshots) {
      if (snap.layer === 'silver' && snap.is_active === 1) {
        map.set(snap.source_id, snap);
      }
    }
    return map;
  }, [snapshots]);

  const domains = useMemo(() => {
    const unique = new Set<string>();
    for (const s of sources) {
      if (s.domain_group) unique.add(s.domain_group);
    }
    return Array.from(unique).sort((a, b) => a.localeCompare(b));
  }, [sources]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return sources.filter((s) => {
      if (originFilter === 'canonical' && s.is_expansion !== 0) return false;
      if (originFilter === 'expansion' && s.is_expansion !== 1) return false;
      if (tierFilter === 'tier0' && s.access_tier !== 'tier0_keyless') return false;
      if (tierFilter === 'restricted' && s.access_tier === 'tier0_keyless') return false;
      if (kindFilter !== 'all' && s.resource_kind !== kindFilter) return false;
      if (domainFilter !== 'all' && s.domain_group !== domainFilter) return false;
      if (commercialOnly && s.commercial_use_allowed !== 'confirmed') return false;
      if (!q) return true;
      return (
        s.source_name.toLowerCase().includes(q) ||
        s.source_id.toLowerCase().includes(q) ||
        s.module_name.toLowerCase().includes(q) ||
        s.domain_group.toLowerCase().includes(q) ||
        s.api_version.toLowerCase().includes(q) ||
        s.license_id.toLowerCase().includes(q) ||
        (s.duplicity_audit_note ?? '').toLowerCase().includes(q)
      );
    });
  }, [sources, search, originFilter, tierFilter, kindFilter, domainFilter, commercialOnly]);

  const canonicalCount = sources.filter((s) => s.is_expansion === 0).length;
  const expansionCount = sources.filter((s) => s.is_expansion === 1).length;
  const infraCount = sources.filter(
    (s) => s.resource_kind === 'catalog' || s.resource_kind === 'protocol' || s.resource_kind === 'platform'
  ).length;
  const statisticalCount = sources.length - infraCount;
  const activeWave1Count = sources.filter(
    (s) => s.implemented_wave1 === 1 && s.access_tier === 'tier0_keyless'
  ).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2 xl:flex-row xl:items-end xl:justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-100">
            Audited Source Catalog & License Governance
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            Preserves all 73 canonical inventory indices (0–72) separated by resource kind plus domain expansions across demography, inequality, cities, climate, and culture.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5 text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
          <span>{sources.length} Total</span>
          <span aria-hidden="true">·</span>
          <span>{canonicalCount} Canonical [0–72]</span>
          <span aria-hidden="true">·</span>
          <span>{expansionCount} Expansions [73+]</span>
          <span aria-hidden="true">·</span>
          <span>{statisticalCount} Data / {infraCount} Infra</span>
          <span aria-hidden="true">·</span>
          <span>{activeWave1Count} Active Live</span>
        </div>
      </div>

      {/* Filter & Search Toolbar */}
      <div className="space-y-3">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative w-full sm:w-72">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Filter source, version, domain, or audit note..."
                className="w-full rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 py-2 pl-9 pr-3 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-900 dark:focus:ring-slate-400"
              />
            </div>

            <div className="inline-flex items-center gap-1 rounded-lg bg-slate-100 dark:bg-slate-900 p-1 border border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setOriginFilter('all')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  originFilter === 'all'
                    ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                All ({sources.length})
              </button>
              <button
                type="button"
                onClick={() => setOriginFilter('canonical')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  originFilter === 'canonical'
                    ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                Canonical 0–72 ({canonicalCount})
              </button>
              <button
                type="button"
                onClick={() => setOriginFilter('expansion')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  originFilter === 'expansion'
                    ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                Expansions 73+ ({expansionCount})
              </button>
            </div>

            <div className="inline-flex items-center gap-1 rounded-lg bg-slate-100 dark:bg-slate-900 p-1 border border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setTierFilter('all')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  tierFilter === 'all'
                    ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                All Tiers
              </button>
              <button
                type="button"
                onClick={() => setTierFilter('tier0')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  tierFilter === 'tier0'
                    ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                Tier 0 Keyless
              </button>
              <button
                type="button"
                onClick={() => setTierFilter('restricted')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  tierFilter === 'restricted'
                    ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                Keyed / Gated
              </button>
            </div>
          </div>

          <label className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={commercialOnly}
              onChange={(e) => setCommercialOnly(e.target.checked)}
              className="h-4 w-4 rounded border-slate-300 dark:border-slate-700 text-slate-900 focus:ring-slate-900"
            />
            <span>Show only catalog entries marked commercial-use confirmed</span>
          </label>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <select
            aria-label="Filter by resource kind"
            value={kindFilter}
            onChange={(e) => setKindFilter(e.target.value as 'all' | ResourceKind)}
            className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-1.5 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-slate-900 dark:focus:ring-slate-400"
          >
            <option value="all">All Resource Kinds</option>
            <option value="api">API (REST / SDMX / OData / SPARQL)</option>
            <option value="bulk">Bulk Files (Parquet / CSV / ZIP)</option>
            <option value="data_source">Data Source / Portal</option>
            <option value="catalog">Catalog (Metadata Index)</option>
            <option value="protocol">Protocol (CKAN / OGC / STAC)</option>
            <option value="platform">Platform (ArcGIS / Socrata / OGD)</option>
          </select>

          <select
            aria-label="Filter by domain"
            value={domainFilter}
            onChange={(e) => setDomainFilter(e.target.value)}
            className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-1.5 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-slate-900 dark:focus:ring-slate-400 max-w-md"
          >
            <option value="all">All Domains ({domains.length})</option>
            {domains.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>

          <span className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">
            Showing {filtered.length} of {sources.length}
          </span>
        </div>
      </div>

      {/* Inline Silver Snapshot Preview Panel */}
      {preview && (
        <section className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-4">
          <div className="flex items-start justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-3">
            <div>
              <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                {preview.source.source_name} — Silver Parquet Preview
              </h2>
              <p className="mt-0.5 text-xs font-mono text-slate-500 dark:text-slate-400">
                {preview.snapshotId
                  ? `${preview.snapshotId} · ${preview.totalRows.toLocaleString()} Silver rows · ${preview.indicators.length} indicators`
                  : 'No Silver snapshot promoted yet. Click Run Sync to ingest live observations.'}
              </p>
              <p className="mt-2 max-w-3xl text-xs text-amber-700 dark:text-amber-400">
                Development dashboard preview: includes stored observations regardless of commercial-license status. Review source terms and enable a commercial serving policy before external distribution.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setPreview(null)}
              aria-label="Close source preview"
              className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {preview.indicators.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {preview.indicators.map((ind) => (
                <div
                  key={ind.indicator_id}
                  className="rounded-md border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60 p-3 text-xs"
                >
                  <div className="font-medium text-slate-900 dark:text-slate-100 truncate">
                    {ind.indicator_name}
                  </div>
                  <div className="mt-1 font-mono text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
                    {ind.indicator_id} · {ind.obs_count} obs · {ind.territory_count} territories · {ind.min_year}–{ind.max_year}
                  </div>
                </div>
              ))}
            </div>
          )}

          {preview.rows.length > 0 && (
            <div className="max-h-72 overflow-y-auto overflow-x-auto rounded border border-slate-200 dark:border-slate-800">
              <table className="w-full border-collapse text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/80 text-slate-500 dark:text-slate-400">
                    <th className="px-3 py-2">ISO3</th>
                    <th className="px-3 py-2">Indicator</th>
                    <th className="px-3 py-2 text-right">Year</th>
                    <th className="px-3 py-2 text-right">Value</th>
                    <th className="px-3 py-2">Unit</th>
                    <th className="px-3 py-2">Methodology</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {preview.rows.slice(0, 60).map((row, idx) => (
                    <tr key={`${row.iso3}-${row.indicator_id}-${row.period_year}-${idx}`}>
                      <td className="px-3 py-1.5 font-mono text-slate-900 dark:text-slate-100">{row.iso3}</td>
                      <td className="px-3 py-1.5 text-slate-700 dark:text-slate-300 truncate max-w-xs">
                        {row.indicator_name}
                      </td>
                      <td className="px-3 py-1.5 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                        {row.period_year}
                      </td>
                      <td className="px-3 py-1.5 text-right font-mono tabular-nums font-medium text-slate-900 dark:text-slate-100">
                        {hasNum(row.value_numeric)
                          ? row.value_numeric.toLocaleString('en-US', { maximumFractionDigits: 2 })
                          : '—'}
                      </td>
                      <td className="px-3 py-1.5 font-mono text-slate-500 dark:text-slate-400">{row.unit}</td>
                      <td className="px-3 py-1.5 font-mono text-[11px] text-slate-500 dark:text-slate-400">
                        {row.methodology_id}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      )}

      {/* High-Density Catalog Table */}
      <div className="overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
        <table className="w-full border-collapse text-left text-sm">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 text-xs font-medium text-slate-500 dark:text-slate-400">
              <th className="px-4 py-3">Idx · Source & Audit</th>
              <th className="px-4 py-3">Kind & Version</th>
              <th className="px-4 py-3">License / Commercial-use Metadata</th>
              <th className="px-4 py-3 text-right">Rate Cap</th>
              <th className="px-4 py-3">Circuit / Last Sync</th>
              <th className="px-4 py-3 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
            {filtered.map((s) => {
              const breaker = breakerByHost.get(s.host);
              const isWave1Active = s.implemented_wave1 === 1 && s.access_tier === 'tier0_keyless';
              const isRunning = ingestingId === s.source_id;

              return (
                <tr
                  key={s.source_id}
                  className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                >
                  <td className="px-4 py-3 align-top max-w-xl">
                    <div className="flex items-baseline gap-2">
                      <span className="font-mono text-xs tabular-nums text-slate-400 dark:text-slate-500 shrink-0">
                        #{s.catalog_index ?? '—'}
                      </span>
                      <span className="font-medium text-slate-900 dark:text-slate-100">
                        {s.source_name}
                      </span>
                      {s.is_expansion === 1 && (
                        <span className="font-mono text-[11px] text-sky-700 dark:text-sky-400 shrink-0">
                          [Expansion]
                        </span>
                      )}
                    </div>
                    <div className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                      <span>{s.domain_group || `Part ${s.module_id} · ${s.module_name}`}</span>
                      <span aria-hidden="true"> · </span>
                      <span className="font-mono">{s.geographic_level}</span>
                    </div>
                    {s.duplicity_audit_note && (
                      <div className="mt-1 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                        Audit: {s.duplicity_audit_note}
                      </div>
                    )}
                    {s.known_block_reason && (
                      <div className="mt-1 text-xs text-amber-700 dark:text-amber-400 leading-relaxed">
                        Gate: {s.known_block_reason}
                      </div>
                    )}
                  </td>

                  <td className="px-4 py-3 align-top text-xs whitespace-nowrap">
                    <div className="font-mono text-slate-800 dark:text-slate-200">
                      {RESOURCE_KIND_LABELS[s.resource_kind] ?? s.resource_kind} · {s.api_version}
                    </div>
                    <div className="mt-0.5 text-slate-500 dark:text-slate-400 font-mono">
                      {s.access_tier === 'tier0_keyless'
                        ? 'Tier 0 Keyless'
                        : s.access_tier === 'tier1_free_key'
                          ? 'Tier 1 Free Key'
                          : s.access_tier === 'tier3_paid'
                            ? 'Tier 3 Paid'
                            : 'Tier 2 Registration'}{' '}
                      · {s.update_frequency}
                    </div>
                  </td>

                  <td className="px-4 py-3 align-top text-xs whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      {s.commercial_use_allowed === 'confirmed' ? (
                        <ShieldCheck className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                      ) : (
                        <ShieldAlert className="h-3.5 w-3.5 text-rose-600 dark:text-rose-400 shrink-0" />
                      )}
                      <span
                        className={
                          s.commercial_use_allowed === 'confirmed'
                            ? 'font-medium text-emerald-700 dark:text-emerald-400'
                            : 'font-medium text-rose-700 dark:text-rose-400'
                        }
                      >
                        {s.commercial_use_allowed === 'confirmed'
                          ? 'Commercial Allowed'
                          : s.commercial_use_allowed === 'denied'
                            ? 'Commercial Denied'
                            : 'License Pending'}
                      </span>
                    </div>
                    <div className="mt-0.5 font-mono text-slate-500 dark:text-slate-400">
                      {s.license_id}
                    </div>
                  </td>

                  <td className="px-4 py-3 align-top text-right font-mono text-xs tabular-nums text-slate-700 dark:text-slate-300 whitespace-nowrap">
                    <div>{s.rate_limit_rpm} rpm</div>
                    <div className="mt-0.5 text-slate-500 dark:text-slate-400">
                      {s.max_concurrency} conc
                    </div>
                  </td>

                  <td className="px-4 py-3 align-top text-xs font-mono tabular-nums whitespace-nowrap">
                    <div
                      className={
                        breaker?.state === 'OPEN'
                          ? 'text-rose-600 dark:text-rose-400 font-medium'
                          : 'text-slate-700 dark:text-slate-300'
                      }
                    >
                      {breaker ? breaker.state : 'CLOSED'}
                    </div>
                    <div className="mt-0.5 text-slate-500 dark:text-slate-400">
                      {s.last_successful_ingestion
                        ? new Date(s.last_successful_ingestion).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })
                        : 'Never synced'}
                      {(() => {
                        const activeSnap = activeSilverBySource.get(s.source_id);
                        return activeSnap ? ` · ${activeSnap.row_count.toLocaleString()} rows` : '';
                      })()}
                    </div>
                  </td>

                  <td className="px-4 py-3 align-top text-right">
                    {isWave1Active ? (
                      <div className="inline-flex items-center justify-end gap-1.5">
                        {s.last_successful_ingestion && (
                          <button
                            type="button"
                            disabled={previewLoading === s.source_id}
                            onClick={() => void handleInspectSource(s.source_id)}
                            title="Preview Silver Parquet observations"
                            className="inline-flex items-center gap-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 px-2.5 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-40 transition-colors whitespace-nowrap shrink-0"
                          >
                            <Eye className="h-3 w-3" />
                            <span>{preview?.source.source_id === s.source_id ? 'Hide' : 'Data'}</span>
                          </button>
                        )}
                        <button
                          type="button"
                          disabled={isRunning || ingestingId !== null}
                          onClick={() => onIngestSource(s.source_id, false)}
                          className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-900 dark:bg-slate-100 px-3 py-1.5 text-xs font-medium text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-white disabled:opacity-40 transition-colors whitespace-nowrap shrink-0"
                        >
                          <Play className="h-3 w-3" />
                          <span>{isRunning ? 'Syncing...' : 'Run Sync'}</span>
                        </button>
                        <button
                          type="button"
                          disabled={isRunning || ingestingId !== null}
                          onClick={() => onIngestSource(s.source_id, true)}
                          title="Force re-fetch bypassing HTTP 304 ETag/Last-Modified cache"
                          aria-label={`Force refresh ${s.source_name}`}
                          className="inline-flex items-center justify-center rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 p-1.5 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-40 transition-colors shrink-0"
                        >
                          <RotateCw className={`h-3.5 w-3.5 ${isRunning ? 'animate-spin' : ''}`} />
                        </button>
                      </div>
                    ) : (
                      <span className="text-xs text-slate-400 dark:text-slate-500 whitespace-nowrap">
                        {s.resource_kind === 'protocol' ||
                        s.resource_kind === 'catalog' ||
                        s.resource_kind === 'platform'
                          ? 'Infra / Index'
                          : s.access_tier === 'tier0_keyless'
                            ? 'Bulk / Wave 2'
                            : 'Gated'}
                      </span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
