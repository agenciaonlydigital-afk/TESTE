import { Download, ShieldCheck } from 'lucide-react';
import { Fragment, useMemo, useState } from 'react';
import type { BrandMarketProfile } from '../types/lakehouse.ts';
import { hasNum } from './macro/macroFormatters.ts';

interface BrandMarketViewProps {
  profiles: BrandMarketProfile[];
  snapshotCount: number;
  loading: boolean;
  mode: 'mass_market' | 'premium';
  onModeChange: (mode: 'mass_market' | 'premium') => void;
}

export function BrandMarketView({
  profiles,
  snapshotCount,
  loading,
  mode,
  onModeChange,
}: BrandMarketViewProps) {
  const [tierFilter, setTierFilter] = useState<
    'all' | 'Tier A (High PPP)' | 'Tier B (Mid PPP)' | 'Tier C (Lower PPP)' | 'Insufficient data'
  >('all');
  const [sortKey, setSortKey] = useState<'mai' | 'ppp' | 'digital_pop' | 'urban'>('mai');
  const [expandedTerritory, setExpandedTerritory] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const list = profiles.filter((p) =>
      tierFilter === 'all' ? true : p.purchasing_power_tier === tierFilter
    );
    return [...list].sort((a, b) => {
      if (sortKey === 'mai') {
        return (b.mai?.market_attractiveness_score ?? -1) - (a.mai?.market_attractiveness_score ?? -1);
      }
      if (sortKey === 'ppp') {
        return (b.gdp_per_capita_ppp_2021 ?? -1) - (a.gdp_per_capita_ppp_2021 ?? -1);
      }
      if (sortKey === 'digital_pop') {
        return (b.digital_addressable_pop ?? -1) - (a.digital_addressable_pop ?? -1);
      }
      return (b.urbanization_pct ?? -1) - (a.urbanization_pct ?? -1);
    });
  }, [profiles, tierFilter, sortKey]);

  function handleExportJson() {
    const blob = new Blob([JSON.stringify(filtered, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `titan-brand-market-profiles-${mode}-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-100">
            Branding & Market Readiness Feature Store
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            Territorial profiles combine harmonized survey measures when available with transparent macro-context hypotheses. Macro proxies are not measured psychographics; question-level evidence must be validated before segmentation, targeting or budget decisions.
          </p>
        </div>

        <button
          type="button"
          onClick={handleExportJson}
          disabled={filtered.length === 0}
          className="inline-flex items-center gap-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2 text-xs font-medium text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-40 transition-colors whitespace-nowrap shrink-0"
        >
          <Download className="h-3.5 w-3.5" />
          <span>Export Market Seeds JSON</span>
        </button>
      </div>

      <div className="flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-100 dark:bg-slate-900 p-1 border border-slate-200 dark:border-slate-800">
            {(['all', 'Tier A (High PPP)', 'Tier B (Mid PPP)', 'Tier C (Lower PPP)', 'Insufficient data'] as const).map(
              (t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setTierFilter(t)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    tierFilter === t
                      ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  {t === 'all' ? 'All Tiers' : t}
                </button>
              )
            )}
          </div>

          <div className="flex items-center gap-1 rounded-lg bg-slate-100 dark:bg-slate-900 p-1 border border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={() => onModeChange('mass_market')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                mode === 'mass_market'
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              Mass-Market Gini
            </button>
            <button
              type="button"
              onClick={() => onModeChange('premium')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                mode === 'premium'
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              Premium Positioning
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-400">
          <span>Sort by:</span>
          <select
            value={sortKey}
            onChange={(e) => setSortKey(e.target.value as 'mai' | 'ppp' | 'digital_pop' | 'urban')}
            className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-2.5 py-1.5 text-xs text-slate-900 dark:text-slate-100"
          >
            <option value="mai">MAI Heuristic Score</option>
            <option value="ppp">GDP/Capita PPP (2021)</option>
            <option value="digital_pop">Estimated Internet Users</option>
            <option value="urban">Urbanization %</option>
          </select>
        </div>
      </div>

      <div className="overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
        <table className="w-full border-collapse text-left text-xs">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 font-medium text-slate-500 dark:text-slate-400">
              <th className="px-4 py-3">Market</th>
              <th className="px-4 py-3">Locale · Currency · TZ</th>
              <th className="px-4 py-3">PPP Tier</th>
              <th className="px-4 py-3 text-right">MAI Heuristic</th>
              <th className="px-4 py-3 text-right">GDP/Cap PPP (2021 Int$)</th>
              <th className="px-4 py-3 text-right">Estimated Internet Users</th>
              <th className="px-4 py-3 text-right">Median Age · Life Exp</th>
              <th className="px-4 py-3 text-right">Urban %</th>
              <th className="px-4 py-3 text-right">Commercial Data</th>
              <th className="px-4 py-3 text-right">Research Profile</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
            {loading ? (
              <tr>
                <td colSpan={10} className="px-4 py-6 text-center text-slate-500">
                  Loading Gold market feature store...
                </td>
              </tr>
            ) : snapshotCount === 0 ? (
              <tr>
                <td colSpan={10} className="px-4 py-8 text-center text-slate-500 dark:text-slate-400">
                  Run Tier-0 Core ingestion to populate real purchasing power, median age, life expectancy, and MAI scores.
                </td>
              </tr>
            ) : (
              filtered.map((p) => (
                <Fragment key={p.territory_id}>
                <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                  <td className="px-4 py-3">
                    <div className="font-medium text-slate-900 dark:text-slate-100">{p.name_en}</div>
                    <div className="font-mono text-[11px] text-slate-500 dark:text-slate-400">
                      {p.iso3} · {p.region}
                    </div>
                  </td>
                  <td className="px-4 py-3 font-mono text-slate-700 dark:text-slate-300">
                    {p.primary_language_iso639} · {p.currency_iso4217} · {p.timezone}
                  </td>
                  <td className="px-4 py-3 font-medium text-slate-800 dark:text-slate-200">
                    {p.purchasing_power_tier}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="font-mono tabular-nums font-semibold text-slate-900 dark:text-slate-100">
                      {hasNum(p.mai?.market_attractiveness_score)
                        ? p.mai.market_attractiveness_score.toFixed(1)
                        : '—'}
                    </div>
                    {p.mai && (
                      <div className="font-mono tabular-nums text-[10px] text-slate-500 dark:text-slate-400">
                        D:{hasNum(p.mai.demographic_score) ? p.mai.demographic_score.toFixed(0) : '—'} · P:
                        {hasNum(p.mai.purchasing_power_score) ? p.mai.purchasing_power_score.toFixed(0) : '—'} · I×
                        {hasNum(p.mai.inflation_risk_multiplier) ? p.mai.inflation_risk_multiplier.toFixed(2) : '—'}
                      </div>
                    )}
                    {p.mai && (
                      <div className="text-[10px] text-slate-500 dark:text-slate-400">
                        Dados {p.mai.data_fields_available}/{p.mai.data_fields_expected} · período {p.mai.temporal_status}
                      </div>
                    )}
                  </td>
                  <td className="px-4 py-3 text-right font-mono tabular-nums text-slate-900 dark:text-slate-100">
                    {hasNum(p.gdp_per_capita_ppp_2021)
                      ? `Int$${Math.round(p.gdp_per_capita_ppp_2021).toLocaleString('en-US')}${p.gdp_per_capita_ppp_2021_year ? ` (${p.gdp_per_capita_ppp_2021_year})` : ''}`
                      : '—'}
                  </td>
                  <td className="px-4 py-3 text-right font-mono tabular-nums text-slate-800 dark:text-slate-200">
                    {hasNum(p.digital_addressable_pop)
                      ? <><div>{(p.digital_addressable_pop / 1e6).toFixed(1)}M</div><div className="text-[10px] text-slate-500">Pop {p.population_total_year} · Internet {p.internet_users_pct_year}</div></>
                      : '—'}
                  </td>
                  <td className="px-4 py-3 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                    {hasNum(p.median_age) ? `${p.median_age.toFixed(1)}y${p.median_age_year ? ` (${p.median_age_year})` : ''}` : '—'} ·{' '}
                    {hasNum(p.life_expectancy_years) ? `${p.life_expectancy_years.toFixed(1)}y${p.life_expectancy_years_year ? ` (${p.life_expectancy_years_year})` : ''}` : '—'}
                  </td>
                  <td className="px-4 py-3 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                    {hasNum(p.urbanization_pct) ? `${p.urbanization_pct.toFixed(1)}%${p.urbanization_pct_year ? ` (${p.urbanization_pct_year})` : ''}` : '—'}
                  </td>
                  <td className="px-4 py-3 text-right">
                    {p.license_clearance === 'confirmed' ? (
                      <span className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-400 font-medium">
                        <ShieldCheck className="h-3.5 w-3.5" />
                        <span>Confirmed</span>
                      </span>
                    ) : (
                      <span className="text-amber-700 dark:text-amber-400 font-medium">Unknown</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button
                      type="button"
                      onClick={() => setExpandedTerritory((current) => current === p.territory_id ? null : p.territory_id)}
                      className="rounded-md border border-slate-200 dark:border-slate-700 px-2.5 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
                      aria-expanded={expandedTerritory === p.territory_id}
                    >
                      {expandedTerritory === p.territory_id ? 'Hide signals' : 'View signals'}
                    </button>
                  </td>
                </tr>
                {expandedTerritory === p.territory_id && (
                  <tr key={`${p.territory_id}-psychographics`} className="bg-slate-50/80 dark:bg-slate-950/50">
                    <td colSpan={10} className="px-4 py-4">
                      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                        <div className="font-semibold text-slate-900 dark:text-slate-100">Psychographic evidence profile · {p.name_en}</div>
                        <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                          Model {p.psychographics.model_version} · inputs {p.psychographics.data_fields_available}/{p.psychographics.data_fields_expected} · inválidos {p.psychographics.invalid_fields.length} · temporal coverage {p.psychographics.temporal_coverage_pct}% · {p.psychographics.temporal_status} · survey evidence {p.psychographics.survey_evidence_count}
                        </div>
                      </div>
                      <p className="mb-3 text-[11px] leading-4 text-slate-600 dark:text-slate-400">
                        Evidências de pesquisa abaixo são medidas ponderadas por pergunta e onda, não perfis de indivíduos nem personas. Os sinais macroeconômicos continuam identificados separadamente como proxies contextuais.
                      </p>
                      {p.psychographics.measured_survey_measures.length > 0 ? (
                        <section className="mb-4 rounded-lg border border-sky-200 dark:border-sky-900 bg-sky-50/60 dark:bg-sky-950/20 p-3">
                          <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">Medidas observadas em pesquisas</h3>
                            <span className="text-[11px] text-slate-500 dark:text-slate-400">{p.psychographics.measured_survey_measures.length} medidas harmonizadas · não equivalem à prevalência de segmentos</span>
                          </div>
                          <div className="grid grid-cols-1 xl:grid-cols-2 gap-3">
                            {p.psychographics.measured_survey_measures.map((measure) => (
                              <article key={measure.measure_id} className="rounded-md border border-sky-100 dark:border-sky-900/70 bg-white dark:bg-slate-900 p-3">
                                <div className="flex flex-wrap items-start justify-between gap-2">
                                  <div>
                                    <div className="font-medium text-sm text-slate-900 dark:text-slate-100">{measure.construct_label}</div>
                                    <div className="mt-0.5 text-[10px] text-slate-500 dark:text-slate-400">{measure.construct_domain.replaceAll('_', ' ')} · {measure.survey_id} / {measure.wave_id} · {measure.period_year}</div>
                                  </div>
                                  <div className="text-right">
                                    <div className="font-mono text-lg font-semibold tabular-nums text-slate-900 dark:text-slate-100">{measure.score_0_100.toFixed(1)}<span className="text-xs font-normal text-slate-500">/100</span></div>
                                    <div className="text-[10px] text-slate-500">média {measure.weighted_mean.toFixed(2)} · escala {measure.canonical_scale_min}–{measure.canonical_scale_max}</div>
                                  </div>
                                </div>
                                <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1 text-[10px] text-slate-600 dark:text-slate-400">
                                  <span>n={measure.sample_size.toLocaleString('en-US')}</span>
                                  <span>n efetivo={measure.effective_sample_size.toFixed(1)}</span>
                                  <span>mínimo={measure.minimum_effective_sample_size}</span>
                                  <span>IC 95%={measure.confidence_interval_95_score ? `${measure.confidence_interval_95_score.lower.toFixed(1)}–${measure.confidence_interval_95_score.upper.toFixed(1)}` : 'indisponível'}</span>
                                  <span>{measure.variance_status.replaceAll('_', ' ')}</span>
                                </div>
                                {measure.response_distribution.length > 0 && (
                                  <div className="mt-3">
                                    <div className="mb-1 text-[10px] font-medium text-slate-600 dark:text-slate-400">Distribuição ponderada das respostas</div>
                                    <div className="flex h-2 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800" aria-label="Distribuição ponderada das respostas">
                                      {measure.response_distribution.map((category, index) => {
                                        const segmentColors = ['bg-sky-600', 'bg-indigo-600', 'bg-violet-600', 'bg-cyan-600', 'bg-emerald-600', 'bg-amber-500'];
                                        return <div key={category.response_value} title={`${category.response_value}: ${category.weighted_share_pct.toFixed(1)}%`} className={`h-full ${segmentColors[index % segmentColors.length]}`} style={{ width: `${Math.max(0, Math.min(100, category.weighted_share_pct))}%` }} />;
                                      })}
                                    </div>
                                    <div className="mt-1 flex flex-wrap gap-x-2 gap-y-1 text-[10px] text-slate-500 dark:text-slate-400">
                                      {measure.response_distribution.map((category) => (
                                        <span key={category.response_value}>{category.response_value}: {category.weighted_share_pct.toFixed(1)}%{category.confidence_interval_95 ? ` (IC ${category.confidence_interval_95.lower.toFixed(1)}–${category.confidence_interval_95.upper.toFixed(1)})` : ''}</span>
                                      ))}
                                    </div>
                                  </div>
                                )}
                                <div className="mt-2 flex flex-wrap gap-1">
                                  {measure.quality_flags.length === 0 ? <span className="text-[10px] text-emerald-700 dark:text-emerald-400">Sem alertas nos critérios exibidos</span> : measure.quality_flags.map((flag) => (
                                    <span key={flag} className="rounded bg-amber-100 dark:bg-amber-950/50 px-1.5 py-0.5 text-[10px] text-amber-800 dark:text-amber-300">{flag.replaceAll('_', ' ')}</span>
                                  ))}
                                  <span className="text-[10px] text-slate-500">licença: {measure.commercial_use_allowed}</span>
                                </div>
                                <div className="mt-1 text-[10px] text-slate-500 dark:text-slate-500">População: {measure.population_scope} · ponderação: {measure.weighting_method} · fonte: {measure.source_id}/{measure.dataset_id} · mapeamento {measure.mapping_version}</div>
                              </article>
                            ))}
                          </div>
                        </section>
                      ) : (
                        <div className="mb-4 rounded-lg border border-dashed border-slate-300 dark:border-slate-700 p-3 text-xs text-slate-600 dark:text-slate-400">
                          Nenhuma medida de pesquisa harmonizada disponível para este território. Os sinais abaixo são apenas proxies macroeconômicos; o sistema não cria preferências psicográficas na ausência de respostas observadas.
                        </div>
                      )}
                      <div className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">Contexto macro — proxies, não psicografia medida</div>
                      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
                        {p.psychographics.signals.map((signal) => (
                          <div key={signal.signal_id} className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3">
                            <div className="flex items-center justify-between gap-2">
                              <div className="font-medium text-slate-900 dark:text-slate-100">{signal.label}</div>
                              <div className="font-mono font-semibold tabular-nums text-slate-900 dark:text-slate-100">
                                {signal.score === null ? '—' : signal.score.toFixed(0)}
                              </div>
                            </div>
                            <div className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">{signal.level.replace('_', ' ')} · {signal.temporal_status} · evidência {signal.evidence_fields_available}/{signal.evidence_fields_expected} ({signal.data_coverage_pct}%)</div>
                            <p className="mt-2 text-xs leading-5 text-slate-700 dark:text-slate-300">{signal.research_hypothesis}</p>
                            <p className="mt-2 text-[11px] leading-4 text-slate-500 dark:text-slate-400">Validar: {signal.validation_action}</p>
                            <div className="mt-2 text-[10px] text-slate-500 dark:text-slate-500">
                              Evidências: {signal.evidence.length > 0 ? signal.evidence.map((item) => `${item.metric}=${item.value} ${item.unit}${item.period_year === null ? ' (ano desconhecido)' : ` (${item.period_year})`}`).join(' · ') : 'sem dados'}
                            </div>
                          </div>
                        ))}
                      </div>
                      <p className="mt-3 text-[11px] leading-5 text-amber-700 dark:text-amber-400">
                        Não são traços psicológicos medidos nem estimativas de participação populacional. Não inferir personalidade, crenças, valores individuais ou atributos sensíveis. Validação por pesquisa representativa ainda necessária.
                      </p>
                    </td>
                  </tr>
                )}
                </Fragment>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
