import type { MacroEconomicRow } from './types.ts';

export type GoldMetricKey = Exclude<
  keyof MacroEconomicRow,
  | 'territory_id'
  | 'iso3'
  | 'iso2'
  | 'name_en'
  | 'continent'
  | 'region'
  | 'h3_res2'
  | 'h3_res4'
  | 'latest_year'
>;

export interface GoldIndicatorColumnSpec {
  field: GoldMetricKey;
  indicatorIds: readonly string[];
  label: string;
}

export const GOLD_INDICATOR_COLUMNS: readonly GoldIndicatorColumnSpec[] = [
  { field: 'gdp_nominal_usd', indicatorIds: ['NY.GDP.MKTP.CD'], label: 'GDP Nominal USD' },
  { field: 'gdp_per_capita_ppp_2021', indicatorIds: ['NY.GDP.PCAP.PP.KD'], label: 'GDP/Capita PPP 2021' },
  { field: 'imf_real_gdp_growth_pct', indicatorIds: ['IMF.NGDP_RPCH'], label: 'IMF Real GDP Growth %' },
  { field: 'inflation_cpi_pct', indicatorIds: ['FP.CPI.TOTL.ZG', 'IMF.PCPIPCH'], label: 'CPI Inflation %' },
  { field: 'gov_debt_pct_gdp', indicatorIds: ['IMF.GGXWDG_NGDP'], label: 'Gov Gross Debt % GDP' },
  {
    field: 'unemployment_pct',
    indicatorIds: ['ILO.UNEMPLOYMENT_PCT', 'SL.UEM.TOTL.ZS', 'OECD.UNEMPLOYMENT_PCT'],
    label: 'Unemployment %',
  },
  { field: 'gini_index', indicatorIds: ['OWID.GINI'], label: 'Gini Index' },
  { field: 'population_total', indicatorIds: ['SP.POP.TOTL'], label: 'Population' },
  { field: 'urbanization_pct', indicatorIds: ['SP.URB.TOTL.IN.ZS', 'OWID.URBAN_PCT'], label: 'Urbanization %' },
  { field: 'internet_users_pct', indicatorIds: ['IT.NET.USER.ZS', 'OWID.INTERNET_PCT'], label: 'Internet Users %' },
  { field: 'life_expectancy_years', indicatorIds: ['WHO.LIFE_EXPECTANCY'], label: 'Life Expectancy' },
  { field: 'household_consumption_pct_gdp', indicatorIds: ['WB_SDMX.NE_CON_PRVT_ZS'], label: 'HH Cons % GDP' },
  { field: 'gni_per_capita_usd', indicatorIds: ['WB_SDMX.NY_GNP_PCAP_CD'], label: 'GNI/Cap USD' },
  { field: 'fdi_net_inflows_pct_gdp', indicatorIds: ['WB_SDMX.BX_KLT_DINV_WD_GD_ZS'], label: 'FDI % GDP' },
  { field: 'trade_openness_pct_gdp', indicatorIds: ['WB_SDMX.NE_TRD_GNFS_ZS'], label: 'Trade % GDP' },
  { field: 'ilostat_lfpr_pct', indicatorIds: ['ILO.LFPR_PCT'], label: 'ILO LFPR %' },
  {
    field: 'imf_policy_rate_pct',
    indicatorIds: ['IMF_SDMX.POLICY_RATE_PCT', 'IMF_SDMX.MONEY_MKT_RATE_PCT', 'IMF_SDMX.TBILL_YIELD_PCT'],
    label: 'IMF Policy Rate %',
  },
  { field: 'imf_reer_index', indicatorIds: ['IMF_SDMX.REER_IX'], label: 'IMF REER' },
  { field: 'oecd_cli_index', indicatorIds: ['OECD.CLI_IX'], label: 'OECD CLI' },
  { field: 'wits_exports_usd', indicatorIds: ['WITS.EXPORTS_USD'], label: 'WITS Exports' },
  { field: 'wits_imports_usd', indicatorIds: ['WITS.IMPORTS_USD'], label: 'WITS Imports' },
  { field: 'ember_clean_share_pct', indicatorIds: ['EMBER.CLEAN_SHARE_PCT'], label: 'Clean Elec %' },
  { field: 'ember_carbon_intensity', indicatorIds: ['EMBER.CARBON_INTENSITY_GCO2_KWH'], label: 'gCO2/kWh' },
  { field: 'uis_gerd_pct_gdp', indicatorIds: ['UIS.GERD_PCT_GDP'], label: 'R&D % GDP' },
  { field: 'unicef_u5_mortality', indicatorIds: ['UNICEF.UNDER5_MORTALITY_PER_1000'], label: 'U5 Mortality' },
  { field: 'unsdg_renewable_pct', indicatorIds: ['UNSDG.RENEWABLE_ENERGY_SHARE_PCT'], label: 'SDG Renew %' },
  { field: 'unsdg_forest_pct', indicatorIds: ['UNSDG.FOREST_AREA_PCT'], label: 'SDG Forest %' },
  { field: 'gbif_occurrences', indicatorIds: ['GBIF.SPECIES_OCCURRENCES'], label: 'GBIF Species' },
  { field: 'wikidata_area_km2', indicatorIds: ['WIKIDATA.AREA_KM2'], label: 'Area km²' },
  { field: 'abs_cpi_pct_yoy', indicatorIds: ['ABS.CPI_PCT_YOY'], label: 'ABS CPI YoY%' },
  { field: 'eurostat3_hicp_pct', indicatorIds: ['EUROSTAT3.HICP_INFLATION_PCT'], label: 'EU3 HICP%' },
  { field: 'statcan_unemp_pct', indicatorIds: ['STATCAN.UNEMPLOYMENT_PCT'], label: 'StatCan Unemp%' },
  { field: 'ukons_cpih_yoy_pct', indicatorIds: ['UKONS.CPIH_PCT_YOY'], label: 'UK CPIH%' },
  { field: 'unsd_elec_prod_gwh', indicatorIds: ['UNSD.ELEC_GROSS_PROD_GWH'], label: 'UNSD Elec GWh' },
  { field: 'nasa_solar_kwh', indicatorIds: ['NASA.SOLAR_IRRADIANCE_KWH'], label: 'Solar kWh/m²' },
  { field: 'obis_marine_species', indicatorIds: ['OBIS.MARINE_SPECIES'], label: 'OBIS Marine' },
  { field: 'geonames_pop', indicatorIds: ['GEONAMES.POPULATION'], label: 'GeoNames Pop' },
  { field: 'datacite_dataset_dois', indicatorIds: ['DATACITE.DATASET_DOIS'], label: 'DataCite DOIs' },
  { field: 'eurostat_gov_debt_pct', indicatorIds: ['EUROSTAT_STATS.GOV_DEBT_PCT_GDP'], label: 'EU Gov Debt%' },
  { field: 'unwpp_tfr', indicatorIds: ['UNWPP.TOTAL_FERTILITY_RATE'], label: 'UN WPP TFR' },
  { field: 'worldpop_datasets', indicatorIds: ['WORLDPOP.DATASET_COUNT'], label: 'WorldPop Grid' },
  { field: 'nasa_cmr_collections', indicatorIds: ['NASA_CMR.EO_COLLECTIONS'], label: 'NASA EO' },
  { field: 'ne_adm1_divisions', indicatorIds: ['NE.ADM1_DIVISIONS'], label: 'NE Admin-1' },
  { field: 'openalex_works_2024', indicatorIds: ['OPENALEX.WORKS_COUNT_2024'], label: 'OpenAlex 2024' },
  { field: 'ukgov_open_datasets', indicatorIds: ['UKGOV.OPEN_DATASETS_TOTAL'], label: 'UK Gov Data' },
  { field: 'overture_themes', indicatorIds: ['OVERTURE.THEME_COLLECTIONS'], label: 'Overture' },
  { field: 'faostat_kcal_day', indicatorIds: ['FAOSTAT.DIETARY_ENERGY_KCAL'], label: 'FAOSTAT kcal' },
  { field: 'uis_edu_exp_pct_gdp', indicatorIds: ['UIS_EDU.GOV_EXP_PCT_GDP'], label: 'Edu Exp%' },
  { field: 'worldpop_age_datasets', indicatorIds: ['WORLDPOP_AGE.DATASETS_2020'], label: 'WPop Age' },
  { field: 'worldpop_density_datasets', indicatorIds: ['WORLDPOP_DENS.DATASETS_1KM'], label: 'WPop Dens' },
  { field: 'eurostat_catalog_datasets', indicatorIds: ['EUROSTAT_CAT.DATASETS_COUNT'], label: 'EU Catalog' },
  { field: 'arcgis_open_datasets', indicatorIds: ['ARCGIS.OPEN_DATASETS_TOTAL'], label: 'ArcGIS' },
  { field: 'stac_public_catalogs', indicatorIds: ['STAC_INDEX.PUBLIC_CATALOGS'], label: 'STAC Index' },
  { field: 'listenbrainz_top100_listens', indicatorIds: ['LISTENBRAINZ.SITEWIDE_TOP100_LISTENS'], label: 'ListenBrainz' },
  { field: 'ecb_fx_per_eur', indicatorIds: ['ECB.FX_PER_EUR'], label: 'ECB FX/EUR' },
  { field: 'vdem_democracy_ix', indicatorIds: ['VDEM.ELECTORAL_DEMOCRACY_IX'], label: 'V-Dem Polyarchy' },
  { field: 'unlocode_nodes', indicatorIds: ['UNLOCODE.LOGISTICS_NODES'], label: 'UN/LOCODE' },
  { field: 'unhabitat_urban_datasets', indicatorIds: ['UNHABITAT.URBAN_DATASETS'], label: 'UN-Habitat' },
  { field: 'ckan_portal_datasets', indicatorIds: ['CKAN_FED.PORTAL_DATASETS'], label: 'CKAN Open' },
  { field: 'socrata_civic_datasets', indicatorIds: ['SOCRATA.CATALOG_DATASETS'], label: 'Socrata Civic' },
  { field: 'osm_importance_score', indicatorIds: ['OSM.NOMINATIM_IMPORTANCE'], label: 'OSM Score' },
  { field: 'musicbrainz_artists', indicatorIds: ['MUSICBRAINZ.ARTISTS_COUNT'], label: 'MusicBrainz' },
  { field: 'uncomtrade_exports_usd', indicatorIds: ['UNCOMTRADE.EXPORTS_USD'], label: 'Comtrade Exp$' },
  { field: 'itu_mobile_per_100', indicatorIds: ['ITU.MOBILE_SUBS_PER_100'], label: 'ITU Mobile/100' },
  { field: 'gadm_adm1_features', indicatorIds: ['GADM.ADM1_FEATURES'], label: 'GADM Adm1' },
  { field: 'wipo_patents_per_million', indicatorIds: ['WIPO.PATENT_APPS_PER_MILLION'], label: 'WIPO Patents/M' },
  { field: 'unodc_homicide_rate', indicatorIds: ['UNODC.HOMICIDE_RATE_PER_100K'], label: 'UNODC Homic/100k' },
  { field: 'wid_top10_share_pct', indicatorIds: ['WID.TOP10_INCOME_SHARE_PCT'], label: 'WID Top10%' },
  { field: 'ghsl_pop_density_km2', indicatorIds: ['GHSL.POP_DENSITY_KM2'], label: 'GHSL Dens/km²' },
  { field: 'pwt_real_gdp_cap', indicatorIds: ['PWT.REAL_GDP_PER_CAPITA'], label: 'PWT Real GDP/Cap' },
  { field: 'eurostat_gdp_meur', indicatorIds: ['EUROSTAT.GDP_CP_MEUR'], label: 'Eurostat GDP M€' },
  { field: 'bis_total_credit_pct_gdp', indicatorIds: ['BIS.TOTAL_CREDIT_PCT_GDP'], label: 'BIS Credit % GDP' },
  { field: 'ibge_ipca_pct', indicatorIds: ['IBGE.IPCA_12M_PCT'], label: 'IBGE IPCA %' },
  { field: 'unhcr_refugees', indicatorIds: ['UNHCR.REFUGEES'], label: 'UNHCR Refugees' },
  { field: 'usgs_seismic_events', indicatorIds: ['USGS.SEISMIC_EVENTS_M55'], label: 'USGS M5.5+ Events' },
  { field: 'gb_adm0_coverage', indicatorIds: ['GB.ADM0.COVERAGE'], label: 'geoBoundaries ADM0' },
  { field: 'crossref_works_count', indicatorIds: ['CROSSREF.GLOBAL_WORKS_COUNT'], label: 'Crossref DOIs' },
  { field: 'unctad_lsci', indicatorIds: ['UNCTAD.LSCI_INDEX'], label: 'UNCTAD LSCI' },
  { field: 'statfin_cpi_pct', indicatorIds: ['STATFIN.CPI_PCT_YOY'], label: 'StatFin CPI YoY%' },
  { field: 'undata_elec_access_pct', indicatorIds: ['UNDATA.ELEC_ACCESS_PCT'], label: 'UNdata Elec %' },
  { field: 'undrr_mortality_per_100k', indicatorIds: ['UNDRR.DISASTER_MORT_PER_100K'], label: 'UNDRR Mort/100k' },
  { field: 'usgov_datasets_total', indicatorIds: ['USGOV.DATAGOV_CATALOG_TOTAL'], label: 'US Data.gov Sets' },
  { field: 'pip_mean_daily_ppp', indicatorIds: ['PIP.MEAN_DAILY_PPP'], label: 'PIP $/Day PPP' },
  { field: 'ct_ghg_co2e', indicatorIds: ['CT.GHG.CO2E_100YR'], label: 'Climate TRACE CO2e' },
  { field: 'wikimedia_enwiki_views', indicatorIds: ['WIKIMEDIA.ENWIKI_MONTHLY_VIEWS'], label: 'Wikimedia Views' },
  { field: 'us_census_pop', indicatorIds: ['USCENSUS.US_POP_ESTIMATE'], label: 'US Census Pop' },
  { field: 'undp_hdi', indicatorIds: ['UNDP.HDI'], label: 'UNDP HDI' },
  { field: 'noaa_tavg_c', indicatorIds: ['NOAA.STATION_TAVG_C'], label: 'NOAA Temp °C' },
  { field: 'gfw_tree_loss_ha', indicatorIds: ['GFW.TREE_COVER_LOSS_HA'], label: 'GFW Tree Loss ha' },
  { field: 'eia_energy_prod_qbtu', indicatorIds: ['EIA.US_PRIMARY_ENERGY_PROD_QBTU'], label: 'US EIA QBtu' },
  { field: 'india_iip_index', indicatorIds: ['INDIA.IIP_INDEX'], label: 'India IIP' },
  { field: 'icao_scheduled_airports', indicatorIds: ['ICAO.SCHEDULED_AIRPORTS'], label: 'ICAO Airports' },
  { field: 'wdpa_protected_pct', indicatorIds: ['WDPA.TERRESTRIAL_PROTECTED_PCT'], label: 'WDPA Prot %' },
];

export type GoldMetricsMap = Pick<MacroEconomicRow, GoldMetricKey>;

function sqlLiteral(val: string): string {
  return `'${val.replace(/'/g, "''")}'`;
}

const GOLD_TEMPORAL_METRICS = [
  'gdp_nominal_usd',
  'gdp_per_capita_ppp_2021',
  'population_total',
  'urbanization_pct',
  'internet_users_pct',
  'inflation_cpi_pct',
  'unemployment_pct',
  'gini_index',
  'life_expectancy_years',
  'unwpp_tfr',
  'itu_mobile_per_100',
  'undp_hdi',
] as const;

export type GoldTemporalMetricKey = (typeof GOLD_TEMPORAL_METRICS)[number];
export type GoldMetricYearsMap = Record<`${GoldTemporalMetricKey}_year`, number | null>;

function indicatorPriorityCase(col: GoldIndicatorColumnSpec): string {
  const cases = col.indicatorIds
    .map((id, index) => `WHEN ${sqlLiteral(id)} THEN ${index + 1}`)
    .join(' ');
  return `CASE indicator_id ${cases} ELSE ${col.indicatorIds.length + 1} END`;
}

function latestValueExpression(col: GoldIndicatorColumnSpec): string {
  const ids = col.indicatorIds.map(sqlLiteral).join(', ');
  return `FIRST(value_numeric ORDER BY period_year DESC NULLS LAST, asserted_at DESC NULLS LAST, ${indicatorPriorityCase(col)} ASC) FILTER (WHERE indicator_id IN (${ids})) AS ${col.field}`;
}

function yearExpression(col: GoldIndicatorColumnSpec): string {
  const ids = col.indicatorIds.map(sqlLiteral).join(', ');
  return `FIRST(period_year ORDER BY period_year DESC NULLS LAST, asserted_at DESC NULLS LAST, ${indicatorPriorityCase(col)} ASC) FILTER (WHERE indicator_id IN (${ids})) AS ${col.field}_year`;
}

export function buildGoldPivotSelectSql(): string {
  const expressions = GOLD_INDICATOR_COLUMNS.map(latestValueExpression);
  const temporalExpressions = GOLD_TEMPORAL_METRICS.map((field) => {
    const spec = GOLD_INDICATOR_COLUMNS.find((col) => col.field === field);
    if (!spec) throw new Error(`Missing GOLD indicator specification for temporal metric: ${field}`);
    return yearExpression(spec);
  });
  return [...expressions, ...temporalExpressions].join(',\n        ');
}

export function mapEmptyGoldMetrics(): GoldMetricsMap {
  const out = {} as Record<GoldMetricKey, number | null>;
  for (const col of GOLD_INDICATOR_COLUMNS) {
    out[col.field] = null;
  }
  return out;
}

function toFiniteNumberOrNull(val: unknown): number | null {
  if (typeof val === 'number' && Number.isFinite(val)) return val;
  if (typeof val === 'string' && val.trim() !== '') {
    const parsed = Number(val);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}

export function mapEmptyGoldMetricYears(): GoldMetricYearsMap {
  return {
    gdp_nominal_usd_year: null,
    gdp_per_capita_ppp_2021_year: null,
    population_total_year: null,
    urbanization_pct_year: null,
    internet_users_pct_year: null,
    inflation_cpi_pct_year: null,
    unemployment_pct_year: null,
    gini_index_year: null,
    life_expectancy_years_year: null,
    unwpp_tfr_year: null,
    itu_mobile_per_100_year: null,
    undp_hdi_year: null,
  };
}

export function mapDuckRowToGoldMetricYears(row: Record<string, unknown> | undefined): GoldMetricYearsMap {
  return {
    gdp_nominal_usd_year: toFiniteNumberOrNull(row?.gdp_nominal_usd_year),
    gdp_per_capita_ppp_2021_year: toFiniteNumberOrNull(row?.gdp_per_capita_ppp_2021_year),
    population_total_year: toFiniteNumberOrNull(row?.population_total_year),
    urbanization_pct_year: toFiniteNumberOrNull(row?.urbanization_pct_year),
    internet_users_pct_year: toFiniteNumberOrNull(row?.internet_users_pct_year),
    inflation_cpi_pct_year: toFiniteNumberOrNull(row?.inflation_cpi_pct_year),
    unemployment_pct_year: toFiniteNumberOrNull(row?.unemployment_pct_year),
    gini_index_year: toFiniteNumberOrNull(row?.gini_index_year),
    life_expectancy_years_year: toFiniteNumberOrNull(row?.life_expectancy_years_year),
    unwpp_tfr_year: toFiniteNumberOrNull(row?.unwpp_tfr_year),
    itu_mobile_per_100_year: toFiniteNumberOrNull(row?.itu_mobile_per_100_year),
    undp_hdi_year: toFiniteNumberOrNull(row?.undp_hdi_year),
  };
}

export function mapDuckRowToGoldMetrics(row: Record<string, unknown> | undefined): GoldMetricsMap {
  const out = {} as Record<GoldMetricKey, number | null>;
  for (const col of GOLD_INDICATOR_COLUMNS) {
    out[col.field] = toFiniteNumberOrNull(row?.[col.field]);
  }
  return out;
}
