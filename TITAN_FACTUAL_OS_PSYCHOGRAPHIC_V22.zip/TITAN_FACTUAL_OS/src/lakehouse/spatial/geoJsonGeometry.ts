export type Position2D = readonly [number, number];
export interface GeoJsonPolygon { type: 'Polygon'; coordinates: readonly (readonly Position2D[])[] }
export interface GeoJsonMultiPolygon { type: 'MultiPolygon'; coordinates: readonly (readonly (readonly Position2D[])[])[] }
export type GeoJsonAreaGeometry = GeoJsonPolygon | GeoJsonMultiPolygon;

function isPosition(value: unknown): value is Position2D {
  return Array.isArray(value)
    && value.length >= 2
    && typeof value[0] === 'number'
    && Number.isFinite(value[0])
    && value[0] >= -180 && value[0] <= 180
    && typeof value[1] === 'number'
    && Number.isFinite(value[1])
    && value[1] >= -90 && value[1] <= 90;
}

function samePosition(a: Position2D, b: Position2D): boolean {
  return a[0] === b[0] && a[1] === b[1];
}

function validateRing(ring: unknown, label: string): asserts ring is readonly Position2D[] {
  if (!Array.isArray(ring) || ring.length < 4 || !ring.every(isPosition)) {
    throw new Error(`${label} must contain at least four valid longitude/latitude positions.`);
  }
  if (!samePosition(ring[0]!, ring[ring.length - 1]!)) {
    throw new Error(`${label} must be closed (first and last positions must match).`);
  }
  const distinctVertices = new Set(ring.slice(0, -1).map((position) => `${position[0]},${position[1]}`));
  if (distinctVertices.size < 3) throw new Error(`${label} must contain at least three distinct vertices.`);
  let twiceSignedArea = 0;
  for (let i = 0; i < ring.length - 1; i++) {
    const current = ring[i]!;
    const next = ring[i + 1]!;
    twiceSignedArea += current[0] * next[1] - next[0] * current[1];
  }
  if (!Number.isFinite(twiceSignedArea) || twiceSignedArea === 0) throw new Error(`${label} must enclose a non-zero area.`);
  for (let i = 1; i < ring.length; i++) {
    if (Math.abs(ring[i]![0] - ring[i - 1]![0]) > 180) {
      throw new Error(`${label} crosses the antimeridian; split/normalize it before using this lightweight predicate.`);
    }
  }
}

/**
 * Lightweight structural checks for the point-in-area helper, not full OGC topology
 * validation. It does not test ring self-intersection, hole containment/overlap,
 * polygon overlap or validity of a multipolygon's topology. Supply geometries that
 * have already passed an authoritative GEOS/OGC validator before analytical use.
 */
export function validateAreaGeometry(value: unknown): GeoJsonAreaGeometry {
  if (!value || typeof value !== 'object') throw new Error('Geometry must be an object.');
  const candidate = value as { type?: unknown; coordinates?: unknown };
  const polygons: unknown[] = candidate.type === 'Polygon'
    ? [candidate.coordinates]
    : candidate.type === 'MultiPolygon' && Array.isArray(candidate.coordinates)
      ? candidate.coordinates
      : [];
  if (polygons.length === 0) throw new Error('Only GeoJSON Polygon and MultiPolygon geometries are supported.');
  for (let p = 0; p < polygons.length; p++) {
    const rings = polygons[p];
    if (!Array.isArray(rings) || rings.length === 0) throw new Error(`Polygon ${p} has no rings.`);
    for (let r = 0; r < rings.length; r++) validateRing(rings[r], `Polygon ${p} ring ${r}`);
  }
  return value as GeoJsonAreaGeometry;
}

function pointOnSegment(point: Position2D, start: Position2D, end: Position2D): boolean {
  const lengthSquared = (end[0] - start[0]) ** 2 + (end[1] - start[1]) ** 2;
  if (lengthSquared <= 1e-20) return false;
  const cross = (point[1] - start[1]) * (end[0] - start[0]) - (point[0] - start[0]) * (end[1] - start[1]);
  if (Math.abs(cross) > 1e-10) return false;
  const dot = (point[0] - start[0]) * (end[0] - start[0]) + (point[1] - start[1]) * (end[1] - start[1]);
  if (dot < -1e-10) return false;
  return dot <= lengthSquared + 1e-10;
}

function pointInRing(point: Position2D, ring: readonly Position2D[]): boolean {
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const a = ring[j]!;
    const b = ring[i]!;
    if (pointOnSegment(point, a, b)) return true;
    const intersects = ((b[1] > point[1]) !== (a[1] > point[1]))
      && (point[0] < ((a[0] - b[0]) * (point[1] - b[1])) / (a[1] - b[1]) + b[0]);
    if (intersects) inside = !inside;
  }
  return inside;
}

function pointInPolygonRings(point: Position2D, rings: readonly (readonly Position2D[])[]): boolean {
  if (!pointInRing(point, rings[0]!)) return false;
  // A point on a hole boundary is considered outside the polygon, per boundary semantics.
  for (const hole of rings.slice(1)) {
    if (pointInRing(point, hole)) return false;
  }
  return true;
}

/** Point-in-area predicate only. This does not calculate overlays, area, or population allocation. */
export function pointInGeoJsonArea(point: Position2D, geometryInput: unknown): boolean {
  if (!isPosition(point)) throw new Error('Point must be a valid longitude/latitude position.');
  const geometry = validateAreaGeometry(geometryInput);
  if (geometry.type === 'Polygon') return pointInPolygonRings(point, geometry.coordinates);
  return geometry.coordinates.some((polygon) => pointInPolygonRings(point, polygon));
}
