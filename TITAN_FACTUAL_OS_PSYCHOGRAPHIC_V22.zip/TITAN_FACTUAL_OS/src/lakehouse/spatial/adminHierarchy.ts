import type Database from 'better-sqlite3';
import { getControlPlaneDb } from '../controlPlane.ts';
import { computePointH3Cells } from '../duckdbEngine.ts';
import type { AdminLevel, SpatialAdminNode, TerritoryCanonical } from '../types.ts';

export const ADMIN_LEVEL_ORDER: AdminLevel[] = [
  'global',
  'continent',
  'country',
  'state',
  'city',
  'neighborhood',
];

export const ADMIN_LEVEL_LABELS: Record<AdminLevel, { en: string; pt: string; adm: string; h3Res: number }> = {
  global: { en: 'Global', pt: 'Global', adm: 'ROOT', h3Res: 0 },
  continent: { en: 'Continent', pt: 'Continente', adm: 'CONT', h3Res: 1 },
  country: { en: 'Country', pt: 'País', adm: 'ADM0', h3Res: 2 },
  state: { en: 'State / Province', pt: 'Estado', adm: 'ADM1', h3Res: 4 },
  city: { en: 'City / Municipality', pt: 'Cidade', adm: 'ADM2', h3Res: 6 },
  neighborhood: { en: 'Neighborhood / District', pt: 'Bairro', adm: 'ADM3/4', h3Res: 8 },
};

export const H3_RESOLUTION_BY_LEVEL: Record<AdminLevel, number> = {
  global: 0,
  continent: 1,
  country: 2,
  state: 4,
  city: 6,
  neighborhood: 8,
};

export const CONTINENT_META: Record<
  string,
  {
    node_id: string;
    code: string;
    name_pt: string;
    lat: number;
    lon: number;
    wikidata: string;
    geoname_id: number;
  }
> = {
  Africa: {
    node_id: 'CONT_AFRICA',
    code: 'AF',
    name_pt: 'África',
    lat: 1.65,
    lon: 17.68,
    wikidata: 'Q15',
    geoname_id: 6255146,
  },
  Asia: {
    node_id: 'CONT_ASIA',
    code: 'AS',
    name_pt: 'Ásia',
    lat: 34.05,
    lon: 100.62,
    wikidata: 'Q48',
    geoname_id: 6255147,
  },
  Europe: {
    node_id: 'CONT_EUROPE',
    code: 'EU',
    name_pt: 'Europa',
    lat: 54.53,
    lon: 15.26,
    wikidata: 'Q46',
    geoname_id: 6255148,
  },
  'North America': {
    node_id: 'CONT_NORTH_AMERICA',
    code: 'NA',
    name_pt: 'América do Norte',
    lat: 46.07,
    lon: -100.55,
    wikidata: 'Q49',
    geoname_id: 6255149,
  },
  Oceania: {
    node_id: 'CONT_OCEANIA',
    code: 'OC',
    name_pt: 'Oceania',
    lat: -22.74,
    lon: 140.02,
    wikidata: 'Q55643',
    geoname_id: 6255151,
  },
  'South America': {
    node_id: 'CONT_SOUTH_AMERICA',
    code: 'SA',
    name_pt: 'América do Sul',
    lat: -14.24,
    lon: -59.93,
    wikidata: 'Q18',
    geoname_id: 6255150,
  },
};

export function getContinentNodeId(continent: string): string {
  const meta = CONTINENT_META[continent];
  if (meta) return meta.node_id;
  return `CONT_${continent.toUpperCase().replace(/[^A-Z0-9]+/g, '_')}`;
}

export function initAndSeedAdminHierarchy(db: Database.Database): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS dim_admin_nodes (
      node_id TEXT PRIMARY KEY,
      parent_id TEXT,
      level TEXT NOT NULL,
      code TEXT NOT NULL,
      iso3 TEXT,
      territory_id TEXT,
      name_en TEXT NOT NULL,
      name_local TEXT,
      centroid_lat REAL,
      centroid_lon REAL,
      h3_index TEXT,
      h3_resolution INTEGER NOT NULL,
      wikidata_qid TEXT,
      geoname_id INTEGER,
      population_est REAL,
      area_km2 REAL,
      FOREIGN KEY (parent_id) REFERENCES dim_admin_nodes(node_id)
    );

    CREATE INDEX IF NOT EXISTS idx_admin_nodes_parent
      ON dim_admin_nodes(parent_id, level);

    CREATE INDEX IF NOT EXISTS idx_admin_nodes_level
      ON dim_admin_nodes(level, iso3);
  `);

  const upsertNode = db.prepare(`
    INSERT INTO dim_admin_nodes (
      node_id, parent_id, level, code, iso3, territory_id, name_en, name_local,
      centroid_lat, centroid_lon, h3_index, h3_resolution, wikidata_qid, geoname_id,
      population_est, area_km2
    ) VALUES (
      @node_id, @parent_id, @level, @code, @iso3, @territory_id, @name_en, @name_local,
      @centroid_lat, @centroid_lon, @h3_index, @h3_resolution, @wikidata_qid, @geoname_id,
      @population_est, @area_km2
    )
    ON CONFLICT(node_id) DO UPDATE SET
      parent_id = excluded.parent_id,
      level = excluded.level,
      code = excluded.code,
      iso3 = excluded.iso3,
      territory_id = excluded.territory_id,
      name_en = excluded.name_en,
      name_local = excluded.name_local,
      centroid_lat = excluded.centroid_lat,
      centroid_lon = excluded.centroid_lon,
      h3_index = COALESCE(excluded.h3_index, dim_admin_nodes.h3_index),
      h3_resolution = excluded.h3_resolution,
      wikidata_qid = COALESCE(excluded.wikidata_qid, dim_admin_nodes.wikidata_qid),
      geoname_id = COALESCE(excluded.geoname_id, dim_admin_nodes.geoname_id)
  `);

  const territories = db
    .prepare('SELECT * FROM dim_territories ORDER BY name_en ASC')
    .all() as TerritoryCanonical[];

  const tx = db.transaction(() => {
    upsertNode.run({
      node_id: 'GLOBAL',
      parent_id: null,
      level: 'global',
      code: 'WORLD',
      iso3: null,
      territory_id: null,
      name_en: 'Global Earth',
      name_local: 'Global',
      centroid_lat: 0,
      centroid_lon: 0,
      h3_index: null,
      h3_resolution: H3_RESOLUTION_BY_LEVEL.global,
      wikidata_qid: 'Q2',
      geoname_id: 6295630,
      population_est: null,
      area_km2: 510072000,
    });

    for (const [continentName, meta] of Object.entries(CONTINENT_META)) {
      upsertNode.run({
        node_id: meta.node_id,
        parent_id: 'GLOBAL',
        level: 'continent',
        code: meta.code,
        iso3: null,
        territory_id: null,
        name_en: continentName,
        name_local: meta.name_pt,
        centroid_lat: meta.lat,
        centroid_lon: meta.lon,
        h3_index: null,
        h3_resolution: H3_RESOLUTION_BY_LEVEL.continent,
        wikidata_qid: meta.wikidata,
        geoname_id: meta.geoname_id,
        population_est: null,
        area_km2: null,
      });
    }

    for (const t of territories) {
      upsertNode.run({
        node_id: `CNTRY_${t.iso3}`,
        parent_id: getContinentNodeId(t.continent),
        level: 'country',
        code: t.iso3,
        iso3: t.iso3,
        territory_id: t.territory_id,
        name_en: t.name_en,
        name_local: t.name_pt,
        centroid_lat: t.centroid_lat,
        centroid_lon: t.centroid_lon,
        h3_index: t.h3_res2 ?? null,
        h3_resolution: H3_RESOLUTION_BY_LEVEL.country,
        wikidata_qid: t.wikidata_qid,
        geoname_id: null,
        population_est: null,
        area_km2: null,
      });
    }
  });
  tx();
}

export async function syncContinentHierarchyH3Cells(): Promise<void> {
  const db = getControlPlaneDb();
  const rows = db
    .prepare(
      `SELECT node_id, centroid_lat, centroid_lon
       FROM dim_admin_nodes
       WHERE level IN ('global', 'continent')
         AND h3_index IS NULL
         AND centroid_lat IS NOT NULL
         AND centroid_lon IS NOT NULL`
    )
    .all() as Array<{ node_id: string; centroid_lat: number; centroid_lon: number }>;

  if (rows.length === 0) return;

  const h3Map = await computePointH3Cells(
    rows.map((r) => ({
      node_id: r.node_id,
      lat: r.centroid_lat,
      lon: r.centroid_lon,
      res: r.node_id === 'GLOBAL' ? 0 : H3_RESOLUTION_BY_LEVEL.continent,
    }))
  );

  if (h3Map.size === 0) return;
  const stmt = db.prepare(`UPDATE dim_admin_nodes SET h3_index = ? WHERE node_id = ?`);
  const tx = db.transaction(() => {
    for (const [nodeId, h3Index] of h3Map.entries()) {
      stmt.run(h3Index, nodeId);
    }
  });
  tx();
}

export function syncHierarchyH3Cells(
  updates: Array<{ territory_id: string; h3_res2: string }>
): void {
  const db = getControlPlaneDb();
  const stmt = db.prepare(`
    UPDATE dim_admin_nodes
    SET h3_index = ?
    WHERE territory_id = ? AND level = 'country'
  `);
  const tx = db.transaction(() => {
    for (const u of updates) {
      stmt.run(u.h3_res2, u.territory_id);
    }
  });
  tx();
}

export function updateCountryAdminMetrics(
  updates: Array<{
    iso3: string;
    population_est?: number | null;
    area_km2?: number | null;
    geoname_id?: number | null;
  }>
): void {
  if (updates.length === 0) return;
  const db = getControlPlaneDb();
  const stmt = db.prepare(`
    UPDATE dim_admin_nodes
    SET population_est = COALESCE(?, population_est),
        area_km2 = COALESCE(?, area_km2),
        geoname_id = COALESCE(?, geoname_id)
    WHERE node_id = ? AND level = 'country'
  `);
  const tx = db.transaction(() => {
    for (const u of updates) {
      stmt.run(
        u.population_est ?? null,
        u.area_km2 ?? null,
        u.geoname_id ?? null,
        `CNTRY_${u.iso3.toUpperCase()}`
      );
    }
  });
  tx();
}

export async function upsertSubnationalAdminNodes(
  nodes: Array<{
    node_id: string;
    parent_id: string;
    level: 'state' | 'city';
    code: string;
    iso3: string;
    territory_id: string;
    name_en: string;
    name_local?: string | null;
    centroid_lat: number | null;
    centroid_lon: number | null;
    population_est?: number | null;
  }>
): Promise<number> {
  if (nodes.length === 0) return 0;

  const h3Map = await computePointH3Cells(
    nodes
      .filter(
        (n) =>
          typeof n.centroid_lat === 'number' &&
          Number.isFinite(n.centroid_lat) &&
          typeof n.centroid_lon === 'number' &&
          Number.isFinite(n.centroid_lon)
      )
      .map((n) => ({
        node_id: n.node_id,
        lat: n.centroid_lat as number,
        lon: n.centroid_lon as number,
        res: H3_RESOLUTION_BY_LEVEL[n.level],
      }))
  );

  const db = getControlPlaneDb();
  const stmt = db.prepare(`
    INSERT INTO dim_admin_nodes (
      node_id, parent_id, level, code, iso3, territory_id, name_en, name_local,
      centroid_lat, centroid_lon, h3_index, h3_resolution, wikidata_qid, geoname_id,
      population_est, area_km2
    ) VALUES (
      @node_id, @parent_id, @level, @code, @iso3, @territory_id, @name_en, @name_local,
      @centroid_lat, @centroid_lon, @h3_index, @h3_resolution, NULL, NULL,
      @population_est, NULL
    )
    ON CONFLICT(node_id) DO UPDATE SET
      parent_id = excluded.parent_id,
      level = excluded.level,
      code = excluded.code,
      iso3 = excluded.iso3,
      territory_id = excluded.territory_id,
      name_en = excluded.name_en,
      name_local = COALESCE(excluded.name_local, dim_admin_nodes.name_local),
      centroid_lat = COALESCE(excluded.centroid_lat, dim_admin_nodes.centroid_lat),
      centroid_lon = COALESCE(excluded.centroid_lon, dim_admin_nodes.centroid_lon),
      h3_index = COALESCE(excluded.h3_index, dim_admin_nodes.h3_index),
      h3_resolution = excluded.h3_resolution,
      population_est = COALESCE(excluded.population_est, dim_admin_nodes.population_est)
  `);

  let count = 0;
  const tx = db.transaction(() => {
    for (const n of nodes) {
      const h3Res = H3_RESOLUTION_BY_LEVEL[n.level];
      const h3Index = h3Map.get(n.node_id) ?? null;
      stmt.run({
        node_id: n.node_id,
        parent_id: n.parent_id,
        level: n.level,
        code: n.code,
        iso3: n.iso3,
        territory_id: n.territory_id,
        name_en: n.name_en,
        name_local: n.name_local ?? n.name_en,
        centroid_lat: n.centroid_lat,
        centroid_lon: n.centroid_lon,
        h3_index: h3Index,
        h3_resolution: h3Res,
        population_est: n.population_est ?? null,
      });
      count += 1;
    }
  });
  tx();
  return count;
}

export function getAdminHierarchyTree(params?: {
  parentId?: string;
  level?: AdminLevel;
}): {
  levels: Array<{ level: AdminLevel; en: string; pt: string; adm: string; h3Res: number; count: number }>;
  nodes: SpatialAdminNode[];
  ancestors: Array<{ node_id: string; name_en: string; level: AdminLevel }>;
  countsByLevel: Record<AdminLevel, number>;
  totalNodes: number;
} {
  const db = getControlPlaneDb();

  const countRows = db
    .prepare(`SELECT level, COUNT(*) as cnt FROM dim_admin_nodes GROUP BY level`)
    .all() as Array<{ level: AdminLevel; cnt: number }>;

  const countsByLevel: Record<AdminLevel, number> = {
    global: 0,
    continent: 0,
    country: 0,
    state: 0,
    city: 0,
    neighborhood: 0,
  };
  for (const r of countRows) {
    if (r.level in countsByLevel) {
      countsByLevel[r.level] = r.cnt;
    }
  }

  const ancestors: Array<{ node_id: string; name_en: string; level: AdminLevel }> = [];
  if (params?.parentId) {
    const ancestorStmt = db.prepare(
      `SELECT node_id, parent_id, name_en, level FROM dim_admin_nodes WHERE node_id = ?`
    );
    const visited = new Set<string>();
    let cursor: string | null = params.parentId;
    while (cursor && !visited.has(cursor) && visited.size < 10) {
      visited.add(cursor);
      const row = ancestorStmt.get(cursor) as
        | { node_id: string; parent_id: string | null; name_en: string; level: AdminLevel }
        | undefined;
      if (!row) break;
      ancestors.push({
        node_id: row.node_id,
        name_en: row.node_id === 'GLOBAL' ? 'Global' : row.name_en,
        level: row.level,
      });
      cursor = row.parent_id;
    }
    ancestors.reverse();
  }

  let nodes: SpatialAdminNode[];
  if (params?.parentId) {
    nodes = db
      .prepare(
        `SELECT n.*,
          (SELECT COUNT(*) FROM dim_admin_nodes c WHERE c.parent_id = n.node_id) AS child_count
         FROM dim_admin_nodes n
         WHERE n.parent_id = ?
         ORDER BY COALESCE(n.population_est, 0) DESC, n.name_en ASC`
      )
      .all(params.parentId) as SpatialAdminNode[];
  } else if (params?.level) {
    nodes = db
      .prepare(
        `SELECT n.*,
          (SELECT COUNT(*) FROM dim_admin_nodes c WHERE c.parent_id = n.node_id) AS child_count
         FROM dim_admin_nodes n
         WHERE n.level = ?
         ORDER BY n.name_en ASC`
      )
      .all(params.level) as SpatialAdminNode[];
  } else {
    nodes = db
      .prepare(
        `SELECT * FROM dim_admin_nodes
         ORDER BY CASE level
           WHEN 'global' THEN 0
           WHEN 'continent' THEN 1
           WHEN 'country' THEN 2
           WHEN 'state' THEN 3
           WHEN 'city' THEN 4
           ELSE 5
         END ASC, name_en ASC`
      )
      .all() as SpatialAdminNode[];
  }

  const totalNodes = Object.values(countsByLevel).reduce((acc, n) => acc + n, 0);

  return {
    levels: ADMIN_LEVEL_ORDER.map((lvl) => ({
      level: lvl,
      ...ADMIN_LEVEL_LABELS[lvl],
      count: countsByLevel[lvl],
    })),
    nodes,
    ancestors,
    countsByLevel,
    totalNodes,
  };
}
