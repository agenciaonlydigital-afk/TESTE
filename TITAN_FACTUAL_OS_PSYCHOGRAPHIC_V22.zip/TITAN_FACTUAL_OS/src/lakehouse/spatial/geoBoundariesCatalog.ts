export type GeoBoundaryAdminLevel = 'ADM0' | 'ADM1' | 'ADM2';
export interface GeoBoundaryCatalogItem {
  boundary_id: string;
  boundary_iso: string;
  boundary_type: GeoBoundaryAdminLevel;
  boundary_name: string | null;
  boundary_year: string | null;
  boundary_license: string | null;
  boundary_url: string | null;
  geojson_download_url: string | null;
  source_data_update_date: string | null;
  attribution_required: boolean;
}
export interface GeoBoundaryCatalogResult {
  iso3: string;
  release_type: 'gbOpen';
  levels: Array<{ level: GeoBoundaryAdminLevel; status: 'available' | 'unavailable'; item_count: number }>;
  items: GeoBoundaryCatalogItem[];
  metadata_only: true;
  geometry_downloaded: false;
}

export function buildGeoBoundariesMetadataUrls(iso3: string): Array<{ level: GeoBoundaryAdminLevel; url: string }> {
  if (!/^[A-Z]{3}$/.test(iso3)) throw new Error('iso3 must be an uppercase ISO-3166 alpha-3 code.');
  return (['ADM0', 'ADM1', 'ADM2'] as const).map((level) => ({
    level,
    url: `https://www.geoboundaries.org/api/current/gbOpen/${iso3}/${level}/`,
  }));
}

function asString(value: unknown): string | null {
  return typeof value === 'string' && value.trim().length > 0 ? value.trim() : null;
}

function normalizeItem(value: unknown, level: GeoBoundaryAdminLevel, iso3: string): GeoBoundaryCatalogItem | null {
  if (!value || typeof value !== 'object') return null;
  const item = value as Record<string, unknown>;
  const boundaryId = asString(item.boundaryID) ?? asString(item.boundaryId);
  const boundaryIso = (asString(item.boundaryISO) ?? asString(item.boundaryIso) ?? iso3).toUpperCase();
  if (!boundaryId || boundaryIso !== iso3) return null;
  const boundaryType = (asString(item.boundaryType) ?? asString(item.boundary_type) ?? level).toUpperCase();
  if (boundaryType !== level) return null;
  const geojsonUrl = asString(item.gjDownloadURL) ?? asString(item.gjDownloadUrl) ?? asString(item.geojson_url);
  const boundaryUrl = asString(item.boundaryURL) ?? asString(item.boundaryUrl);
  for (const candidate of [geojsonUrl, boundaryUrl]) {
    if (candidate && !/^https:\/\//i.test(candidate)) throw new Error(`Refusing non-HTTPS boundary URL: ${candidate}`);
  }
  const license = asString(item.boundaryLicense) ?? asString(item.boundary_license);
  return {
    boundary_id: boundaryId,
    boundary_iso: boundaryIso,
    boundary_type: level,
    boundary_name: asString(item.boundaryName) ?? asString(item.boundary_name),
    boundary_year: asString(item.boundaryYear) ?? asString(item.boundary_year),
    boundary_license: license,
    boundary_url: boundaryUrl,
    geojson_download_url: geojsonUrl,
    source_data_update_date: asString(item.sourceDataUpdateDate) ?? asString(item.source_data_update_date),
    // geoBoundaries is an attribution-required data project; remain conservative even if metadata omits a license string.
    attribution_required: true,
  };
}

/** Fetches only catalog metadata for ADM0-ADM2; geometry files are never fetched here. */
export async function fetchGeoBoundariesCatalog(
  iso3: string,
  fetcher: typeof fetch = fetch,
  signal?: AbortSignal,
): Promise<GeoBoundaryCatalogResult> {
  const endpoints = buildGeoBoundariesMetadataUrls(iso3);
  const items: GeoBoundaryCatalogItem[] = [];
  const levels: GeoBoundaryCatalogResult['levels'] = [];
  for (const endpoint of endpoints) {
    const response = await fetcher(endpoint.url, { headers: { accept: 'application/json' }, signal });
    if (response.status === 404) {
      levels.push({ level: endpoint.level, status: 'unavailable', item_count: 0 });
      continue;
    }
    if (!response.ok) throw new Error(`geoBoundaries ${endpoint.level} metadata request failed with HTTP ${response.status}.`);
    const body: unknown = await response.json();
    const rows = Array.isArray(body) ? body : body && typeof body === 'object' ? [body] : [];
    const normalized = rows.map((item) => normalizeItem(item, endpoint.level, iso3)).filter((item): item is GeoBoundaryCatalogItem => item !== null);
    items.push(...normalized);
    levels.push({ level: endpoint.level, status: normalized.length > 0 ? 'available' : 'unavailable', item_count: normalized.length });
  }
  return { iso3, release_type: 'gbOpen', levels, items, metadata_only: true, geometry_downloaded: false };
}

export interface GeoBoundaryCatalogBatchFailure {
  iso3: string;
  error: string;
}

export interface GeoBoundaryCatalogBatchResult {
  results: GeoBoundaryCatalogResult[];
  failures: GeoBoundaryCatalogBatchFailure[];
  requested_countries: number;
  successful_countries: number;
}

/**
 * Discovers ADM0-ADM2 metadata for a supplied ISO3 universe with bounded concurrency.
 * A failed country is reported independently so a global catalog refresh can resume.
 * This does not download geometry files or infer that an unavailable admin level is absent.
 */
export async function fetchGeoBoundariesCatalogBatch(
  iso3Codes: readonly string[],
  options: { concurrency?: number; fetcher?: typeof fetch; signal?: AbortSignal } = {},
): Promise<GeoBoundaryCatalogBatchResult> {
  if (iso3Codes.length === 0 || iso3Codes.length > 300) throw new RangeError('Batch must contain between 1 and 300 ISO3 country codes.');
  if (iso3Codes.some((code) => !/^[A-Z]{3}$/.test(code))) throw new Error('Every batch country must be an uppercase ISO-3166 alpha-3 code.');
  if (new Set(iso3Codes).size !== iso3Codes.length) throw new Error('Batch country codes must be unique.');
  const concurrency = options.concurrency ?? 4;
  if (!Number.isInteger(concurrency) || concurrency < 1 || concurrency > 8) throw new RangeError('Batch concurrency must be an integer from 1 to 8.');
  const fetcher = options.fetcher ?? fetch;
  const results = new Array<GeoBoundaryCatalogResult | undefined>(iso3Codes.length);
  const failures: GeoBoundaryCatalogBatchFailure[] = [];
  let nextIndex = 0;
  const worker = async () => {
    while (true) {
      if (options.signal?.aborted) throw options.signal.reason ?? new Error('GeoBoundaries batch was aborted.');
      const index = nextIndex++;
      if (index >= iso3Codes.length) return;
      const iso3 = iso3Codes[index]!;
      try {
        results[index] = await fetchGeoBoundariesCatalog(iso3, fetcher, options.signal);
      } catch (error) {
        if (options.signal?.aborted) throw error;
        failures.push({ iso3, error: error instanceof Error ? error.message : String(error) });
      }
    }
  };
  await Promise.all(Array.from({ length: Math.min(concurrency, iso3Codes.length) }, () => worker()));
  const completed = results.filter((result): result is GeoBoundaryCatalogResult => result !== undefined);
  return {
    results: completed,
    failures: failures.sort((a, b) => iso3Codes.indexOf(a.iso3) - iso3Codes.indexOf(b.iso3)),
    requested_countries: iso3Codes.length,
    successful_countries: completed.length,
  };
}
