export type AllocationBasis = 'population' | 'area' | 'custom';
export interface BoundaryCrosswalkRow {
  source_boundary_id: string;
  target_boundary_id: string;
  source_boundary_version: string;
  target_boundary_version: string;
  allocation_weight: number;
  allocation_basis: AllocationBasis;
  valid_from_year: number;
  valid_to_year: number | null;
}

export function validateBoundaryCrosswalk(
  rows: readonly BoundaryCrosswalkRow[],
  tolerance = 0.001,
): BoundaryCrosswalkRow[] {
  if (!Number.isFinite(tolerance) || tolerance <= 0 || tolerance >= 0.1) throw new RangeError('tolerance must be > 0 and < 0.1.');
  if (rows.length === 0) throw new Error('Crosswalk must contain at least one mapping.');
  const bySource = new Map<string, BoundaryCrosswalkRow[]>();
  const bySourceTarget = new Map<string, BoundaryCrosswalkRow[]>();
  for (const row of rows) {
    if (![row.source_boundary_id, row.target_boundary_id, row.source_boundary_version, row.target_boundary_version].every((value) => typeof value === 'string' && value.trim().length > 0)) {
      throw new Error('Crosswalk IDs and boundary versions are required.');
    }
    if (!['population', 'area', 'custom'].includes(row.allocation_basis)) {
      throw new Error('allocation_basis must be population, area or custom.');
    }
    if (!Number.isFinite(row.allocation_weight) || row.allocation_weight < 0 || row.allocation_weight > 1) {
      throw new Error('allocation_weight must be between 0 and 1.');
    }
    if (!Number.isInteger(row.valid_from_year) || row.valid_from_year < 1800 || row.valid_from_year > 2200
      || (row.valid_to_year !== null && (!Number.isInteger(row.valid_to_year) || row.valid_to_year < row.valid_from_year || row.valid_to_year > 2200))) {
      throw new Error('Crosswalk validity years are invalid.');
    }
    const sourceKey = `${row.source_boundary_version}\u0000${row.source_boundary_id}`;
    const group = bySource.get(sourceKey) ?? [];
    group.push(row);
    bySource.set(sourceKey, group);
    const pairKey = `${sourceKey}\u0000${row.target_boundary_version}\u0000${row.target_boundary_id}`;
    const pair = bySourceTarget.get(pairKey) ?? [];
    pair.push(row);
    bySourceTarget.set(pairKey, pair);
  }

  // The same source-target pair may be reused in different, non-overlapping
  // periods. Overlapping rows would double-count that target in the active map.
  for (const [pairKey, pairRows] of bySourceTarget) {
    const ordered = [...pairRows].sort((a, b) => a.valid_from_year - b.valid_from_year);
    for (let index = 1; index < ordered.length; index++) {
      const previous = ordered[index - 1]!;
      const current = ordered[index]!;
      const previousEnd = previous.valid_to_year ?? 2200;
      if (current.valid_from_year <= previousEnd) {
        throw new Error(`Overlapping validity intervals for source-target pair ${pairKey.replaceAll('\u0000', ':')}.`);
      }
    }
  }

  for (const [sourceKey, mappings] of bySource) {
    if (new Set(mappings.map((row) => row.target_boundary_version)).size > 1) {
      throw new Error(`Crosswalk source ${sourceKey.replace('\u0000', ':')} maps to multiple target boundary versions.`);
    }

    // Validate each temporal segment independently. This supports a source
    // boundary being reallocated after a territorial reorganization without
    // incorrectly summing shares from mutually exclusive historical periods.
    const breakpoints = new Set<number>();
    for (const row of mappings) {
      breakpoints.add(row.valid_from_year);
      if (row.valid_to_year !== null && row.valid_to_year < 2200) breakpoints.add(row.valid_to_year + 1);
    }
    for (const year of [...breakpoints].sort((a, b) => a - b)) {
      const active = mappings.filter((row) => row.valid_from_year <= year && (row.valid_to_year === null || row.valid_to_year >= year));
      if (active.length === 0) continue;
      const sum = active.reduce((total, row) => total + row.allocation_weight, 0);
      if (!Number.isFinite(sum) || Math.abs(sum - 1) > tolerance) {
        throw new Error(`Crosswalk weights for ${sourceKey.replace('\u0000', ':')} sum to ${sum} in ${year}, not 1 ± ${tolerance}.`);
      }
      if (new Set(active.map((row) => row.allocation_basis)).size > 1) {
        throw new Error(`Crosswalk source ${sourceKey.replace('\u0000', ':')} mixes allocation bases in ${year}.`);
      }
    }
  }
  return [...rows];
}

export type CrosswalkAllocationInput =
  | { source_boundary_id: string; source_boundary_version: string; period_year: number; value: number; value_kind: 'additive' }
  | { source_boundary_id: string; source_boundary_version: string; period_year: number; value: number; value_kind: 'rate'; source_denominator: number };

export interface AllocatedBoundaryValue {
  target_boundary_id: string;
  target_boundary_version: string;
  period_year: number;
  value: number;
  allocated_numerator: number;
  allocated_denominator: number | null;
  allocation_basis: AllocationBasis;
}

/** Applies externally supplied/versioned allocation shares; does not derive spatial weights. */
export function allocateThroughBoundaryCrosswalk(
  crosswalkRows: readonly BoundaryCrosswalkRow[],
  values: readonly CrosswalkAllocationInput[],
): AllocatedBoundaryValue[] {
  const validated = validateBoundaryCrosswalk(crosswalkRows);
  const mappings = new Map<string, BoundaryCrosswalkRow[]>();
  for (const row of validated) {
    const sourceKey = `${row.source_boundary_version}\u0000${row.source_boundary_id}`;
    const group = mappings.get(sourceKey) ?? [];
    group.push(row);
    mappings.set(sourceKey, group);
  }
  const outputs = new Map<string, { targetId: string; targetVersion: string; periodYear: number; numerator: number; denominator: number | null; basis: AllocationBasis }>();
  for (const item of values) {
    if (item.value_kind !== 'additive' && item.value_kind !== 'rate') throw new Error('value_kind must be additive or rate.');
    if (![item.source_boundary_id, item.source_boundary_version].every((value) => typeof value === 'string' && value.trim().length > 0)) throw new Error('Source boundary ID and version are required.');
    if (!Number.isInteger(item.period_year) || item.period_year < 1800 || item.period_year > 2200) throw new Error('period_year is invalid for crosswalk allocation.');
    if (!Number.isFinite(item.value)) throw new Error(`Non-finite value for source boundary ${item.source_boundary_id}.`);
    if (item.value_kind === 'rate' && (!Number.isFinite(item.source_denominator) || item.source_denominator <= 0)) {
      throw new Error(`Rates require a positive source_denominator for ${item.source_boundary_id}.`);
    }
    const sourceMappings = mappings.get(`${item.source_boundary_version}\u0000${item.source_boundary_id}`);
    if (!sourceMappings) throw new Error(`No crosswalk mapping found for source boundary ${item.source_boundary_version}:${item.source_boundary_id}.`);
    const activeMappings = sourceMappings.filter((mapping) => item.period_year >= mapping.valid_from_year
      && (mapping.valid_to_year === null || item.period_year <= mapping.valid_to_year));
    if (activeMappings.length === 0) throw new Error(`No active crosswalk mapping for ${item.source_boundary_version}:${item.source_boundary_id}; mapping is not valid for period ${item.period_year}.`);
    for (const mapping of activeMappings) {
      if (mapping.allocation_weight === 0) continue;
      const targetKey = `${item.period_year}\u0000${mapping.target_boundary_version}\u0000${mapping.target_boundary_id}`;
      const current = outputs.get(targetKey) ?? { targetId: mapping.target_boundary_id, targetVersion: mapping.target_boundary_version, periodYear: item.period_year, numerator: 0, denominator: item.value_kind === 'rate' ? 0 : null, basis: mapping.allocation_basis };
      if (current.basis !== mapping.allocation_basis) throw new Error('Cannot combine different allocation bases in the same target output.');
      if (item.value_kind === 'rate') {
        if (current.denominator === null) throw new Error('Cannot combine additive totals and rates in the same target output.');
        current.numerator += item.value * item.source_denominator * mapping.allocation_weight;
        current.denominator += item.source_denominator * mapping.allocation_weight;
      } else {
        if (current.denominator !== null) throw new Error('Cannot combine additive totals and rates in the same target output.');
        current.numerator += item.value * mapping.allocation_weight;
      }
      if (!Number.isFinite(current.numerator) || (current.denominator !== null && !Number.isFinite(current.denominator))) {
        throw new Error(`Crosswalk allocation overflowed for target ${mapping.target_boundary_version}:${mapping.target_boundary_id}.`);
      }
      outputs.set(targetKey, current);
    }
  }
  return [...outputs.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([, value]) => ({
    target_boundary_id: value.targetId,
    target_boundary_version: value.targetVersion,
    period_year: value.periodYear,
    value: value.denominator === null ? value.numerator : value.denominator > 0 ? value.numerator / value.denominator : Number.NaN,
    allocated_numerator: value.numerator,
    allocated_denominator: value.denominator,
    allocation_basis: value.basis,
  }));
}
