export interface IndicatorCoverage {
  indicator_id: string; expected_territories: number; observed_territories: number;
  coverage_ratio: number; missing_territories: string[]; meets_threshold: boolean;
}
export function evaluateIndicatorCoverage(
  observations: Array<{ territory_id: string; indicator_id: string }>,
  expectedTerritoryIds: Iterable<string>,
  minimumRatio = 0.98
): IndicatorCoverage[] {
  if (!Number.isFinite(minimumRatio) || minimumRatio <= 0 || minimumRatio > 1) throw new RangeError('minimumRatio must be > 0 and <= 1');
  const expected = [...new Set(expectedTerritoryIds)].sort();
  if (!expected.length) return [];
  const groups = new Map<string, Set<string>>();
  for (const row of observations) {
    const group = groups.get(row.indicator_id) ?? new Set<string>();
    group.add(row.territory_id); groups.set(row.indicator_id, group);
  }
  return [...groups.entries()].sort(([a],[b])=>a.localeCompare(b)).map(([indicatorId, seen]) => {
    const observed = expected.filter((id)=>seen.has(id));
    const missing = expected.filter((id)=>!seen.has(id));
    const ratio = observed.length / expected.length;
    return { indicator_id:indicatorId, expected_territories:expected.length, observed_territories:observed.length,
      coverage_ratio:ratio, missing_territories:missing, meets_threshold:ratio >= minimumRatio };
  });
}
