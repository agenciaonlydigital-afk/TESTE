import Database from 'better-sqlite3';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { buildAuditedSourceCatalog } from './sourceInventory.ts';
import {
  initAndSeedAdminHierarchy,
  syncHierarchyH3Cells,
} from './spatial/adminHierarchy.ts';
import {
  INGESTION_LEASE_SCHEMA_SQL,
  acquireIngestionLease as acquireLease,
  listActiveIngestionLeases as listActiveLeases,
  releaseIngestionLease as releaseLease,
  renewIngestionLease as renewLease,
} from './ingestionLease.ts';
import { isEligibleForOrphanCleanup } from './maintenancePolicy.ts';
import type {
  CircuitBreakerRecord,
  CircuitState,
  HttpResourceCacheEntry,
  LineageRun,
  SnapshotManifest,
  SourceCatalogEntry,
  TerritoryCanonical,
} from './types.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_PATH = path.join(DATA_DIR, 'control_plane.sqlite');

let dbInstance: Database.Database | null = null;

export function getControlPlaneDb(): Database.Database {
  if (dbInstance) return dbInstance;

  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.mkdirSync(path.join(DATA_DIR, 'tmp'), { recursive: true });
  fs.mkdirSync(path.join(DATA_DIR, 'lakehouse', 'bronze'), { recursive: true });
  fs.mkdirSync(path.join(DATA_DIR, 'lakehouse', 'silver'), { recursive: true });
  fs.mkdirSync(path.join(DATA_DIR, 'lakehouse', 'gold'), { recursive: true });

  const db = new Database(DB_PATH);
  db.pragma('journal_mode = WAL');
  db.pragma('busy_timeout = 5000');
  db.pragma('synchronous = NORMAL');
  db.pragma('foreign_keys = ON');
  db.pragma('journal_size_limit = 67108864');

  initSchema(db);
  seedCatalogAndTerritories(db);
  initAndSeedAdminHierarchy(db);
  markOrphanedRunsFailed(db);

  dbInstance = db;
  return db;
}

export function closeControlPlaneDb(): void {
  if (!dbInstance) return;
  try {
    dbInstance.pragma('wal_checkpoint(TRUNCATE)');
  } catch {
    // ignore checkpoint error on shutdown
  }
  try {
    dbInstance.close();
  } finally {
    dbInstance = null;
  }
}

function initSchema(db: Database.Database): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS dim_data_sources (
      source_id TEXT PRIMARY KEY,
      catalog_index INTEGER,
      dataset_id TEXT NOT NULL,
      source_name TEXT NOT NULL,
      module_id INTEGER NOT NULL,
      module_name TEXT NOT NULL,
      domain_group TEXT NOT NULL DEFAULT '',
      resource_kind TEXT NOT NULL DEFAULT 'api',
      api_version TEXT NOT NULL DEFAULT 'v1',
      access_tier TEXT NOT NULL,
      license_id TEXT NOT NULL,
      commercial_use_allowed TEXT NOT NULL,
      redistribution_allowed TEXT NOT NULL,
      geographic_coverage TEXT NOT NULL,
      geographic_level TEXT NOT NULL,
      rate_limit_rpm INTEGER NOT NULL,
      max_concurrency INTEGER NOT NULL,
      preferred_mode TEXT NOT NULL,
      host TEXT NOT NULL,
      endpoint_url TEXT NOT NULL,
      update_frequency TEXT NOT NULL,
      incremental_value TEXT NOT NULL,
      known_block_reason TEXT,
      duplicity_audit_note TEXT,
      is_expansion INTEGER NOT NULL DEFAULT 0,
      last_successful_ingestion TEXT,
      last_verified_at TEXT,
      implemented_wave1 INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS dim_territories (
      territory_id TEXT PRIMARY KEY,
      iso2 TEXT NOT NULL,
      iso3 TEXT NOT NULL UNIQUE,
      un_m49 TEXT NOT NULL,
      wikidata_qid TEXT NOT NULL,
      name_en TEXT NOT NULL,
      name_pt TEXT NOT NULL,
      continent TEXT NOT NULL,
      region TEXT NOT NULL,
      currency_iso4217 TEXT NOT NULL,
      primary_language_iso639 TEXT NOT NULL,
      timezone TEXT NOT NULL,
      centroid_lat REAL NOT NULL,
      centroid_lon REAL NOT NULL,
      h3_res2 TEXT,
      h3_res4 TEXT
    );

    CREATE TABLE IF NOT EXISTS dim_territory_aliases (
      alias_normalized TEXT PRIMARY KEY,
      territory_id TEXT NOT NULL,
      FOREIGN KEY (territory_id) REFERENCES dim_territories(territory_id)
    );

    CREATE TABLE IF NOT EXISTS snapshot_manifest (
      snapshot_id TEXT PRIMARY KEY,
      source_id TEXT NOT NULL,
      dataset_id TEXT NOT NULL,
      layer TEXT NOT NULL,
      parquet_path TEXT NOT NULL,
      sha256 TEXT NOT NULL,
      row_count INTEGER NOT NULL,
      byte_size INTEGER NOT NULL,
      qa_status TEXT NOT NULL,
      qa_notes TEXT,
      is_active INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_snapshot_active
      ON snapshot_manifest(source_id, layer, is_active);

    CREATE TABLE IF NOT EXISTS circuit_breaker_state (
      host TEXT PRIMARY KEY,
      state TEXT NOT NULL,
      error_streak INTEGER NOT NULL DEFAULT 0,
      cooldown_until TEXT,
      last_etag TEXT,
      last_modified TEXT,
      last_error TEXT,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS http_resource_cache (
      url_sha256 TEXT PRIMARY KEY,
      url TEXT NOT NULL,
      host TEXT NOT NULL,
      etag TEXT,
      last_modified TEXT,
      content_sha256 TEXT,
      last_checked_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS lineage_runs (
      run_id TEXT PRIMARY KEY,
      source_id TEXT NOT NULL,
      job_name TEXT NOT NULL,
      status TEXT NOT NULL,
      input_etag TEXT,
      output_snapshot_id TEXT,
      rows_in INTEGER NOT NULL DEFAULT 0,
      rows_out INTEGER NOT NULL DEFAULT 0,
      duration_ms INTEGER NOT NULL DEFAULT 0,
      details_json TEXT NOT NULL,
      started_at TEXT NOT NULL,
      finished_at TEXT
    );

    CREATE TABLE IF NOT EXISTS dlq_unresolved_entities (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      source_id TEXT NOT NULL,
      raw_entity_code TEXT NOT NULL,
      raw_entity_name TEXT,
      reason TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
  `);

  db.exec(INGESTION_LEASE_SCHEMA_SQL);

  // Safe schema evolution for existing control_plane.sqlite files
  const territoryCols = db.prepare(`PRAGMA table_info(dim_territories)`).all() as Array<{ name: string }>;
  const territoryColNames = new Set(territoryCols.map((c) => c.name));
  if (!territoryColNames.has('h3_res2')) {
    db.exec(`ALTER TABLE dim_territories ADD COLUMN h3_res2 TEXT;`);
  }
  if (!territoryColNames.has('h3_res4')) {
    db.exec(`ALTER TABLE dim_territories ADD COLUMN h3_res4 TEXT;`);
  }

  const sourceCols = db.prepare(`PRAGMA table_info(dim_data_sources)`).all() as Array<{ name: string }>;
  const sourceColNames = new Set(sourceCols.map((c) => c.name));
  if (!sourceColNames.has('catalog_index')) {
    db.exec(`ALTER TABLE dim_data_sources ADD COLUMN catalog_index INTEGER;`);
  }
  if (!sourceColNames.has('domain_group')) {
    db.exec(`ALTER TABLE dim_data_sources ADD COLUMN domain_group TEXT NOT NULL DEFAULT '';`);
  }
  if (!sourceColNames.has('resource_kind')) {
    db.exec(`ALTER TABLE dim_data_sources ADD COLUMN resource_kind TEXT NOT NULL DEFAULT 'api';`);
  }
  if (!sourceColNames.has('api_version')) {
    db.exec(`ALTER TABLE dim_data_sources ADD COLUMN api_version TEXT NOT NULL DEFAULT 'v1';`);
  }
  if (!sourceColNames.has('duplicity_audit_note')) {
    db.exec(`ALTER TABLE dim_data_sources ADD COLUMN duplicity_audit_note TEXT;`);
  }
  if (!sourceColNames.has('is_expansion')) {
    db.exec(`ALTER TABLE dim_data_sources ADD COLUMN is_expansion INTEGER NOT NULL DEFAULT 0;`);
  }
}

function markOrphanedRunsFailed(db: Database.Database): void {
  const now = new Date().toISOString();
  // A second server instance must not mark a still-running worker as orphaned.
  // Only runs without a matching, unexpired source lease are recovered.
  db.prepare(`
    UPDATE lineage_runs
    SET status = 'FAILED',
        details_json = '{"error":"Orphaned RUNNING job recovered after its ingestion lease expired"}',
        finished_at = ?
    WHERE status = 'RUNNING'
      AND NOT EXISTS (
        SELECT 1 FROM ingestion_leases lease
        WHERE lease.source_id = lineage_runs.source_id
          AND lease.run_id = lineage_runs.run_id
          AND lease.lease_expires_at > ?
      )
  `).run(now, now);
}

export function acquireSourceIngestionLease(input: {
  sourceId: string;
  runId: string;
  ownerId: string;
}): boolean {
  const db = getControlPlaneDb();
  const acquired = acquireLease(db, input);
  if (!acquired) return false;
  const now = new Date().toISOString();
  db.prepare(`
    UPDATE lineage_runs
    SET status = 'FAILED',
        details_json = '{"error":"Previous RUNNING job lost its source lease"}',
        finished_at = ?
    WHERE source_id = ? AND status = 'RUNNING' AND run_id <> ?
      AND NOT EXISTS (
        SELECT 1 FROM ingestion_leases lease
        WHERE lease.source_id = lineage_runs.source_id
          AND lease.run_id = lineage_runs.run_id
          AND lease.lease_expires_at > ?
      )
  `).run(now, input.sourceId, input.runId, now);
  return true;
}

export function renewSourceIngestionLease(input: {
  sourceId: string;
  runId: string;
  ownerId: string;
}): boolean {
  return renewLease(getControlPlaneDb(), input);
}

export function releaseSourceIngestionLease(input: {
  sourceId: string;
  runId: string;
  ownerId: string;
}): boolean {
  return releaseLease(getControlPlaneDb(), input);
}

export function listActiveSourceIngestionLeases(): Array<{
  source_id: string;
  run_id: string;
  owner_id: string;
  acquired_at: string;
  heartbeat_at: string;
  lease_expires_at: string;
}> {
  return listActiveLeases(getControlPlaneDb());
}

function seedCatalogAndTerritories(db: Database.Database): void {
  const now = new Date().toISOString();
  const upsertSource = db.prepare(`
    INSERT INTO dim_data_sources (
      source_id, catalog_index, dataset_id, source_name, module_id, module_name,
      domain_group, resource_kind, api_version, access_tier, license_id,
      commercial_use_allowed, redistribution_allowed, geographic_coverage, geographic_level,
      rate_limit_rpm, max_concurrency, preferred_mode, host, endpoint_url,
      update_frequency, incremental_value, known_block_reason, duplicity_audit_note,
      is_expansion, last_successful_ingestion, last_verified_at, implemented_wave1
    ) VALUES (
      @source_id, @catalog_index, @dataset_id, @source_name, @module_id, @module_name,
      @domain_group, @resource_kind, @api_version, @access_tier, @license_id,
      @commercial_use_allowed, @redistribution_allowed, @geographic_coverage, @geographic_level,
      @rate_limit_rpm, @max_concurrency, @preferred_mode, @host, @endpoint_url,
      @update_frequency, @incremental_value, @known_block_reason, @duplicity_audit_note,
      @is_expansion, @last_successful_ingestion, @last_verified_at, @implemented_wave1
    )
    ON CONFLICT(source_id) DO UPDATE SET
      catalog_index = excluded.catalog_index,
      dataset_id = excluded.dataset_id,
      source_name = excluded.source_name,
      module_id = excluded.module_id,
      module_name = excluded.module_name,
      domain_group = excluded.domain_group,
      resource_kind = excluded.resource_kind,
      api_version = excluded.api_version,
      access_tier = excluded.access_tier,
      license_id = excluded.license_id,
      commercial_use_allowed = excluded.commercial_use_allowed,
      redistribution_allowed = excluded.redistribution_allowed,
      geographic_coverage = excluded.geographic_coverage,
      geographic_level = excluded.geographic_level,
      rate_limit_rpm = excluded.rate_limit_rpm,
      max_concurrency = excluded.max_concurrency,
      preferred_mode = excluded.preferred_mode,
      host = excluded.host,
      endpoint_url = excluded.endpoint_url,
      update_frequency = excluded.update_frequency,
      incremental_value = excluded.incremental_value,
      known_block_reason = excluded.known_block_reason,
      duplicity_audit_note = excluded.duplicity_audit_note,
      is_expansion = excluded.is_expansion,
      implemented_wave1 = excluded.implemented_wave1,
      last_verified_at = COALESCE(excluded.last_verified_at, dim_data_sources.last_verified_at)
  `);

  const sources = buildAuditedSourceCatalog(now);
  const txSources = db.transaction((items: SourceCatalogEntry[]) => {
    for (const s of items) upsertSource.run(s);
  });
  txSources(sources);

  const existingTerritories = db.prepare('SELECT COUNT(*) as cnt FROM dim_territories').get() as { cnt: number };
  if (existingTerritories.cnt === 0) {
    const insertTerritory = db.prepare(`
      INSERT INTO dim_territories (
        territory_id, iso2, iso3, un_m49, wikidata_qid, name_en, name_pt,
        continent, region, currency_iso4217, primary_language_iso639, timezone,
        centroid_lat, centroid_lon
      ) VALUES (
        @territory_id, @iso2, @iso3, @un_m49, @wikidata_qid, @name_en, @name_pt,
        @continent, @region, @currency_iso4217, @primary_language_iso639, @timezone,
        @centroid_lat, @centroid_lon
      )
    `);
    const insertAlias = db.prepare(`
      INSERT OR IGNORE INTO dim_territory_aliases (alias_normalized, territory_id)
      VALUES (?, ?)
    `);

    const territories: Array<TerritoryCanonical & { aliases?: string[] }> = [
      { territory_id: 'T_BRA', iso2: 'BR', iso3: 'BRA', un_m49: '076', wikidata_qid: 'Q155', name_en: 'Brazil', name_pt: 'Brasil', continent: 'South America', region: 'Latin America & Caribbean', currency_iso4217: 'BRL', primary_language_iso639: 'pt', timezone: 'America/Sao_Paulo', centroid_lat: -14.235, centroid_lon: -51.925, aliases: ['brazil', 'brasil', 'bra', 'br'] },
      { territory_id: 'T_USA', iso2: 'US', iso3: 'USA', un_m49: '840', wikidata_qid: 'Q30', name_en: 'United States', name_pt: 'Estados Unidos', continent: 'North America', region: 'Northern America', currency_iso4217: 'USD', primary_language_iso639: 'en', timezone: 'America/New_York', centroid_lat: 39.828, centroid_lon: -98.579, aliases: ['united states', 'united states of america', 'usa', 'us'] },
      { territory_id: 'T_CAN', iso2: 'CA', iso3: 'CAN', un_m49: '124', wikidata_qid: 'Q16', name_en: 'Canada', name_pt: 'Canadá', continent: 'North America', region: 'Northern America', currency_iso4217: 'CAD', primary_language_iso639: 'en', timezone: 'America/Toronto', centroid_lat: 56.13, centroid_lon: -106.346, aliases: ['canada', 'can', 'ca'] },
      { territory_id: 'T_MEX', iso2: 'MX', iso3: 'MEX', un_m49: '484', wikidata_qid: 'Q96', name_en: 'Mexico', name_pt: 'México', continent: 'North America', region: 'Latin America & Caribbean', currency_iso4217: 'MXN', primary_language_iso639: 'es', timezone: 'America/Mexico_City', centroid_lat: 23.634, centroid_lon: -102.552, aliases: ['mexico', 'mex', 'mx'] },
      { territory_id: 'T_ARG', iso2: 'AR', iso3: 'ARG', un_m49: '032', wikidata_qid: 'Q414', name_en: 'Argentina', name_pt: 'Argentina', continent: 'South America', region: 'Latin America & Caribbean', currency_iso4217: 'ARS', primary_language_iso639: 'es', timezone: 'America/Argentina/Buenos_Aires', centroid_lat: -38.416, centroid_lon: -63.616, aliases: ['argentina', 'arg', 'ar'] },
      { territory_id: 'T_CHL', iso2: 'CL', iso3: 'CHL', un_m49: '152', wikidata_qid: 'Q298', name_en: 'Chile', name_pt: 'Chile', continent: 'South America', region: 'Latin America & Caribbean', currency_iso4217: 'CLP', primary_language_iso639: 'es', timezone: 'America/Santiago', centroid_lat: -35.675, centroid_lon: -71.542, aliases: ['chile', 'chl', 'cl'] },
      { territory_id: 'T_COL', iso2: 'CO', iso3: 'COL', un_m49: '170', wikidata_qid: 'Q739', name_en: 'Colombia', name_pt: 'Colômbia', continent: 'South America', region: 'Latin America & Caribbean', currency_iso4217: 'COP', primary_language_iso639: 'es', timezone: 'America/Bogota', centroid_lat: 4.57, centroid_lon: -74.297, aliases: ['colombia', 'col', 'co'] },
      { territory_id: 'T_GBR', iso2: 'GB', iso3: 'GBR', un_m49: '826', wikidata_qid: 'Q145', name_en: 'United Kingdom', name_pt: 'Reino Unido', continent: 'Europe', region: 'Northern Europe', currency_iso4217: 'GBP', primary_language_iso639: 'en', timezone: 'Europe/London', centroid_lat: 55.378, centroid_lon: -3.435, aliases: ['united kingdom', 'uk', 'gbr', 'gb'] },
      { territory_id: 'T_DEU', iso2: 'DE', iso3: 'DEU', un_m49: '276', wikidata_qid: 'Q183', name_en: 'Germany', name_pt: 'Alemanha', continent: 'Europe', region: 'Western Europe', currency_iso4217: 'EUR', primary_language_iso639: 'de', timezone: 'Europe/Berlin', centroid_lat: 51.165, centroid_lon: 10.451, aliases: ['germany', 'deutschland', 'deu', 'de'] },
      { territory_id: 'T_FRA', iso2: 'FR', iso3: 'FRA', un_m49: '250', wikidata_qid: 'Q142', name_en: 'France', name_pt: 'França', continent: 'Europe', region: 'Western Europe', currency_iso4217: 'EUR', primary_language_iso639: 'fr', timezone: 'Europe/Paris', centroid_lat: 46.227, centroid_lon: 2.213, aliases: ['france', 'fra', 'fr'] },
      { territory_id: 'T_ESP', iso2: 'ES', iso3: 'ESP', un_m49: '724', wikidata_qid: 'Q29', name_en: 'Spain', name_pt: 'Espanha', continent: 'Europe', region: 'Southern Europe', currency_iso4217: 'EUR', primary_language_iso639: 'es', timezone: 'Europe/Madrid', centroid_lat: 40.463, centroid_lon: -3.749, aliases: ['spain', 'esp', 'es'] },
      { territory_id: 'T_PRT', iso2: 'PT', iso3: 'PRT', un_m49: '620', wikidata_qid: 'Q45', name_en: 'Portugal', name_pt: 'Portugal', continent: 'Europe', region: 'Southern Europe', currency_iso4217: 'EUR', primary_language_iso639: 'pt', timezone: 'Europe/Lisbon', centroid_lat: 39.399, centroid_lon: -8.224, aliases: ['portugal', 'prt', 'pt'] },
      { territory_id: 'T_ITA', iso2: 'IT', iso3: 'ITA', un_m49: '380', wikidata_qid: 'Q38', name_en: 'Italy', name_pt: 'Itália', continent: 'Europe', region: 'Southern Europe', currency_iso4217: 'EUR', primary_language_iso639: 'it', timezone: 'Europe/Rome', centroid_lat: 41.871, centroid_lon: 12.567, aliases: ['italy', 'ita', 'it'] },
      { territory_id: 'T_NLD', iso2: 'NL', iso3: 'NLD', un_m49: '528', wikidata_qid: 'Q55', name_en: 'Netherlands', name_pt: 'Países Baixos', continent: 'Europe', region: 'Western Europe', currency_iso4217: 'EUR', primary_language_iso639: 'nl', timezone: 'Europe/Amsterdam', centroid_lat: 52.132, centroid_lon: 5.291, aliases: ['netherlands', 'nld', 'nl'] },
      { territory_id: 'T_POL', iso2: 'PL', iso3: 'POL', un_m49: '616', wikidata_qid: 'Q36', name_en: 'Poland', name_pt: 'Polônia', continent: 'Europe', region: 'Eastern Europe', currency_iso4217: 'PLN', primary_language_iso639: 'pl', timezone: 'Europe/Warsaw', centroid_lat: 51.919, centroid_lon: 19.145, aliases: ['poland', 'pol', 'pl'] },
      { territory_id: 'T_SWE', iso2: 'SE', iso3: 'SWE', un_m49: '752', wikidata_qid: 'Q34', name_en: 'Sweden', name_pt: 'Suécia', continent: 'Europe', region: 'Northern Europe', currency_iso4217: 'SEK', primary_language_iso639: 'sv', timezone: 'Europe/Stockholm', centroid_lat: 60.128, centroid_lon: 18.643, aliases: ['sweden', 'swe', 'se'] },
      { territory_id: 'T_CHE', iso2: 'CH', iso3: 'CHE', un_m49: '756', wikidata_qid: 'Q39', name_en: 'Switzerland', name_pt: 'Suíça', continent: 'Europe', region: 'Western Europe', currency_iso4217: 'CHF', primary_language_iso639: 'de', timezone: 'Europe/Zurich', centroid_lat: 46.818, centroid_lon: 8.227, aliases: ['switzerland', 'che', 'ch'] },
      { territory_id: 'T_NOR', iso2: 'NO', iso3: 'NOR', un_m49: '578', wikidata_qid: 'Q20', name_en: 'Norway', name_pt: 'Noruega', continent: 'Europe', region: 'Northern Europe', currency_iso4217: 'NOK', primary_language_iso639: 'no', timezone: 'Europe/Oslo', centroid_lat: 60.472, centroid_lon: 8.468, aliases: ['norway', 'nor', 'no'] },
      { territory_id: 'T_CHN', iso2: 'CN', iso3: 'CHN', un_m49: '156', wikidata_qid: 'Q148', name_en: 'China', name_pt: 'China', continent: 'Asia', region: 'Eastern Asia', currency_iso4217: 'CNY', primary_language_iso639: 'zh', timezone: 'Asia/Shanghai', centroid_lat: 35.861, centroid_lon: 104.195, aliases: ['china', 'chn', 'cn'] },
      { territory_id: 'T_IND', iso2: 'IN', iso3: 'IND', un_m49: '356', wikidata_qid: 'Q668', name_en: 'India', name_pt: 'Índia', continent: 'Asia', region: 'Southern Asia', currency_iso4217: 'INR', primary_language_iso639: 'hi', timezone: 'Asia/Kolkata', centroid_lat: 20.593, centroid_lon: 78.962, aliases: ['india', 'ind', 'in'] },
      { territory_id: 'T_JPN', iso2: 'JP', iso3: 'JPN', un_m49: '392', wikidata_qid: 'Q17', name_en: 'Japan', name_pt: 'Japão', continent: 'Asia', region: 'Eastern Asia', currency_iso4217: 'JPY', primary_language_iso639: 'ja', timezone: 'Asia/Tokyo', centroid_lat: 36.204, centroid_lon: 138.252, aliases: ['japan', 'jpn', 'jp'] },
      { territory_id: 'T_KOR', iso2: 'KR', iso3: 'KOR', un_m49: '410', wikidata_qid: 'Q884', name_en: 'South Korea', name_pt: 'Coreia do Sul', continent: 'Asia', region: 'Eastern Asia', currency_iso4217: 'KRW', primary_language_iso639: 'ko', timezone: 'Asia/Seoul', centroid_lat: 35.907, centroid_lon: 127.766, aliases: ['south korea', 'korea, rep.', 'republic of korea', 'kor', 'kr'] },
      { territory_id: 'T_IDN', iso2: 'ID', iso3: 'IDN', un_m49: '360', wikidata_qid: 'Q252', name_en: 'Indonesia', name_pt: 'Indonésia', continent: 'Asia', region: 'South-Eastern Asia', currency_iso4217: 'IDR', primary_language_iso639: 'id', timezone: 'Asia/Jakarta', centroid_lat: -0.789, centroid_lon: 113.921, aliases: ['indonesia', 'idn', 'id'] },
      { territory_id: 'T_SGP', iso2: 'SG', iso3: 'SGP', un_m49: '702', wikidata_qid: 'Q334', name_en: 'Singapore', name_pt: 'Singapura', continent: 'Asia', region: 'South-Eastern Asia', currency_iso4217: 'SGD', primary_language_iso639: 'en', timezone: 'Asia/Singapore', centroid_lat: 1.352, centroid_lon: 103.819, aliases: ['singapore', 'sgp', 'sg'] },
      { territory_id: 'T_ARE', iso2: 'AE', iso3: 'ARE', un_m49: '784', wikidata_qid: 'Q878', name_en: 'United Arab Emirates', name_pt: 'Emirados Árabes Unidos', continent: 'Asia', region: 'Western Asia', currency_iso4217: 'AED', primary_language_iso639: 'ar', timezone: 'Asia/Dubai', centroid_lat: 23.424, centroid_lon: 53.847, aliases: ['united arab emirates', 'uae', 'are', 'ae'] },
      { territory_id: 'T_SAU', iso2: 'SA', iso3: 'SAU', un_m49: '682', wikidata_qid: 'Q851', name_en: 'Saudi Arabia', name_pt: 'Arábia Saudita', continent: 'Asia', region: 'Western Asia', currency_iso4217: 'SAR', primary_language_iso639: 'ar', timezone: 'Asia/Riyadh', centroid_lat: 23.885, centroid_lon: 45.079, aliases: ['saudi arabia', 'sau', 'sa'] },
      { territory_id: 'T_TUR', iso2: 'TR', iso3: 'TUR', un_m49: '792', wikidata_qid: 'Q43', name_en: 'Turkiye', name_pt: 'Turquia', continent: 'Asia', region: 'Western Asia', currency_iso4217: 'TRY', primary_language_iso639: 'tr', timezone: 'Europe/Istanbul', centroid_lat: 38.963, centroid_lon: 35.243, aliases: ['turkiye', 'turkey', 'tur', 'tr'] },
      { territory_id: 'T_ZAF', iso2: 'ZA', iso3: 'ZAF', un_m49: '710', wikidata_qid: 'Q258', name_en: 'South Africa', name_pt: 'África do Sul', continent: 'Africa', region: 'Southern Africa', currency_iso4217: 'ZAR', primary_language_iso639: 'en', timezone: 'Africa/Johannesburg', centroid_lat: -30.559, centroid_lon: 22.937, aliases: ['south africa', 'zaf', 'za'] },
      { territory_id: 'T_NGA', iso2: 'NG', iso3: 'NGA', un_m49: '566', wikidata_qid: 'Q1033', name_en: 'Nigeria', name_pt: 'Nigéria', continent: 'Africa', region: 'Western Africa', currency_iso4217: 'NGN', primary_language_iso639: 'en', timezone: 'Africa/Lagos', centroid_lat: 9.082, centroid_lon: 8.675, aliases: ['nigeria', 'nga', 'ng'] },
      { territory_id: 'T_EGY', iso2: 'EG', iso3: 'EGY', un_m49: '818', wikidata_qid: 'Q79', name_en: 'Egypt', name_pt: 'Egito', continent: 'Africa', region: 'Northern Africa', currency_iso4217: 'EGP', primary_language_iso639: 'ar', timezone: 'Africa/Cairo', centroid_lat: 26.82, centroid_lon: 30.802, aliases: ['egypt', 'egypt, arab rep.', 'egy', 'eg'] },
      { territory_id: 'T_AUS', iso2: 'AU', iso3: 'AUS', un_m49: '036', wikidata_qid: 'Q408', name_en: 'Australia', name_pt: 'Austrália', continent: 'Oceania', region: 'Australia & New Zealand', currency_iso4217: 'AUD', primary_language_iso639: 'en', timezone: 'Australia/Sydney', centroid_lat: -25.274, centroid_lon: 133.775, aliases: ['australia', 'aus', 'au'] },
      { territory_id: 'T_NZL', iso2: 'NZ', iso3: 'NZL', un_m49: '554', wikidata_qid: 'Q664', name_en: 'New Zealand', name_pt: 'Nova Zelândia', continent: 'Oceania', region: 'Australia & New Zealand', currency_iso4217: 'NZD', primary_language_iso639: 'en', timezone: 'Pacific/Auckland', centroid_lat: -40.9, centroid_lon: 174.885, aliases: ['new zealand', 'nzl', 'nz'] },
    ];

    const tx = db.transaction(() => {
      for (const t of territories) {
        const { aliases, ...row } = t;
        insertTerritory.run(row);
        insertAlias.run(t.iso3.toLowerCase(), t.territory_id);
        insertAlias.run(t.iso2.toLowerCase(), t.territory_id);
        insertAlias.run(t.name_en.toLowerCase(), t.territory_id);
        for (const a of aliases ?? []) {
          insertAlias.run(a.toLowerCase(), t.territory_id);
        }
      }
    });
    tx();
  }

  // Idempotent migration for newly added canonical territories (e.g. Finland for StatFin PxWeb #22)
  const extraTerritories: Array<TerritoryCanonical & { aliases: string[] }> = [
    {
      territory_id: 'T_FIN',
      iso2: 'FI',
      iso3: 'FIN',
      un_m49: '246',
      wikidata_qid: 'Q33',
      name_en: 'Finland',
      name_pt: 'Finlândia',
      continent: 'Europe',
      region: 'Northern Europe',
      currency_iso4217: 'EUR',
      primary_language_iso639: 'fi',
      timezone: 'Europe/Helsinki',
      centroid_lat: 61.924,
      centroid_lon: 25.748,
      aliases: ['finland', 'finlândia', 'finlandia', 'suomi', 'fin', 'fi'],
    },
  ];
  const insertExtraTerritory = db.prepare(`
    INSERT OR IGNORE INTO dim_territories (
      territory_id, iso2, iso3, un_m49, wikidata_qid, name_en, name_pt,
      continent, region, currency_iso4217, primary_language_iso639, timezone,
      centroid_lat, centroid_lon
    ) VALUES (
      @territory_id, @iso2, @iso3, @un_m49, @wikidata_qid, @name_en, @name_pt,
      @continent, @region, @currency_iso4217, @primary_language_iso639, @timezone,
      @centroid_lat, @centroid_lon
    )
  `);
  const insertExtraAlias = db.prepare(`
    INSERT OR IGNORE INTO dim_territory_aliases (alias_normalized, territory_id)
    VALUES (?, ?)
  `);
  const txExtra = db.transaction(() => {
    for (const t of extraTerritories) {
      const { aliases, ...row } = t;
      insertExtraTerritory.run(row);
      insertExtraAlias.run(t.iso3.toLowerCase(), t.territory_id);
      insertExtraAlias.run(t.iso2.toLowerCase(), t.territory_id);
      insertExtraAlias.run(t.name_en.toLowerCase(), t.territory_id);
      for (const a of aliases) {
        insertExtraAlias.run(a.toLowerCase(), t.territory_id);
      }
    }
  });
  txExtra();
}

export function updateTerritoryH3Cells(
  updates: Array<{ territory_id: string; h3_res2: string; h3_res4: string }>
): void {
  const db = getControlPlaneDb();
  const stmt = db.prepare(`
    UPDATE dim_territories SET h3_res2 = ?, h3_res4 = ? WHERE territory_id = ?
  `);
  const tx = db.transaction(() => {
    for (const u of updates) {
      stmt.run(u.h3_res2, u.h3_res4, u.territory_id);
    }
  });
  tx();
  syncHierarchyH3Cells(updates);
}

export function listDataSources(): SourceCatalogEntry[] {
  const db = getControlPlaneDb();
  return db
    .prepare(
      'SELECT * FROM dim_data_sources ORDER BY implemented_wave1 DESC, is_expansion ASC, COALESCE(catalog_index, 999) ASC, source_name ASC'
    )
    .all() as SourceCatalogEntry[];
}

export function getDataSource(sourceId: string): SourceCatalogEntry | undefined {
  const db = getControlPlaneDb();
  return db
    .prepare('SELECT * FROM dim_data_sources WHERE source_id = ?')
    .get(sourceId) as SourceCatalogEntry | undefined;
}

export function listTerritories(): TerritoryCanonical[] {
  const db = getControlPlaneDb();
  return db.prepare('SELECT * FROM dim_territories ORDER BY name_en ASC').all() as TerritoryCanonical[];
}

export function resolveTerritoryByCodeOrName(raw: string): TerritoryCanonical | undefined {
  const db = getControlPlaneDb();
  const normalized = raw.trim().toLowerCase();
  const aliasRow = db
    .prepare('SELECT territory_id FROM dim_territory_aliases WHERE alias_normalized = ?')
    .get(normalized) as { territory_id: string } | undefined;
  if (!aliasRow) return undefined;
  return db
    .prepare('SELECT * FROM dim_territories WHERE territory_id = ?')
    .get(aliasRow.territory_id) as TerritoryCanonical | undefined;
}

export function logUnresolvedEntity(sourceId: string, rawCode: string, rawName: string | null, reason: string): void {
  const db = getControlPlaneDb();
  db.prepare(`
    INSERT INTO dlq_unresolved_entities (source_id, raw_entity_code, raw_entity_name, reason, created_at)
    VALUES (?, ?, ?, ?, ?)
  `).run(sourceId, rawCode, rawName, reason, new Date().toISOString());
}

export function urlHash(url: string): string {
  return crypto.createHash('sha256').update(url).digest('hex');
}

export function getHttpResourceCache(url: string): HttpResourceCacheEntry | undefined {
  const db = getControlPlaneDb();
  return db
    .prepare('SELECT * FROM http_resource_cache WHERE url_sha256 = ?')
    .get(urlHash(url)) as HttpResourceCacheEntry | undefined;
}

export function upsertHttpResourceCache(entry: {
  url: string;
  host: string;
  etag: string | null;
  lastModified: string | null;
  contentSha256: string | null;
}): void {
  const db = getControlPlaneDb();
  db.prepare(`
    INSERT INTO http_resource_cache (url_sha256, url, host, etag, last_modified, content_sha256, last_checked_at)
    VALUES (@url_sha256, @url, @host, @etag, @last_modified, @content_sha256, @last_checked_at)
    ON CONFLICT(url_sha256) DO UPDATE SET
      etag = COALESCE(excluded.etag, http_resource_cache.etag),
      last_modified = COALESCE(excluded.last_modified, http_resource_cache.last_modified),
      content_sha256 = COALESCE(excluded.content_sha256, http_resource_cache.content_sha256),
      last_checked_at = excluded.last_checked_at
  `).run({
    url_sha256: urlHash(entry.url),
    url: entry.url,
    host: entry.host,
    etag: entry.etag,
    last_modified: entry.lastModified,
    content_sha256: entry.contentSha256,
    last_checked_at: new Date().toISOString(),
  });
}

export function getCircuitBreaker(host: string): CircuitBreakerRecord {
  const db = getControlPlaneDb();
  const row = db.prepare('SELECT * FROM circuit_breaker_state WHERE host = ?').get(host) as
    | CircuitBreakerRecord
    | undefined;
  if (row) {
    if (row.state === 'OPEN' && row.cooldown_until && new Date(row.cooldown_until) <= new Date()) {
      db.prepare(`UPDATE circuit_breaker_state SET state = 'HALF_OPEN', updated_at = ? WHERE host = ?`).run(
        new Date().toISOString(),
        host
      );
      return { ...row, state: 'HALF_OPEN' };
    }
    return row;
  }
  const now = new Date().toISOString();
  const initial: CircuitBreakerRecord = {
    host,
    state: 'CLOSED',
    error_streak: 0,
    cooldown_until: null,
    last_etag: null,
    last_modified: null,
    last_error: null,
    updated_at: now,
  };
  db.prepare(`
    INSERT INTO circuit_breaker_state (host, state, error_streak, cooldown_until, last_etag, last_modified, last_error, updated_at)
    VALUES (@host, @state, @error_streak, @cooldown_until, @last_etag, @last_modified, @last_error, @updated_at)
  `).run(initial);
  return initial;
}

export function recordHostSuccess(host: string, etag: string | null, lastModified: string | null): void {
  const db = getControlPlaneDb();
  getCircuitBreaker(host);
  db.prepare(`
    UPDATE circuit_breaker_state
    SET state = 'CLOSED',
        error_streak = 0,
        cooldown_until = NULL,
        last_etag = COALESCE(?, last_etag),
        last_modified = COALESCE(?, last_modified),
        last_error = NULL,
        updated_at = ?
    WHERE host = ?
  `).run(etag, lastModified, new Date().toISOString(), host);
}

export function recordHostFailure(host: string, errorMessage: string): CircuitState {
  const db = getControlPlaneDb();
  const current = getCircuitBreaker(host);
  const nextStreak = current.error_streak + 1;
  const open = nextStreak >= 3;
  const state: CircuitState = open ? 'OPEN' : current.state === 'HALF_OPEN' ? 'OPEN' : 'CLOSED';
  const cooldownMs = state === 'OPEN' ? Math.min(30 * 60_000, 5 * 60_000 * Math.pow(2, Math.max(0, nextStreak - 3))) : 0;
  const cooldownUntil = state === 'OPEN' ? new Date(Date.now() + cooldownMs).toISOString() : null;

  db.prepare(`
    UPDATE circuit_breaker_state
    SET state = ?, error_streak = ?, cooldown_until = ?, last_error = ?, updated_at = ?
    WHERE host = ?
  `).run(state, nextStreak, cooldownUntil, errorMessage.slice(0, 400), new Date().toISOString(), host);

  return state;
}

export function resetCircuitBreaker(host?: string): number {
  const db = getControlPlaneDb();
  const now = new Date().toISOString();
  if (host) {
    const info = db
      .prepare(`
        UPDATE circuit_breaker_state
        SET state = 'CLOSED',
            error_streak = 0,
            cooldown_until = NULL,
            last_error = NULL,
            updated_at = ?
        WHERE host = ?
      `)
      .run(now, host);
    return info.changes;
  }
  const info = db
    .prepare(`
      UPDATE circuit_breaker_state
      SET state = 'CLOSED',
          error_streak = 0,
          cooldown_until = NULL,
          last_error = NULL,
          updated_at = ?
      WHERE state != 'CLOSED' OR error_streak > 0
    `)
    .run(now);
  return info.changes;
}

export function startLineageRun(run: Omit<LineageRun, 'finished_at'>): void {
  const db = getControlPlaneDb();
  db.prepare(`
    INSERT INTO lineage_runs (
      run_id, source_id, job_name, status, input_etag, output_snapshot_id,
      rows_in, rows_out, duration_ms, details_json, started_at, finished_at
    ) VALUES (
      @run_id, @source_id, @job_name, @status, @input_etag, @output_snapshot_id,
      @rows_in, @rows_out, @duration_ms, @details_json, @started_at, NULL
    )
  `).run(run);
}

export function finishLineageRun(
  runId: string,
  patch: Partial<Pick<LineageRun, 'status' | 'output_snapshot_id' | 'rows_in' | 'rows_out' | 'duration_ms' | 'details_json'>>
): void {
  const db = getControlPlaneDb();
  db.prepare(`
    UPDATE lineage_runs
    SET status = COALESCE(@status, status),
        output_snapshot_id = COALESCE(@output_snapshot_id, output_snapshot_id),
        rows_in = COALESCE(@rows_in, rows_in),
        rows_out = COALESCE(@rows_out, rows_out),
        duration_ms = COALESCE(@duration_ms, duration_ms),
        details_json = COALESCE(@details_json, details_json),
        finished_at = @finished_at
    WHERE run_id = @run_id
  `).run({
    run_id: runId,
    status: patch.status ?? null,
    output_snapshot_id: patch.output_snapshot_id ?? null,
    rows_in: patch.rows_in ?? null,
    rows_out: patch.rows_out ?? null,
    duration_ms: patch.duration_ms ?? null,
    details_json: patch.details_json ?? null,
    finished_at: new Date().toISOString(),
  });
}

export function registerAndPromoteSnapshot(snapshot: Omit<SnapshotManifest, 'is_active'>): void {
  const db = getControlPlaneDb();
  const tx = db.transaction(() => {
    const active = snapshot.qa_status === 'PASSED' ? 1 : 0;
    if (active === 1) {
      db.prepare(`
        UPDATE snapshot_manifest
        SET is_active = 0
        WHERE source_id = ? AND layer = ? AND is_active = 1
      `).run(snapshot.source_id, snapshot.layer);
    }

    db.prepare(`
      INSERT INTO snapshot_manifest (
        snapshot_id, source_id, dataset_id, layer, parquet_path, sha256,
        row_count, byte_size, qa_status, qa_notes, is_active, created_at
      ) VALUES (
        @snapshot_id, @source_id, @dataset_id, @layer, @parquet_path, @sha256,
        @row_count, @byte_size, @qa_status, @qa_notes, @is_active, @created_at
      )
    `).run({ ...snapshot, is_active: active });

    if (active === 1 && snapshot.layer === 'silver') {
      db.prepare(`
        UPDATE dim_data_sources
        SET last_successful_ingestion = ?, last_verified_at = ?
        WHERE source_id = ?
      `).run(snapshot.created_at, snapshot.created_at, snapshot.source_id);
    }
  });
  tx();
}

export function getActiveSilverSnapshot(sourceId: string): SnapshotManifest | undefined {
  const db = getControlPlaneDb();
  return db
    .prepare(`
      SELECT * FROM snapshot_manifest
      WHERE source_id = ? AND layer = 'silver' AND is_active = 1
      ORDER BY created_at DESC LIMIT 1
    `)
    .get(sourceId) as SnapshotManifest | undefined;
}

export function listActiveSilverParquetPaths(): string[] {
  const db = getControlPlaneDb();
  const rows = db
    .prepare(`
      SELECT parquet_path FROM snapshot_manifest
      WHERE layer = 'silver' AND is_active = 1 AND qa_status = 'PASSED'
    `)
    .all() as Array<{ parquet_path: string }>;
  return rows.map((r) => r.parquet_path).filter((p) => fs.existsSync(p));
}

export function getActiveGoldSnapshotCount(): number {
  const db = getControlPlaneDb();
  const row = db
    .prepare(`SELECT COUNT(*) AS cnt FROM snapshot_manifest WHERE layer = 'gold' AND is_active = 1 AND qa_status = 'PASSED'`)
    .get() as { cnt: number };
  return row.cnt;
}

function walkParquetFiles(dir: string, acc: string[]): void {
  if (!fs.existsSync(dir)) return;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      walkParquetFiles(full, acc);
    } else if (entry.isFile() && entry.name.endsWith('.parquet')) {
      acc.push(full);
    }
  }
}

function pruneEmptySubdirs(dir: string, isRoot = true): void {
  if (!fs.existsSync(dir)) return;
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    if (entry.isDirectory()) {
      pruneEmptySubdirs(path.join(dir, entry.name), false);
    }
  }
  if (!isRoot) {
    try {
      if (fs.readdirSync(dir).length === 0) {
        fs.rmdirSync(dir);
      }
    } catch {
      // ignore non-empty or busy directory
    }
  }
}

export function runControlPlaneMaintenance(keepLastN = 2): {
  prunedSnapshots: number;
  orphansRemoved: number;
  reclaimedBytes: number;
  sweptTmpFiles: number;
  walCheckpointed: boolean;
} {
  const db = getControlPlaneDb();
  const allInactive = db
    .prepare(`
      SELECT snapshot_id, source_id, layer, parquet_path, byte_size
      FROM snapshot_manifest
      WHERE is_active = 0
      ORDER BY source_id ASC, layer ASC, created_at DESC
    `)
    .all() as Array<{
      snapshot_id: string;
      source_id: string;
      layer: string;
      parquet_path: string;
      byte_size: number;
    }>;

  const counters = new Map<string, number>();
  const toDelete: typeof allInactive = [];

  for (const row of allInactive) {
    const key = `${row.source_id}|${row.layer}`;
    const count = counters.get(key) ?? 0;
    counters.set(key, count + 1);
    if (count >= keepLastN) {
      toDelete.push(row);
    }
  }

  let reclaimedBytes = 0;
  const delStmt = db.prepare('DELETE FROM snapshot_manifest WHERE snapshot_id = ?');
  // Commit manifest deletion first. Filesystem writes are not transactional
  // with SQLite; unlinking before COMMIT could leave a live manifest pointing
  // at a missing Parquet file after a database rollback or process crash.
  const tx = db.transaction(() => {
    for (const row of toDelete) delStmt.run(row.snapshot_id);
  });
  tx();

  // Failed unlinks become old untracked orphans and are retried by later maintenance.
  for (const row of toDelete) {
    try {
      if (fs.existsSync(row.parquet_path)) {
        const size = fs.statSync(row.parquet_path).size;
        fs.unlinkSync(row.parquet_path);
        reclaimedBytes += size;
      }
    } catch {
      // Retain the orphan on disk; do not recreate a manifest for a retired snapshot.
    }
  }

  // VACUUM unreferenced orphan Parquet files on disk (inspired by Delta Lake / DuckLake VACUUM)
  const trackedPaths = new Set(
    (db.prepare('SELECT parquet_path FROM snapshot_manifest').all() as Array<{ parquet_path: string }>).map((r) =>
      path.resolve(r.parquet_path)
    )
  );
  let orphansRemoved = 0;
  const cleanupNowMs = Date.now();

  for (const layerDir of ['bronze', 'silver', 'gold']) {
    const rootDir = path.join(DATA_DIR, 'lakehouse', layerDir);
    const filesOnDisk: string[] = [];
    walkParquetFiles(rootDir, filesOnDisk);
    for (const file of filesOnDisk) {
      const resolved = path.resolve(file);
      if (resolved.endsWith('.tmp.parquet')) {
        try {
          const st = fs.statSync(resolved);
          if (isEligibleForOrphanCleanup(st.mtimeMs, cleanupNowMs)) {
            fs.unlinkSync(resolved);
            reclaimedBytes += st.size;
            orphansRemoved++;
          }
        } catch {
          // ignore
        }
        continue;
      }
      if (!trackedPaths.has(resolved)) {
        try {
          const st = fs.statSync(resolved);
          // A finalized file can exist briefly before its manifest is committed.
          // A 24-hour grace period makes concurrent writers safe and still allows
          // eventual cleanup after an abrupt process termination.
          if (!isEligibleForOrphanCleanup(st.mtimeMs, cleanupNowMs)) continue;
          fs.unlinkSync(resolved);
          reclaimedBytes += st.size;
          orphansRemoved++;
        } catch {
          // ignore
        }
      }
    }
    pruneEmptySubdirs(rootDir, true);
  }

  // Sweep orphaned temp files older than 30 minutes
  let sweptTmpFiles = 0;
  const tmpDir = path.join(DATA_DIR, 'tmp');
  const cutoffMs = Date.now() - 24 * 60 * 60_000;
  if (fs.existsSync(tmpDir)) {
    for (const name of fs.readdirSync(tmpDir)) {
      if (name === 'duckdb_spill') continue;
      const full = path.join(tmpDir, name);
      try {
        const st = fs.statSync(full);
        if (st.isFile() && st.mtimeMs < cutoffMs) {
          reclaimedBytes += st.size;
          fs.unlinkSync(full);
          sweptTmpFiles++;
        }
      } catch {
        // ignore
      }
    }
  }

  let walCheckpointed = false;
  try {
    db.pragma('wal_checkpoint(RESTART)');
    walCheckpointed = true;
  } catch {
    walCheckpointed = false;
  }

  return {
    prunedSnapshots: toDelete.length,
    orphansRemoved,
    reclaimedBytes,
    sweptTmpFiles,
    walCheckpointed,
  };
}

export function getControlPlaneOverview() {
  const db = getControlPlaneDb();
  const activeSnapshots = db
    .prepare(
      `SELECT * FROM snapshot_manifest
       WHERE is_active = 1
       ORDER BY CASE layer WHEN 'gold' THEN 0 WHEN 'silver' THEN 1 ELSE 2 END ASC, created_at DESC`
    )
    .all() as SnapshotManifest[];
  const recentInactive = db
    .prepare('SELECT * FROM snapshot_manifest WHERE is_active = 0 ORDER BY created_at DESC LIMIT 60')
    .all() as SnapshotManifest[];
  const snapshots = [...activeSnapshots, ...recentInactive];
  const breakers = db
    .prepare('SELECT * FROM circuit_breaker_state ORDER BY updated_at DESC')
    .all() as CircuitBreakerRecord[];
  const lineage = db
    .prepare('SELECT * FROM lineage_runs ORDER BY started_at DESC LIMIT 100')
    .all() as LineageRun[];
  const dlqCount = (
    db.prepare('SELECT COUNT(*) as cnt FROM dlq_unresolved_entities').get() as { cnt: number }
  ).cnt;
  const recentDlq = db
    .prepare('SELECT * FROM dlq_unresolved_entities ORDER BY id DESC LIMIT 20')
    .all();

  let walBytes = 0;
  const walPath = `${DB_PATH}-wal`;
  try {
    if (fs.existsSync(walPath)) walBytes = fs.statSync(walPath).size;
  } catch {
    walBytes = 0;
  }

  return { snapshots, breakers, lineage, dlqCount, recentDlq, walBytes };
}
