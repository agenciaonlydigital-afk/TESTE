import type { SourceCatalogEntry } from './types.ts';

export type AcquisitionStrategy = 'rest_api' | 'sdmx_api' | 'odata_api' | 'sparql' | 'graphql' | 'bulk_download' | 'protocol_adapter' | 'catalog_discovery';
export type AcquisitionReadiness = 'READY' | 'CREDENTIALS_REQUIRED' | 'CATALOG_ONLY' | 'CONNECTOR_MISSING';
export interface AcquisitionPlanItem {
  source_id: string; module_id: number; module_name: string;
  strategy: AcquisitionStrategy; readiness: AcquisitionReadiness;
  priority: number; max_concurrency: number; rate_limit_rpm: number; reason: string;
}

function strategyFor(source: SourceCatalogEntry): AcquisitionStrategy {
  if (source.source_id === 'overture_maps_geoparquet') return 'catalog_discovery';
  if (source.resource_kind === 'bulk' || source.preferred_mode === 'bulk_file') return 'bulk_download';
  switch (source.preferred_mode) {
    case 'sdmx': return 'sdmx_api'; case 'odata': return 'odata_api';
    case 'sparql': return 'sparql'; case 'graphql': return 'graphql';
    case 'protocol': return 'protocol_adapter'; default: return 'rest_api';
  }
}
function priorityFor(frequency: string): number {
  const f = frequency.toLowerCase();
  if (/real.?time|hourly|daily/.test(f)) return 4;
  if (/weekly|monthly/.test(f)) return 3;
  if (/quarterly|biannual|semiannual/.test(f)) return 2;
  return 1;
}
export function planSourceAcquisition(source: SourceCatalogEntry, connectorAvailable: boolean): AcquisitionPlanItem {
  const strategy = strategyFor(source);
  let readiness: AcquisitionReadiness; let reason: string;
  if (source.implemented_wave1 !== 1) {
    readiness = 'CATALOG_ONLY'; reason = source.known_block_reason ?? 'Catalogued, but not declared implemented in Wave 1.';
  } else if (!connectorAvailable) {
    readiness = 'CONNECTOR_MISSING'; reason = 'Catalog says implemented but no handler is registered; execution must be blocked.';
  } else if (source.access_tier !== 'tier0_keyless') {
    readiness = 'CREDENTIALS_REQUIRED'; reason = source.known_block_reason ?? `Access tier ${source.access_tier} requires credentials or registration.`;
  } else {
    readiness = 'READY';
    reason = strategy === 'catalog_discovery'
      ? 'Existing handler discovers STAC metadata; this is not a full remote GeoParquet ingest.'
      : `Uses the existing source-specific ${strategy} handler; endpoint and parser are preserved.`;
  }
  return { source_id: source.source_id, module_id: source.module_id, module_name: source.module_name, strategy,
    readiness, priority: priorityFor(source.update_frequency), max_concurrency: Math.max(1, source.max_concurrency),
    rate_limit_rpm: Math.max(1, source.rate_limit_rpm), reason };
}
export function buildAcquisitionPlan(sources: SourceCatalogEntry[], hasConnector: (sourceId: string) => boolean): AcquisitionPlanItem[] {
  const rank: Record<AcquisitionReadiness, number> = { READY: 0, CREDENTIALS_REQUIRED: 1, CONNECTOR_MISSING: 2, CATALOG_ONLY: 3 };
  return sources.map((s) => planSourceAcquisition(s, hasConnector(s.source_id))).sort((a,b) => rank[a.readiness]-rank[b.readiness] || b.priority-a.priority || a.module_id-b.module_id || a.source_id.localeCompare(b.source_id));
}
