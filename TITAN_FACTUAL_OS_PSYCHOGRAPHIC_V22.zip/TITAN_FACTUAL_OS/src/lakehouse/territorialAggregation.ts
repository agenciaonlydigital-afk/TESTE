import type { MacroEconomicRow } from './types.ts';

export interface WeightedAggregate {
  value: number | null;
  contributing_countries: number;
}

export interface MetricYearRange {
  year_min: number | null;
  year_max: number | null;
  contributing_countries: number;
}

export interface ContinentalMacroAggregate {
  continent: string;
  country_count: number;
  countries_with_population: number;
  countries_with_gdp: number;
  population_total: number | null;
  gdp_nominal_usd: number | null;
  gdp_per_capita_ppp_2021: number | null;
  countries_with_gdp_per_capita_ppp: number;
  urbanization_pct_population_weighted: number | null;
  countries_with_urbanization: number;
  internet_users_pct_population_weighted: number | null;
  countries_with_internet_users: number;
  metric_year_ranges: {
    gdp_nominal_usd: MetricYearRange;
    gdp_per_capita_ppp_2021: MetricYearRange;
    population_total: MetricYearRange;
    urbanization_pct: MetricYearRange;
    internet_users_pct: MetricYearRange;
  };
  methodology: {
    population: 'sum';
    gdp_nominal_usd: 'sum';
    per_capita_and_population_rates: 'population_weighted_mean';
    temporal_basis: 'latest_available_per_country_and_indicator';
    temporal_warning: string;
    non_additive_metrics_excluded: string[];
  };
}

function metricYearRange(
  rows: MacroEconomicRow[],
  valueKey: 'gdp_nominal_usd' | 'gdp_per_capita_ppp_2021' | 'population_total' | 'urbanization_pct' | 'internet_users_pct',
  yearKey: 'gdp_nominal_usd_year' | 'gdp_per_capita_ppp_2021_year' | 'population_total_year' | 'urbanization_pct_year' | 'internet_users_pct_year'
): MetricYearRange {
  const years = rows
    .filter((row) => row[valueKey] !== null && Number.isFinite(row[valueKey]))
    .map((row) => row[yearKey])
    .filter((year): year is number => typeof year === 'number' && Number.isInteger(year));
  return {
    year_min: years.length ? Math.min(...years) : null,
    year_max: years.length ? Math.max(...years) : null,
    contributing_countries: years.length,
  };
}

function sumKnown(values: Array<number | null | undefined>): number | null {
  const known = values.filter((value): value is number => typeof value === 'number' && Number.isFinite(value));
  return known.length ? known.reduce((total, value) => total + value, 0) : null;
}

export function populationWeightedMean(
  records: Array<{ value: number | null; population: number | null }>
): WeightedAggregate {
  let weightedSum = 0;
  let populationSum = 0;
  let contributingCountries = 0;

  for (const record of records) {
    if (
      record.value === null || record.population === null ||
      !Number.isFinite(record.value) || !Number.isFinite(record.population) || record.population <= 0
    ) continue;

    weightedSum += record.value * record.population;
    populationSum += record.population;
    contributingCountries++;
  }

  return {
    value: populationSum > 0 ? weightedSum / populationSum : null,
    contributing_countries: contributingCountries,
  };
}

/**
 * Adds only additive quantities and population-weights rates/per-capita indicators.
 * Country-level values are each the latest available value for that indicator;
 * they may belong to different reporting years, which is exposed in the output.
 */
export function aggregateContinentalMacroRows(rows: MacroEconomicRow[]): ContinentalMacroAggregate[] {
  const groups = new Map<string, MacroEconomicRow[]>();
  for (const row of rows) {
    const continent = row.continent || 'Unclassified';
    const group = groups.get(continent) ?? [];
    group.push(row);
    groups.set(continent, group);
  }

  return [...groups.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([continent, countries]) => {
    const ppp = populationWeightedMean(countries.map((country) => ({
      value: country.gdp_per_capita_ppp_2021,
      population: country.population_total,
    })));
    const urbanization = populationWeightedMean(countries.map((country) => ({
      value: country.urbanization_pct,
      population: country.population_total,
    })));
    const internet = populationWeightedMean(countries.map((country) => ({
      value: country.internet_users_pct,
      population: country.population_total,
    })));
    const metricYearRanges = {
      gdp_nominal_usd: metricYearRange(countries, 'gdp_nominal_usd', 'gdp_nominal_usd_year'),
      gdp_per_capita_ppp_2021: metricYearRange(countries, 'gdp_per_capita_ppp_2021', 'gdp_per_capita_ppp_2021_year'),
      population_total: metricYearRange(countries, 'population_total', 'population_total_year'),
      urbanization_pct: metricYearRange(countries, 'urbanization_pct', 'urbanization_pct_year'),
      internet_users_pct: metricYearRange(countries, 'internet_users_pct', 'internet_users_pct_year'),
    };

    return {
      continent,
      country_count: countries.length,
      countries_with_population: countries.filter((country) => country.population_total !== null).length,
      countries_with_gdp: countries.filter((country) => country.gdp_nominal_usd !== null).length,
      population_total: sumKnown(countries.map((country) => country.population_total)),
      gdp_nominal_usd: sumKnown(countries.map((country) => country.gdp_nominal_usd)),
      gdp_per_capita_ppp_2021: ppp.value,
      countries_with_gdp_per_capita_ppp: ppp.contributing_countries,
      urbanization_pct_population_weighted: urbanization.value,
      countries_with_urbanization: urbanization.contributing_countries,
      internet_users_pct_population_weighted: internet.value,
      countries_with_internet_users: internet.contributing_countries,
      metric_year_ranges: metricYearRanges,
      methodology: {
        population: 'sum',
        gdp_nominal_usd: 'sum',
        per_capita_and_population_rates: 'population_weighted_mean',
        temporal_basis: 'latest_available_per_country_and_indicator',
        temporal_warning: 'Each metric exposes its own country-level observation-year range and contributing-country count. Values should not be interpreted as a same-year continental snapshot unless the ranges align.',
        non_additive_metrics_excluded: [
          'unemployment_pct', 'life_expectancy_years', 'gini_index', 'inflation_cpi_pct',
          'government_indices', 'market_attractiveness_score',
        ],
      },
    };
  });
}
