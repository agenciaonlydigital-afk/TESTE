import { DuckDBInstance, type DuckDBConnection } from '@duckdb/node-api';
import fs from 'node:fs';
import path from 'node:path';
import type { TerritoryCanonical } from './types.ts';
import { recordDuckDBLatency } from './duckdbMetrics.ts';
export { getDuckDBMetrics, recordDuckDBLatency } from './duckdbMetrics.ts';

let instancePromise: Promise<DuckDBInstance> | null = null;
let extensionStatus = {
  spatial: false,
  h3: false,
  httpfs: false,
};

const configuredTempDir = process.env.TITAN_DUCKDB_TEMP_DIRECTORY?.trim();
const TEMP_DIR = configuredTempDir ? path.resolve(configuredTempDir) : path.resolve(process.cwd(), 'data', 'tmp', 'duckdb_spill');

function getDuckDBRuntimeOptions(): Record<string, string> {
  const configuredThreads = process.env.TITAN_DUCKDB_THREADS?.trim();
  const parsedThreads = configuredThreads ? Number(configuredThreads) : 2;
  if (!Number.isInteger(parsedThreads) || parsedThreads < 1) {
    throw new Error('TITAN_DUCKDB_THREADS must be an integer between 1 and 16.');
  }
  const threads = Math.min(16, parsedThreads);
  const memoryLimit = process.env.TITAN_DUCKDB_MEMORY_LIMIT?.trim() || '1GB';
  if (!/^\d+(?:\.\d+)?(?:KB|MB|GB|TB)$/i.test(memoryLimit)) {
    throw new Error('TITAN_DUCKDB_MEMORY_LIMIT must be a size such as 512MB, 2GB or 1TB.');
  }
  return { threads: String(threads), memory_limit: memoryLimit, temp_directory: TEMP_DIR };
}

export async function getDuckDBInstance(): Promise<DuckDBInstance> {
  if (!instancePromise) {
    fs.mkdirSync(TEMP_DIR, { recursive: true });
    instancePromise = DuckDBInstance.create(':memory:', getDuckDBRuntimeOptions());
  }
  return instancePromise;
}

export async function closeDuckDBInstance(): Promise<void> {
  if (!instancePromise) return;
  try {
    const inst = await instancePromise;
    const maybeClosable = inst as unknown as { closeSync?: () => void };
    if (typeof maybeClosable.closeSync === 'function') {
      maybeClosable.closeSync();
    }
  } catch {
    // ignore close error during shutdown
  } finally {
    instancePromise = null;
  }
}

export async function withDuckDBConnection<T>(
  fn: (conn: DuckDBConnection) => Promise<T>,
  options: { loadSpatial?: boolean; loadH3?: boolean; disableInsertionOrder?: boolean } = {}
): Promise<T> {
  const inst = await getDuckDBInstance();
  const conn = await inst.connect();
  const startedMs = Date.now();
  try {
    if (options.disableInsertionOrder) {
      await conn.run('SET preserve_insertion_order = false;');
    }
    if (options.loadSpatial) {
      try {
        await conn.run('LOAD spatial;');
        extensionStatus.spatial = true;
      } catch {
        try {
          await conn.run('INSTALL spatial; LOAD spatial;');
          extensionStatus.spatial = true;
        } catch {
          extensionStatus.spatial = false;
        }
      }
    }
    if (options.loadH3) {
      try {
        await conn.run('LOAD h3;');
        extensionStatus.h3 = true;
      } catch {
        try {
          await conn.run('INSTALL h3 FROM community; LOAD h3;');
          extensionStatus.h3 = true;
        } catch {
          extensionStatus.h3 = false;
        }
      }
    }
    return await fn(conn);
  } finally {
    recordDuckDBLatency(Date.now() - startedMs);
    conn.closeSync();
  }
}

export async function probeDuckDBCapabilities(): Promise<{
  spatial: boolean;
  h3: boolean;
  httpfs: boolean;
  version: string;
}> {
  return withDuckDBConnection(async (conn) => {
    const verReader = await conn.runAndReadAll('SELECT version() AS v;');
    const versionRows = verReader.getRowObjectsJson();
    const version = String(versionRows[0]?.v ?? 'unknown');

    try {
      await conn.run('LOAD spatial;');
      extensionStatus.spatial = true;
    } catch {
      try {
        await conn.run('INSTALL spatial; LOAD spatial;');
        extensionStatus.spatial = true;
      } catch {
        extensionStatus.spatial = false;
      }
    }

    try {
      await conn.run('LOAD h3;');
      extensionStatus.h3 = true;
    } catch {
      try {
        await conn.run('INSTALL h3 FROM community; LOAD h3;');
        extensionStatus.h3 = true;
      } catch {
        extensionStatus.h3 = false;
      }
    }

    try {
      await conn.run('LOAD httpfs;');
      extensionStatus.httpfs = true;
    } catch {
      try {
        await conn.run('INSTALL httpfs; LOAD httpfs;');
        extensionStatus.httpfs = true;
      } catch {
        extensionStatus.httpfs = false;
      }
    }

    return { ...extensionStatus, version };
  });
}

export function getExtensionStatus() {
  return { ...extensionStatus };
}

export function sqlQuote(value: string): string {
  return `'${value.replace(/'/g, "''")}'`;
}

export async function writeRecordsToParquet(
  ndjsonTmpPath: string,
  targetParquetPath: string,
  orderByClause?: string
): Promise<{ rowCount: number; byteSize: number }> {
  fs.mkdirSync(path.dirname(targetParquetPath), { recursive: true });
  const tmpParquetPath = `${targetParquetPath}.tmp.parquet`;

  return withDuckDBConnection(
    async (conn) => {
      try {
        const orderSql = orderByClause ? `ORDER BY ${orderByClause}` : '';
        await conn.run(`
          COPY (
            SELECT * FROM read_json_auto(${sqlQuote(ndjsonTmpPath)}, format='newline_delimited')
            ${orderSql}
          ) TO ${sqlQuote(tmpParquetPath)}
          (FORMAT PARQUET, COMPRESSION ZSTD, ROW_GROUP_SIZE 100000);
        `);

        const countReader = await conn.runAndReadAll(
          `SELECT COUNT(*) AS cnt FROM read_parquet(${sqlQuote(tmpParquetPath)});`
        );
        const rows = countReader.getRowObjectsJson();
        const rowCount = Number(rows[0]?.cnt ?? 0);

        fs.renameSync(tmpParquetPath, targetParquetPath);
        const stat = fs.statSync(targetParquetPath);

        return { rowCount, byteSize: stat.size };
      } catch (err) {
        try {
          if (fs.existsSync(tmpParquetPath)) fs.unlinkSync(tmpParquetPath);
        } catch {
          // ignore cleanup failure
        }
        throw err;
      }
    },
    { disableInsertionOrder: !orderByClause }
  );
}

export async function computeTerritoryH3Cells(
  territories: TerritoryCanonical[]
): Promise<Array<{ territory_id: string; h3_res2: string; h3_res4: string }>> {
  const valid = territories.filter(
    (t) => Number.isFinite(t.centroid_lat) && Number.isFinite(t.centroid_lon)
  );
  if (valid.length === 0) return [];

  return withDuckDBConnection(
    async (conn) => {
      if (!extensionStatus.h3) {
        return [];
      }
      const valuesSql = valid
        .map(
          (t) =>
            `(${sqlQuote(t.territory_id)}, ${Number(t.centroid_lat)}, ${Number(t.centroid_lon)})`
        )
        .join(', ');

      const reader = await conn.runAndReadAll(`
        WITH pts(territory_id, lat, lon) AS (VALUES ${valuesSql})
        SELECT
          territory_id,
          h3_h3_to_string(h3_latlng_to_cell(lat, lon, 2)) AS h3_res2,
          h3_h3_to_string(h3_latlng_to_cell(lat, lon, 4)) AS h3_res4
        FROM pts;
      `);
      const rows = reader.getRowObjectsJson() as Array<{
        territory_id?: unknown;
        h3_res2?: unknown;
        h3_res4?: unknown;
      }>;
      return rows
        .filter(
          (r) =>
            typeof r.territory_id === 'string' &&
            typeof r.h3_res2 === 'string' &&
            typeof r.h3_res4 === 'string'
        )
        .map((r) => ({
          territory_id: r.territory_id as string,
          h3_res2: r.h3_res2 as string,
          h3_res4: r.h3_res4 as string,
        }));
    },
    { loadH3: true }
  );
}

export async function computePointH3Cells(
  points: Array<{ node_id: string; lat: number; lon: number; res: number }>
): Promise<Map<string, string>> {
  const out = new Map<string, string>();
  const valid = points.filter(
    (p) =>
      Number.isFinite(p.lat) &&
      Number.isFinite(p.lon) &&
      p.lat >= -90 &&
      p.lat <= 90 &&
      p.lon >= -180 &&
      p.lon <= 180
  );
  if (valid.length === 0) return out;

  await withDuckDBConnection(
    async (conn) => {
      if (!extensionStatus.h3) return;
      const chunkSize = 400;
      for (let i = 0; i < valid.length; i += chunkSize) {
        const slice = valid.slice(i, i + chunkSize);
        const valuesSql = slice
          .map(
            (p) =>
              `(${sqlQuote(p.node_id)}, ${Number(p.lat)}, ${Number(p.lon)}, ${Math.trunc(p.res)})`
          )
          .join(', ');
        const reader = await conn.runAndReadAll(`
          WITH pts(node_id, lat, lon, res) AS (VALUES ${valuesSql})
          SELECT
            node_id,
            h3_h3_to_string(h3_latlng_to_cell(lat, lon, res)) AS h3_index
          FROM pts;
        `);
        try {
          const rows = reader.getRowObjectsJson() as Array<{ node_id?: unknown; h3_index?: unknown }>;
          for (const r of rows) {
            if (typeof r.node_id === 'string' && typeof r.h3_index === 'string') {
              out.set(r.node_id, r.h3_index);
            }
          }
        } finally {
          reader.closeSync();
        }
      }
    },
    { loadH3: true }
  );

  return out;
}

