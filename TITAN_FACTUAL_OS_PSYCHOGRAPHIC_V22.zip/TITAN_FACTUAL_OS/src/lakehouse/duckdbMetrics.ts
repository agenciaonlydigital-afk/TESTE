const LATENCY_SAMPLE_LIMIT = 256;
const queryLatenciesMs: number[] = [];
let latencyWriteIndex = 0;

export function recordDuckDBLatency(durationMs: number): void {
  if (!Number.isFinite(durationMs) || durationMs < 0) return;
  if (queryLatenciesMs.length < LATENCY_SAMPLE_LIMIT) {
    queryLatenciesMs.push(durationMs);
    return;
  }
  queryLatenciesMs[latencyWriteIndex] = durationMs;
  latencyWriteIndex = (latencyWriteIndex + 1) % LATENCY_SAMPLE_LIMIT;
}

export function getDuckDBMetrics(): { queryCount: number; avgMs: number; p95Ms: number } {
  if (queryLatenciesMs.length === 0) return { queryCount: 0, avgMs: 0, p95Ms: 0 };
  const sorted = [...queryLatenciesMs].sort((a, b) => a - b);
  const sum = sorted.reduce((acc, value) => acc + value, 0);
  const p95Index = Math.min(sorted.length - 1, Math.floor(sorted.length * 0.95));
  return {
    queryCount: sorted.length,
    avgMs: Math.round(sum / sorted.length),
    p95Ms: Math.round(sorted[p95Index]),
  };
}
