export interface ObservationIdentityInput {
  territory_id: string;
  indicator_id: string;
  period_year: number;
  survey_id?: string | null;
  survey_wave_id?: string | null;
  question_id?: string | null;
  response_category?: string | null;
  sex?: string | null;
  age_group?: string | null;
  education_level?: string | null;
  income_group?: string | null;
  urban_rural?: string | null;
  sampling_stratum?: string | null;
  cluster_id?: string | null;
  population_scope?: string | null;
  weighting_method?: string | null;
  fieldwork_start?: string | null;
  fieldwork_end?: string | null;
}

/**
 * Stable Silver observation key. Survey wave/question/category and demographic
 * strata are dimensions, not duplicates, and therefore remain distinct rows.
 */
export function buildObservationIdentity(row: ObservationIdentityInput): string {
  const dimensions = [
    row.survey_id, row.survey_wave_id, row.question_id, row.response_category,
    row.sex, row.age_group, row.education_level, row.income_group, row.urban_rural,
    row.sampling_stratum, row.cluster_id, row.population_scope, row.weighting_method,
    row.fieldwork_start, row.fieldwork_end,
  ];
  return [row.territory_id, row.indicator_id, row.period_year, ...dimensions]
    .map((value) => encodeURIComponent(value == null ? '' : String(value)))
    .join('|');
}
