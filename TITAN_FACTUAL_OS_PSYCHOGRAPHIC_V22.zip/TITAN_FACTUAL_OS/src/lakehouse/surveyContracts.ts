import { z } from 'zod';
export const SurveyRegistrySchema = z.object({
  survey_id:z.string().min(2), title:z.string().min(3), provider:z.string().min(2), wave_id:z.string().min(1),
  country_iso3:z.string().length(3), target_population:z.string().min(3), sample_size:z.number().int().positive().nullable(),
  sampling_design:z.string().min(3), weighting_method:z.string().min(3).nullable(),
  fieldwork_start:z.string().date().nullable(), fieldwork_end:z.string().date().nullable(),
  questionnaire_url:z.string().url().nullable(), dataset_url:z.string().url().nullable(),
  license_id:z.string().min(2), commercial_use_allowed:z.enum(['confirmed','denied','unknown']),
  redistribution_allowed:z.enum(['confirmed','denied','unknown']), source_id:z.string().min(2),
});
export const SurveyQuestionSchema = z.object({
  survey_id:z.string().min(2), wave_id:z.string().min(1), question_id:z.string().min(1), construct_id:z.string().min(2),
  question_text:z.string().min(3), response_scale:z.string().min(2),
  response_direction:z.enum(['higher_is_more','higher_is_less','categorical','unknown']),
  comparable_across_waves:z.boolean(), harmonization_method:z.string().nullable(),
});
export const PsychographicConstructSchema = z.object({
  construct_id:z.string().min(2), name:z.string().min(3), definition:z.string().min(10),
  construct_family:z.enum(['values','trust','norms','identity','attitudes','wellbeing','risk_perception','other']),
  measurement_policy:z.string().min(10), prohibited_inferences:z.array(z.string()).default([]),
});

/** Versioned estimates are separate from source registry records and raw microdata. */
export const SurveyEstimateSchema = z.object({
  survey_id: z.string().min(2), wave_id: z.string().min(1), country_iso3: z.string().regex(/^[A-Z]{3}$/),
  question_id: z.string().min(1), sample_size: z.number().int().positive(),
  weighted_mean: z.number().finite(), sum_weights: z.number().finite().positive(),
  kish_effective_sample_size: z.number().finite().positive(), strata_count: z.number().int().nonnegative(),
  psu_count: z.number().int().nonnegative(), standard_error: z.number().finite().nonnegative().nullable(),
  confidence_interval_95: z.object({ lower: z.number().finite(), upper: z.number().finite() }).nullable(),
  variance_status: z.enum(['available_taylor_linearization_wr_first_stage', 'unavailable_design_metadata', 'unavailable_singleton_stratum']),
  variance_method: z.string().min(3), minimum_effective_sample_size: z.number().positive(),
  meets_effective_sample_threshold: z.boolean(), warnings: z.array(z.string()), estimation_notes: z.array(z.string()),
}).refine((estimate) => estimate.confidence_interval_95 === null || estimate.confidence_interval_95.lower <= estimate.confidence_interval_95.upper,
  { message: 'confidence interval lower bound must be <= upper bound', path: ['confidence_interval_95'] })
  .refine((estimate) => estimate.kish_effective_sample_size <= estimate.sample_size + 1e-6,
    { message: 'Kish effective sample size cannot exceed sample size', path: ['kish_effective_sample_size'] })
  .refine((estimate) => estimate.psu_count <= estimate.sample_size && estimate.strata_count <= estimate.psu_count,
    { message: 'survey design counts are inconsistent', path: ['psu_count'] })
  .refine((estimate) => estimate.meets_effective_sample_threshold === (estimate.kish_effective_sample_size >= estimate.minimum_effective_sample_size),
    { message: 'effective-sample threshold flag is inconsistent', path: ['meets_effective_sample_threshold'] })
  .refine((estimate) => estimate.variance_status === 'available_taylor_linearization_wr_first_stage'
    ? estimate.standard_error !== null && estimate.confidence_interval_95 !== null && estimate.strata_count > 0 && estimate.psu_count > estimate.strata_count
    : estimate.standard_error === null && estimate.confidence_interval_95 === null,
    { message: 'variance status, design counts and interval fields are inconsistent', path: ['variance_status'] });
