export type EmptyConnectorDisposition =
  | { status: 'UP_TO_DATE_304'; reason: string }
  | { status: 'FAILED'; reason: string };

/**
 * An empty parser result is never treated as a successful 304 unless the connector
 * explicitly confirms that every required HTTP request was not modified.
 */
export function classifyEmptyConnectorOutcome(input: {
  rawRowCount: number;
  notModified: boolean;
}): EmptyConnectorDisposition {
  if (!Number.isInteger(input.rawRowCount) || input.rawRowCount < 0) {
    throw new RangeError('rawRowCount must be a non-negative integer');
  }
  if (input.rawRowCount === 0 && input.notModified) {
    return {
      status: 'UP_TO_DATE_304',
      reason: 'All required source requests returned HTTP 304.',
    };
  }
  return {
    status: 'FAILED',
    reason: input.rawRowCount > 0
      ? `Connector parsed ${input.rawRowCount} raw rows but produced zero valid Silver observations.`
      : 'Connector produced no observations without an explicit HTTP 304 confirmation.',
  };
}
