/**
 * File cleanup deliberately uses a long grace period. Connectors may download
 * or transform large public datasets for hours; short TTLs can delete live work.
 */
export const ORPHAN_FILE_GRACE_MS = 24 * 60 * 60_000;

export function isEligibleForOrphanCleanup(
  modifiedAtMs: number,
  nowMs = Date.now(),
  graceMs = ORPHAN_FILE_GRACE_MS,
): boolean {
  if (!Number.isFinite(modifiedAtMs) || !Number.isFinite(nowMs)) return false;
  if (!Number.isFinite(graceMs) || graceMs < 0) return false;
  return modifiedAtMs <= nowMs - graceMs;
}
