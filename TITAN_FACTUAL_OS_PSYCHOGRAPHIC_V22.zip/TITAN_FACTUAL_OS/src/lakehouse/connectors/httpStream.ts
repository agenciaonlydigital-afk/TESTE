import { createHash } from 'node:crypto';
import { createWriteStream } from 'node:fs';
import { mkdir, open, rm } from 'node:fs/promises';
import path from 'node:path';
import { Readable, Transform } from 'node:stream';
import { pipeline } from 'node:stream/promises';

export interface StreamedBodyResult {
  sha256: string;
  byteSize: number;
}

/**
 * Streams an HTTP response body to an exclusively-created file while hashing.
 * The file is synced before success is returned. On failure, only the file
 * created by this invocation is removed, including early-open/abort races.
 */
export async function streamBodyToDiskWithHash(
  body: ReadableStream<Uint8Array>,
  destPath: string,
  signal?: AbortSignal,
): Promise<StreamedBodyResult> {
  await mkdir(path.dirname(destPath), { recursive: true });
  const fileHandle = await open(destPath, 'wx');
  const hash = createHash('sha256');
  let byteSize = 0;
  const source = Readable.fromWeb(body as unknown as import('node:stream/web').ReadableStream);
  const hasher = new Transform({
    transform(chunk: Buffer | Uint8Array, _encoding, callback) {
      const bytes = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
      hash.update(bytes);
      byteSize += bytes.byteLength;
      callback(null, bytes);
    },
  });
  const destination = createWriteStream(destPath, { fd: fileHandle.fd, autoClose: false });

  try {
    if (signal) await pipeline(source, hasher, destination, { signal });
    else await pipeline(source, hasher, destination);
    await fileHandle.sync();
    await fileHandle.close();
    return { sha256: hash.digest('hex'), byteSize };
  } catch (error) {
    source.destroy();
    hasher.destroy();
    destination.destroy();
    await fileHandle.close().catch(() => undefined);
    await rm(destPath, { force: true }).catch(() => undefined);
    throw error;
  }
}
