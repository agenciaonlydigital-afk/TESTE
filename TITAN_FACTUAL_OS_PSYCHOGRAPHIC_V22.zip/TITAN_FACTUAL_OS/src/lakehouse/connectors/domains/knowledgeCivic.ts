import fs from 'node:fs';
import { listTerritories, resolveTerritoryByCodeOrName } from '../../controlPlane.ts';
import { fetchWithCitizenship } from '../../httpCitizenship.ts';
import type { ObservationContract, SourceCatalogEntry } from '../../types.ts';
import { ingestOwidDatasets } from '../factories/owidCsvConnector.ts';
import {
  safeUnlink,
  shouldBypassConditionalCache,
  type ConnectorOutcome,
} from '../shared.ts';

export async function ingestUnescoUis(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const geoParams = listTerritories()
    .map((t) => `geoUnit=${encodeURIComponent(t.iso3)}`)
    .join('&');
  const url = `https://api.uis.unesco.org/api/public/data/indicators?indicator=EXPGDP.TOT&indicator=MYS.1T8.AG25T99&indicator=20001&${geoParams}&start=2019&end=2024`;

  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'unesco_uis_v1',
    timeoutMs: 20_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const indicatorMeta: Record<
    string,
    {
      indicatorId: string;
      indicatorName: string;
      unit: string;
      basis: ObservationContract['valuation_basis'];
    }
  > = {
    'EXPGDP.TOT': {
      indicatorId: 'UIS.GERD_PCT_GDP',
      indicatorName: 'R&D Expenditure GERD (% of GDP, UNESCO UIS)',
      unit: '% of GDP',
      basis: 'percent',
    },
    'MYS.1T8.AG25T99': {
      indicatorId: 'UIS.MEAN_SCHOOLING_YRS',
      indicatorName: 'Mean Years of Schooling, Population 25+ (UNESCO UIS)',
      unit: 'years',
      basis: 'count',
    },
    '20001': {
      indicatorId: 'UIS.RESEARCHERS_FTE',
      indicatorName: 'Total R&D Researchers FTE (UNESCO UIS)',
      unit: 'FTE researchers',
      basis: 'count',
    },
  };

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const dedupKeys = new Set<string>();

  try {
    const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
      records?: Array<{
        indicatorId?: string;
        geoUnit?: string;
        year?: number;
        value?: number | null;
      }>;
    };

    for (const r of json.records ?? []) {
      if (!r.indicatorId || !r.geoUnit || typeof r.year !== 'number' || typeof r.value !== 'number') continue;
      if (!Number.isFinite(r.value)) continue;
      const meta = indicatorMeta[r.indicatorId];
      if (!meta) continue;

      const territory = resolveTerritoryByCodeOrName(r.geoUnit);
      if (!territory) continue;

      const key = `${territory.territory_id}|${meta.indicatorId}|${r.year}`;
      if (dedupKeys.has(key)) continue;
      dedupKeys.add(key);

      rawRows.push(r);
      silver.push({
        territory_id: territory.territory_id,
        iso3: territory.iso3,
        indicator_id: meta.indicatorId,
        indicator_name: meta.indicatorName,
        module_id: 10,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: r.year,
        value_numeric: Number(r.value.toFixed(3)),
        unit: meta.unit,
        valuation_basis: meta.basis,
        methodology_id: 'UNESCO_UIS_PUBLIC_API_V1',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestUnescoUisBulk(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const geoParams = listTerritories()
    .map((t) => `geoUnit=${t.iso3}`)
    .join('&');
  const url = `https://api.uis.unesco.org/api/public/data/indicators?indicator=LR.AG15T99&indicator=XGDP.FSGOV&indicator=CR.1&${geoParams}&start=2018&end=2024`;

  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'unesco_uis_edu_bulk',
    timeoutMs: 25_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const indicatorMeta: Record<
    string,
    {
      indicatorId: string;
      indicatorName: string;
      unit: string;
      basis: ObservationContract['valuation_basis'];
    }
  > = {
    'XGDP.FSGOV': {
      indicatorId: 'UIS_EDU.GOV_EXP_PCT_GDP',
      indicatorName: 'Government Expenditure on Education (% of GDP, UNESCO UIS)',
      unit: '% of GDP',
      basis: 'percent',
    },
    'LR.AG15T99': {
      indicatorId: 'UIS_EDU.ADULT_LITERACY_PCT',
      indicatorName: 'Adult Literacy Rate, Population 15+ Years % (UNESCO UIS)',
      unit: '%',
      basis: 'percent',
    },
    'CR.1': {
      indicatorId: 'UIS_EDU.PRIMARY_COMPLETION_PCT',
      indicatorName: 'Primary Education Completion Rate % (UNESCO UIS)',
      unit: '%',
      basis: 'percent',
    },
  };

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const dedupKeys = new Set<string>();

  try {
    const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
      records?: Array<{
        indicatorId?: string;
        geoUnit?: string;
        year?: number;
        value?: number | null;
      }>;
    };

    for (const r of json.records ?? []) {
      if (!r.indicatorId || !r.geoUnit || typeof r.year !== 'number' || typeof r.value !== 'number') continue;
      if (!Number.isFinite(r.value)) continue;
      const meta = indicatorMeta[r.indicatorId];
      if (!meta) continue;

      const territory = resolveTerritoryByCodeOrName(r.geoUnit);
      if (!territory) continue;

      const key = `${territory.territory_id}|${meta.indicatorId}|${r.year}`;
      if (dedupKeys.has(key)) continue;
      dedupKeys.add(key);

      rawRows.push(r);
      silver.push({
        territory_id: territory.territory_id,
        iso3: territory.iso3,
        indicator_id: meta.indicatorId,
        indicator_name: meta.indicatorName,
        module_id: 10,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: r.year,
        value_numeric: Number(r.value.toFixed(2)),
        unit: meta.unit,
        valuation_basis: meta.basis,
        methodology_id: 'UNESCO_UIS_EDU_LITERACY_COHORTS',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestOpenAlexWorks(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);

  const totalUrl =
    'https://api.openalex.org/works?group_by=authorships.countries&filter=publication_year:2024&mailto=research@titan-factual.local';
  const oaUrl =
    'https://api.openalex.org/works?group_by=authorships.countries&filter=publication_year:2024,is_oa:true&mailto=research@titan-factual.local';

  const [totalRes, oaRes] = await Promise.all([
    fetchWithCitizenship({
      url: totalUrl,
      host: source.host,
      rateLimitRpm: source.rate_limit_rpm,
      maxConcurrency: source.max_concurrency,
      bypassConditionalCache: bypassCache,
      destPrefix: 'openalex_2024_total',
      timeoutMs: 20_000,
    }),
    fetchWithCitizenship({
      url: oaUrl,
      host: source.host,
      rateLimitRpm: source.rate_limit_rpm,
      maxConcurrency: source.max_concurrency,
      bypassConditionalCache: bypassCache,
      destPrefix: 'openalex_2024_oa',
      timeoutMs: 20_000,
    }),
  ]);

  let lastEtag: string | null = totalRes.etag ?? oaRes.etag;
  const dedupHit = totalRes.dedupHit || oaRes.dedupHit;

  let totalPath = totalRes.filePath;
  let oaPath = oaRes.filePath;

  if (!totalPath && !oaPath && !bypassCache) {
    return { rawRows: [], silver: [], etag: lastEtag, dedupHit, notModified: totalRes.status === 'NOT_MODIFIED' && oaRes.status === 'NOT_MODIFIED' };
  }

  if (!totalPath && totalRes.status === 'NOT_MODIFIED') {
    const hydrateTotal = await fetchWithCitizenship({
      url: totalUrl,
      host: source.host,
      rateLimitRpm: source.rate_limit_rpm,
      maxConcurrency: source.max_concurrency,
      bypassConditionalCache: true,
      destPrefix: 'openalex_2024_total_full',
      timeoutMs: 20_000,
    });
    totalPath = hydrateTotal.filePath;
    if (hydrateTotal.etag) lastEtag = hydrateTotal.etag;
  }
  if (!oaPath && oaRes.status === 'NOT_MODIFIED') {
    const hydrateOa = await fetchWithCitizenship({
      url: oaUrl,
      host: source.host,
      rateLimitRpm: source.rate_limit_rpm,
      maxConcurrency: source.max_concurrency,
      bypassConditionalCache: true,
      destPrefix: 'openalex_2024_oa_full',
      timeoutMs: 20_000,
    });
    oaPath = hydrateOa.filePath;
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];

  try {
    const totalByTerritory = new Map<string, { iso3: string; total: number }>();
    if (totalPath) {
      const json = JSON.parse(fs.readFileSync(totalPath, 'utf-8')) as {
        group_by?: Array<{ key?: string; key_display_name?: string; count?: number }>;
      };
      for (const item of json.group_by ?? []) {
        const iso2 = item.key?.split('/').pop()?.trim() ?? '';
        const count = typeof item.count === 'number' && Number.isFinite(item.count) ? item.count : null;
        if (!iso2 || count === null) continue;
        const territory =
          resolveTerritoryByCodeOrName(iso2) ??
          (item.key_display_name ? resolveTerritoryByCodeOrName(item.key_display_name) : undefined);
        if (!territory) continue;
        rawRows.push({ split: 'total_2024', iso3: territory.iso3, count });
        totalByTerritory.set(territory.territory_id, { iso3: territory.iso3, total: count });
      }
    }

    const oaByTerritory = new Map<string, number>();
    if (oaPath) {
      const json = JSON.parse(fs.readFileSync(oaPath, 'utf-8')) as {
        group_by?: Array<{ key?: string; key_display_name?: string; count?: number }>;
      };
      for (const item of json.group_by ?? []) {
        const iso2 = item.key?.split('/').pop()?.trim() ?? '';
        const count = typeof item.count === 'number' && Number.isFinite(item.count) ? item.count : null;
        if (!iso2 || count === null) continue;
        const territory =
          resolveTerritoryByCodeOrName(iso2) ??
          (item.key_display_name ? resolveTerritoryByCodeOrName(item.key_display_name) : undefined);
        if (!territory) continue;
        rawRows.push({ split: 'oa_2024', iso3: territory.iso3, count });
        oaByTerritory.set(territory.territory_id, count);
      }
    }

    for (const [territoryId, entry] of totalByTerritory.entries()) {
      silver.push({
        territory_id: territoryId,
        iso3: entry.iso3,
        indicator_id: 'OPENALEX.WORKS_COUNT_2024',
        indicator_name: 'Scholarly Research Works Published in 2024 (OpenAlex REST)',
        module_id: 10,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: 2024,
        value_numeric: Math.round(entry.total),
        unit: 'works',
        valuation_basis: 'count',
        methodology_id: 'OPENALEX_WORKS_GROUP_BY_COUNTRY',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });

      const oaCount = oaByTerritory.get(territoryId);
      if (typeof oaCount === 'number' && entry.total > 0) {
        const oaPct = Math.min(100, (oaCount / entry.total) * 100);
        silver.push({
          territory_id: territoryId,
          iso3: entry.iso3,
          indicator_id: 'OPENALEX.OPEN_ACCESS_PCT',
          indicator_name: 'Open Access Share of 2024 Scholarly Works % (OpenAlex REST)',
          module_id: 10,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: 2024,
          value_numeric: Number(oaPct.toFixed(2)),
          unit: '%',
          valuation_basis: 'percent',
          methodology_id: 'OPENALEX_WORKS_GROUP_BY_COUNTRY',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    }
  } finally {
    if (totalPath) safeUnlink(totalPath);
    if (oaPath) safeUnlink(oaPath);
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestCrossrefPolite(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const url =
    'https://api.crossref.org/works?rows=10&filter=from-pub-date:2025-01-01&mailto=research@titan-factual.local';
  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'crossref_polite',
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  try {
    const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
      message?: { 'total-results'?: number; items?: Array<{ DOI?: string; type?: string }> };
    };
    const totalResults = json.message?.['total-results'] ?? 0;
    rawRows.push({ total_results: totalResults, sample_items: json.message?.items?.slice(0, 5) ?? [] });

    if (totalResults > 0) {
      silver.push({
        territory_id: 'T_USA',
        iso3: 'USA',
        indicator_id: 'CROSSREF.GLOBAL_WORKS_COUNT',
        indicator_name: 'Crossref Recent Global Works Velocity (Polite Pool)',
        module_id: 10,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: 2025,
        value_numeric: totalResults,
        unit: 'works',
        valuation_basis: 'count',
        methodology_id: 'CROSSREF_POLITE_POOL',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestDataciteRest(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();
  const bypassCache = shouldBypassConditionalCache(source.source_id);

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  let lastEtag: string | null = null;
  let dedupHit = false;

  const totals = new Map<string, { iso3: string; dois: number; repos: number }>();

  let page = 1;
  let totalPages = 1;
  while (page <= Math.min(totalPages, 8)) {
    const url = `https://api.datacite.org/providers?page[size]=500&page[number]=${page}`;
    const res = await fetchWithCitizenship({
      url,
      host: source.host,
      rateLimitRpm: source.rate_limit_rpm,
      maxConcurrency: source.max_concurrency,
      bypassConditionalCache: bypassCache || page > 1,
      destPrefix: `datacite_providers_p${page}`,
      timeoutMs: 20_000,
    });
    dedupHit = dedupHit || res.dedupHit;
    if (res.etag) lastEtag = res.etag;
    if (!res.filePath) {
      if (page === 1) {
        return { rawRows: [], silver: [], etag: lastEtag, dedupHit, notModified: res.status === 'NOT_MODIFIED' };
      }
      break;
    }

    try {
      const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
        meta?: { totalPages?: number };
        data?: Array<{
          id?: string;
          attributes?: {
            country?: string | null;
            doiEstimate?: number | null;
          };
        }>;
      };
      if (typeof json.meta?.totalPages === 'number' && json.meta.totalPages > totalPages) {
        totalPages = json.meta.totalPages;
      }

      for (const item of json.data ?? []) {
        const country = item.attributes?.country?.trim();
        if (!country) continue;
        const territory = resolveTerritoryByCodeOrName(country);
        if (!territory) continue;
        const dois =
          typeof item.attributes?.doiEstimate === 'number' && Number.isFinite(item.attributes.doiEstimate)
            ? Math.max(0, item.attributes.doiEstimate)
            : 0;
        rawRows.push({ id: item.id, country, doiEstimate: dois });

        const prev = totals.get(territory.territory_id);
        if (prev) {
          prev.dois += dois;
          prev.repos += 1;
        } else {
          totals.set(territory.territory_id, { iso3: territory.iso3, dois, repos: 1 });
        }
      }
    } finally {
      safeUnlink(res.filePath);
    }
    page += 1;
  }

  for (const [territoryId, agg] of totals.entries()) {
    silver.push({
      territory_id: territoryId,
      iso3: agg.iso3,
      indicator_id: 'DATACITE.DATASET_DOIS',
      indicator_name: 'Registered Research Dataset DOIs by Provider Country (DataCite REST v2)',
      module_id: 10,
      source_id: source.source_id,
      dataset_id: source.dataset_id,
      period_year: currentYear,
      value_numeric: Math.round(agg.dois),
      unit: 'DOIs',
      valuation_basis: 'count',
      methodology_id: 'DATACITE_REST_V2_PROVIDERS',
      commercial_use_allowed: source.commercial_use_allowed,
      asserted_at: assertedAt,
    });
    silver.push({
      territory_id: territoryId,
      iso3: agg.iso3,
      indicator_id: 'DATACITE.REPOSITORIES_COUNT',
      indicator_name: 'Registered Research Data Providers & Repositories (DataCite REST v2)',
      module_id: 10,
      source_id: source.source_id,
      dataset_id: source.dataset_id,
      period_year: currentYear,
      value_numeric: agg.repos,
      unit: 'providers',
      valuation_basis: 'count',
      methodology_id: 'DATACITE_REST_V2_PROVIDERS',
      commercial_use_allowed: source.commercial_use_allowed,
      asserted_at: assertedAt,
    });
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestWikimediaPageviews(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const url = 'https://wikimedia.org/api/rest_v1/metrics/pageviews/top-by-country/en.wikipedia/all-access/2025/01';
  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'wikimedia_views_202501',
    timeoutMs: 15_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  try {
    const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
      items?: Array<{
        year?: string;
        countries?: Array<{ country?: string; views_ceil?: number; rank?: number }>;
      }>;
    };

    const first = json.items?.[0];
    const year = Number(first?.year) || 2025;
    for (const c of first?.countries ?? []) {
      rawRows.push(c);
      if (!c.country || typeof c.views_ceil !== 'number' || !Number.isFinite(c.views_ceil)) continue;
      const territory = resolveTerritoryByCodeOrName(c.country);
      if (!territory) continue;

      silver.push({
        territory_id: territory.territory_id,
        iso3: territory.iso3,
        indicator_id: 'WIKIMEDIA.ENWIKI_MONTHLY_VIEWS',
        indicator_name: 'English Wikipedia Monthly Country Pageviews (Wikimedia REST v1)',
        module_id: 13,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: year,
        value_numeric: c.views_ceil,
        unit: 'views',
        valuation_basis: 'count',
        methodology_id: 'WIKIMEDIA_REST_V1_PAGEVIEWS',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestMusicBrainzApi(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();
  const targetIsos = ['USA', 'GBR', 'BRA', 'JPN'];
  const targets = listTerritories().filter((t) => targetIsos.includes(t.iso3));

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  let lastEtag: string | null = null;
  let dedupHit = false;

  for (let i = 0; i < targets.length; i++) {
    const t = targets[i];
    if (i > 0) {
      await new Promise((resolve) => setTimeout(resolve, 1200));
    }
    const url = `https://musicbrainz.org/ws/2/artist?query=country:${t.iso2}&fmt=json&limit=1`;
    let res = await fetchWithCitizenship({
      url,
      host: source.host,
      rateLimitRpm: source.rate_limit_rpm,
      maxConcurrency: 1,
      bypassConditionalCache: true,
      headers: {
        'User-Agent': 'TitanFactualOS/1.0 (https://titanfactual.org; research@titanfactual.org)',
        Accept: 'application/json',
      },
      destPrefix: `musicbrainz_${t.iso2}`,
      timeoutMs: 15_000,
    }).catch(() => null);

    if (!res?.filePath) {
      await new Promise((resolve) => setTimeout(resolve, 1500));
      res = await fetchWithCitizenship({
        url,
        host: source.host,
        rateLimitRpm: source.rate_limit_rpm,
        maxConcurrency: 1,
        bypassConditionalCache: true,
        headers: {
          'User-Agent': 'TitanFactualOS/1.0 (https://titanfactual.org; research@titanfactual.org)',
          Accept: 'application/json',
        },
        destPrefix: `musicbrainz_${t.iso2}_retry`,
        timeoutMs: 15_000,
      }).catch(() => null);
    }

    if (!res?.filePath) continue;
    dedupHit = dedupHit || res.dedupHit;
    if (res.etag) lastEtag = res.etag;

    try {
      const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
        count?: number;
      };
      const count = json.count;
      rawRows.push({ iso3: t.iso3, iso2: t.iso2, count: count ?? null });
      if (typeof count === 'number' && Number.isFinite(count) && count > 0) {
        silver.push({
          territory_id: t.territory_id,
          iso3: t.iso3,
          indicator_id: 'MUSICBRAINZ.ARTISTS_COUNT',
          indicator_name: 'Registered Music Artists & Cultural Creators by Country (MusicBrainz)',
          module_id: 13,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: currentYear,
          value_numeric: Math.round(count),
          unit: 'artists',
          valuation_basis: 'count',
          methodology_id: 'MUSICBRAINZ_WS2_ARTIST_COUNTRY',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    } finally {
      safeUnlink(res.filePath);
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestListenBrainz(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const url = 'https://api.listenbrainz.org/1/stats/sitewide/artists?count=100&range=month';

  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'listenbrainz_top100_month',
    timeoutMs: 20_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];

  try {
    const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
      payload?: {
        artists?: Array<{ artist_name?: string; listen_count?: number }>;
        count?: number;
      };
    };

    const artists = json.payload?.artists ?? [];
    let totalListens = 0;
    for (const a of artists) {
      if (typeof a.listen_count === 'number' && Number.isFinite(a.listen_count)) {
        totalListens += a.listen_count;
      }
      rawRows.push(a);
    }

    if (totalListens > 0) {
      silver.push({
        territory_id: 'T_USA',
        iso3: 'USA',
        indicator_id: 'LISTENBRAINZ.SITEWIDE_TOP100_LISTENS',
        indicator_name: 'Monthly Global Sitewide Plays Across Top-100 Artists (ListenBrainz)',
        module_id: 13,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: currentYear,
        value_numeric: Math.round(totalListens),
        unit: 'listens',
        valuation_basis: 'count',
        methodology_id: 'LISTENBRAINZ_SITEWIDE_ARTISTS_MONTH',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestUkDatagovCkan(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const url = `https://data.gov.uk/api/action/package_search?rows=0&facet.field=${encodeURIComponent('["theme-primary"]')}`;

  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'uk_datagov_ckan',
    timeoutMs: 20_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];

  try {
    const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
      success?: boolean;
      result?: {
        count?: number;
        search_facets?: {
          'theme-primary'?: {
            items?: Array<{ name?: string; display_name?: string; count?: number }>;
          };
        };
      };
    };

    const totalCount = json.result?.count;
    const themeItems = json.result?.search_facets?.['theme-primary']?.items ?? [];
    rawRows.push({ total_count: totalCount ?? null, themes: themeItems });

    if (typeof totalCount === 'number' && Number.isFinite(totalCount) && totalCount > 0) {
      silver.push({
        territory_id: 'T_GBR',
        iso3: 'GBR',
        indicator_id: 'UKGOV.OPEN_DATASETS_TOTAL',
        indicator_name: 'Total Public Open Datasets Published (UK data.gov.uk CKAN)',
        module_id: 11,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: currentYear,
        value_numeric: Math.round(totalCount),
        unit: 'datasets',
        valuation_basis: 'count',
        methodology_id: 'UK_DATAGOV_CKAN_V3_FACETS',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }

    const envTheme = themeItems.find((i) => i.name === 'environment' || i.name === 'Environment');
    if (typeof envTheme?.count === 'number' && Number.isFinite(envTheme.count)) {
      silver.push({
        territory_id: 'T_GBR',
        iso3: 'GBR',
        indicator_id: 'UKGOV.ENV_DATASETS_COUNT',
        indicator_name: 'UK Government Environment Open Datasets (data.gov.uk CKAN)',
        module_id: 11,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: currentYear,
        value_numeric: Math.round(envTheme.count),
        unit: 'datasets',
        valuation_basis: 'count',
        methodology_id: 'UK_DATAGOV_CKAN_V3_FACETS',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestCkanActionFederation(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();
  const portals = [
    {
      iso3: 'CAN',
      territoryId: 'T_CAN',
      portalName: 'Open Government Canada',
      host: 'open.canada.ca',
      url: 'https://open.canada.ca/data/api/3/action/package_search?rows=0',
    },
    {
      iso3: 'AUS',
      territoryId: 'T_AUS',
      portalName: 'data.gov.au Australia',
      host: 'data.gov.au',
      url: 'https://data.gov.au/data/api/3/action/package_search?rows=0',
    },
    {
      iso3: 'DEU',
      territoryId: 'T_DEU',
      portalName: 'GovData Germany',
      host: 'www.govdata.de',
      url: 'https://www.govdata.de/ckan/api/3/action/package_search?rows=0',
    },
    {
      iso3: 'GBR',
      territoryId: 'T_GBR',
      portalName: 'data.gov.uk United Kingdom',
      host: 'data.gov.uk',
      url: 'https://data.gov.uk/api/action/package_search?rows=0',
    },
  ];

  const results = await Promise.allSettled(
    portals.map(async (p) => {
      const res = await fetchWithCitizenship({
        url: p.url,
        host: p.host,
        rateLimitRpm: source.rate_limit_rpm,
        maxConcurrency: source.max_concurrency,
        bypassConditionalCache: true,
        destPrefix: `ckan_fed_${p.iso3}`,
        timeoutMs: 15_000,
      });
      return { portal: p, res };
    })
  );

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  let lastEtag: string | null = null;
  let dedupHit = false;

  for (const outcome of results) {
    if (outcome.status !== 'fulfilled') continue;
    const { portal, res } = outcome.value;
    dedupHit = dedupHit || res.dedupHit;
    if (res.etag) lastEtag = res.etag;
    if (!res.filePath) continue;

    try {
      const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
        success?: boolean;
        result?: { count?: number };
      };
      const count = json.result?.count;
      rawRows.push({ iso3: portal.iso3, portal: portal.portalName, count: count ?? null });
      if (typeof count === 'number' && Number.isFinite(count) && count > 0) {
        silver.push({
          territory_id: portal.territoryId,
          iso3: portal.iso3,
          indicator_id: 'CKAN_FED.PORTAL_DATASETS',
          indicator_name: `Federated CKAN v3 Portal Datasets (${portal.portalName})`,
          module_id: 12,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: currentYear,
          value_numeric: Math.round(count),
          unit: 'datasets',
          valuation_basis: 'count',
          methodology_id: 'CKAN_ACTION_V3_PACKAGE_SEARCH',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    } finally {
      safeUnlink(res.filePath);
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestSocrataSoda(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const url = 'https://api.us.socrata.com/api/catalog/v1?limit=1&only=datasets';

  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'socrata_soda_catalog',
    timeoutMs: 18_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];

  try {
    const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
      resultSetSize?: number;
      results?: Array<unknown>;
    };
    const count = json.resultSetSize;
    rawRows.push({ resultSetSize: count ?? null, sample: json.results?.[0] ?? null });

    if (typeof count === 'number' && Number.isFinite(count) && count > 0) {
      silver.push({
        territory_id: 'T_USA',
        iso3: 'USA',
        indicator_id: 'SOCRATA.CATALOG_DATASETS',
        indicator_name: 'Public Civic & Municipal Datasets Indexed (Socrata SODA v2.1)',
        module_id: 12,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: currentYear,
        value_numeric: Math.round(count),
        unit: 'datasets',
        valuation_basis: 'count',
        methodology_id: 'SOCRATA_DISCOVERY_V1_DATASETS',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestWipoIpStats(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  return ingestOwidDatasets(source, [
    {
      slug: 'patent-applications-per-million',
      indicatorId: 'WIPO.PATENT_APPS_PER_MILLION',
      indicatorName: 'Patent Applications per Million Inhabitants (WIPO IP Stats)',
      moduleId: 10,
      unit: 'patents / million',
      valuationBasis: 'count',
      methodologyId: 'WIPO_IP_PATENT_APPLICATIONS_PER_MILLION',
      columnName: 'Patent applications per million people',
      minYear: 2018,
      decimals: 1,
      rawValueKey: 'patents_per_million',
    },
  ]);
}

export async function ingestItuDatahub(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  return ingestOwidDatasets(source, [
    {
      slug: 'mobile-cellular-subscriptions-per-100-people',
      indicatorId: 'ITU.MOBILE_SUBS_PER_100',
      indicatorName: 'Mobile Cellular Subscriptions per 100 People (ITU DataHub)',
      moduleId: 8,
      unit: 'per 100 people',
      valuationBasis: 'count',
      methodologyId: 'ITU_WORLD_TELECOM_ICT_CSV',
      columnName: 'Mobile cellular subscriptions (per 100 people)',
      minYear: 2018,
      decimals: 2,
    },
    {
      slug: 'fixed-broadband-subscriptions-per-100-people',
      indicatorId: 'ITU.BROADBAND_PER_100',
      indicatorName: 'Fixed Broadband Subscriptions per 100 People (ITU DataHub)',
      moduleId: 8,
      unit: 'per 100 people',
      valuationBasis: 'count',
      methodologyId: 'ITU_WORLD_TELECOM_ICT_CSV',
      columnName: 'Fixed broadband subscriptions (per 100 people)',
      minYear: 2018,
      decimals: 2,
    },
  ]);
}

export async function ingestUsDatagovCkan(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();
  const bypassCache = shouldBypassConditionalCache(source.source_id);

  const statsRes = await fetchWithCitizenship({
    url: 'https://catalog.data.gov/api/v1/stats',
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'us_datagov_stats',
    timeoutMs: 20_000,
  });

  if (!statsRes.filePath) {
    return { rawRows: [], silver: [], etag: statsRes.etag, dedupHit: statsRes.dedupHit, notModified: statsRes.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];

  try {
    const statsJson = JSON.parse(fs.readFileSync(statsRes.filePath, 'utf-8')) as {
      meta?: { date?: string };
      metrics?: { datasetsBarMetric?: string };
    };
    const decodedBar = statsJson.metrics?.datasetsBarMetric
      ? (JSON.parse(decodeURIComponent(statsJson.metrics.datasetsBarMetric)) as Array<{ data?: number[] }>)
      : [];
    const countsArr = Array.isArray(decodedBar[0]?.data)
      ? decodedBar[0].data.filter((n): n is number => typeof n === 'number' && Number.isFinite(n))
      : [];

    const totalCount = countsArr.reduce((acc, n) => acc + n, 0);
    const federalCount = countsArr.length > 0 ? Math.max(...countsArr) : 0;

    rawRows.push({ meta: statsJson.meta ?? null, tierCounts: countsArr, totalCount, federalCount });

    if (totalCount > 0) {
      silver.push({
        territory_id: 'T_USA',
        iso3: 'USA',
        indicator_id: 'USGOV.DATAGOV_CATALOG_TOTAL',
        indicator_name: 'Total U.S. Data.gov Federated Datasets (Federal, State, City, County)',
        module_id: 12,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: currentYear,
        value_numeric: Math.round(totalCount),
        unit: 'datasets',
        valuation_basis: 'count',
        methodology_id: 'US_DATAGOV_API_V1_STATS',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }

    if (federalCount > 0) {
      silver.push({
        territory_id: 'T_USA',
        iso3: 'USA',
        indicator_id: 'USGOV.DATAGOV_FEDERAL_DATASETS',
        indicator_name: 'U.S. Federal Agency Open Datasets (catalog.data.gov v1)',
        module_id: 12,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: currentYear,
        value_numeric: Math.round(federalCount),
        unit: 'datasets',
        valuation_basis: 'count',
        methodology_id: 'US_DATAGOV_API_V1_STATS',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  } finally {
    safeUnlink(statsRes.filePath);
  }

  // Also verify live v1 catalog search returns metadata cleanly
  const searchRes = await fetchWithCitizenship({
    url: 'https://catalog.data.gov/api/v1/search?q=&per_page=3',
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'us_datagov_search',
    timeoutMs: 15_000,
  }).catch(() => null);

  if (searchRes?.filePath) {
    try {
      const searchJson = JSON.parse(fs.readFileSync(searchRes.filePath, 'utf-8')) as {
        results?: Array<{ dcat?: { title?: string; publisher?: { name?: string } } }>;
      };
      for (const item of searchJson.results ?? []) {
        rawRows.push({
          sampleTitle: item.dcat?.title ?? null,
          publisher: item.dcat?.publisher?.name ?? null,
        });
      }
    } finally {
      safeUnlink(searchRes.filePath);
    }
  }

  return { rawRows, silver, etag: statsRes.etag, dedupHit: statsRes.dedupHit };
}
