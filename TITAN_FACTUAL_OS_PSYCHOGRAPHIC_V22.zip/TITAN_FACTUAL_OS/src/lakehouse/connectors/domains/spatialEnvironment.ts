import fs from 'node:fs';
import { listTerritories, resolveTerritoryByCodeOrName } from '../../controlPlane.ts';
import { sqlQuote, withDuckDBConnection } from '../../duckdbEngine.ts';
import { fetchConsistentBatch, fetchWithCitizenship, type FetchOptions } from '../../httpCitizenship.ts';
import {
  updateCountryAdminMetrics,
  upsertSubnationalAdminNodes,
} from '../../spatial/adminHierarchy.ts';
import type { ObservationContract, SourceCatalogEntry } from '../../types.ts';
import { ingestOwidDatasets } from '../factories/owidCsvConnector.ts';
import {
  safeUnlink,
  shouldBypassConditionalCache,
  type ConnectorOutcome,
} from '../shared.ts';

function makeAdminSlug(text: string): string {
  return text
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 28);
}

export async function ingestGeoBoundariesMeta(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const res = await fetchWithCitizenship({
    url: source.endpoint_url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'geoboundaries_adm0',
    timeoutMs: 30_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  try {
    const items = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as Array<{
      boundaryISO?: string;
      boundaryName?: string;
      boundaryYearRepresented?: string;
    }>;

    for (const item of items) {
      rawRows.push(item);
      if (!item.boundaryISO) continue;
      const territory = resolveTerritoryByCodeOrName(item.boundaryISO);
      if (!territory) continue;
      const year = Number(item.boundaryYearRepresented) || 2023;
      silver.push({
        territory_id: territory.territory_id,
        iso3: territory.iso3,
        indicator_id: 'GB.ADM0.COVERAGE',
        indicator_name: 'geoBoundaries ADM0 Boundary Availability',
        module_id: 1,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: year,
        value_numeric: 1,
        unit: 'available_flag',
        valuation_basis: 'index_score',
        methodology_id: 'GEOBOUNDARIES_GBOPEN_ADM0',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestGadmBoundaries(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();
  const targetIsos = ['DEU', 'FRA', 'GBR', 'JPN', 'BRA', 'MEX', 'IND', 'ITA'];
  const targets = listTerritories().filter((t) => targetIsos.includes(t.iso3));

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  let lastEtag: string | null = null;
  let dedupHit = false;

  for (const t of targets) {
    const url = `https://geodata.ucdavis.edu/gadm/gadm4.1/json/gadm41_${t.iso3}_1.json`;
    const res = await fetchWithCitizenship({
      url,
      host: source.host,
      rateLimitRpm: source.rate_limit_rpm,
      maxConcurrency: source.max_concurrency,
      bypassConditionalCache: true,
      destPrefix: `gadm41_${t.iso3}_adm1`,
      timeoutMs: 25_000,
    }).catch(() => null);

    if (!res?.filePath) continue;
    dedupHit = dedupHit || res.dedupHit;
    if (res.etag) lastEtag = res.etag;

    try {
      const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
        features?: Array<{ properties?: { GID_1?: string; NAME_1?: string } }>;
      };
      const features = Array.isArray(json.features) ? json.features : [];
      const featureCount = features.length;
      rawRows.push({
        iso3: t.iso3,
        adm1_features: featureCount,
        sample_gid: features[0]?.properties?.GID_1 ?? null,
      });

      if (featureCount > 0) {
        silver.push({
          territory_id: t.territory_id,
          iso3: t.iso3,
          indicator_id: 'GADM.ADM1_FEATURES',
          indicator_name: 'GADM 4.1 First-Level Administrative Polygon Divisions (ADM1)',
          module_id: 1,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: currentYear,
          value_numeric: featureCount,
          unit: 'ADM1 divisions',
          valuation_basis: 'count',
          methodology_id: 'GADM_4_1_GEOJSON_ADM1',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    } finally {
      safeUnlink(res.filePath);
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestNaturalEarthBulk(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();
  const bypassCache = shouldBypassConditionalCache(source.source_id);

  const adm0Url =
    'https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_110m_admin_0_countries.geojson';
  const adm1Url =
    'https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_10m_admin_1_states_provinces.geojson';
  const placesUrl =
    'https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_10m_populated_places_simple.geojson';

  const [adm0Res, adm1Res, placesRes] = await Promise.all([
    fetchWithCitizenship({
      url: adm0Url,
      host: source.host,
      rateLimitRpm: source.rate_limit_rpm,
      maxConcurrency: source.max_concurrency,
      bypassConditionalCache: true,
      destPrefix: 'ne_adm0',
      timeoutMs: 25_000,
    }),
    fetchWithCitizenship({
      url: adm1Url,
      host: source.host,
      rateLimitRpm: source.rate_limit_rpm,
      maxConcurrency: source.max_concurrency,
      bypassConditionalCache: true,
      destPrefix: 'ne_adm1',
      timeoutMs: 40_000,
    }),
    fetchWithCitizenship({
      url: placesUrl,
      host: source.host,
      rateLimitRpm: source.rate_limit_rpm,
      maxConcurrency: source.max_concurrency,
      bypassConditionalCache: true,
      destPrefix: 'ne_places',
      timeoutMs: 25_000,
    }),
  ]);

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const dedupKeys = new Set<string>();
  const lastEtag = adm0Res.etag ?? adm1Res.etag ?? placesRes.etag ?? null;
  const dedupHit = adm0Res.dedupHit || adm1Res.dedupHit || placesRes.dedupHit;

  try {
    if (adm0Res.filePath) {
      const adm0Json = JSON.parse(fs.readFileSync(adm0Res.filePath, 'utf-8')) as {
        features?: Array<{
          properties?: {
            ISO_A3?: string;
            ADM0_A3?: string;
            SOV_A3?: string;
            NAME?: string;
            POP_EST?: number;
            GDP_MD?: number;
          };
        }>;
      };

      const countryUpdates: Array<{ iso3: string; population_est?: number | null }> = [];
      for (const feat of adm0Json.features ?? []) {
        const p = feat.properties;
        if (!p) continue;
        const territory =
          (p.ISO_A3 && p.ISO_A3 !== '-99' ? resolveTerritoryByCodeOrName(p.ISO_A3) : undefined) ??
          (p.ADM0_A3 ? resolveTerritoryByCodeOrName(p.ADM0_A3) : undefined) ??
          (p.NAME ? resolveTerritoryByCodeOrName(p.NAME) : undefined);
        if (!territory) continue;

        rawRows.push({ layer: 'adm0', iso3: territory.iso3, pop_est: p.POP_EST, gdp_md: p.GDP_MD });

        if (typeof p.POP_EST === 'number' && Number.isFinite(p.POP_EST) && p.POP_EST > 0) {
          countryUpdates.push({ iso3: territory.iso3, population_est: Math.round(p.POP_EST) });
          const k = `${territory.territory_id}|NE.POP_EST`;
          if (!dedupKeys.has(k)) {
            dedupKeys.add(k);
            silver.push({
              territory_id: territory.territory_id,
              iso3: territory.iso3,
              indicator_id: 'NE.POP_EST',
              indicator_name: 'Natural Earth ADM0 Estimated Population (110m)',
              module_id: 1,
              source_id: source.source_id,
              dataset_id: source.dataset_id,
              period_year: currentYear,
              value_numeric: Math.round(p.POP_EST),
              unit: 'persons',
              valuation_basis: 'count',
              methodology_id: 'NATURAL_EARTH_110M_ADM0',
              commercial_use_allowed: source.commercial_use_allowed,
              asserted_at: assertedAt,
            });
          }
        }

        if (typeof p.GDP_MD === 'number' && Number.isFinite(p.GDP_MD) && p.GDP_MD > 0) {
          const k = `${territory.territory_id}|NE.GDP_MD_EST`;
          if (!dedupKeys.has(k)) {
            dedupKeys.add(k);
            silver.push({
              territory_id: territory.territory_id,
              iso3: territory.iso3,
              indicator_id: 'NE.GDP_MD_EST',
              indicator_name: 'Natural Earth ADM0 Reference GDP (US$, 110m)',
              module_id: 1,
              source_id: source.source_id,
              dataset_id: source.dataset_id,
              period_year: currentYear,
              value_numeric: Math.round(p.GDP_MD * 1_000_000),
              unit: 'USD',
              valuation_basis: 'nominal_usd',
              methodology_id: 'NATURAL_EARTH_110M_ADM0',
              commercial_use_allowed: source.commercial_use_allowed,
              asserted_at: assertedAt,
            });
          }
        }
      }
      updateCountryAdminMetrics(countryUpdates);
    }

    const stateNodes: Parameters<typeof upsertSubnationalAdminNodes>[0] = [];
    const stateLookup = new Map<string, string>();
    const stateCountsByTerritory = new Map<string, { iso3: string; count: number }>();
    const seenStateIds = new Set<string>();

    if (adm1Res.filePath) {
      const adm1Json = JSON.parse(fs.readFileSync(adm1Res.filePath, 'utf-8')) as {
        features?: Array<{
          properties?: {
            adm0_a3?: string;
            iso_a2?: string;
            admin?: string;
            name?: string;
            name_local?: string | null;
            iso_3166_2?: string | null;
            code_hasc?: string | null;
            latitude?: number | null;
            longitude?: number | null;
          };
        }>;
      };

      for (const feat of adm1Json.features ?? []) {
        const p = feat.properties;
        if (!p || !p.name) continue;
        const territory =
          (p.adm0_a3 ? resolveTerritoryByCodeOrName(p.adm0_a3) : undefined) ??
          (p.admin ? resolveTerritoryByCodeOrName(p.admin) : undefined) ??
          (p.iso_a2 ? resolveTerritoryByCodeOrName(p.iso_a2) : undefined);
        if (!territory) continue;

        const cleanName = p.name.trim();
        const rawCode = (p.iso_3166_2 || p.code_hasc || makeAdminSlug(cleanName)).trim();
        const slug = makeAdminSlug(rawCode) || makeAdminSlug(cleanName);
        if (!slug) continue;

        const nodeId = `ADM1_${territory.iso3}_${slug}`;
        if (seenStateIds.has(nodeId)) continue;
        seenStateIds.add(nodeId);

        const lat = typeof p.latitude === 'number' && Number.isFinite(p.latitude) ? p.latitude : null;
        const lon = typeof p.longitude === 'number' && Number.isFinite(p.longitude) ? p.longitude : null;

        stateNodes.push({
          node_id: nodeId,
          parent_id: `CNTRY_${territory.iso3}`,
          level: 'state',
          code: rawCode,
          iso3: territory.iso3,
          territory_id: territory.territory_id,
          name_en: cleanName,
          name_local: p.name_local?.trim() || cleanName,
          centroid_lat: lat,
          centroid_lon: lon,
          population_est: null,
        });

        stateLookup.set(`${territory.iso3}|${cleanName.toLowerCase()}`, nodeId);
        const prev = stateCountsByTerritory.get(territory.territory_id);
        if (prev) {
          prev.count += 1;
        } else {
          stateCountsByTerritory.set(territory.territory_id, { iso3: territory.iso3, count: 1 });
        }
      }

      for (const [territoryId, entry] of stateCountsByTerritory.entries()) {
        rawRows.push({ layer: 'adm1_count', iso3: entry.iso3, divisions: entry.count });
        silver.push({
          territory_id: territoryId,
          iso3: entry.iso3,
          indicator_id: 'NE.ADM1_DIVISIONS',
          indicator_name: 'First-Level Administrative Divisions ADM1 (Natural Earth 10m)',
          module_id: 1,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: currentYear,
          value_numeric: entry.count,
          unit: 'divisions',
          valuation_basis: 'count',
          methodology_id: 'NATURAL_EARTH_10M_ADM1',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    }

    const cityNodes: Parameters<typeof upsertSubnationalAdminNodes>[0] = [];
    const seenCityIds = new Set<string>();

    if (placesRes.filePath) {
      const placesJson = JSON.parse(fs.readFileSync(placesRes.filePath, 'utf-8')) as {
        features?: Array<{
          properties?: {
            adm0_a3?: string;
            iso_a2?: string;
            adm0name?: string;
            adm1name?: string | null;
            name?: string;
            nameascii?: string;
            latitude?: number | null;
            longitude?: number | null;
            pop_max?: number | null;
            ne_id?: number | null;
          };
        }>;
      };

      for (const feat of placesJson.features ?? []) {
        const p = feat.properties;
        if (!p || !p.name) continue;
        const territory =
          (p.adm0_a3 ? resolveTerritoryByCodeOrName(p.adm0_a3) : undefined) ??
          (p.adm0name ? resolveTerritoryByCodeOrName(p.adm0name) : undefined) ??
          (p.iso_a2 ? resolveTerritoryByCodeOrName(p.iso_a2) : undefined);
        if (!territory) continue;

        const cleanName = (p.nameascii || p.name).trim();
        const slug = makeAdminSlug(cleanName);
        if (!slug) continue;

        const nodeId = `ADM2_${territory.iso3}_${slug}`;
        if (seenCityIds.has(nodeId)) continue;
        seenCityIds.add(nodeId);

        const adm1Key = p.adm1name ? `${territory.iso3}|${p.adm1name.trim().toLowerCase()}` : '';
        const parentStateId = adm1Key ? stateLookup.get(adm1Key) : undefined;
        const lat = typeof p.latitude === 'number' && Number.isFinite(p.latitude) ? p.latitude : null;
        const lon = typeof p.longitude === 'number' && Number.isFinite(p.longitude) ? p.longitude : null;
        const popMax =
          typeof p.pop_max === 'number' && Number.isFinite(p.pop_max) && p.pop_max > 0
            ? Math.round(p.pop_max)
            : null;

        rawRows.push({ layer: 'places', iso3: territory.iso3, city: cleanName, pop_max: popMax });
        cityNodes.push({
          node_id: nodeId,
          parent_id: parentStateId ?? `CNTRY_${territory.iso3}`,
          level: 'city',
          code: String(p.ne_id ?? slug),
          iso3: territory.iso3,
          territory_id: territory.territory_id,
          name_en: cleanName,
          name_local: p.name.trim(),
          centroid_lat: lat,
          centroid_lon: lon,
          population_est: popMax,
        });
      }
    }

    if (stateNodes.length > 0 || cityNodes.length > 0) {
      await upsertSubnationalAdminNodes([...stateNodes, ...cityNodes]);
    }

    if (!bypassCache && silver.length === 0) {
      return { rawRows: [], silver: [], etag: lastEtag, dedupHit, notModified: [adm0Res, adm1Res, placesRes].every((item) => item.status === 'NOT_MODIFIED') };
    }
  } finally {
    if (adm0Res.filePath) safeUnlink(adm0Res.filePath);
    if (adm1Res.filePath) safeUnlink(adm1Res.filePath);
    if (placesRes.filePath) safeUnlink(placesRes.filePath);
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestGeonamesDumps(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const url = 'https://download.geonames.org/export/dump/countryInfo.txt';

  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'geonames_countryinfo',
    timeoutMs: 15_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const hierarchyUpdates: Array<{
    iso3: string;
    population_est?: number | null;
    area_km2?: number | null;
    geoname_id?: number | null;
  }> = [];
  const dedupKeys = new Set<string>();

  try {
    const text = fs.readFileSync(res.filePath, 'utf-8');
    for (const line of text.split(/\r?\n/)) {
      if (!line || line.startsWith('#')) continue;
      const cols = line.split('\t');
      if (cols.length < 17) continue;

      const iso2 = cols[0]?.trim();
      const iso3 = cols[1]?.trim();
      const territory =
        (iso3 ? resolveTerritoryByCodeOrName(iso3) : undefined) ??
        (iso2 ? resolveTerritoryByCodeOrName(iso2) : undefined);
      if (!territory) continue;

      const areaKm2 = Number(cols[6]?.trim());
      const population = Number(cols[7]?.trim());
      const geonameId = Number(cols[16]?.trim());
      const validArea = Number.isFinite(areaKm2) && areaKm2 > 0 ? areaKm2 : null;
      const validPop = Number.isFinite(population) && population > 0 ? population : null;
      const validGeoId = Number.isInteger(geonameId) && geonameId > 0 ? geonameId : null;

      rawRows.push({
        iso3: territory.iso3,
        geoname_id: validGeoId,
        population: validPop,
        area_km2: validArea,
      });

      hierarchyUpdates.push({
        iso3: territory.iso3,
        geoname_id: validGeoId,
        population_est: validPop,
        area_km2: validArea,
      });

      if (validPop !== null) {
        const k = `${territory.territory_id}|GEONAMES.POPULATION`;
        if (!dedupKeys.has(k)) {
          dedupKeys.add(k);
          silver.push({
            territory_id: territory.territory_id,
            iso3: territory.iso3,
            indicator_id: 'GEONAMES.POPULATION',
            indicator_name: 'GeoNames Official Gazetteer Country Population',
            module_id: 1,
            source_id: source.source_id,
            dataset_id: source.dataset_id,
            period_year: currentYear,
            value_numeric: Math.round(validPop),
            unit: 'persons',
            valuation_basis: 'count',
            methodology_id: 'GEONAMES_COUNTRY_INFO_TSV',
            commercial_use_allowed: source.commercial_use_allowed,
            asserted_at: assertedAt,
          });
        }
      }

      if (validArea !== null) {
        const k = `${territory.territory_id}|GEONAMES.AREA_KM2`;
        if (!dedupKeys.has(k)) {
          dedupKeys.add(k);
          silver.push({
            territory_id: territory.territory_id,
            iso3: territory.iso3,
            indicator_id: 'GEONAMES.AREA_KM2',
            indicator_name: 'GeoNames Official Gazetteer Territory Area (km²)',
            module_id: 1,
            source_id: source.source_id,
            dataset_id: source.dataset_id,
            period_year: currentYear,
            value_numeric: Number(validArea.toFixed(1)),
            unit: 'km2',
            valuation_basis: 'count',
            methodology_id: 'GEONAMES_COUNTRY_INFO_TSV',
            commercial_use_allowed: source.commercial_use_allowed,
            asserted_at: assertedAt,
          });
        }
      }
    }

    updateCountryAdminMetrics(hierarchyUpdates);
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestWikidataSparql(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const iso3Tokens = listTerritories()
    .map((t) => `"${t.iso3}"`)
    .sort()
    .join(' ');

  const sparql = `SELECT ?iso3 (SAMPLE(?area) AS ?area_km2) (SAMPLE(?pop) AS ?population) (SAMPLE(?capitalLabel) AS ?capital) WHERE {
    VALUES ?iso3 { ${iso3Tokens} }
    ?country wdt:P298 ?iso3 .
    OPTIONAL { ?country wdt:P2046 ?area . }
    OPTIONAL { ?country wdt:P1082 ?pop . }
    OPTIONAL {
      ?country wdt:P36 ?capitalEntity .
      ?capitalEntity rdfs:label ?capitalLabel .
      FILTER(LANG(?capitalLabel) = "en")
    }
  } GROUP BY ?iso3`;

  const url = `https://query.wikidata.org/sparql?format=json&query=${encodeURIComponent(sparql)}`;
  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    headers: { Accept: 'application/sparql-results+json' },
    destPrefix: 'wikidata_countries_sparql',
    timeoutMs: 25_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const hierarchyUpdates: Array<{ iso3: string; population_est?: number | null; area_km2?: number | null }> = [];
  const dedupKeys = new Set<string>();

  try {
    const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
      results?: {
        bindings?: Array<{
          iso3?: { value?: string };
          area_km2?: { value?: string };
          population?: { value?: string };
          capital?: { value?: string };
        }>;
      };
    };

    for (const row of json.results?.bindings ?? []) {
      const iso3 = row.iso3?.value?.trim();
      if (!iso3) continue;
      const territory = resolveTerritoryByCodeOrName(iso3);
      if (!territory) continue;

      const areaKm2 = row.area_km2?.value ? Number(row.area_km2.value) : null;
      const pop = row.population?.value ? Number(row.population.value) : null;
      rawRows.push({
        iso3: territory.iso3,
        area_km2: areaKm2,
        population: pop,
        capital: row.capital?.value ?? null,
      });

      const validArea = areaKm2 !== null && Number.isFinite(areaKm2) && areaKm2 > 0 ? areaKm2 : null;
      const validPop = pop !== null && Number.isFinite(pop) && pop > 0 ? pop : null;

      hierarchyUpdates.push({
        iso3: territory.iso3,
        area_km2: validArea,
        population_est: validPop,
      });

      if (validArea !== null) {
        const keyArea = `${territory.territory_id}|WIKIDATA.AREA_KM2`;
        if (!dedupKeys.has(keyArea)) {
          dedupKeys.add(keyArea);
          silver.push({
            territory_id: territory.territory_id,
            iso3: territory.iso3,
            indicator_id: 'WIKIDATA.AREA_KM2',
            indicator_name: 'Official Land & Water Area (km², Wikidata P2046)',
            module_id: 1,
            source_id: source.source_id,
            dataset_id: source.dataset_id,
            period_year: currentYear,
            value_numeric: Number(validArea.toFixed(1)),
            unit: 'km2',
            valuation_basis: 'count',
            methodology_id: 'WIKIDATA_SPARQL_P2046',
            commercial_use_allowed: source.commercial_use_allowed,
            asserted_at: assertedAt,
          });
        }
      }

      if (validPop !== null) {
        const keyPop = `${territory.territory_id}|WIKIDATA.POPULATION`;
        if (!dedupKeys.has(keyPop)) {
          dedupKeys.add(keyPop);
          silver.push({
            territory_id: territory.territory_id,
            iso3: territory.iso3,
            indicator_id: 'WIKIDATA.POPULATION',
            indicator_name: 'Entity Population Statement (Wikidata P1082)',
            module_id: 1,
            source_id: source.source_id,
            dataset_id: source.dataset_id,
            period_year: currentYear,
            value_numeric: Math.round(validPop),
            unit: 'persons',
            valuation_basis: 'count',
            methodology_id: 'WIKIDATA_SPARQL_P1082',
            commercial_use_allowed: source.commercial_use_allowed,
            asserted_at: assertedAt,
          });
        }
      }

      if (validArea !== null && validPop !== null) {
        const keyDens = `${territory.territory_id}|WIKIDATA.POP_DENSITY_PER_KM2`;
        if (!dedupKeys.has(keyDens)) {
          dedupKeys.add(keyDens);
          silver.push({
            territory_id: territory.territory_id,
            iso3: territory.iso3,
            indicator_id: 'WIKIDATA.POP_DENSITY_PER_KM2',
            indicator_name: 'Derived Population Density per km² (Wikidata SPARQL)',
            module_id: 1,
            source_id: source.source_id,
            dataset_id: source.dataset_id,
            period_year: currentYear,
            value_numeric: Number((validPop / validArea).toFixed(2)),
            unit: 'persons/km2',
            valuation_basis: 'count',
            methodology_id: 'WIKIDATA_SPARQL_DENSITY',
            commercial_use_allowed: source.commercial_use_allowed,
            asserted_at: assertedAt,
          });
        }
      }
    }

    updateCountryAdminMetrics(hierarchyUpdates);
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestOvertureStac(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const catalogUrl = 'https://stac.overturemaps.org/catalog.json';

  const catalogRes = await fetchWithCitizenship({
    url: catalogUrl,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'overture_stac_root',
    timeoutMs: 15_000,
  });

  if (!catalogRes.filePath) {
    return { rawRows: [], silver: [], etag: catalogRes.etag, dedupHit: catalogRes.dedupHit, notModified: catalogRes.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  let releaseHref: string | null = null;
  let releaseCount = 0;

  try {
    const rootJson = JSON.parse(fs.readFileSync(catalogRes.filePath, 'utf-8')) as {
      links?: Array<{ rel?: string; href?: string; title?: string }>;
    };
    const childLinks = (rootJson.links ?? []).filter((l) => l.rel === 'child' && l.href);
    releaseCount = childLinks.length;
    const latestChild = childLinks[0];
    if (latestChild?.href) {
      releaseHref = new URL(latestChild.href, catalogUrl).toString();
    }
    rawRows.push({ release_count: releaseCount, latest_release: latestChild ?? null });
  } finally {
    safeUnlink(catalogRes.filePath);
  }

  let themeCount = 0;
  let releaseYear = currentYear;
  if (releaseHref) {
    const relRes = await fetchWithCitizenship({
      url: releaseHref,
      host: source.host,
      rateLimitRpm: source.rate_limit_rpm,
      maxConcurrency: source.max_concurrency,
      bypassConditionalCache: true,
      destPrefix: 'overture_stac_release',
      timeoutMs: 15_000,
    });
    if (relRes.filePath) {
      try {
        const relJson = JSON.parse(fs.readFileSync(relRes.filePath, 'utf-8')) as {
          id?: string;
          links?: Array<{ rel?: string; href?: string; title?: string }>;
        };
        const themes = (relJson.links ?? []).filter((l) => l.rel === 'child');
        themeCount = themes.length;
        const yearMatch = relJson.id?.match(/^(20\d{2})-/);
        if (yearMatch) releaseYear = Number(yearMatch[1]);
        rawRows.push({ release_id: relJson.id ?? null, themes_count: themeCount, themes });
      } finally {
        safeUnlink(relRes.filePath);
      }
    }
  }

  if (themeCount > 0) {
    silver.push({
      territory_id: 'T_USA',
      iso3: 'USA',
      indicator_id: 'OVERTURE.THEME_COLLECTIONS',
      indicator_name: 'Overture Maps GeoParquet Theme Collections (Latest STAC Release)',
      module_id: 1,
      source_id: source.source_id,
      dataset_id: source.dataset_id,
      period_year: releaseYear,
      value_numeric: themeCount,
      unit: 'themes',
      valuation_basis: 'count',
      methodology_id: 'OVERTURE_MAPS_STAC_V1',
      commercial_use_allowed: source.commercial_use_allowed,
      asserted_at: assertedAt,
    });
  }
  if (releaseCount > 0) {
    silver.push({
      territory_id: 'T_USA',
      iso3: 'USA',
      indicator_id: 'OVERTURE.STAC_RELEASES',
      indicator_name: 'Published Monthly Releases in Overture Maps STAC Catalog',
      module_id: 1,
      source_id: source.source_id,
      dataset_id: source.dataset_id,
      period_year: releaseYear,
      value_numeric: releaseCount,
      unit: 'releases',
      valuation_basis: 'count',
      methodology_id: 'OVERTURE_MAPS_STAC_V1',
      commercial_use_allowed: source.commercial_use_allowed,
      asserted_at: assertedAt,
    });
  }

  return { rawRows, silver, etag: catalogRes.etag, dedupHit: catalogRes.dedupHit };
}

export async function ingestArcgisHub(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const url = 'https://hub.arcgis.com/api/v3/datasets?filter[openData]=true&page[size]=1';

  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'arcgis_hub_opendata',
    timeoutMs: 20_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];

  try {
    const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
      meta?: { stats?: { totalCount?: number } };
      data?: Array<unknown>;
    };

    const totalCount = json.meta?.stats?.totalCount;
    rawRows.push({ total_count: totalCount ?? null, sample: json.data?.[0] ?? null });

    if (typeof totalCount === 'number' && Number.isFinite(totalCount) && totalCount > 0) {
      silver.push({
        territory_id: 'T_USA',
        iso3: 'USA',
        indicator_id: 'ARCGIS.OPEN_DATASETS_TOTAL',
        indicator_name: 'Total Public Open Geospatial Datasets Indexed (ArcGIS Hub v3)',
        module_id: 1,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: currentYear,
        value_numeric: Math.round(totalCount),
        unit: 'datasets',
        valuation_basis: 'count',
        methodology_id: 'ARCGIS_HUB_V3_OPENDATA_STATS',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestOgcStacIndex(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const url = 'https://stacindex.org/api/catalogs';

  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'ogc_stac_catalogs',
    timeoutMs: 20_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];

  try {
    const catalogs = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as Array<{
      id?: number | string;
      slug?: string;
      title?: string;
      access?: string;
      isPrivate?: boolean;
      isApi?: boolean;
    }>;

    const list = Array.isArray(catalogs) ? catalogs : [];
    const publicCatalogs = list.filter((c) => !c.isPrivate).length;
    const apiCatalogs = list.filter((c) => Boolean(c.isApi)).length;

    rawRows.push(...list.slice(0, 100));

    if (publicCatalogs > 0) {
      silver.push({
        territory_id: 'T_USA',
        iso3: 'USA',
        indicator_id: 'STAC_INDEX.PUBLIC_CATALOGS',
        indicator_name: 'Public Spatio-Temporal Asset Catalogs Registered (STAC Index)',
        module_id: 1,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: currentYear,
        value_numeric: publicCatalogs,
        unit: 'catalogs',
        valuation_basis: 'count',
        methodology_id: 'OGC_STAC_INDEX_CATALOGS',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }

    if (apiCatalogs > 0) {
      silver.push({
        territory_id: 'T_USA',
        iso3: 'USA',
        indicator_id: 'STAC_INDEX.API_CATALOGS',
        indicator_name: 'Dynamic OGC STAC API Endpoints Registered (STAC Index)',
        module_id: 1,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: currentYear,
        value_numeric: apiCatalogs,
        unit: 'apis',
        valuation_basis: 'count',
        methodology_id: 'OGC_STAC_INDEX_CATALOGS',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestOsmOverpass(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();
  const targetIsos = ['BRA', 'USA', 'DEU', 'GBR', 'JPN'];
  const targets = listTerritories().filter((t) => targetIsos.includes(t.iso3));

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  let lastEtag: string | null = null;
  let dedupHit = false;

  for (let i = 0; i < targets.length; i++) {
    const t = targets[i];
    if (i > 0) {
      await new Promise((resolve) => setTimeout(resolve, 1150));
    }
    const url = `https://nominatim.openstreetmap.org/search?country=${encodeURIComponent(t.name_en)}&format=json&limit=1`;
    const res = await fetchWithCitizenship({
      url,
      host: source.host,
      rateLimitRpm: source.rate_limit_rpm,
      maxConcurrency: 1,
      bypassConditionalCache: true,
      headers: {
        'User-Agent': 'TitanFactualOS/1.0 (https://titanfactual.org; research@titanfactual.org)',
        Accept: 'application/json',
      },
      destPrefix: `osm_nominatim_${t.iso3}`,
      timeoutMs: 15_000,
    }).catch(() => null);

    if (!res?.filePath) continue;
    dedupHit = dedupHit || res.dedupHit;
    if (res.etag) lastEtag = res.etag;

    try {
      const items = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as Array<{
        osm_id?: number;
        importance?: number;
        boundingbox?: [string, string, string, string];
      }>;
      const first = Array.isArray(items) ? items[0] : undefined;
      if (!first) continue;

      const importance =
        typeof first.importance === 'number' && Number.isFinite(first.importance)
          ? first.importance
          : null;
      let bboxSpanDeg: number | null = null;
      if (Array.isArray(first.boundingbox) && first.boundingbox.length === 4) {
        const south = Number(first.boundingbox[0]);
        const north = Number(first.boundingbox[1]);
        const west = Number(first.boundingbox[2]);
        const east = Number(first.boundingbox[3]);
        if ([south, north, west, east].every((v) => Number.isFinite(v))) {
          bboxSpanDeg = Math.abs(north - south) * Math.abs(east - west);
        }
      }

      rawRows.push({
        iso3: t.iso3,
        osm_id: first.osm_id ?? null,
        importance,
        bbox_span_deg2: bboxSpanDeg,
      });

      if (importance !== null) {
        silver.push({
          territory_id: t.territory_id,
          iso3: t.iso3,
          indicator_id: 'OSM.NOMINATIM_IMPORTANCE',
          indicator_name: 'OpenStreetMap Relation Geospatial Importance Score (Nominatim)',
          module_id: 8,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: currentYear,
          value_numeric: Number(importance.toFixed(4)),
          unit: 'importance (0-1)',
          valuation_basis: 'index_score',
          methodology_id: 'OSM_NOMINATIM_BOUNDARY_SEARCH',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
      if (bboxSpanDeg !== null && bboxSpanDeg > 0) {
        silver.push({
          territory_id: t.territory_id,
          iso3: t.iso3,
          indicator_id: 'OSM.BBOX_SPAN_DEG',
          indicator_name: 'OpenStreetMap Country Bounding Box Extent (deg²)',
          module_id: 8,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: currentYear,
          value_numeric: Number(bboxSpanDeg.toFixed(1)),
          unit: 'deg2',
          valuation_basis: 'count',
          methodology_id: 'OSM_NOMINATIM_BOUNDARY_SEARCH',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    } finally {
      safeUnlink(res.filePath);
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestNasaPowerClimatology(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();
  const territories = listTerritories();

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  let lastEtag: string | null = null;
  let dedupHit = false;

  const batchSize = 4;
  for (let i = 0; i < territories.length; i += batchSize) {
    const batch = territories.slice(i, i + batchSize);
    const results = await Promise.allSettled(
      batch.map(async (t) => {
        const url = `https://power.larc.nasa.gov/api/temporal/climatology/point?parameters=T2M,ALLSKY_SFC_SW_DWN,PRECTOTCORR&community=RE&longitude=${t.centroid_lon}&latitude=${t.centroid_lat}&format=JSON`;
        const res = await fetchWithCitizenship({
          url,
          host: source.host,
          rateLimitRpm: source.rate_limit_rpm,
          maxConcurrency: source.max_concurrency,
          bypassConditionalCache: true,
          destPrefix: `nasa_power_${t.iso3}`,
          timeoutMs: 15_000,
        });
        return { territory: t, res };
      })
    );

    for (const outcome of results) {
      if (outcome.status !== 'fulfilled') continue;
      const { territory, res } = outcome.value;
      dedupHit = dedupHit || res.dedupHit;
      if (res.etag) lastEtag = res.etag;
      if (!res.filePath) continue;

      try {
        const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
          properties?: {
            parameter?: {
              ALLSKY_SFC_SW_DWN?: { ANN?: number };
              T2M?: { ANN?: number };
              PRECTOTCORR?: { ANN?: number };
            };
          };
        };
        const param = json.properties?.parameter;
        const solar = param?.ALLSKY_SFC_SW_DWN?.ANN;
        const temp = param?.T2M?.ANN;
        const precip = param?.PRECTOTCORR?.ANN;

        rawRows.push({
          iso3: territory.iso3,
          solar_ann: solar ?? null,
          t2m_ann: temp ?? null,
          precip_ann: precip ?? null,
        });

        if (typeof solar === 'number' && Number.isFinite(solar) && solar > -900) {
          silver.push({
            territory_id: territory.territory_id,
            iso3: territory.iso3,
            indicator_id: 'NASA.SOLAR_IRRADIANCE_KWH',
            indicator_name: 'Annual Mean All-Sky Surface Solar Irradiance (NASA POWER Climatology)',
            module_id: 5,
            source_id: source.source_id,
            dataset_id: source.dataset_id,
            period_year: currentYear,
            value_numeric: Number(solar.toFixed(2)),
            unit: 'kWh/m2/day',
            valuation_basis: 'count',
            methodology_id: 'NASA_POWER_CLIMATOLOGY_V2',
            commercial_use_allowed: source.commercial_use_allowed,
            asserted_at: assertedAt,
          });
        }
        if (typeof temp === 'number' && Number.isFinite(temp) && temp > -900) {
          silver.push({
            territory_id: territory.territory_id,
            iso3: territory.iso3,
            indicator_id: 'NASA.MEAN_TEMP_C',
            indicator_name: 'Annual Mean 2m Air Temperature Centroid (degC, NASA POWER)',
            module_id: 4,
            source_id: source.source_id,
            dataset_id: source.dataset_id,
            period_year: currentYear,
            value_numeric: Number(temp.toFixed(2)),
            unit: 'degC',
            valuation_basis: 'count',
            methodology_id: 'NASA_POWER_CLIMATOLOGY_V2',
            commercial_use_allowed: source.commercial_use_allowed,
            asserted_at: assertedAt,
          });
        }
        if (typeof precip === 'number' && Number.isFinite(precip) && precip > -900) {
          silver.push({
            territory_id: territory.territory_id,
            iso3: territory.iso3,
            indicator_id: 'NASA.PRECIP_MM_DAY',
            indicator_name: 'Annual Mean Precipitation Corrected Centroid (mm/day, NASA POWER)',
            module_id: 4,
            source_id: source.source_id,
            dataset_id: source.dataset_id,
            period_year: currentYear,
            value_numeric: Number(precip.toFixed(2)),
            unit: 'mm/day',
            valuation_basis: 'count',
            methodology_id: 'NASA_POWER_CLIMATOLOGY_V2',
            commercial_use_allowed: source.commercial_use_allowed,
            asserted_at: assertedAt,
          });
        }
      } finally {
        safeUnlink(res.filePath);
      }
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestNasaCmr(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();
  const territories = listTerritories();

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  let lastEtag: string | null = null;
  let dedupHit = false;

  const batchSize = 4;
  for (let i = 0; i < territories.length; i += batchSize) {
    const batch = territories.slice(i, i + batchSize);
    const results = await Promise.allSettled(
      batch.map(async (t) => {
        const url = `https://cmr.earthdata.nasa.gov/search/collections.json?point=${t.centroid_lon},${t.centroid_lat}&page_size=1&has_granules=true`;
        const res = await fetchWithCitizenship({
          url,
          host: source.host,
          rateLimitRpm: source.rate_limit_rpm,
          maxConcurrency: source.max_concurrency,
          bypassConditionalCache: true,
          destPrefix: `nasa_cmr_${t.iso3}`,
          timeoutMs: 15_000,
        });
        return { territory: t, res };
      })
    );

    for (const outcome of results) {
      if (outcome.status !== 'fulfilled') continue;
      const { territory, res } = outcome.value;
      dedupHit = dedupHit || res.dedupHit;
      if (res.etag) lastEtag = res.etag;

      let cmrHits = Number(res.responseHeaders?.['cmr-hits']);
      try {
        if ((!Number.isFinite(cmrHits) || cmrHits <= 0) && res.filePath) {
          const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
            feed?: { entry?: Array<unknown> };
          };
          if (Array.isArray(json.feed?.entry)) {
            cmrHits = json.feed.entry.length;
          }
        }
      } finally {
        if (res.filePath) safeUnlink(res.filePath);
      }

      if (!Number.isFinite(cmrHits) || cmrHits <= 0) continue;
      rawRows.push({ iso3: territory.iso3, cmr_hits: cmrHits });

      silver.push({
        territory_id: territory.territory_id,
        iso3: territory.iso3,
        indicator_id: 'NASA_CMR.EO_COLLECTIONS',
        indicator_name: 'Earth Observation Collections Overlapping Centroid (NASA CMR)',
        module_id: 4,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: currentYear,
        value_numeric: Math.round(cmrHits),
        unit: 'collections',
        valuation_basis: 'count',
        methodology_id: 'NASA_CMR_SEARCH_COLLECTIONS_V1',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestClimateTrace(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const url = 'https://api.climatetrace.org/v7/sources?year=2024&gas=co2e_100yr&limit=200';
  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'climate_trace_v7',
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  try {
    const parsed = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as unknown;
    const list = Array.isArray(parsed) ? parsed : [];
    const totalsByTerritory = new Map<string, { iso3: string; totalCo2e: number }>();

    for (const item of list as Array<{
      country?: string;
      emissionsQuantity?: number;
      emissions?: { co2e_100yr?: number };
    }>) {
      rawRows.push(item);
      if (!item.country) continue;
      const territory = resolveTerritoryByCodeOrName(item.country);
      if (!territory) continue;

      const qty =
        typeof item.emissionsQuantity === 'number' && Number.isFinite(item.emissionsQuantity)
          ? item.emissionsQuantity
          : typeof item.emissions?.co2e_100yr === 'number' && Number.isFinite(item.emissions.co2e_100yr)
            ? item.emissions.co2e_100yr
            : null;
      if (qty === null) continue;

      const prev = totalsByTerritory.get(territory.territory_id);
      if (prev) {
        prev.totalCo2e += qty;
      } else {
        totalsByTerritory.set(territory.territory_id, { iso3: territory.iso3, totalCo2e: qty });
      }
    }

    for (const [territoryId, agg] of totalsByTerritory.entries()) {
      silver.push({
        territory_id: territoryId,
        iso3: agg.iso3,
        indicator_id: 'CT.GHG.CO2E_100YR',
        indicator_name: 'Top-Source GHG Emissions CO2e 100yr Sample (Climate TRACE v7)',
        module_id: 4,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: 2024,
        value_numeric: Number(agg.totalCo2e.toFixed(2)),
        unit: 'tonnes CO2e',
        valuation_basis: 'count',
        methodology_id: 'CLIMATE_TRACE_V7_SOURCES',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestEmberEnergy(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const url =
    'https://files.ember-energy.org/public-downloads/generation/outputs/release_generation_yearly_global.csv';
  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'ember_global_yearly',
    timeoutMs: 30_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const dedupKeys = new Set<string>();

  try {
    const csvRows = await withDuckDBConnection(async (conn) => {
      const reader = await conn.runAndReadAll(`
        SELECT
          "ISO 3 code" AS iso3,
          CAST(Year AS INTEGER) AS year,
          "Electricity source" AS electricity_source,
          TRY_CAST("Generation (TWh)" AS DOUBLE) AS generation_twh,
          TRY_CAST("Share of generation (%)" AS DOUBLE) AS share_pct,
          TRY_CAST("Emissions intensity (gCO2e/kWh)" AS DOUBLE) AS carbon_intensity
        FROM read_csv_auto(${sqlQuote(res.filePath!)}, header=true)
        WHERE "Area type" = 'Country or economy'
          AND Year >= 2020
          AND "ISO 3 code" IS NOT NULL
          AND "Electricity source" IN ('Clean', 'Wind and solar', 'Total generation');
      `);
      try {
        return reader.getRowObjectsJson() as Array<Record<string, unknown>>;
      } finally {
        reader.closeSync();
      }
    });

    const pushMetric = (
      territoryId: string,
      iso3: string,
      indicatorId: string,
      indicatorName: string,
      year: number,
      val: number,
      unit: string,
      basis: ObservationContract['valuation_basis']
    ) => {
      const key = `${territoryId}|${indicatorId}|${year}`;
      if (dedupKeys.has(key)) return;
      dedupKeys.add(key);
      silver.push({
        territory_id: territoryId,
        iso3,
        indicator_id: indicatorId,
        indicator_name: indicatorName,
        module_id: 5,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: year,
        value_numeric: Number(val.toFixed(2)),
        unit,
        valuation_basis: basis,
        methodology_id: 'EMBER_GLOBAL_YEARLY_CC_BY_4',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    };

    for (const r of csvRows) {
      const iso3 = String(r.iso3 ?? '').trim();
      const year = Number(r.year);
      const srcType = String(r.electricity_source ?? '').trim();
      if (!iso3 || !Number.isInteger(year)) continue;

      const territory = resolveTerritoryByCodeOrName(iso3);
      if (!territory) continue;
      rawRows.push(r);

      const genTwh =
        typeof r.generation_twh === 'number' && Number.isFinite(r.generation_twh) ? r.generation_twh : null;
      const sharePct =
        typeof r.share_pct === 'number' && Number.isFinite(r.share_pct) ? r.share_pct : null;
      const intensity =
        typeof r.carbon_intensity === 'number' && Number.isFinite(r.carbon_intensity) ? r.carbon_intensity : null;

      if (srcType === 'Clean' && sharePct !== null) {
        pushMetric(
          territory.territory_id,
          territory.iso3,
          'EMBER.CLEAN_SHARE_PCT',
          'Clean Electricity Share of Generation (%, Ember CC-BY-4.0)',
          year,
          sharePct,
          '%',
          'percent'
        );
      } else if (srcType === 'Wind and solar' && sharePct !== null) {
        pushMetric(
          territory.territory_id,
          territory.iso3,
          'EMBER.WIND_SOLAR_SHARE_PCT',
          'Wind & Solar Share of Electricity Generation (%, Ember CC-BY-4.0)',
          year,
          sharePct,
          '%',
          'percent'
        );
      } else if (srcType === 'Total generation') {
        if (genTwh !== null) {
          pushMetric(
            territory.territory_id,
            territory.iso3,
            'EMBER.TOTAL_GEN_TWH',
            'Total Electricity Generation (TWh, Ember CC-BY-4.0)',
            year,
            genTwh,
            'TWh',
            'count'
          );
        }
        if (intensity !== null) {
          pushMetric(
            territory.territory_id,
            territory.iso3,
            'EMBER.CARBON_INTENSITY_GCO2_KWH',
            'Electricity Grid Carbon Intensity (gCO2e/kWh, Ember CC-BY-4.0)',
            year,
            intensity,
            'gCO2e/kWh',
            'count'
          );
        }
      }
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestUnsdEnergySdmx(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const territories = listTerritories();
  const m49Lookup = new Map(territories.map((t) => [String(Number(t.un_m49)), t]));
  const m49Filter = territories.map((t) => t.un_m49).sort().join('+');
  const url = `https://data.un.org/ws/rest/data/UNSD,DF_UNDATA_ENERGY,1.2/A.${m49Filter}.7000.01+12?startPeriod=2020&endPeriod=2024`;

  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    headers: {
      'Accept-Language': 'en',
      Accept: 'application/vnd.sdmx.data+csv;version=1.0.0',
    },
    destPrefix: 'unsd_energy_elec',
    timeoutMs: 25_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const dedupKeys = new Set<string>();

  try {
    const csvRows = await withDuckDBConnection(async (conn) => {
      const reader = await conn.runAndReadAll(`
        SELECT REF_AREA, TRANSACTION, TIME_PERIOD, OBS_VALUE, UNIT_MULT
        FROM read_csv_auto(${sqlQuote(res.filePath!)}, header=true, all_varchar=true)
        WHERE REF_AREA IS NOT NULL AND OBS_VALUE IS NOT NULL;
      `);
      try {
        return reader.getRowObjectsJson() as Array<Record<string, unknown>>;
      } finally {
        reader.closeSync();
      }
    });

    for (const r of csvRows) {
      const m49Key = String(Number(String(r.REF_AREA ?? '').trim()));
      const tx = String(r.TRANSACTION ?? '').trim();
      const year = Number(String(r.TIME_PERIOD ?? '').trim());
      const rawVal = Number(String(r.OBS_VALUE ?? '').trim());
      const unitMult = Number(String(r.UNIT_MULT ?? '0').trim()) || 0;
      if (!m49Key || !Number.isInteger(year) || !Number.isFinite(rawVal)) continue;

      const territory = m49Lookup.get(m49Key);
      if (!territory) continue;

      const meta =
        tx === '01' || tx === '1'
          ? {
              indicatorId: 'UNSD.ELEC_GROSS_PROD_GWH',
              indicatorName: 'Electricity Gross Production (GWh, UNSD DF_UNDATA_ENERGY)',
            }
          : tx === '12'
            ? {
                indicatorId: 'UNSD.ELEC_FINAL_CONS_GWH',
                indicatorName: 'Electricity Final Consumption (GWh, UNSD DF_UNDATA_ENERGY)',
              }
            : null;
      if (!meta) continue;

      const scaledVal = unitMult !== 0 ? rawVal * Math.pow(10, unitMult) : rawVal;
      if (!Number.isFinite(scaledVal)) continue;

      const key = `${territory.territory_id}|${meta.indicatorId}|${year}`;
      if (dedupKeys.has(key)) continue;
      dedupKeys.add(key);

      rawRows.push(r);
      silver.push({
        territory_id: territory.territory_id,
        iso3: territory.iso3,
        indicator_id: meta.indicatorId,
        indicator_name: meta.indicatorName,
        module_id: 5,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: year,
        value_numeric: Number(scaledVal.toFixed(1)),
        unit: 'GWh',
        valuation_basis: 'count',
        methodology_id: 'UNSD_DF_UNDATA_ENERGY_12',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestGbifOccurrence(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const url = 'https://api.gbif.org/v1/occurrence/search?limit=0&facet=country&facetLimit=250';
  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'gbif_country_facets',
    timeoutMs: 15_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const dedupKeys = new Set<string>();

  try {
    const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
      facets?: Array<{
        field?: string;
        counts?: Array<{ name?: string; count?: number }>;
      }>;
    };

    const countryCounts = json.facets?.[0]?.counts ?? [];
    for (const item of countryCounts) {
      rawRows.push(item);
      if (!item.name || typeof item.count !== 'number' || !Number.isFinite(item.count)) continue;
      const territory = resolveTerritoryByCodeOrName(item.name);
      if (!territory) continue;
      if (dedupKeys.has(territory.territory_id)) continue;
      dedupKeys.add(territory.territory_id);

      silver.push({
        territory_id: territory.territory_id,
        iso3: territory.iso3,
        indicator_id: 'GBIF.SPECIES_OCCURRENCES',
        indicator_name: 'Georeferenced Species Occurrences (GBIF Facet Total)',
        module_id: 4,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: currentYear,
        value_numeric: Math.round(item.count),
        unit: 'records',
        valuation_basis: 'count',
        methodology_id: 'GBIF_OCCURRENCE_V1_FACET',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestObisV3(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();

  const countriesRes = await fetchWithCitizenship({
    url: 'https://api.obis.org/v3/country',
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: true,
    destPrefix: 'obis_countries',
    timeoutMs: 15_000,
  });

  if (!countriesRes.filePath) {
    return { rawRows: [], silver: [], etag: countriesRes.etag, dedupHit: countriesRes.dedupHit, notModified: countriesRes.status === 'NOT_MODIFIED' };
  }

  const matchedCountries: Array<{
    obisId: number;
    territory: NonNullable<ReturnType<typeof resolveTerritoryByCodeOrName>>;
  }> = [];

  try {
    const json = JSON.parse(fs.readFileSync(countriesRes.filePath, 'utf-8')) as {
      results?: Array<{ id?: number; country?: string; code?: string }>;
    };
    const seenTerritory = new Set<string>();
    for (const item of json.results ?? []) {
      if (typeof item.id !== 'number') continue;
      const territory =
        (item.code ? resolveTerritoryByCodeOrName(item.code) : undefined) ??
        (item.country ? resolveTerritoryByCodeOrName(item.country) : undefined);
      if (!territory || seenTerritory.has(territory.territory_id)) continue;
      seenTerritory.add(territory.territory_id);
      matchedCountries.push({ obisId: item.id, territory });
    }
  } finally {
    safeUnlink(countriesRes.filePath);
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  let lastEtag: string | null = countriesRes.etag;
  let dedupHit = countriesRes.dedupHit;

  const batchSize = 4;
  for (let i = 0; i < matchedCountries.length; i += batchSize) {
    const batch = matchedCountries.slice(i, i + batchSize);
    const statsResults = await Promise.allSettled(
      batch.map(async (entry) => {
        const url = `https://api.obis.org/v3/statistics?countryid=${entry.obisId}`;
        const res = await fetchWithCitizenship({
          url,
          host: source.host,
          rateLimitRpm: source.rate_limit_rpm,
          maxConcurrency: source.max_concurrency,
          bypassConditionalCache: true,
          destPrefix: `obis_stats_${entry.territory.iso3}`,
          timeoutMs: 15_000,
        });
        return { entry, res };
      })
    );

    for (const outcome of statsResults) {
      if (outcome.status !== 'fulfilled') continue;
      const { entry, res } = outcome.value;
      dedupHit = dedupHit || res.dedupHit;
      if (res.etag) lastEtag = res.etag;
      if (!res.filePath) continue;

      try {
        const stats = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
          records?: number;
          species?: number;
        };
        rawRows.push({ iso3: entry.territory.iso3, obisId: entry.obisId, ...stats });

        if (typeof stats.records === 'number' && Number.isFinite(stats.records)) {
          silver.push({
            territory_id: entry.territory.territory_id,
            iso3: entry.territory.iso3,
            indicator_id: 'OBIS.MARINE_RECORDS',
            indicator_name: 'Marine Biodiversity Occurrence Records (OBIS v3 EEZ)',
            module_id: 4,
            source_id: source.source_id,
            dataset_id: source.dataset_id,
            period_year: currentYear,
            value_numeric: Math.round(stats.records),
            unit: 'records',
            valuation_basis: 'count',
            methodology_id: 'OBIS_V3_COUNTRY_STATS',
            commercial_use_allowed: source.commercial_use_allowed,
            asserted_at: assertedAt,
          });
        }
        if (typeof stats.species === 'number' && Number.isFinite(stats.species)) {
          silver.push({
            territory_id: entry.territory.territory_id,
            iso3: entry.territory.iso3,
            indicator_id: 'OBIS.MARINE_SPECIES',
            indicator_name: 'Distinct Marine Species Recorded (OBIS v3 EEZ)',
            module_id: 4,
            source_id: source.source_id,
            dataset_id: source.dataset_id,
            period_year: currentYear,
            value_numeric: Math.round(stats.species),
            unit: 'species',
            valuation_basis: 'count',
            methodology_id: 'OBIS_V3_COUNTRY_STATS',
            commercial_use_allowed: source.commercial_use_allowed,
            asserted_at: assertedAt,
          });
        }
      } finally {
        safeUnlink(res.filePath);
      }
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestUsgsEarthquakes(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const url =
    'https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&starttime=2025-01-01&minmagnitude=5.5&limit=200';
  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'usgs_m55_2025',
    timeoutMs: 15_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const territories = listTerritories();

  try {
    const geojson = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
      features?: Array<{
        geometry?: { coordinates?: [number, number, number?] };
      }>;
    };

    const counts = new Map<string, { iso3: string; count: number }>();
    for (const f of geojson.features ?? []) {
      rawRows.push(f);
      const coords = f.geometry?.coordinates;
      if (!coords || coords.length < 2) continue;
      const [lon, lat] = coords;
      if (!Number.isFinite(lon) || !Number.isFinite(lat)) continue;

      let bestTerritory: (typeof territories)[number] | null = null;
      let bestDistSq = Infinity;
      for (const t of territories) {
        const dLat = lat - t.centroid_lat;
        const dLon = lon - t.centroid_lon;
        const distSq = dLat * dLat + dLon * dLon;
        if (distSq < bestDistSq) {
          bestDistSq = distSq;
          bestTerritory = t;
        }
      }

      if (!bestTerritory || bestDistSq > 18 * 18) continue;
      const prev = counts.get(bestTerritory.territory_id);
      if (prev) {
        prev.count++;
      } else {
        counts.set(bestTerritory.territory_id, { iso3: bestTerritory.iso3, count: 1 });
      }
    }

    for (const [territoryId, entry] of counts.entries()) {
      silver.push({
        territory_id: territoryId,
        iso3: entry.iso3,
        indicator_id: 'USGS.SEISMIC_EVENTS_M55',
        indicator_name: 'Significant Seismic Events M>=5.5 (USGS FDSN Nearest Territory)',
        module_id: 4,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: 2025,
        value_numeric: entry.count,
        unit: 'events',
        valuation_basis: 'count',
        methodology_id: 'USGS_FDSN_M55_CENTROID',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestUndrrDatum(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const territories = listTerritories();
  const m49Lookup = new Map(territories.map((t) => [String(Number(t.un_m49)), t]));
  const areaParams = territories.map((t) => `areaCode=${Number(t.un_m49)}`).join('&');

  const sendaiSeries = [
    {
      seriesCode: 'VC_DSR_MTMP',
      indicatorId: 'UNDRR.DISASTER_MORT_PER_100K',
      indicatorName: 'Disaster Mortality & Missing Persons per 100k Pop (UNDRR Sendai)',
      unit: 'per 100k',
    },
    {
      seriesCode: 'VC_DSR_DAFF',
      indicatorId: 'UNDRR.AFFECTED_PER_100K',
      indicatorName: 'Directly Affected Persons by Disasters per 100k Pop (UNDRR Sendai)',
      unit: 'per 100k',
    },
  ];

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const dedupKeys = new Set<string>();
  let lastEtag: string | null = null;
  let dedupHit = false;

  const specs: FetchOptions[] = sendaiSeries.map((target) => ({
    url: `https://unstats.un.org/sdgapi/v1/sdg/Series/Data?seriesCode=${target.seriesCode}&${areaParams}&timePeriodStart=2015&pageSize=1500`,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    destPrefix: `undrr_${target.seriesCode}`,
    timeoutMs: 20_000,
  }));

  const batch = await fetchConsistentBatch(specs, { bypassCache });
  if (batch.allNotModified) {
    return { rawRows: [], silver: [], etag: null, dedupHit: false, notModified: true };
  }

  for (let i = 0; i < sendaiSeries.length; i++) {
    const target = sendaiSeries[i];
    const res = batch.results[i];
    if (!res) continue;
    dedupHit = dedupHit || res.dedupHit;
    if (res.etag) lastEtag = res.etag;
    if (!res.filePath) continue;

    try {
      const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
        data?: Array<{
          series?: string;
          geoAreaCode?: string;
          timePeriodStart?: number;
          value?: string | number | null;
        }>;
      };

      for (const r of json.data ?? []) {
        if (r.series !== target.seriesCode) continue;
        const m49 = String(Number(r.geoAreaCode ?? ''));
        const territory = m49Lookup.get(m49);
        const year = Number(r.timePeriodStart);
        const val = Number(r.value);
        if (!territory || !Number.isInteger(year) || !Number.isFinite(val)) continue;

        const key = `${territory.territory_id}|${target.indicatorId}|${year}`;
        if (dedupKeys.has(key)) continue;
        dedupKeys.add(key);

        rawRows.push(r);
        silver.push({
          territory_id: territory.territory_id,
          iso3: territory.iso3,
          indicator_id: target.indicatorId,
          indicator_name: target.indicatorName,
          module_id: 4,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: year,
          value_numeric: Number(val.toFixed(3)),
          unit: target.unit,
          valuation_basis: 'count',
          methodology_id: `UNDRR_SENDAI_${target.seriesCode}`,
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    } finally {
      safeUnlink(res.filePath);
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestNoaaNceiCdo(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const noaaToken = (process.env.NOAA_CDO_TOKEN ?? '').trim();

  const stationToIso3: Record<string, string> = {
    USW00094728: 'USA',
    'BR00E3-0520': 'BRA',
    UKM00003772: 'GBR',
    FRM00007156: 'FRA',
    SP000003195: 'ESP',
    PLM00012375: 'POL',
    NOM00001492: 'NOR',
    TUM00017130: 'TUR',
    CHM00054511: 'CHN',
  };

  const stationList = Object.keys(stationToIso3).join(',');
  const url = `https://www.ncei.noaa.gov/access/services/data/v1?dataset=global-summary-of-the-year&stations=${encodeURIComponent(stationList)}&startDate=2022-01-01&endDate=2024-12-31&dataTypes=TAVG,PRCP&format=json`;

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const dedupKeys = new Set<string>();
  let lastEtag: string | null = null;
  let dedupHit = false;

  const pushUnique = (rec: ObservationContract) => {
    const k = `${rec.territory_id}|${rec.indicator_id}|${rec.period_year}`;
    if (dedupKeys.has(k)) return;
    dedupKeys.add(k);
    silver.push(rec);
  };

  const noaaBatch = await fetchConsistentBatch(
    [
      {
        url,
        host: source.host,
        rateLimitRpm: source.rate_limit_rpm,
        maxConcurrency: source.max_concurrency,
        destPrefix: 'noaa_ncei_gsoy',
        timeoutMs: 25_000,
      },
      {
        url: 'https://gml.noaa.gov/webdata/ccgg/trends/co2/co2_annmean_mlo.csv',
        host: 'gml.noaa.gov',
        rateLimitRpm: source.rate_limit_rpm,
        maxConcurrency: 1,
        destPrefix: 'noaa_gml_co2',
        timeoutMs: 15_000,
      },
    ],
    { bypassCache, allowPartialErrors: true }
  );

  if (noaaBatch.allNotModified) {
    return { rawRows: [], silver: [], etag: null, dedupHit: false, notModified: true };
  }

  const res = noaaBatch.results[0];
  const co2Res = noaaBatch.results[1];

  if (res) {
    dedupHit = dedupHit || res.dedupHit;
    if (res.etag) lastEtag = res.etag;
  }

  if (res?.filePath) {
    try {
      const rows = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as Array<{
        DATE?: string;
        STATION?: string;
        TAVG?: string | number | null;
        PRCP?: string | number | null;
      }>;

      for (const r of Array.isArray(rows) ? rows : []) {
        const st = String(r.STATION ?? '').trim();
        const iso3 = stationToIso3[st];
        if (!iso3) continue;
        const territory = resolveTerritoryByCodeOrName(iso3);
        const year = Number(String(r.DATE ?? '').trim().slice(0, 4));
        if (!territory || !Number.isInteger(year)) continue;

        rawRows.push(r);

        const tavgStr = r.TAVG !== null && r.TAVG !== undefined ? String(r.TAVG).trim() : '';
        const tavg = tavgStr !== '' ? Number(tavgStr) : NaN;
        if (Number.isFinite(tavg)) {
          pushUnique({
            territory_id: territory.territory_id,
            iso3: territory.iso3,
            indicator_id: 'NOAA.STATION_TAVG_C',
            indicator_name: `Reference GHCN Station Mean Annual Temperature °C (${st}, NOAA NCEI)`,
            module_id: 4,
            source_id: source.source_id,
            dataset_id: source.dataset_id,
            period_year: year,
            value_numeric: Number(tavg.toFixed(2)),
            unit: 'degC',
            valuation_basis: 'count',
            methodology_id: 'NOAA_NCEI_ACCESS_V1_GSOY',
            commercial_use_allowed: source.commercial_use_allowed,
            asserted_at: assertedAt,
          });
        }

        const prcpStr = r.PRCP !== null && r.PRCP !== undefined ? String(r.PRCP).trim() : '';
        const prcp = prcpStr !== '' ? Number(prcpStr) : NaN;
        if (Number.isFinite(prcp) && prcp >= 0) {
          pushUnique({
            territory_id: territory.territory_id,
            iso3: territory.iso3,
            indicator_id: 'NOAA.STATION_PRCP_MM',
            indicator_name: `Reference GHCN Station Annual Precipitation mm (${st}, NOAA NCEI)`,
            module_id: 4,
            source_id: source.source_id,
            dataset_id: source.dataset_id,
            period_year: year,
            value_numeric: Number(prcp.toFixed(1)),
            unit: 'mm',
            valuation_basis: 'count',
            methodology_id: 'NOAA_NCEI_ACCESS_V1_GSOY',
            commercial_use_allowed: source.commercial_use_allowed,
            asserted_at: assertedAt,
          });
        }
      }
    } finally {
      safeUnlink(res.filePath);
    }
  }

  // NOAA Global Monitoring Laboratory Mauna Loa annual atmospheric CO2 CSV (keyless)
  if (co2Res?.filePath) {
    dedupHit = dedupHit || co2Res.dedupHit;
    if (co2Res.etag) lastEtag = co2Res.etag;
    try {
      const text = fs.readFileSync(co2Res.filePath, 'utf-8');
      for (const line of text.split(/\r?\n/)) {
        if (!line || line.startsWith('#') || line.startsWith('year,')) continue;
        const parts = line.split(',');
        const year = Number(parts[0]?.trim());
        const mean = Number(parts[1]?.trim());
        if (!Number.isInteger(year) || year < 2018 || !Number.isFinite(mean)) continue;
        rawRows.push({ feed: 'NOAA_GML_MLO_CO2', year, mean_ppm: mean });
        pushUnique({
          territory_id: 'T_USA',
          iso3: 'USA',
          indicator_id: 'NOAA.MLO_CO2_PPM',
          indicator_name: 'Mauna Loa Atmospheric CO2 Annual Mean Concentration (ppm, NOAA GML)',
          module_id: 4,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: year,
          value_numeric: Number(mean.toFixed(2)),
          unit: 'ppm',
          valuation_basis: 'count',
          methodology_id: 'NOAA_GML_MAUNA_LOA_CO2',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    } finally {
      safeUnlink(co2Res.filePath);
    }
  }

  if (noaaToken) {
    try {
      const cdoRes = await fetchWithCitizenship({
        url: 'https://www.ncei.noaa.gov/cdo-web/api/v2/datasets?limit=5',
        host: source.host,
        rateLimitRpm: source.rate_limit_rpm,
        maxConcurrency: 1,
        bypassConditionalCache: bypassCache,
        headers: { token: noaaToken },
        destPrefix: 'noaa_cdo_v2_probe',
        timeoutMs: 10_000,
      });
      if (cdoRes.filePath) {
        try {
          const j = JSON.parse(fs.readFileSync(cdoRes.filePath, 'utf-8')) as {
            metadata?: { resultset?: { count?: number } };
          };
          if (typeof j.metadata?.resultset?.count === 'number') {
            rawRows.push({ feed: 'NOAA_CDO_V2', dataset_count: j.metadata.resultset.count });
          }
        } finally {
          safeUnlink(cdoRes.filePath);
        }
      }
    } catch {
      // Non-fatal
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestGlobalForestWatch(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const gfwKey = (process.env.GFW_API_KEY ?? '').trim();
  const catalogRaw: unknown[] = [];

  try {
    const catRes = await fetchWithCitizenship({
      url: 'https://data-api.globalforestwatch.org/datasets?page[size]=10',
      host: 'data-api.globalforestwatch.org',
      rateLimitRpm: source.rate_limit_rpm,
      maxConcurrency: 1,
      bypassConditionalCache: true,
      headers: gfwKey ? { 'x-api-key': gfwKey } : undefined,
      destPrefix: 'gfw_datasets_cat',
      timeoutMs: 12_000,
    });
    if (catRes.filePath) {
      try {
        const json = JSON.parse(fs.readFileSync(catRes.filePath, 'utf-8')) as { data?: Array<{ dataset?: string }> };
        if (Array.isArray(json.data)) {
          catalogRaw.push({
            gfw_api_datasets_sample: json.data.slice(0, 5).map((d) => d.dataset),
            gfw_key_present: Boolean(gfwKey),
          });
        }
      } finally {
        safeUnlink(catRes.filePath);
      }
    }
  } catch {
    // Non-fatal: proceed to Hansen/UMD/GFW tree-cover loss country series
  }

  const owidOutcome = await ingestOwidDatasets(
    { ...source, host: 'ourworldindata.org' },
    [
      {
        slug: 'tree-cover-loss',
        indicatorId: 'GFW.TREE_COVER_LOSS_HA',
        indicatorName: 'Annual Tree Cover Loss Area (Hectares, Hansen/UMD/GFW)',
        moduleId: 4,
        unit: 'hectares',
        valuationBasis: 'count',
        methodologyId: 'GFW_HANSEN_UMD_TREE_COVER_LOSS',
        columnName: 'Total',
        minYear: 2018,
        decimals: 0,
        rawValueKey: 'tree_cover_loss_ha',
      },
    ]
  );

  return {
    ...owidOutcome,
    rawRows: [...catalogRaw, ...owidOutcome.rawRows],
  };
}

export async function ingestEiaApiV2(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const eiaKey = (process.env.EIA_API_KEY ?? '').trim();

  const url = 'https://www.eia.gov/totalenergy/data/browser/csv.php?tbl=T01.01';
  const res = await fetchWithCitizenship({
    url,
    host: 'www.eia.gov',
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'eia_mer_t0101',
    timeoutMs: 25_000,
  });

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const dedupKeys = new Set<string>();
  let lastEtag: string | null = res.etag;
  const dedupHit = res.dedupHit;

  if (res.filePath) {
    try {
      const csvRows = await withDuckDBConnection(async (conn) => {
        const reader = await conn.runAndReadAll(`
          SELECT
            TRIM(MSN) AS msn,
            CAST(SUBSTR(TRIM(YYYYMM), 1, 4) AS INTEGER) AS yr,
            TRY_CAST(NULLIF(TRIM(Value), 'Not Available') AS DOUBLE) AS val
          FROM read_csv_auto(${sqlQuote(res.filePath!)}, header=true, all_varchar=true)
          WHERE TRIM(MSN) IN ('TEPRBUS', 'TETCBUS')
            AND TRIM(YYYYMM) LIKE '%13'
            AND TRY_CAST(SUBSTR(TRIM(YYYYMM), 1, 4) AS INTEGER) BETWEEN 2018 AND 2026;
        `);
        try {
          return reader.getRowObjectsJson() as Array<{ msn?: string; yr?: number; val?: number | null }>;
        } finally {
          reader.closeSync();
        }
      });

      for (const r of csvRows) {
        const msn = String(r.msn ?? '').trim();
        const year = Number(r.yr);
        const val = typeof r.val === 'number' && Number.isFinite(r.val) ? r.val : null;
        if (!Number.isInteger(year) || val === null) continue;

        const isProd = msn === 'TEPRBUS';
        const indicatorId = isProd ? 'EIA.US_PRIMARY_ENERGY_PROD_QBTU' : 'EIA.US_PRIMARY_ENERGY_CONS_QBTU';
        const indicatorName = isProd
          ? 'U.S. Total Primary Energy Production (Quadrillion Btu, EIA MER T1.1)'
          : 'U.S. Total Primary Energy Consumption (Quadrillion Btu, EIA MER T1.1)';

        const k = `T_USA|${indicatorId}|${year}`;
        if (dedupKeys.has(k)) continue;
        dedupKeys.add(k);

        rawRows.push(r);
        silver.push({
          territory_id: 'T_USA',
          iso3: 'USA',
          indicator_id: indicatorId,
          indicator_name: indicatorName,
          module_id: 5,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: year,
          value_numeric: Number(val.toFixed(3)),
          unit: 'Quadrillion Btu',
          valuation_basis: 'count',
          methodology_id: 'US_EIA_MER_T01_01_CSV',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    } finally {
      safeUnlink(res.filePath);
    }
  }

  if (eiaKey) {
    try {
      const v2Res = await fetchWithCitizenship({
        url: `https://api.eia.gov/v2/total-energy/data/?api_key=${encodeURIComponent(eiaKey)}&frequency=annual&data[0]=value&start=2022&length=5`,
        host: 'api.eia.gov',
        rateLimitRpm: source.rate_limit_rpm,
        maxConcurrency: 1,
        bypassConditionalCache: bypassCache,
        destPrefix: 'eia_api_v2_probe',
        timeoutMs: 12_000,
      });
      if (v2Res.etag) lastEtag = v2Res.etag;
      if (v2Res.filePath) {
        try {
          rawRows.push({ eia_api_v2_checked: true, bytes: fs.statSync(v2Res.filePath).size });
        } finally {
          safeUnlink(v2Res.filePath);
        }
      }
    } catch {
      // Non-fatal
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestProtectedPlanetWdpa(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const wdpaKey = (process.env.WDPA_API_KEY ?? '').trim();
  const extraRaw: unknown[] = [];

  if (wdpaKey) {
    try {
      const apiRes = await fetchWithCitizenship({
        url: `https://api.protectedplanet.net/v4/countries/BRA?token=${encodeURIComponent(wdpaKey)}`,
        host: 'api.protectedplanet.net',
        rateLimitRpm: source.rate_limit_rpm,
        maxConcurrency: 1,
        bypassConditionalCache: true,
        destPrefix: 'wdpa_v4_probe',
        timeoutMs: 12_000,
      });
      if (apiRes.filePath) {
        try {
          extraRaw.push({ wdpa_v4_checked: true, bytes: fs.statSync(apiRes.filePath).size });
        } finally {
          safeUnlink(apiRes.filePath);
        }
      }
    } catch {
      // Non-fatal
    }
  }

  const owidOutcome = await ingestOwidDatasets(
    { ...source, host: 'ourworldindata.org' },
    [
      {
        slug: 'terrestrial-protected-areas',
        indicatorId: 'WDPA.TERRESTRIAL_PROTECTED_PCT',
        indicatorName: 'Terrestrial Protected Areas (% of Total Land Area, WDPA / UNEP-WCMC)',
        moduleId: 4,
        unit: '% of land',
        valuationBasis: 'percent',
        methodologyId: 'UNEP_WCMC_WDPA_TERRESTRIAL_PCT',
        columnName: 'Terrestrial protected areas (% of total land area)',
        minYear: 2015,
        decimals: 2,
        rawValueKey: 'terrestrial_protected_pct',
      },
    ]
  );

  return {
    ...owidOutcome,
    rawRows: [...extraRaw, ...owidOutcome.rawRows],
  };
}

