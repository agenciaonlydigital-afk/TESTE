import fs from 'node:fs';
import { listTerritories, resolveTerritoryByCodeOrName } from '../../controlPlane.ts';
import { sqlQuote, withDuckDBConnection } from '../../duckdbEngine.ts';
import { fetchConsistentBatch, fetchWithCitizenship, type FetchOptions } from '../../httpCitizenship.ts';
import type { ObservationContract, SourceCatalogEntry } from '../../types.ts';
import { safeUnlink, shouldBypassConditionalCache, type ConnectorOutcome } from '../shared.ts';

export async function ingestWbWitsRest(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const iso3s = listTerritories()
    .map((t) => t.iso3)
    .sort();
  const chunks: string[][] = [];
  for (let i = 0; i < iso3s.length; i += 16) {
    chunks.push(iso3s.slice(i, i + 16));
  }

  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  let lastEtag: string | null = null;
  let dedupHit = false;
  const dedupKeys = new Set<string>();

  const specs: FetchOptions[] = chunks.map((chunk, idx) => ({
    url: `https://wits.worldbank.org/API/V1/SDMX/V21/datasource/tradestats-trade/reporter/${chunk.join(';')}/year/2020;2021;2022;2023/partner/WLD/product/Total/indicator/XPRT-TRD-VL;MPRT-TRD-VL?format=JSON`,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    destPrefix: `wb_wits_c${idx}`,
    timeoutMs: 20_000,
  }));

  const batch = await fetchConsistentBatch(specs, { bypassCache });
  if (batch.allNotModified) {
    return { rawRows: [], silver: [], etag: null, dedupHit: false, notModified: true };
  }

  for (let idx = 0; idx < batch.results.length; idx++) {
    const res = batch.results[idx];
    if (!res) continue;
    dedupHit = dedupHit || res.dedupHit;
    if (res.etag) lastEtag = res.etag;
    if (!res.filePath) continue;

    try {
      const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
        dataSets?: Array<{
          series?: Record<string, { observations?: Record<string, Array<number | null>> }>;
        }>;
        structure?: {
          dimensions?: {
            series?: Array<{ id?: string; values?: Array<{ id?: string }> }>;
            observation?: Array<{ id?: string; values?: Array<{ id?: string }> }>;
          };
        };
      };

      const seriesDims = json.structure?.dimensions?.series ?? [];
      const obsYears = json.structure?.dimensions?.observation?.[0]?.values ?? [];
      const reporterPos = seriesDims.findIndex((d) => d.id === 'REPORTER');
      const indicatorPos = seriesDims.findIndex((d) => d.id === 'INDICATOR');
      const seriesMap = json.dataSets?.[0]?.series ?? {};

      if (reporterPos < 0 || indicatorPos < 0) continue;

      for (const [seriesKey, seriesBody] of Object.entries(seriesMap)) {
        const coords = seriesKey.split(':').map(Number);
        const reporterCode = seriesDims[reporterPos]?.values?.[coords[reporterPos]]?.id;
        const witsIndicator = seriesDims[indicatorPos]?.values?.[coords[indicatorPos]]?.id;
        if (!reporterCode || !witsIndicator) continue;

        const territory = resolveTerritoryByCodeOrName(reporterCode);
        if (!territory) continue;

        const meta =
          witsIndicator === 'XPRT-TRD-VL'
            ? {
                indicatorId: 'WITS.EXPORTS_USD',
                indicatorName: 'Merchandise Exports to World (Current US$, WB WITS)',
              }
            : witsIndicator === 'MPRT-TRD-VL'
              ? {
                  indicatorId: 'WITS.IMPORTS_USD',
                  indicatorName: 'Merchandise Imports from World (Current US$, WB WITS)',
                }
              : null;
        if (!meta) continue;

        for (const [obsIdxStr, obsArr] of Object.entries(seriesBody.observations ?? {})) {
          const yearStr = obsYears[Number(obsIdxStr)]?.id;
          const valThousands = obsArr?.[0];
          const year = Number(yearStr);
          if (!Number.isInteger(year) || typeof valThousands !== 'number' || !Number.isFinite(valThousands)) {
            continue;
          }

          const usdValue = Math.round(valThousands * 1000);
          const key = `${territory.territory_id}|${meta.indicatorId}|${year}`;
          if (dedupKeys.has(key)) continue;
          dedupKeys.add(key);

          rawRows.push({
            reporter: territory.iso3,
            indicator: witsIndicator,
            year,
            value_thousands_usd: valThousands,
          });
          silver.push({
            territory_id: territory.territory_id,
            iso3: territory.iso3,
            indicator_id: meta.indicatorId,
            indicator_name: meta.indicatorName,
            module_id: 6,
            source_id: source.source_id,
            dataset_id: source.dataset_id,
            period_year: year,
            value_numeric: usdValue,
            unit: 'USD',
            valuation_basis: 'nominal_usd',
            methodology_id: 'WB_WITS_TRADESTATS_V21',
            commercial_use_allowed: source.commercial_use_allowed,
            asserted_at: assertedAt,
          });
        }
      }
    } finally {
      safeUnlink(res.filePath);
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestUnComtradePreview(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const repUrl = 'https://comtradeapi.un.org/files/v1/app/reference/Reporters.json';
  const repRes = await fetchWithCitizenship({
    url: repUrl,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: true,
    destPrefix: 'uncomtrade_reporters',
    timeoutMs: 20_000,
  });

  const reporterToTerritory = new Map<number, ReturnType<typeof listTerritories>[number]>();
  if (repRes.filePath) {
    try {
      const repJson = JSON.parse(fs.readFileSync(repRes.filePath, 'utf-8')) as {
        results?: Array<{
          id?: number;
          text?: string;
          reporterCodeIsoAlpha3?: string | null;
          isGroup?: boolean;
          entryExpiredDate?: string | null;
        }>;
      };
      for (const item of repJson.results ?? []) {
        if (item.isGroup || item.entryExpiredDate) continue;
        if (typeof item.id !== 'number' || !item.reporterCodeIsoAlpha3) continue;
        if (item.text && item.text.includes('...')) continue;
        const territory = resolveTerritoryByCodeOrName(item.reporterCodeIsoAlpha3);
        if (territory && !reporterToTerritory.has(item.id)) {
          reporterToTerritory.set(item.id, territory);
        }
      }
    } finally {
      safeUnlink(repRes.filePath);
    }
  }

  for (const t of listTerritories()) {
    const hasMapping = Array.from(reporterToTerritory.values()).some((m) => m.territory_id === t.territory_id);
    if (!hasMapping) {
      const m49Num = Number(t.un_m49);
      if (Number.isInteger(m49Num) && m49Num > 0) {
        reporterToTerritory.set(m49Num, t);
      }
    }
  }

  const reporterCodes = Array.from(reporterToTerritory.keys());
  const chunks: number[][] = [];
  for (let i = 0; i < reporterCodes.length; i += 16) {
    chunks.push(reporterCodes.slice(i, i + 16));
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const dedupKeys = new Set<string>();
  let lastEtag: string | null = null;
  let dedupHit = false;

  for (let idx = 0; idx < chunks.length; idx++) {
    const chunk = chunks[idx];
    const url = `https://comtradeapi.un.org/public/v1/preview/C/A/HS?reporterCode=${chunk.join(',')}&period=2023&cmdCode=TOTAL&flowCode=X,M&partnerCode=0`;
    const res = await fetchWithCitizenship({
      url,
      host: source.host,
      rateLimitRpm: source.rate_limit_rpm,
      maxConcurrency: source.max_concurrency,
      bypassConditionalCache: true,
      destPrefix: `uncomtrade_hs_c${idx}`,
      timeoutMs: 20_000,
    }).catch(() => null);

    if (!res?.filePath) continue;
    dedupHit = dedupHit || res.dedupHit;
    if (res.etag) lastEtag = res.etag;

    try {
      const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
        data?: Array<{
          reporterCode?: number;
          refYear?: number;
          flowCode?: string;
          partnerCode?: number;
          partner2Code?: number;
          motCode?: number;
          customsCode?: string;
          primaryValue?: number | null;
        }>;
      };

      for (const row of json.data ?? []) {
        if (row.partnerCode !== 0) continue;
        if (row.partner2Code !== undefined && row.partner2Code !== 0) continue;
        if (row.motCode !== undefined && row.motCode !== 0) continue;
        if (row.customsCode !== undefined && row.customsCode !== 'C00') continue;

        const reporterId = Number(row.reporterCode);
        const year = Number(row.refYear);
        const val = typeof row.primaryValue === 'number' && Number.isFinite(row.primaryValue) ? row.primaryValue : null;
        const territory = reporterToTerritory.get(reporterId);
        if (!territory || !Number.isInteger(year) || val === null || val <= 0) continue;

        const isExport = row.flowCode === 'X';
        const isImport = row.flowCode === 'M';
        if (!isExport && !isImport) continue;

        const indicatorId = isExport ? 'UNCOMTRADE.EXPORTS_USD' : 'UNCOMTRADE.IMPORTS_USD';
        const indicatorName = isExport
          ? 'Merchandise Exports to World, HS TOTAL (US$, UN Comtrade Public v1)'
          : 'Merchandise Imports from World, HS TOTAL (US$, UN Comtrade Public v1)';

        const key = `${territory.territory_id}|${indicatorId}|${year}`;
        if (dedupKeys.has(key)) continue;
        dedupKeys.add(key);

        rawRows.push({
          iso3: territory.iso3,
          reporterCode: reporterId,
          flowCode: row.flowCode,
          year,
          primaryValue: val,
        });
        silver.push({
          territory_id: territory.territory_id,
          iso3: territory.iso3,
          indicator_id: indicatorId,
          indicator_name: indicatorName,
          module_id: 6,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: year,
          value_numeric: Math.round(val),
          unit: 'USD',
          valuation_basis: 'nominal_usd',
          methodology_id: 'UN_COMTRADE_PUBLIC_V1_HS_TOTAL',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    } finally {
      safeUnlink(res.filePath);
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestUnLocodeBulk(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();
  const url = 'https://raw.githubusercontent.com/datasets/un-locode/main/data/code-list.csv';

  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: shouldBypassConditionalCache(source.source_id),
    destPrefix: 'un_locode_codelist',
    timeoutMs: 30_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];

  try {
    const csvRows = await withDuckDBConnection(async (conn) => {
      const reader = await conn.runAndReadAll(`
        SELECT
          UPPER(TRIM(Country)) AS iso2,
          COUNT(*)::INTEGER AS total_nodes,
          SUM(CASE WHEN COALESCE(Function, '') LIKE '1%' THEN 1 ELSE 0 END)::INTEGER AS seaports,
          SUM(CASE WHEN COALESCE(Function, '') LIKE '___4%' THEN 1 ELSE 0 END)::INTEGER AS airports
        FROM read_csv_auto(${sqlQuote(res.filePath!)}, header=true, all_varchar=true)
        WHERE Country IS NOT NULL AND Location IS NOT NULL
        GROUP BY UPPER(TRIM(Country));
      `);
      try {
        return reader.getRowObjectsJson() as Array<{
          iso2?: string | null;
          total_nodes?: number | null;
          seaports?: number | null;
          airports?: number | null;
        }>;
      } finally {
        reader.closeSync();
      }
    });

    for (const r of csvRows) {
      const iso2 = String(r.iso2 ?? '').trim();
      if (!iso2) continue;
      const territory = resolveTerritoryByCodeOrName(iso2);
      if (!territory) continue;

      const totalNodes = Number(r.total_nodes ?? 0);
      const seaports = Number(r.seaports ?? 0);
      const airports = Number(r.airports ?? 0);
      rawRows.push({ iso3: territory.iso3, total_nodes: totalNodes, seaports, airports });

      if (totalNodes > 0) {
        silver.push({
          territory_id: territory.territory_id,
          iso3: territory.iso3,
          indicator_id: 'UNLOCODE.LOGISTICS_NODES',
          indicator_name: 'Registered UN/LOCODE Trade & Transport Nodes (Ports, Airports, Rail)',
          module_id: 8,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: currentYear,
          value_numeric: totalNodes,
          unit: 'locations',
          valuation_basis: 'count',
          methodology_id: 'UNECE_LOCODE_2024_CSV',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
      if (seaports > 0) {
        silver.push({
          territory_id: territory.territory_id,
          iso3: territory.iso3,
          indicator_id: 'UNLOCODE.SEAPORTS_COUNT',
          indicator_name: 'UN/LOCODE Maritime Seaport Terminals (Function 1)',
          module_id: 8,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: currentYear,
          value_numeric: seaports,
          unit: 'seaports',
          valuation_basis: 'count',
          methodology_id: 'UNECE_LOCODE_2024_CSV',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
      if (airports > 0) {
        silver.push({
          territory_id: territory.territory_id,
          iso3: territory.iso3,
          indicator_id: 'UNLOCODE.AIRPORTS_COUNT',
          indicator_name: 'UN/LOCODE Aviation Terminals & Airports (Function 4)',
          module_id: 8,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: currentYear,
          value_numeric: airports,
          unit: 'airports',
          valuation_basis: 'count',
          methodology_id: 'UNECE_LOCODE_2024_CSV',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestUnctadStat(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const territories = listTerritories();
  const byIso3 = new Map(territories.map((t) => [t.iso3, t]));
  const isoFilter = territories.map((t) => t.iso3).join(';');

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const dedupKeys = new Set<string>();
  let lastEtag: string | null = null;
  let dedupHit = false;

  // 1. UNCTAD Liner Shipping Connectivity Index (LSCI, IS.SHP.GCNW.XQ) via World Bank REST v2
  // 2. UNCTAD Digital Economy digitally-delivered services imports via World Bank Data360
  const lsciUrl = `https://api.worldbank.org/v2/country/${isoFilter}/indicator/IS.SHP.GCNW.XQ?format=json&per_page=500&mrv=3`;
  const refAreaParam = territories.map((t) => `REF_AREA=${t.iso3}`).join('&');
  const d360Url = `https://data360api.worldbank.org/data360/data?DATABASE_ID=UNCTAD_DE&INDICATOR=UNCTAD_DE_DIG_SERVTRADE_ANN_IMP&${refAreaParam}&timePeriodFrom=2021&skip=0`;

  const batch = await fetchConsistentBatch(
    [
      {
        url: lsciUrl,
        host: 'api.worldbank.org',
        rateLimitRpm: source.rate_limit_rpm,
        maxConcurrency: source.max_concurrency,
        destPrefix: 'unctad_lsci',
        timeoutMs: 20_000,
      },
      {
        url: d360Url,
        host: source.host,
        rateLimitRpm: source.rate_limit_rpm,
        maxConcurrency: source.max_concurrency,
        destPrefix: 'unctad_de_servtrade',
        timeoutMs: 20_000,
      },
    ],
    { bypassCache, allowPartialErrors: true }
  );

  if (batch.allNotModified) {
    return { rawRows: [], silver: [], etag: null, dedupHit: false, notModified: true };
  }

  const lsciRes = batch.results[0];
  const d360Res = batch.results[1];

  if (lsciRes) {
    dedupHit = dedupHit || lsciRes.dedupHit;
    if (lsciRes.etag) lastEtag = lsciRes.etag;
  }

  if (lsciRes?.filePath) {
    try {
      const parsed = JSON.parse(fs.readFileSync(lsciRes.filePath, 'utf-8')) as unknown;
      const rows = Array.isArray(parsed) && Array.isArray(parsed[1]) ? (parsed[1] as Array<Record<string, unknown>>) : [];
      for (const r of rows) {
        const iso3 = String(r.countryiso3code ?? '').trim().toUpperCase();
        const year = Number(r.date);
        const val = typeof r.value === 'number' && Number.isFinite(r.value) ? r.value : null;
        const territory = byIso3.get(iso3);
        if (!territory || !Number.isInteger(year) || val === null) continue;

        const key = `${territory.territory_id}|UNCTAD.LSCI_INDEX|${year}`;
        if (dedupKeys.has(key)) continue;
        dedupKeys.add(key);

        rawRows.push({ feed: 'IS.SHP.GCNW.XQ', iso3, year, value: val });
        silver.push({
          territory_id: territory.territory_id,
          iso3: territory.iso3,
          indicator_id: 'UNCTAD.LSCI_INDEX',
          indicator_name: 'Maritime Liner Shipping Connectivity Index (2004=100, UNCTAD)',
          module_id: 6,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: year,
          value_numeric: Number(val.toFixed(2)),
          unit: 'index (2004=100)',
          valuation_basis: 'index_score',
          methodology_id: 'UNCTAD_LSCI_MARITIME_V1',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    } finally {
      safeUnlink(lsciRes.filePath);
    }
  }

  if (d360Res?.filePath) {
    dedupHit = dedupHit || d360Res.dedupHit;
    if (d360Res.etag) lastEtag = d360Res.etag;
    try {
      const json = JSON.parse(fs.readFileSync(d360Res.filePath, 'utf-8')) as {
        value?: Array<{
          REF_AREA?: string;
          TIME_PERIOD?: string;
          OBS_VALUE?: string | number | null;
          UNIT_MULT?: number | null;
        }>;
      };
      for (const r of json.value ?? []) {
        const iso3 = String(r.REF_AREA ?? '').trim().toUpperCase();
        const year = Number(r.TIME_PERIOD);
        const rawVal = Number(r.OBS_VALUE);
        const mult = Number(r.UNIT_MULT ?? 0) || 0;
        const territory = byIso3.get(iso3);
        if (!territory || !Number.isInteger(year) || !Number.isFinite(rawVal)) continue;

        const usdVal = mult !== 0 ? rawVal * Math.pow(10, mult) : rawVal;
        if (!Number.isFinite(usdVal) || usdVal <= 0) continue;

        const key = `${territory.territory_id}|UNCTAD.DIG_SERVICES_IMP_USD|${year}`;
        if (dedupKeys.has(key)) continue;
        dedupKeys.add(key);

        rawRows.push({ feed: 'UNCTAD_DE', iso3, year, value: usdVal });
        silver.push({
          territory_id: territory.territory_id,
          iso3: territory.iso3,
          indicator_id: 'UNCTAD.DIG_SERVICES_IMP_USD',
          indicator_name: 'Digitally-Delivered Commercial Services Imports (US$, UNCTAD DE)',
          module_id: 6,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: year,
          value_numeric: Math.round(usdVal),
          unit: 'USD',
          valuation_basis: 'nominal_usd',
          methodology_id: 'UNCTAD_DE_DIG_SERVTRADE_DATA360',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    } finally {
      safeUnlink(d360Res.filePath);
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestIcaoApiService(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const icaoKey = (process.env.ICAO_API_KEY ?? '').trim();

  const url = 'https://davidmegginson.github.io/ourairports-data/airports.csv';
  const res = await fetchWithCitizenship({
    url,
    host: 'davidmegginson.github.io',
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'ourairports_icao_registry',
    timeoutMs: 35_000,
  });

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  let lastEtag: string | null = res.etag;
  const dedupHit = res.dedupHit;

  if (res.filePath) {
    try {
      const csvRows = await withDuckDBConnection(async (conn) => {
        const reader = await conn.runAndReadAll(`
          SELECT
            UPPER(TRIM(iso_country)) AS iso2,
            COUNT(*) FILTER (WHERE scheduled_service = 'yes')::INTEGER AS scheduled_airports,
            COUNT(*) FILTER (WHERE icao_code IS NOT NULL AND TRIM(icao_code) <> '')::INTEGER AS icao_coded_airports
          FROM read_csv_auto(${sqlQuote(res.filePath!)}, header=true, all_varchar=true)
          WHERE iso_country IS NOT NULL AND length(TRIM(iso_country)) = 2
          GROUP BY UPPER(TRIM(iso_country));
        `);
        try {
          return reader.getRowObjectsJson() as Array<{
            iso2?: string;
            scheduled_airports?: number;
            icao_coded_airports?: number;
          }>;
        } finally {
          reader.closeSync();
        }
      });

      for (const r of csvRows) {
        const iso2 = String(r.iso2 ?? '').trim();
        if (!iso2) continue;
        const territory = resolveTerritoryByCodeOrName(iso2);
        if (!territory) continue;

        const scheduled = Number(r.scheduled_airports ?? 0);
        const icaoCoded = Number(r.icao_coded_airports ?? 0);
        rawRows.push({ iso3: territory.iso3, scheduled_airports: scheduled, icao_coded_airports: icaoCoded });

        if (scheduled > 0) {
          silver.push({
            territory_id: territory.territory_id,
            iso3: territory.iso3,
            indicator_id: 'ICAO.SCHEDULED_AIRPORTS',
            indicator_name: 'Scheduled Commercial Service Airports (ICAO / OurAirports)',
            module_id: 8,
            source_id: source.source_id,
            dataset_id: source.dataset_id,
            period_year: currentYear,
            value_numeric: scheduled,
            unit: 'airports',
            valuation_basis: 'count',
            methodology_id: 'OURAIRPORTS_CC0_ICAO_REGISTRY',
            commercial_use_allowed: source.commercial_use_allowed,
            asserted_at: assertedAt,
          });
        }

        if (icaoCoded > 0) {
          silver.push({
            territory_id: territory.territory_id,
            iso3: territory.iso3,
            indicator_id: 'ICAO.TOTAL_AIRPORTS',
            indicator_name: 'Registered 4-Letter ICAO Coded Aerodromes & Airports (Doc 7910 Registry)',
            module_id: 8,
            source_id: source.source_id,
            dataset_id: source.dataset_id,
            period_year: currentYear,
            value_numeric: icaoCoded,
            unit: 'aerodromes',
            valuation_basis: 'count',
            methodology_id: 'OURAIRPORTS_CC0_ICAO_REGISTRY',
            commercial_use_allowed: source.commercial_use_allowed,
            asserted_at: assertedAt,
          });
        }
      }
    } finally {
      safeUnlink(res.filePath);
    }
  }

  if (icaoKey) {
    try {
      const apiRes = await fetchWithCitizenship({
        url: `https://applications.icao.int/dataservices/api/safety-characteristics-list?api_key=${encodeURIComponent(icaoKey)}&format=json`,
        host: 'applications.icao.int',
        rateLimitRpm: source.rate_limit_rpm,
        maxConcurrency: 1,
        bypassConditionalCache: bypassCache,
        destPrefix: 'icao_api_v1_probe',
        timeoutMs: 12_000,
      });
      if (apiRes.etag) lastEtag = apiRes.etag;
      if (apiRes.filePath) {
        try {
          rawRows.push({ icao_api_checked: true, bytes: fs.statSync(apiRes.filePath).size });
        } finally {
          safeUnlink(apiRes.filePath);
        }
      }
    } catch {
      // Non-fatal
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

