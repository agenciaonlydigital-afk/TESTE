import fs from 'node:fs';
import { listTerritories, resolveTerritoryByCodeOrName } from '../../controlPlane.ts';
import { sqlQuote, withDuckDBConnection } from '../../duckdbEngine.ts';
import { fetchWithCitizenship } from '../../httpCitizenship.ts';
import type { ObservationContract, SourceCatalogEntry } from '../../types.ts';
import { ingestOwidDatasets } from '../factories/owidCsvConnector.ts';
import {
  getCanonicalIso3Filter,
  safeUnlink,
  shouldBypassConditionalCache,
  type ConnectorOutcome,
} from '../shared.ts';

export async function ingestWorldBankWDI(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const indicators: Array<{
    id: string;
    name: string;
    moduleId: number;
    unit: string;
    basis: ObservationContract['valuation_basis'];
  }> = [
    { id: 'NY.GDP.MKTP.CD', name: 'GDP (Nominal Current US$)', moduleId: 2, unit: 'USD', basis: 'nominal_usd' },
    { id: 'NY.GDP.PCAP.PP.KD', name: 'GDP per Capita, PPP (Constant 2021 Int$)', moduleId: 2, unit: 'Intl$ 2021 PPP', basis: 'constant_2021_ppp' },
    { id: 'FP.CPI.TOTL.ZG', name: 'Inflation, Consumer Prices (Annual %)', moduleId: 2, unit: '%', basis: 'percent' },
    { id: 'SL.UEM.TOTL.ZS', name: 'Unemployment, Total (% of labor force)', moduleId: 2, unit: '%', basis: 'percent' },
    { id: 'SP.POP.TOTL', name: 'Population, Total', moduleId: 3, unit: 'persons', basis: 'count' },
  ];

  const assertedAt = new Date().toISOString();
  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  let lastEtag: string | null = null;
  let dedupHit = false;
  const bypassCache = shouldBypassConditionalCache(source.source_id);

  for (const ind of indicators) {
    try {
      let page = 1;
      let totalPages = 1;

      while (page <= Math.min(totalPages, 3)) {
        const url = `https://api.worldbank.org/v2/country/all/indicator/${ind.id}?format=json&per_page=1000&date=2019:2025&page=${page}`;
        const res = await fetchWithCitizenship({
          url,
          host: source.host,
          rateLimitRpm: source.rate_limit_rpm,
          maxConcurrency: source.max_concurrency,
          bypassConditionalCache: bypassCache,
          destPrefix: `wb_${ind.id}_p${page}`,
          timeoutMs: 12_000,
        });
        dedupHit = dedupHit || res.dedupHit;
        if (res.etag) lastEtag = res.etag;
        if (res.status === 'NOT_MODIFIED' || !res.filePath) {
          break;
        }

        try {
          const content = fs.readFileSync(res.filePath, 'utf-8');
          const parsed = JSON.parse(content) as unknown;
          if (!Array.isArray(parsed) || parsed.length < 2 || !Array.isArray(parsed[1])) {
            break;
          }
          const meta = parsed[0] as { pages?: number } | undefined;
          if (typeof meta?.pages === 'number' && meta.pages > totalPages) {
            totalPages = meta.pages;
          }

          const rows = parsed[1] as Array<{
            countryiso3code?: string;
            country?: { id?: string; value?: string };
            date?: string;
            value?: number | null;
          }>;

          for (const r of rows) {
            if (r.value === null || r.value === undefined) continue;
            rawRows.push({ indicator_id: ind.id, page, ...r });

            const code = r.countryiso3code || r.country?.id || '';
            const territory =
              resolveTerritoryByCodeOrName(code) ??
              (r.country?.value ? resolveTerritoryByCodeOrName(r.country.value) : undefined);
            if (!territory) continue;

            const year = Number(r.date);
            if (!Number.isInteger(year) || typeof r.value !== 'number' || !Number.isFinite(r.value)) continue;

            silver.push({
              territory_id: territory.territory_id,
              iso3: territory.iso3,
              indicator_id: ind.id,
              indicator_name: ind.name,
              module_id: ind.moduleId,
              source_id: source.source_id,
              dataset_id: source.dataset_id,
              period_year: year,
              value_numeric: r.value,
              unit: ind.unit,
              valuation_basis: ind.basis,
              methodology_id: 'WB_WDI_V2',
              commercial_use_allowed: source.commercial_use_allowed,
              asserted_at: assertedAt,
            });
          }
        } finally {
          safeUnlink(res.filePath);
        }

        page++;
      }
    } catch {
      continue;
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestWorldBankSdmx(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const indicators: Array<{
    data360Id: string;
    indicatorKey: string;
    name: string;
    moduleId: number;
    unit: string;
    basis: ObservationContract['valuation_basis'];
  }> = [
    {
      data360Id: 'WB_WDI_NE_CON_PRVT_ZS',
      indicatorKey: 'WB_SDMX.NE_CON_PRVT_ZS',
      name: 'Household Final Consumption Expenditure (% of GDP, WB SDMX)',
      moduleId: 2,
      unit: '% of GDP',
      basis: 'percent',
    },
    {
      data360Id: 'WB_WDI_NY_GNP_PCAP_CD',
      indicatorKey: 'WB_SDMX.NY_GNP_PCAP_CD',
      name: 'GNI per Capita, Atlas Method (Current US$, WB SDMX)',
      moduleId: 2,
      unit: 'USD',
      basis: 'nominal_usd',
    },
    {
      data360Id: 'WB_WDI_BX_KLT_DINV_WD_GD_ZS',
      indicatorKey: 'WB_SDMX.BX_KLT_DINV_WD_GD_ZS',
      name: 'Foreign Direct Investment Net Inflows (% of GDP, WB SDMX)',
      moduleId: 2,
      unit: '% of GDP',
      basis: 'percent',
    },
    {
      data360Id: 'WB_WDI_NV_IND_MANF_ZS',
      indicatorKey: 'WB_SDMX.NV_IND_MANF_ZS',
      name: 'Manufacturing Value Added (% of GDP, WB SDMX)',
      moduleId: 2,
      unit: '% of GDP',
      basis: 'percent',
    },
    {
      data360Id: 'WB_WDI_NE_TRD_GNFS_ZS',
      indicatorKey: 'WB_SDMX.NE_TRD_GNFS_ZS',
      name: 'Trade Openness (% of GDP, WB SDMX)',
      moduleId: 2,
      unit: '% of GDP',
      basis: 'percent',
    },
    {
      data360Id: 'WB_WDI_SP_DYN_TFRT_IN',
      indicatorKey: 'WB_SDMX.SP_DYN_TFRT_IN',
      name: 'Fertility Rate, Total (Births/Woman, WB SDMX)',
      moduleId: 3,
      unit: 'births/woman',
      basis: 'count',
    },
  ];

  const assertedAt = new Date().toISOString();
  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  let lastEtag: string | null = null;
  let dedupHit = false;
  const bypassCache = shouldBypassConditionalCache(source.source_id);

  try {
    const dsdRes = await fetchWithCitizenship({
      url: 'https://api.worldbank.org/v2/sdmx/rest/datastructure/WB/WDI/1.0/',
      host: 'api.worldbank.org',
      rateLimitRpm: 60,
      maxConcurrency: 1,
      bypassConditionalCache: bypassCache,
      headers: { Accept: 'application/vnd.sdmx.structure+xml;version=2.1, application/xml' },
      destPrefix: 'wb_sdmx_dsd',
      timeoutMs: 8_000,
    });
    if (dsdRes.filePath) {
      try {
        const xml = fs.readFileSync(dsdRes.filePath, 'utf-8');
        const dims = Array.from(xml.matchAll(/<(?:Dimension|TimeDimension|PrimaryMeasure)\s+id="([^"]+)"/g)).map(
          (m) => m[1]
        );
        rawRows.push({
          sdmx_registry: 'https://api.worldbank.org/v2/sdmx/rest/datastructure/WB/WDI/1.0/',
          dataflow: 'WB:WDI(1.0)',
          dsd_dimensions: dims,
        });
      } finally {
        safeUnlink(dsdRes.filePath);
      }
    }
  } catch {
    // Non-fatal: continue with SDMX-modeled Data360 WB_WDI cube
  }

  const fetchedByIndicator: Array<{
    ind: (typeof indicators)[number];
    pages: Array<Array<{
      OBS_VALUE?: string | number | null;
      UNIT_MULT?: number | null;
      DATABASE_ID?: string;
      INDICATOR?: string;
      REF_AREA?: string;
      TIME_PERIOD?: string | number;
      FREQ?: string;
      SEX?: string;
      AGE?: string;
      URBANISATION?: string;
      UNIT_MEASURE?: string;
    }>>;
    status: string;
    firstUrl: string;
  }> = [];

  for (const ind of indicators) {
    const firstUrl = `https://data360api.worldbank.org/data360/data?DATABASE_ID=WB_WDI&INDICATOR=${ind.data360Id}&timePeriodFrom=2021&timePeriodTo=2025&skip=0`;
    const firstRes = await fetchWithCitizenship({
      url: firstUrl,
      host: source.host,
      rateLimitRpm: source.rate_limit_rpm,
      maxConcurrency: source.max_concurrency,
      bypassConditionalCache: bypassCache,
      destPrefix: `wb_sdmx_${ind.data360Id}_p0`,
      timeoutMs: 12_000,
    });
    dedupHit = dedupHit || firstRes.dedupHit;
    if (firstRes.etag) lastEtag = firstRes.etag;

    if (firstRes.status === 'NOT_MODIFIED' || !firstRes.filePath) {
      fetchedByIndicator.push({ ind, pages: [], status: firstRes.status, firstUrl });
      continue;
    }

    const pages: (typeof fetchedByIndicator)[number]['pages'] = [];
    try {
      const parsed = JSON.parse(fs.readFileSync(firstRes.filePath, 'utf-8')) as {
        count?: number;
        value?: (typeof fetchedByIndicator)[number]['pages'][number];
      };
      const firstRows = Array.isArray(parsed.value) ? parsed.value : [];
      pages.push(firstRows);

      const totalCount = typeof parsed.count === 'number' ? parsed.count : firstRows.length;
      let skip = firstRows.length;
      let pageIdx = 1;
      while (skip < totalCount && firstRows.length > 0 && pageIdx < 4) {
        const nextUrl = `https://data360api.worldbank.org/data360/data?DATABASE_ID=WB_WDI&INDICATOR=${ind.data360Id}&timePeriodFrom=2021&timePeriodTo=2025&skip=${skip}`;
        const nextRes = await fetchWithCitizenship({
          url: nextUrl,
          host: source.host,
          rateLimitRpm: source.rate_limit_rpm,
          maxConcurrency: source.max_concurrency,
          bypassConditionalCache: true,
          destPrefix: `wb_sdmx_${ind.data360Id}_p${pageIdx}`,
          timeoutMs: 12_000,
        });
        if (!nextRes.filePath) break;
        try {
          const nextParsed = JSON.parse(fs.readFileSync(nextRes.filePath, 'utf-8')) as {
            value?: (typeof fetchedByIndicator)[number]['pages'][number];
          };
          const nextRows = Array.isArray(nextParsed.value) ? nextParsed.value : [];
          if (nextRows.length === 0) break;
          pages.push(nextRows);
          skip += nextRows.length;
          pageIdx++;
        } finally {
          safeUnlink(nextRes.filePath);
        }
      }
    } finally {
      safeUnlink(firstRes.filePath);
    }

    fetchedByIndicator.push({ ind, pages, status: firstRes.status, firstUrl });
  }

  const anyChanged = fetchedByIndicator.some((item) => item.status === 'OK');
  if (!anyChanged && !bypassCache) {
    return { rawRows: [], silver: [], etag: lastEtag, dedupHit, notModified: fetchedByIndicator.length > 0 && fetchedByIndicator.every((item) => item.status === 'NOT_MODIFIED') };
  }

  for (const item of fetchedByIndicator) {
    if (item.pages.length === 0 && item.status === 'NOT_MODIFIED') {
      const fullRes = await fetchWithCitizenship({
        url: item.firstUrl,
        host: source.host,
        rateLimitRpm: source.rate_limit_rpm,
        maxConcurrency: source.max_concurrency,
        bypassConditionalCache: true,
        destPrefix: `wb_sdmx_${item.ind.data360Id}_full`,
        timeoutMs: 12_000,
      });
      if (fullRes.filePath) {
        try {
          const parsed = JSON.parse(fs.readFileSync(fullRes.filePath, 'utf-8')) as {
            value?: (typeof fetchedByIndicator)[number]['pages'][number];
          };
          if (Array.isArray(parsed.value)) {
            item.pages.push(parsed.value);
          }
        } finally {
          safeUnlink(fullRes.filePath);
        }
      }
    }
  }

  const dedupKeys = new Set<string>();
  for (const { ind, pages } of fetchedByIndicator) {
    for (const rows of pages) {
      for (const r of rows) {
        if (!r.REF_AREA || (r.FREQ && r.FREQ !== 'A')) continue;
        if ((r.SEX && r.SEX !== '_T') || (r.AGE && r.AGE !== '_T') || (r.URBANISATION && r.URBANISATION !== '_T')) {
          continue;
        }
        const rawVal = Number(r.OBS_VALUE);
        const year = Number(r.TIME_PERIOD);
        if (!Number.isFinite(rawVal) || !Number.isInteger(year)) continue;

        const mult = typeof r.UNIT_MULT === 'number' && Number.isFinite(r.UNIT_MULT) ? r.UNIT_MULT : 0;
        const scaledVal = mult !== 0 ? rawVal * Math.pow(10, mult) : rawVal;
        if (!Number.isFinite(scaledVal)) continue;

        const territory = resolveTerritoryByCodeOrName(r.REF_AREA);
        if (!territory) continue;

        const key = `${territory.territory_id}|${ind.indicatorKey}|${year}`;
        if (dedupKeys.has(key)) continue;
        dedupKeys.add(key);

        rawRows.push(r);
        silver.push({
          territory_id: territory.territory_id,
          iso3: territory.iso3,
          indicator_id: ind.indicatorKey,
          indicator_name: ind.name,
          module_id: ind.moduleId,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: year,
          value_numeric: Number(scaledVal.toFixed(4)),
          unit: ind.unit,
          valuation_basis: ind.basis,
          methodology_id: 'WB_WDI_SDMX_DATA360_V13',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

/**
 * Healed IMF WEO connector: reads WEO 6.0.0 SDMX 2.1 JSON directly from api.imf.org
 * (replaces blocked www.imf.org/external/datamapper/api endpoint while preserving canonical IMF.* indicators).
 */
export async function ingestImfDataMapper(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const iso3Filter = getCanonicalIso3Filter('+');
  const url = `https://api.imf.org/external/sdmx/2.1/data/IMF.RES,WEO,6.0.0/${iso3Filter}.NGDP_RPCH+PCPIPCH+GGXWDG_NGDP.A?startPeriod=2020&endPeriod=2026`;

  const res = await fetchWithCitizenship({
    url,
    host: 'api.imf.org',
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: shouldBypassConditionalCache(source.source_id),
    headers: { Accept: 'application/json' },
    destPrefix: 'imf_weo_sdmx21',
    timeoutMs: 25_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const indicatorMeta: Record<string, { indicatorKey: string; name: string; unit: string }> = {
    NGDP_RPCH: {
      indicatorKey: 'IMF.NGDP_RPCH',
      name: 'Real GDP Growth (IMF WEO, %)',
      unit: '%',
    },
    PCPIPCH: {
      indicatorKey: 'IMF.PCPIPCH',
      name: 'Inflation Average Consumer Prices (IMF WEO, %)',
      unit: '%',
    },
    GGXWDG_NGDP: {
      indicatorKey: 'IMF.GGXWDG_NGDP',
      name: 'General Government Gross Debt (% of GDP, IMF WEO)',
      unit: '% of GDP',
    },
  };

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const dedupKeys = new Set<string>();

  try {
    const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
      data?: {
        dataSets?: Array<{
          series?: Record<string, { observations?: Record<string, Array<number | string | null>> }>;
        }>;
        structures?: Array<{
          dimensions?: {
            series?: Array<{ id?: string; values?: Array<{ id?: string }> }>;
            observation?: Array<{ id?: string; values?: Array<{ id?: string }> }>;
          };
        }>;
      };
      dataSets?: Array<{
        series?: Record<string, { observations?: Record<string, Array<number | string | null>> }>;
      }>;
      structure?: {
        dimensions?: {
          series?: Array<{ id?: string; values?: Array<{ id?: string }> }>;
          observation?: Array<{ id?: string; values?: Array<{ id?: string }> }>;
        };
      };
    };

    const dataSets = json.dataSets ?? json.data?.dataSets ?? [];
    const structure = json.structure ?? json.data?.structures?.[0];
    const seriesDims = structure?.dimensions?.series ?? [];
    const obsPeriods = structure?.dimensions?.observation?.[0]?.values ?? [];
    const countryPos = seriesDims.findIndex((d) => d.id === 'COUNTRY' || d.id === 'REF_AREA');
    const indicatorPos = seriesDims.findIndex((d) => d.id === 'INDICATOR');
    const seriesMap = dataSets[0]?.series ?? {};

    if (countryPos >= 0 && indicatorPos >= 0) {
      for (const [seriesKey, seriesBody] of Object.entries(seriesMap)) {
        const coords = seriesKey.split(':').map(Number);
        const iso3Raw = seriesDims[countryPos]?.values?.[coords[countryPos]]?.id;
        const indCode = seriesDims[indicatorPos]?.values?.[coords[indicatorPos]]?.id;
        if (!iso3Raw || !indCode) continue;

        const meta = indicatorMeta[indCode];
        if (!meta) continue;
        const territory = resolveTerritoryByCodeOrName(iso3Raw);
        if (!territory) continue;

        for (const [obsIdxStr, obsArr] of Object.entries(seriesBody.observations ?? {})) {
          const yearStr = obsPeriods[Number(obsIdxStr)]?.id;
          const year = Number(yearStr);
          const rawVal = obsArr?.[0];
          const val = typeof rawVal === 'number' ? rawVal : Number(rawVal);
          if (!Number.isInteger(year) || year < 2020 || year > 2026 || !Number.isFinite(val)) continue;

          const key = `${territory.territory_id}|${meta.indicatorKey}|${year}`;
          if (dedupKeys.has(key)) continue;
          dedupKeys.add(key);

          rawRows.push({ indicator: indCode, iso3: territory.iso3, year, value: val });
          silver.push({
            territory_id: territory.territory_id,
            iso3: territory.iso3,
            indicator_id: meta.indicatorKey,
            indicator_name: meta.name,
            module_id: 2,
            source_id: source.source_id,
            dataset_id: source.dataset_id,
            period_year: year,
            value_numeric: Number(val.toFixed(3)),
            unit: meta.unit,
            valuation_basis: 'percent',
            methodology_id: 'IMF_WEO_6_0_0_SDMX21',
            commercial_use_allowed: source.commercial_use_allowed,
            asserted_at: assertedAt,
          });
        }
      }
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestImfSdmx3(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const iso3Filter = getCanonicalIso3Filter('+');
  const flows: Array<{
    flowId: string;
    url: string;
    indicatorsSql: string;
    indicatorMap: Record<
      string,
      {
        indicatorKey: string;
        name: string;
        unit: string;
        basis: ObservationContract['valuation_basis'];
        methodologyId: string;
      }
    >;
  }> = [
    {
      flowId: 'eer',
      url: `https://api.imf.org/external/sdmx/3.0/data/dataflow/IMF.STA/EER/+/${iso3Filter}?lastNObservations=6`,
      indicatorsSql: `'REER_IX_RY2010_ACW_RCPI', 'NEER_IX_RY2010_ACW'`,
      indicatorMap: {
        REER_IX_RY2010_ACW_RCPI: {
          indicatorKey: 'IMF_SDMX.REER_IX',
          name: 'Real Effective Exchange Rate Index (CPI, 2010=100, IMF SDMX 3.0)',
          unit: 'index (2010=100)',
          basis: 'index_score',
          methodologyId: 'IMF_SDMX3_STA_EER',
        },
        NEER_IX_RY2010_ACW: {
          indicatorKey: 'IMF_SDMX.NEER_IX',
          name: 'Nominal Effective Exchange Rate Index (2010=100, IMF SDMX 3.0)',
          unit: 'index (2010=100)',
          basis: 'index_score',
          methodologyId: 'IMF_SDMX3_STA_EER',
        },
      },
    },
    {
      flowId: 'mfs_ir',
      url: `https://api.imf.org/external/sdmx/3.0/data/dataflow/IMF.STA/MFS_IR/+/${iso3Filter}?lastNObservations=6`,
      indicatorsSql: `'MFS166_RT_PT_A_PT', 'S13BOND_RT_PT_A_PT', 'MMRT_RT_PT_A_PT', 'GSTBILY_RT_PT_A_PT', 'MFS162_RT_PT_A_PT'`,
      indicatorMap: {
        MFS166_RT_PT_A_PT: {
          indicatorKey: 'IMF_SDMX.POLICY_RATE_PCT',
          name: 'Monetary Policy-Related Rate (% p.a., IMF MFS_IR SDMX 3.0)',
          unit: '% p.a.',
          basis: 'percent',
          methodologyId: 'IMF_SDMX3_MFS_IR',
        },
        S13BOND_RT_PT_A_PT: {
          indicatorKey: 'IMF_SDMX.GOV_BOND_YIELD_PCT',
          name: 'Government Bond Yield (% p.a., IMF MFS_IR SDMX 3.0)',
          unit: '% p.a.',
          basis: 'percent',
          methodologyId: 'IMF_SDMX3_MFS_IR',
        },
        MMRT_RT_PT_A_PT: {
          indicatorKey: 'IMF_SDMX.MONEY_MKT_RATE_PCT',
          name: 'Money Market Interest Rate (% p.a., IMF MFS_IR SDMX 3.0)',
          unit: '% p.a.',
          basis: 'percent',
          methodologyId: 'IMF_SDMX3_MFS_IR',
        },
        GSTBILY_RT_PT_A_PT: {
          indicatorKey: 'IMF_SDMX.TBILL_YIELD_PCT',
          name: 'Treasury Bill Yield (% p.a., IMF MFS_IR SDMX 3.0)',
          unit: '% p.a.',
          basis: 'percent',
          methodologyId: 'IMF_SDMX3_MFS_IR',
        },
        MFS162_RT_PT_A_PT: {
          indicatorKey: 'IMF_SDMX.LENDING_RATE_PCT',
          name: 'Bank Lending Interest Rate (% p.a., IMF MFS_IR SDMX 3.0)',
          unit: '% p.a.',
          basis: 'percent',
          methodologyId: 'IMF_SDMX3_MFS_IR',
        },
      },
    },
    {
      flowId: 'weo',
      url: `https://api.imf.org/external/sdmx/3.0/data/dataflow/IMF.RES/WEO/+/${iso3Filter}?lastNObservations=6`,
      indicatorsSql: `'BCA_NGDPD', 'NGSD_NGDP', 'NID_NGDP', 'GGXCNL_NGDP'`,
      indicatorMap: {
        BCA_NGDPD: {
          indicatorKey: 'IMF_SDMX.CA_BALANCE_PCT_GDP',
          name: 'Current Account Balance (% of GDP, IMF WEO SDMX 3.0)',
          unit: '% of GDP',
          basis: 'percent',
          methodologyId: 'IMF_SDMX3_WEO',
        },
        NGSD_NGDP: {
          indicatorKey: 'IMF_SDMX.GROSS_SAVINGS_PCT_GDP',
          name: 'Gross National Savings (% of GDP, IMF WEO SDMX 3.0)',
          unit: '% of GDP',
          basis: 'percent',
          methodologyId: 'IMF_SDMX3_WEO',
        },
        NID_NGDP: {
          indicatorKey: 'IMF_SDMX.INVESTMENT_PCT_GDP',
          name: 'Total Investment (% of GDP, IMF WEO SDMX 3.0)',
          unit: '% of GDP',
          basis: 'percent',
          methodologyId: 'IMF_SDMX3_WEO',
        },
        GGXCNL_NGDP: {
          indicatorKey: 'IMF_SDMX.FISCAL_NET_LEND_PCT_GDP',
          name: 'General Government Net Lending/Borrowing (% of GDP, IMF WEO SDMX 3.0)',
          unit: '% of GDP',
          basis: 'percent',
          methodologyId: 'IMF_SDMX3_WEO',
        },
      },
    },
  ];

  const assertedAt = new Date().toISOString();
  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  let lastEtag: string | null = null;
  let dedupHit = false;
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const headers = { Accept: 'application/vnd.sdmx.data+csv;version=2.0.0' };

  const fetched: Array<{ flow: (typeof flows)[number]; filePath: string | null; status: string }> = [];
  for (const flow of flows) {
    try {
      const res = await fetchWithCitizenship({
        url: flow.url,
        host: source.host,
        rateLimitRpm: source.rate_limit_rpm,
        maxConcurrency: source.max_concurrency,
        bypassConditionalCache: bypassCache,
        headers,
        destPrefix: `imf_sdmx3_${flow.flowId}`,
        timeoutMs: 20_000,
      });
      dedupHit = dedupHit || res.dedupHit;
      if (res.etag) lastEtag = res.etag;
      fetched.push({ flow, filePath: res.filePath, status: res.status });
    } catch {
      fetched.push({ flow, filePath: null, status: 'ERROR' });
    }
  }

  const anyChanged = fetched.some((f) => f.status === 'OK');
  if (fetched.every((f) => f.status === 'ERROR')) {
    throw new Error(`All IMF SDMX 3.0 dataflow requests failed for ${source.host}`);
  }
  if (!anyChanged && !bypassCache) {
    return { rawRows: [], silver: [], etag: lastEtag, dedupHit, notModified: fetched.length > 0 && fetched.every((item) => item.status === 'NOT_MODIFIED') };
  }

  for (const item of fetched) {
    if (!item.filePath && item.status === 'NOT_MODIFIED') {
      try {
        const fullRes = await fetchWithCitizenship({
          url: item.flow.url,
          host: source.host,
          rateLimitRpm: source.rate_limit_rpm,
          maxConcurrency: source.max_concurrency,
          bypassConditionalCache: true,
          headers,
          destPrefix: `imf_sdmx3_${item.flow.flowId}_full`,
          timeoutMs: 20_000,
        });
        item.filePath = fullRes.filePath;
      } catch {
        // ignore hydration blip
      }
    }
  }

  const dedupKeys = new Set<string>();
  for (const { flow, filePath } of fetched) {
    if (!filePath) continue;
    try {
      const csvRows = await withDuckDBConnection(async (conn) => {
        const reader = await conn.runAndReadAll(`
          SELECT COUNTRY, INDICATOR, FREQUENCY, TIME_PERIOD, OBS_VALUE
          FROM read_csv_auto(${sqlQuote(filePath)}, header=true, all_varchar=true)
          WHERE FREQUENCY = 'A'
            AND COUNTRY IS NOT NULL
            AND OBS_VALUE IS NOT NULL
            AND INDICATOR IN (${flow.indicatorsSql});
        `);
        try {
          return reader.getRowObjectsJson() as Array<Record<string, unknown>>;
        } finally {
          reader.closeSync();
        }
      });

      for (const r of csvRows) {
        const countryCode = String(r.COUNTRY ?? '').trim();
        const indicatorCode = String(r.INDICATOR ?? '').trim();
        const year = Number(String(r.TIME_PERIOD ?? '').trim());
        const val = Number(String(r.OBS_VALUE ?? '').trim());
        if (!countryCode || !Number.isInteger(year) || year < 2021 || year > 2026 || !Number.isFinite(val)) {
          continue;
        }
        const meta = flow.indicatorMap[indicatorCode];
        if (!meta) continue;

        const territory = resolveTerritoryByCodeOrName(countryCode);
        if (!territory) continue;

        const dedupKey = `${territory.territory_id}|${meta.indicatorKey}|${year}`;
        if (dedupKeys.has(dedupKey)) continue;
        dedupKeys.add(dedupKey);

        rawRows.push({ flow: flow.flowId, ...r });
        silver.push({
          territory_id: territory.territory_id,
          iso3: territory.iso3,
          indicator_id: meta.indicatorKey,
          indicator_name: meta.name,
          module_id: 2,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: year,
          value_numeric: Number(val.toFixed(4)),
          unit: meta.unit,
          valuation_basis: meta.basis,
          methodology_id: meta.methodologyId,
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    } finally {
      safeUnlink(filePath);
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestIlostatSdmx(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const iso3Filter = getCanonicalIso3Filter('+');
  const flows: Array<{
    flowId: string;
    url: string;
    ageSql: string;
    targets: Record<
      string,
      {
        indicatorKey: string;
        name: string;
        methodologyId: string;
      }
    >;
  }> = [
    {
      flowId: 'DF_EAP_2WAP_SEX_AGE_RT',
      url: `https://sdmx.ilo.org/rest/data/ILO,DF_EAP_2WAP_SEX_AGE_RT,1.0/${iso3Filter}.A..SEX_T.AGE_YTHADULT_YGE15?startPeriod=2021&endPeriod=2025`,
      ageSql: `'AGE_YTHADULT_YGE15'`,
      targets: {
        AGE_YTHADULT_YGE15: {
          indicatorKey: 'ILO.LFPR_PCT',
          name: 'Labor Force Participation Rate, Ages 15+ (%, ILOSTAT Modeled)',
          methodologyId: 'ILO_SDMX21_EAP_2WAP',
        },
      },
    },
    {
      flowId: 'DF_UNE_2EAP_SEX_AGE_RT',
      url: `https://sdmx.ilo.org/rest/data/ILO,DF_UNE_2EAP_SEX_AGE_RT,1.0/${iso3Filter}.A..SEX_T.AGE_YTHADULT_YGE15+AGE_YTHADULT_Y15-24?startPeriod=2021&endPeriod=2025`,
      ageSql: `'AGE_YTHADULT_YGE15', 'AGE_YTHADULT_Y15-24'`,
      targets: {
        AGE_YTHADULT_YGE15: {
          indicatorKey: 'ILO.UNEMPLOYMENT_PCT',
          name: 'Unemployment Rate, Ages 15+ (%, ILOSTAT Modeled)',
          methodologyId: 'ILO_SDMX21_UNE_2EAP',
        },
        'AGE_YTHADULT_Y15-24': {
          indicatorKey: 'ILO.YOUTH_UNEMPLOYMENT_PCT',
          name: 'Youth Unemployment Rate, Ages 15-24 (%, ILOSTAT Modeled)',
          methodologyId: 'ILO_SDMX21_UNE_2EAP',
        },
      },
    },
    {
      flowId: 'DF_EMP_2WAP_SEX_AGE_RT',
      url: `https://sdmx.ilo.org/rest/data/ILO,DF_EMP_2WAP_SEX_AGE_RT,1.0/${iso3Filter}.A..SEX_T.AGE_YTHADULT_YGE15?startPeriod=2021&endPeriod=2025`,
      ageSql: `'AGE_YTHADULT_YGE15'`,
      targets: {
        AGE_YTHADULT_YGE15: {
          indicatorKey: 'ILO.EMPLOYMENT_TO_POP_PCT',
          name: 'Employment-to-Population Ratio, Ages 15+ (%, ILOSTAT Modeled)',
          methodologyId: 'ILO_SDMX21_EMP_2WAP',
        },
      },
    },
  ];

  const assertedAt = new Date().toISOString();
  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  let lastEtag: string | null = null;
  let dedupHit = false;
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const headers = {
    Accept: 'application/vnd.sdmx.data+csv;version=1.0.0',
    'Accept-Language': 'en',
  };

  const fetched: Array<{ flow: (typeof flows)[number]; filePath: string | null; status: string }> = [];
  for (const flow of flows) {
    try {
      const res = await fetchWithCitizenship({
        url: flow.url,
        host: source.host,
        rateLimitRpm: source.rate_limit_rpm,
        maxConcurrency: source.max_concurrency,
        bypassConditionalCache: bypassCache,
        headers,
        destPrefix: `ilo_${flow.flowId}`,
        timeoutMs: 20_000,
      });
      dedupHit = dedupHit || res.dedupHit;
      if (res.etag) lastEtag = res.etag;
      fetched.push({ flow, filePath: res.filePath, status: res.status });
    } catch {
      fetched.push({ flow, filePath: null, status: 'ERROR' });
    }
  }

  const anyChanged = fetched.some((f) => f.status === 'OK');
  if (fetched.every((f) => f.status === 'ERROR')) {
    throw new Error(`All ILOSTAT SDMX dataflow requests failed for ${source.host}`);
  }
  if (!anyChanged && !bypassCache) {
    return { rawRows: [], silver: [], etag: lastEtag, dedupHit, notModified: fetched.length > 0 && fetched.every((item) => item.status === 'NOT_MODIFIED') };
  }

  for (const item of fetched) {
    if (!item.filePath && item.status === 'NOT_MODIFIED') {
      try {
        const fullRes = await fetchWithCitizenship({
          url: item.flow.url,
          host: source.host,
          rateLimitRpm: source.rate_limit_rpm,
          maxConcurrency: source.max_concurrency,
          bypassConditionalCache: true,
          headers,
          destPrefix: `ilo_${item.flow.flowId}_full`,
          timeoutMs: 20_000,
        });
        item.filePath = fullRes.filePath;
      } catch {
        // ignore hydration blip
      }
    }
  }

  const dedupKeys = new Set<string>();
  for (const { flow, filePath } of fetched) {
    if (!filePath) continue;
    try {
      const csvRows = await withDuckDBConnection(async (conn) => {
        const reader = await conn.runAndReadAll(`
          SELECT REF_AREA, MEASURE, SEX, AGE, TIME_PERIOD, OBS_VALUE
          FROM read_csv_auto(${sqlQuote(filePath)}, header=true, all_varchar=true)
          WHERE FREQ = 'A'
            AND SEX = 'SEX_T'
            AND AGE IN (${flow.ageSql})
            AND REF_AREA IS NOT NULL
            AND OBS_VALUE IS NOT NULL;
        `);
        try {
          return reader.getRowObjectsJson() as Array<Record<string, unknown>>;
        } finally {
          reader.closeSync();
        }
      });

      for (const r of csvRows) {
        const iso3Raw = String(r.REF_AREA ?? '').trim();
        const ageCode = String(r.AGE ?? '').trim();
        const year = Number(String(r.TIME_PERIOD ?? '').trim());
        const val = Number(String(r.OBS_VALUE ?? '').trim());
        if (!iso3Raw || !Number.isInteger(year) || !Number.isFinite(val)) continue;

        const target = flow.targets[ageCode];
        if (!target) continue;
        const territory = resolveTerritoryByCodeOrName(iso3Raw);
        if (!territory) continue;

        const dedupKey = `${territory.territory_id}|${target.indicatorKey}|${year}`;
        if (dedupKeys.has(dedupKey)) continue;
        dedupKeys.add(dedupKey);

        rawRows.push({ flow: flow.flowId, ...r });
        silver.push({
          territory_id: territory.territory_id,
          iso3: territory.iso3,
          indicator_id: target.indicatorKey,
          indicator_name: target.name,
          module_id: 2,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: year,
          value_numeric: Number(val.toFixed(3)),
          unit: '%',
          valuation_basis: 'percent',
          methodology_id: target.methodologyId,
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    } finally {
      safeUnlink(filePath);
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestOecdSdmx(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const iso3Filter = getCanonicalIso3Filter('+');
  const flows = [
    {
      flowId: 'cli',
      url: 'https://sdmx.oecd.org/public/rest/data/OECD.SDD.STES,DSD_STES@DF_CLI/.M.LI...AA...H?startPeriod=2024-01&dimensionAtObservation=AllDimensions&format=csvfile',
    },
    {
      flowId: 'naag',
      url: `https://sdmx.oecd.org/public/rest/data/OECD.SDD.NAD,DSD_NAAG@DF_NAAG_I/A.${iso3Filter}...?startPeriod=2021&dimensionAtObservation=AllDimensions&format=csvfile`,
    },
    {
      flowId: 'prices',
      url: `https://sdmx.oecd.org/public/rest/data/OECD.SDD.TPS,DSD_PRICES@DF_PRICES_ALL/${iso3Filter}.A.N.CPI.PA._T.N.GY?startPeriod=2021&dimensionAtObservation=AllDimensions&format=csvfile`,
    },
    {
      flowId: 'lfs_une',
      url: `https://sdmx.oecd.org/public/rest/data/OECD.SDD.TPS,DSD_LFS@DF_IALFS_UNE_M/${iso3Filter}..._Z.Y._T.Y_GE15..A?startPeriod=2021&dimensionAtObservation=AllDimensions&format=csvfile`,
    },
  ] as const;

  const assertedAt = new Date().toISOString();
  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  let lastEtag: string | null = null;
  let dedupHit = false;
  const bypassCache = shouldBypassConditionalCache(source.source_id);

  const fetched: Array<{ flowId: (typeof flows)[number]['flowId']; url: string; filePath: string | null; status: string }> = [];
  for (const flow of flows) {
    try {
      const res = await fetchWithCitizenship({
        url: flow.url,
        host: source.host,
        rateLimitRpm: source.rate_limit_rpm,
        maxConcurrency: source.max_concurrency,
        bypassConditionalCache: bypassCache,
        destPrefix: `oecd_${flow.flowId}`,
        timeoutMs: 25_000,
      });
      dedupHit = dedupHit || res.dedupHit;
      if (res.etag) lastEtag = res.etag;
      fetched.push({ flowId: flow.flowId, url: flow.url, filePath: res.filePath, status: res.status });
    } catch {
      fetched.push({ flowId: flow.flowId, url: flow.url, filePath: null, status: 'ERROR' });
    }
  }

  const anyChanged = fetched.some((f) => f.status === 'OK');
  if (fetched.every((f) => f.status === 'ERROR')) {
    throw new Error(`All OECD SDMX dataflow requests failed for ${source.host}`);
  }
  if (!anyChanged && !bypassCache) {
    return { rawRows: [], silver: [], etag: lastEtag, dedupHit, notModified: fetched.length > 0 && fetched.every((item) => item.status === 'NOT_MODIFIED') };
  }

  for (const item of fetched) {
    if (!item.filePath && item.status === 'NOT_MODIFIED') {
      try {
        const fullRes = await fetchWithCitizenship({
          url: item.url,
          host: source.host,
          rateLimitRpm: source.rate_limit_rpm,
          maxConcurrency: source.max_concurrency,
          bypassConditionalCache: true,
          destPrefix: `oecd_${item.flowId}_full`,
          timeoutMs: 25_000,
        });
        item.filePath = fullRes.filePath;
      } catch {
        // ignore hydration blip
      }
    }
  }

  const dedupKeys = new Set<string>();
  const pushSilver = (rec: ObservationContract) => {
    const key = `${rec.territory_id}|${rec.indicator_id}|${rec.period_year}`;
    if (dedupKeys.has(key)) return;
    dedupKeys.add(key);
    silver.push(rec);
  };

  for (const item of fetched) {
    if (!item.filePath) continue;
    try {
      if (item.flowId === 'cli') {
        const csvRows = await withDuckDBConnection(async (conn) => {
          const reader = await conn.runAndReadAll(`
            SELECT REF_AREA, TIME_PERIOD, OBS_VALUE
            FROM read_csv_auto(${sqlQuote(item.filePath!)}, header=true, all_varchar=true)
            WHERE REF_AREA IS NOT NULL AND TIME_PERIOD IS NOT NULL AND OBS_VALUE IS NOT NULL;
          `);
          try {
            return reader.getRowObjectsJson() as Array<Record<string, unknown>>;
          } finally {
            reader.closeSync();
          }
        });

        const latestByTerritory = new Map<string, { iso3: string; period: string; year: number; val: number }>();
        for (const r of csvRows) {
          const code = String(r.REF_AREA ?? '').trim();
          const period = String(r.TIME_PERIOD ?? '').trim();
          const val = Number(String(r.OBS_VALUE ?? '').trim());
          if (!code || !period || !Number.isFinite(val)) continue;
          const territory = resolveTerritoryByCodeOrName(code);
          if (!territory) continue;
          const year = Number(period.slice(0, 4));
          if (!Number.isInteger(year) || year < 2021 || year > 2026) continue;

          rawRows.push({ flow: 'cli', ...r });
          const prev = latestByTerritory.get(territory.territory_id);
          if (!prev || period > prev.period) {
            latestByTerritory.set(territory.territory_id, { iso3: territory.iso3, period, year, val });
          }
        }

        for (const [territoryId, entry] of latestByTerritory.entries()) {
          pushSilver({
            territory_id: territoryId,
            iso3: entry.iso3,
            indicator_id: 'OECD.CLI_IX',
            indicator_name: `Composite Leading Indicator, Amplitude Adj. (${entry.period}, OECD CLI)`,
            module_id: 2,
            source_id: source.source_id,
            dataset_id: source.dataset_id,
            period_year: entry.year,
            value_numeric: Number(entry.val.toFixed(3)),
            unit: 'index (100=trend)',
            valuation_basis: 'index_score',
            methodology_id: 'OECD_SDMX_DSD_STES_CLI',
            commercial_use_allowed: source.commercial_use_allowed,
            asserted_at: assertedAt,
          });
        }
      } else if (item.flowId === 'naag') {
        const csvRows = await withDuckDBConnection(async (conn) => {
          const reader = await conn.runAndReadAll(`
            SELECT REF_AREA, MEASURE, UNIT_MEASURE, TIME_PERIOD, OBS_VALUE
            FROM read_csv_auto(${sqlQuote(item.filePath!)}, header=true, all_varchar=true)
            WHERE REF_AREA IS NOT NULL
              AND OBS_VALUE IS NOT NULL
              AND (
                (MEASURE = 'B1GQ_POP' AND UNIT_MEASURE = 'USD_PPP_PS')
                OR (MEASURE = 'B1GQ_R_GR' AND UNIT_MEASURE = 'PC')
              );
          `);
          try {
            return reader.getRowObjectsJson() as Array<Record<string, unknown>>;
          } finally {
            reader.closeSync();
          }
        });

        for (const r of csvRows) {
          const territory = resolveTerritoryByCodeOrName(String(r.REF_AREA ?? '').trim());
          const measure = String(r.MEASURE ?? '').trim();
          const year = Number(String(r.TIME_PERIOD ?? '').trim());
          const val = Number(String(r.OBS_VALUE ?? '').trim());
          if (!territory || !Number.isInteger(year) || !Number.isFinite(val)) continue;
          rawRows.push({ flow: 'naag', ...r });

          if (measure === 'B1GQ_POP') {
            pushSilver({
              territory_id: territory.territory_id,
              iso3: territory.iso3,
              indicator_id: 'OECD.GDP_PCAP_PPP_USD',
              indicator_name: 'GDP per Capita, Current PPP USD (OECD NAAG)',
              module_id: 2,
              source_id: source.source_id,
              dataset_id: source.dataset_id,
              period_year: year,
              value_numeric: Number(val.toFixed(2)),
              unit: 'PPP USD',
              valuation_basis: 'constant_2021_ppp',
              methodology_id: 'OECD_SDMX_NAAG_I',
              commercial_use_allowed: source.commercial_use_allowed,
              asserted_at: assertedAt,
            });
          } else if (measure === 'B1GQ_R_GR') {
            pushSilver({
              territory_id: territory.territory_id,
              iso3: territory.iso3,
              indicator_id: 'OECD.REAL_GDP_GROWTH_PCT',
              indicator_name: 'Real GDP Growth, Annual % (OECD NAAG)',
              module_id: 2,
              source_id: source.source_id,
              dataset_id: source.dataset_id,
              period_year: year,
              value_numeric: Number(val.toFixed(2)),
              unit: '%',
              valuation_basis: 'percent',
              methodology_id: 'OECD_SDMX_NAAG_I',
              commercial_use_allowed: source.commercial_use_allowed,
              asserted_at: assertedAt,
            });
          }
        }
      } else if (item.flowId === 'prices') {
        const csvRows = await withDuckDBConnection(async (conn) => {
          const reader = await conn.runAndReadAll(`
            SELECT REF_AREA, TIME_PERIOD, OBS_VALUE
            FROM read_csv_auto(${sqlQuote(item.filePath!)}, header=true, all_varchar=true)
            WHERE REF_AREA IS NOT NULL AND OBS_VALUE IS NOT NULL;
          `);
          try {
            return reader.getRowObjectsJson() as Array<Record<string, unknown>>;
          } finally {
            reader.closeSync();
          }
        });

        for (const r of csvRows) {
          const territory = resolveTerritoryByCodeOrName(String(r.REF_AREA ?? '').trim());
          const year = Number(String(r.TIME_PERIOD ?? '').trim());
          const val = Number(String(r.OBS_VALUE ?? '').trim());
          if (!territory || !Number.isInteger(year) || !Number.isFinite(val)) continue;
          rawRows.push({ flow: 'prices', ...r });
          pushSilver({
            territory_id: territory.territory_id,
            iso3: territory.iso3,
            indicator_id: 'OECD.CPI_INFLATION_PCT',
            indicator_name: 'Consumer Price Inflation, Annual % (OECD Prices)',
            module_id: 2,
            source_id: source.source_id,
            dataset_id: source.dataset_id,
            period_year: year,
            value_numeric: Number(val.toFixed(2)),
            unit: '%',
            valuation_basis: 'percent',
            methodology_id: 'OECD_SDMX_PRICES_CPI',
            commercial_use_allowed: source.commercial_use_allowed,
            asserted_at: assertedAt,
          });
        }
      } else if (item.flowId === 'lfs_une') {
        const csvRows = await withDuckDBConnection(async (conn) => {
          const reader = await conn.runAndReadAll(`
            SELECT REF_AREA, TIME_PERIOD, OBS_VALUE
            FROM read_csv_auto(${sqlQuote(item.filePath!)}, header=true, all_varchar=true)
            WHERE REF_AREA IS NOT NULL AND OBS_VALUE IS NOT NULL;
          `);
          try {
            return reader.getRowObjectsJson() as Array<Record<string, unknown>>;
          } finally {
            reader.closeSync();
          }
        });

        for (const r of csvRows) {
          const territory = resolveTerritoryByCodeOrName(String(r.REF_AREA ?? '').trim());
          const year = Number(String(r.TIME_PERIOD ?? '').trim());
          const val = Number(String(r.OBS_VALUE ?? '').trim());
          if (!territory || !Number.isInteger(year) || !Number.isFinite(val)) continue;
          rawRows.push({ flow: 'lfs_une', ...r });
          pushSilver({
            territory_id: territory.territory_id,
            iso3: territory.iso3,
            indicator_id: 'OECD.UNEMPLOYMENT_PCT',
            indicator_name: 'Harmonized Unemployment Rate, Annual % (OECD LFS)',
            module_id: 2,
            source_id: source.source_id,
            dataset_id: source.dataset_id,
            period_year: year,
            value_numeric: Number(val.toFixed(2)),
            unit: '%',
            valuation_basis: 'percent',
            methodology_id: 'OECD_SDMX_IALFS_UNE',
            commercial_use_allowed: source.commercial_use_allowed,
            asserted_at: assertedAt,
          });
        }
      }
    } finally {
      safeUnlink(item.filePath);
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestEurostatMacro(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const url =
    'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/nama_10_gdp?format=JSON&lang=EN&sinceTimePeriod=2021&unit=CP_MEUR&na_item=B1GQ&geo=DE&geo=FR&geo=ES&geo=IT&geo=NL&geo=PL&geo=PT&geo=SE';
  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: shouldBypassConditionalCache(source.source_id),
    destPrefix: 'eurostat_gdp',
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  try {
    const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
      id?: string[];
      size?: number[];
      dimension?: Record<string, { category?: { index?: Record<string, number> } }>;
      value?: Record<string, number>;
    };
    const dims = json.id ?? [];
    const sizes = json.size ?? [];
    const geoIdxMap = json.dimension?.geo?.category?.index ?? {};
    const timeIdxMap = json.dimension?.time?.category?.index ?? {};
    const geoPos = dims.indexOf('geo');
    const timePos = dims.indexOf('time');

    if (geoPos >= 0 && timePos >= 0 && json.value) {
      const geoEntries = Object.entries(geoIdxMap);
      const timeEntries = Object.entries(timeIdxMap);

      for (const [geoCode, gIdx] of geoEntries) {
        const territory = resolveTerritoryByCodeOrName(geoCode);
        if (!territory) continue;
        for (const [timeStr, tIdx] of timeEntries) {
          const coords = new Array<number>(dims.length).fill(0);
          coords[geoPos] = gIdx;
          coords[timePos] = tIdx;
          let flatIdx = 0;
          let stride = 1;
          for (let d = dims.length - 1; d >= 0; d--) {
            flatIdx += coords[d] * stride;
            stride *= sizes[d];
          }
          const val = json.value[String(flatIdx)];
          const year = Number(timeStr);
          if (typeof val !== 'number' || !Number.isInteger(year)) continue;
          rawRows.push({ geo: geoCode, time: year, value_meur: val });
          silver.push({
            territory_id: territory.territory_id,
            iso3: territory.iso3,
            indicator_id: 'EUROSTAT.GDP_CP_MEUR',
            indicator_name: 'GDP at Market Prices (Eurostat, Million EUR)',
            module_id: 2,
            source_id: source.source_id,
            dataset_id: source.dataset_id,
            period_year: year,
            value_numeric: val,
            unit: 'Million EUR',
            valuation_basis: 'nominal_usd',
            methodology_id: 'EUROSTAT_JSONSTAT_NAMA_10_GDP',
            commercial_use_allowed: source.commercial_use_allowed,
            asserted_at: assertedAt,
          });
        }
      }
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestEurostatSdmx3(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const euGeoFilter = listTerritories()
    .filter((t) => t.continent === 'Europe' && t.iso2 !== 'GB')
    .map((t) => t.iso2)
    .join(',');

  const flows = [
    {
      flowId: 'prc_hicp_aind',
      url: `https://ec.europa.eu/eurostat/api/dissemination/sdmx/3.0/data/dataflow/ESTAT/prc_hicp_aind/1.0?c[freq]=A&c[unit]=RCH_A_AVG&c[coicop]=CP00&c[geo]=${euGeoFilter}&c[TIME_PERIOD]=ge:2021&compress=false&format=csvdata`,
      indicatorId: 'EUROSTAT3.HICP_INFLATION_PCT',
      indicatorName: 'HICP All-Items Annual Average Rate of Change (%, Eurostat SDMX 3.0)',
      unit: '%',
      basis: 'percent' as const,
      methodologyId: 'EUROSTAT_SDMX3_PRC_HICP_AIND',
    },
    {
      flowId: 'une_rt_a',
      url: `https://ec.europa.eu/eurostat/api/dissemination/sdmx/3.0/data/dataflow/ESTAT/une_rt_a/1.0?c[freq]=A&c[sex]=T&c[age]=Y15-74&c[unit]=PC_ACT&c[geo]=${euGeoFilter}&c[TIME_PERIOD]=ge:2021&compress=false&format=csvdata`,
      indicatorId: 'EUROSTAT3.UNEMPLOYMENT_PCT',
      indicatorName: 'Unemployment Rate, Ages 15-74 (% Active Pop, Eurostat SDMX 3.0)',
      unit: '%',
      basis: 'percent' as const,
      methodologyId: 'EUROSTAT_SDMX3_UNE_RT_A',
    },
  ];

  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  let lastEtag: string | null = null;
  let dedupHit = false;

  const fetched: Array<{ flow: (typeof flows)[number]; filePath: string | null; status: string }> = [];
  for (const flow of flows) {
    try {
      const res = await fetchWithCitizenship({
        url: flow.url,
        host: source.host,
        rateLimitRpm: source.rate_limit_rpm,
        maxConcurrency: source.max_concurrency,
        bypassConditionalCache: bypassCache,
        destPrefix: `eurostat3_${flow.flowId}`,
        timeoutMs: 20_000,
      });
      dedupHit = dedupHit || res.dedupHit;
      if (res.etag) lastEtag = res.etag;
      fetched.push({ flow, filePath: res.filePath, status: res.status });
    } catch {
      fetched.push({ flow, filePath: null, status: 'ERROR' });
    }
  }

  const anyChanged = fetched.some((f) => f.status === 'OK');
  if (fetched.every((f) => f.status === 'ERROR')) {
    throw new Error(`All Eurostat SDMX 3.0 requests failed for ${source.host}`);
  }
  if (!anyChanged && !bypassCache) {
    return { rawRows: [], silver: [], etag: lastEtag, dedupHit, notModified: fetched.length > 0 && fetched.every((item) => item.status === 'NOT_MODIFIED') };
  }

  for (const item of fetched) {
    if (!item.filePath && item.status === 'NOT_MODIFIED') {
      try {
        const fullRes = await fetchWithCitizenship({
          url: item.flow.url,
          host: source.host,
          rateLimitRpm: source.rate_limit_rpm,
          maxConcurrency: source.max_concurrency,
          bypassConditionalCache: true,
          destPrefix: `eurostat3_${item.flow.flowId}_full`,
          timeoutMs: 20_000,
        });
        item.filePath = fullRes.filePath;
      } catch {
        // ignore hydration blip
      }
    }
  }

  const dedupKeys = new Set<string>();
  for (const { flow, filePath } of fetched) {
    if (!filePath) continue;
    try {
      const csvRows = await withDuckDBConnection(async (conn) => {
        const reader = await conn.runAndReadAll(`
          SELECT geo, TIME_PERIOD, OBS_VALUE
          FROM read_csv_auto(${sqlQuote(filePath)}, header=true, all_varchar=true)
          WHERE geo IS NOT NULL AND TIME_PERIOD IS NOT NULL AND OBS_VALUE IS NOT NULL;
        `);
        try {
          return reader.getRowObjectsJson() as Array<Record<string, unknown>>;
        } finally {
          reader.closeSync();
        }
      });

      for (const r of csvRows) {
        const geo = String(r.geo ?? '').trim();
        const year = Number(String(r.TIME_PERIOD ?? '').trim());
        const val = Number(String(r.OBS_VALUE ?? '').trim());
        if (!geo || !Number.isInteger(year) || year < 2021 || year > 2026 || !Number.isFinite(val)) continue;

        const territory = resolveTerritoryByCodeOrName(geo);
        if (!territory) continue;

        const key = `${territory.territory_id}|${flow.indicatorId}|${year}`;
        if (dedupKeys.has(key)) continue;
        dedupKeys.add(key);

        rawRows.push({ flow: flow.flowId, ...r });
        silver.push({
          territory_id: territory.territory_id,
          iso3: territory.iso3,
          indicator_id: flow.indicatorId,
          indicator_name: flow.indicatorName,
          module_id: 2,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: year,
          value_numeric: Number(val.toFixed(2)),
          unit: flow.unit,
          valuation_basis: flow.basis,
          methodology_id: flow.methodologyId,
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    } finally {
      safeUnlink(filePath);
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestEurostatStatsApi(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);

  const slices = [
    {
      flowId: 'gov_debt',
      url: 'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/gov_10dd_edpt1?format=JSON&lang=EN&sinceTimePeriod=2021&na_item=GD&sector=S13&unit=PC_GDP&geo=DE&geo=FR&geo=ES&geo=IT&geo=NL&geo=PL&geo=PT&geo=SE&geo=NO',
      indicatorId: 'EUROSTAT_STATS.GOV_DEBT_PCT_GDP',
      indicatorName: 'General Government Gross Debt (% of GDP, Eurostat Stats 1.0)',
      methodologyId: 'EUROSTAT_STATS_GOV_10DD_GD',
    },
    {
      flowId: 'gov_balance',
      url: 'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/gov_10dd_edpt1?format=JSON&lang=EN&sinceTimePeriod=2021&na_item=B9&sector=S13&unit=PC_GDP&geo=DE&geo=FR&geo=ES&geo=IT&geo=NL&geo=PL&geo=PT&geo=SE&geo=NO',
      indicatorId: 'EUROSTAT_STATS.GOV_BALANCE_PCT_GDP',
      indicatorName: 'General Government Net Lending/Borrowing (% of GDP, Eurostat Stats 1.0)',
      methodologyId: 'EUROSTAT_STATS_GOV_10DD_B9',
    },
  ];

  const fetched: Array<{ slice: (typeof slices)[number]; filePath: string | null; status: string }> = [];
  let lastEtag: string | null = null;
  let dedupHit = false;

  for (const slice of slices) {
    const res = await fetchWithCitizenship({
      url: slice.url,
      host: source.host,
      rateLimitRpm: source.rate_limit_rpm,
      maxConcurrency: source.max_concurrency,
      bypassConditionalCache: bypassCache,
      destPrefix: `eurostat_stats_${slice.flowId}`,
      timeoutMs: 20_000,
    });
    dedupHit = dedupHit || res.dedupHit;
    if (res.etag) lastEtag = res.etag;
    fetched.push({ slice, filePath: res.filePath, status: res.status });
  }

  const anyChanged = fetched.some((f) => f.status === 'OK');
  if (!anyChanged && !bypassCache) {
    return { rawRows: [], silver: [], etag: lastEtag, dedupHit, notModified: fetched.length > 0 && fetched.every((item) => item.status === 'NOT_MODIFIED') };
  }

  for (const item of fetched) {
    if (!item.filePath && item.status === 'NOT_MODIFIED') {
      const fullRes = await fetchWithCitizenship({
        url: item.slice.url,
        host: source.host,
        rateLimitRpm: source.rate_limit_rpm,
        maxConcurrency: source.max_concurrency,
        bypassConditionalCache: true,
        destPrefix: `eurostat_stats_${item.slice.flowId}_full`,
        timeoutMs: 20_000,
      });
      item.filePath = fullRes.filePath;
    }
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const dedupKeys = new Set<string>();

  for (const { slice, filePath } of fetched) {
    if (!filePath) continue;
    try {
      const json = JSON.parse(fs.readFileSync(filePath, 'utf-8')) as {
        id?: string[];
        size?: number[];
        dimension?: Record<string, { category?: { index?: Record<string, number> } }>;
        value?: Record<string, number>;
      };
      const dims = json.id ?? [];
      const sizes = json.size ?? [];
      const geoIdxMap = json.dimension?.geo?.category?.index ?? {};
      const timeIdxMap = json.dimension?.time?.category?.index ?? {};
      const geoPos = dims.indexOf('geo');
      const timePos = dims.indexOf('time');

      if (geoPos >= 0 && timePos >= 0 && json.value) {
        for (const [geoCode, gIdx] of Object.entries(geoIdxMap)) {
          const territory = resolveTerritoryByCodeOrName(geoCode);
          if (!territory) continue;
          for (const [timeStr, tIdx] of Object.entries(timeIdxMap)) {
            const coords = new Array<number>(dims.length).fill(0);
            coords[geoPos] = gIdx;
            coords[timePos] = tIdx;
            let flatIdx = 0;
            let stride = 1;
            for (let d = dims.length - 1; d >= 0; d--) {
              flatIdx += coords[d] * stride;
              stride *= sizes[d];
            }
            const val = json.value[String(flatIdx)];
            const year = Number(timeStr);
            if (typeof val !== 'number' || !Number.isFinite(val) || !Number.isInteger(year) || year > 2026) continue;

            const dedupKey = `${territory.territory_id}|${slice.indicatorId}|${year}`;
            if (dedupKeys.has(dedupKey)) continue;
            dedupKeys.add(dedupKey);

            rawRows.push({ flow: slice.flowId, geo: geoCode, year, value: val });
            silver.push({
              territory_id: territory.territory_id,
              iso3: territory.iso3,
              indicator_id: slice.indicatorId,
              indicator_name: slice.indicatorName,
              module_id: 2,
              source_id: source.source_id,
              dataset_id: source.dataset_id,
              period_year: year,
              value_numeric: Number(val.toFixed(2)),
              unit: '% of GDP',
              valuation_basis: 'percent',
              methodology_id: slice.methodologyId,
              commercial_use_allowed: source.commercial_use_allowed,
              asserted_at: assertedAt,
            });
          }
        }
      }
    } finally {
      safeUnlink(filePath);
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestEurostatCatalogue(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();
  const url = 'https://ec.europa.eu/eurostat/api/dissemination/catalogue/toc/txt?lang=en';

  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: shouldBypassConditionalCache(source.source_id),
    destPrefix: 'eurostat_catalogue_toc',
    timeoutMs: 25_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];

  try {
    const content = fs.readFileSync(res.filePath, 'utf-8');
    const lines = content.split(/\r?\n/);
    let datasetsCount = 0;
    let foldersCount = 0;
    let totalSeriesValues = 0;

    for (let i = 1; i < lines.length; i++) {
      const line = lines[i];
      if (!line.trim()) continue;
      const cols = line.split('\t').map((c) => c.replace(/^"|"$/g, '').trim());
      const itemType = cols[2]?.toLowerCase() ?? '';
      if (itemType === 'dataset' || itemType === 'table') {
        datasetsCount += 1;
        const valsNum = Number(cols[cols.length - 1]);
        if (Number.isFinite(valsNum) && valsNum > 0) {
          totalSeriesValues += valsNum;
        }
        if (rawRows.length < 200) {
          rawRows.push({
            title: cols[0] ?? '',
            code: cols[1] ?? '',
            type: itemType,
            last_update: cols[3] ?? '',
            values: Number.isFinite(valsNum) ? valsNum : null,
          });
        }
      } else if (itemType === 'folder') {
        foldersCount += 1;
      }
    }

    if (datasetsCount > 0) {
      silver.push({
        territory_id: 'T_DEU',
        iso3: 'DEU',
        indicator_id: 'EUROSTAT_CAT.DATASETS_COUNT',
        indicator_name: 'Total Active Statistical Datasets & Tables (Eurostat TOC)',
        module_id: 2,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: currentYear,
        value_numeric: datasetsCount,
        unit: 'datasets',
        valuation_basis: 'count',
        methodology_id: 'EUROSTAT_CATALOGUE_TOC_TXT',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }

    if (totalSeriesValues > 0) {
      silver.push({
        territory_id: 'T_DEU',
        iso3: 'DEU',
        indicator_id: 'EUROSTAT_CAT.TOTAL_SERIES_VALUES',
        indicator_name: 'Total Indexed Observation Values Across Eurostat Catalogue',
        module_id: 2,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: currentYear,
        value_numeric: Math.round(totalSeriesValues),
        unit: 'observations',
        valuation_basis: 'count',
        methodology_id: 'EUROSTAT_CATALOGUE_TOC_TXT',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }

    rawRows.unshift({
      summary: true,
      datasets_count: datasetsCount,
      folders_count: foldersCount,
      total_series_values: Math.round(totalSeriesValues),
    });
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestEcbSdmx(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const url =
    'https://data-api.ecb.europa.eu/service/data/EXR/A.USD+GBP+JPY+BRL+CNY+INR+MXN+CAD+AUD+CHF+KRW+TRY+ZAR+IDR+PLN+SEK+NOK+SAR.EUR.SP00.A?lastNObservations=1&format=csvdata';

  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: shouldBypassConditionalCache(source.source_id),
    destPrefix: 'ecb_sdmx_exr',
    timeoutMs: 25_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const territories = listTerritories();

  try {
    const csvRows = await withDuckDBConnection(async (conn) => {
      const reader = await conn.runAndReadAll(`
        SELECT CURRENCY, TIME_PERIOD, TRY_CAST(OBS_VALUE AS DOUBLE) AS val
        FROM read_csv_auto(${sqlQuote(res.filePath!)}, header=true, all_varchar=true)
        WHERE CURRENCY IS NOT NULL AND TIME_PERIOD IS NOT NULL AND OBS_VALUE IS NOT NULL;
      `);
      try {
        return reader.getRowObjectsJson() as Array<{
          CURRENCY?: string | null;
          TIME_PERIOD?: string | null;
          val?: number | null;
        }>;
      } finally {
        reader.closeSync();
      }
    });

    const fxByCurrency = new Map<string, { year: number; val: number }>();
    let refYear = new Date().getUTCFullYear() - 1;

    for (const r of csvRows) {
      const ccy = String(r.CURRENCY ?? '').trim().toUpperCase();
      const year = Number(String(r.TIME_PERIOD ?? '').trim().slice(0, 4));
      const val = typeof r.val === 'number' && Number.isFinite(r.val) ? r.val : null;
      if (!ccy || !Number.isInteger(year) || val === null || val <= 0) continue;
      rawRows.push({ currency: ccy, year, fx_per_eur: val });
      const prev = fxByCurrency.get(ccy);
      if (!prev || year > prev.year) {
        fxByCurrency.set(ccy, { year, val });
      }
      if (year > refYear) refYear = year;
    }

    fxByCurrency.set('EUR', { year: refYear, val: 1.0 });

    for (const t of territories) {
      const match = fxByCurrency.get(t.currency_iso4217.toUpperCase());
      if (!match) continue;
      silver.push({
        territory_id: t.territory_id,
        iso3: t.iso3,
        indicator_id: 'ECB.FX_PER_EUR',
        indicator_name: `ECB Official Annual Reference FX Rate (${t.currency_iso4217} per EUR)`,
        module_id: 2,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: match.year,
        value_numeric: Number(match.val.toFixed(4)),
        unit: `${t.currency_iso4217}/EUR`,
        valuation_basis: 'count',
        methodology_id: 'ECB_SDMX21_EXR_A_SP00',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestBisSdmxV2(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const url =
    'https://stats.bis.org/api/v2/data/dataflow/BIS/WS_TC/2.0/Q.BR+US+DE+CN+GB+FR+JP+CA+AU+IN+KR+MX+TR+ZA+CH+SE+NO+PL+ES+IT+NL+SA+ID+SG.C.A.M.770.A?startPeriod=2023-Q1&format=csv';
  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: shouldBypassConditionalCache(source.source_id),
    destPrefix: 'bis_ws_tc_v2',
    timeoutMs: 20_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  try {
    const csvRows = await withDuckDBConnection(async (conn) => {
      const reader = await conn.runAndReadAll(`
        SELECT BORROWERS_CTY, TIME_PERIOD, OBS_VALUE
        FROM read_csv_auto(${sqlQuote(res.filePath!)}, header=true)
        WHERE BORROWERS_CTY IS NOT NULL AND OBS_VALUE IS NOT NULL;
      `);
      try {
        return reader.getRowObjectsJson() as Array<Record<string, unknown>>;
      } finally {
        reader.closeSync();
      }
    });

    const latestByTerritory = new Map<string, { iso3: string; period: string; year: number; val: number }>();
    for (const r of csvRows) {
      rawRows.push(r);
      const code = String(r.BORROWERS_CTY ?? '').trim();
      const period = String(r.TIME_PERIOD ?? '').trim();
      const val = Number(r.OBS_VALUE);
      if (!code || !period || !Number.isFinite(val)) continue;

      const territory = resolveTerritoryByCodeOrName(code);
      if (!territory) continue;
      const year = Number(period.slice(0, 4));
      if (!Number.isInteger(year)) continue;

      const prev = latestByTerritory.get(territory.territory_id);
      if (!prev || period > prev.period) {
        latestByTerritory.set(territory.territory_id, { iso3: territory.iso3, period, year, val });
      }
    }

    for (const [territoryId, entry] of latestByTerritory.entries()) {
      silver.push({
        territory_id: territoryId,
        iso3: entry.iso3,
        indicator_id: 'BIS.TOTAL_CREDIT_PCT_GDP',
        indicator_name: `Total Credit to Non-Financial Sector (${entry.period}, BIS WS_TC)`,
        module_id: 2,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: entry.year,
        value_numeric: Number(entry.val.toFixed(2)),
        unit: '% of GDP',
        valuation_basis: 'percent',
        methodology_id: 'BIS_WS_TC_SDMX_V2',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestAbsSdmx(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const slices = [
    {
      flowId: 'cpi_index',
      url: 'https://data.api.abs.gov.au/rest/data/ABS,CPI,1.1.0/1.10001.10.50.Q?startPeriod=2021&format=csv',
      indicatorId: 'ABS.CPI_INDEX',
      indicatorName: 'Australia CPI Index, 8 Capital Cities Weighted (ABS SDMX)',
      unit: 'index',
      basis: 'index_score' as const,
    },
    {
      flowId: 'cpi_yoy',
      url: 'https://data.api.abs.gov.au/rest/data/ABS,CPI,1.1.0/3.10001.10.50.Q?startPeriod=2021&format=csv',
      indicatorId: 'ABS.CPI_PCT_YOY',
      indicatorName: 'Australia CPI Annual Percentage Change YoY (ABS SDMX)',
      unit: '%',
      basis: 'percent' as const,
    },
  ];

  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  let lastEtag: string | null = null;
  let dedupHit = false;

  const fetched: Array<{ slice: (typeof slices)[number]; filePath: string | null; status: string }> = [];
  for (const slice of slices) {
    const res = await fetchWithCitizenship({
      url: slice.url,
      host: source.host,
      rateLimitRpm: source.rate_limit_rpm,
      maxConcurrency: source.max_concurrency,
      bypassConditionalCache: bypassCache,
      headers: { Accept: 'application/vnd.sdmx.data+csv;version=1.0.0', 'Accept-Language': 'en' },
      destPrefix: `abs_${slice.flowId}`,
      timeoutMs: 15_000,
    });
    dedupHit = dedupHit || res.dedupHit;
    if (res.etag) lastEtag = res.etag;
    fetched.push({ slice, filePath: res.filePath, status: res.status });
  }

  const anyChanged = fetched.some((f) => f.status === 'OK');
  if (!anyChanged && !bypassCache) {
    return { rawRows: [], silver: [], etag: lastEtag, dedupHit, notModified: fetched.length > 0 && fetched.every((item) => item.status === 'NOT_MODIFIED') };
  }

  for (const item of fetched) {
    if (!item.filePath && item.status === 'NOT_MODIFIED') {
      const fullRes = await fetchWithCitizenship({
        url: item.slice.url,
        host: source.host,
        rateLimitRpm: source.rate_limit_rpm,
        maxConcurrency: source.max_concurrency,
        bypassConditionalCache: true,
        headers: { Accept: 'application/vnd.sdmx.data+csv;version=1.0.0', 'Accept-Language': 'en' },
        destPrefix: `abs_${item.slice.flowId}_full`,
        timeoutMs: 15_000,
      });
      item.filePath = fullRes.filePath;
    }
  }

  for (const { slice, filePath } of fetched) {
    if (!filePath) continue;
    try {
      const csvRows = await withDuckDBConnection(async (conn) => {
        const reader = await conn.runAndReadAll(`
          SELECT TIME_PERIOD, OBS_VALUE
          FROM read_csv_auto(${sqlQuote(filePath)}, header=true, all_varchar=true)
          WHERE TIME_PERIOD IS NOT NULL AND OBS_VALUE IS NOT NULL;
        `);
        try {
          return reader.getRowObjectsJson() as Array<Record<string, unknown>>;
        } finally {
          reader.closeSync();
        }
      });

      const latestByYear = new Map<number, { period: string; val: number }>();
      for (const r of csvRows) {
        const period = String(r.TIME_PERIOD ?? '').trim();
        const val = Number(String(r.OBS_VALUE ?? '').trim());
        const year = Number(period.slice(0, 4));
        if (!Number.isInteger(year) || !Number.isFinite(val)) continue;
        rawRows.push({ flow: slice.flowId, ...r });

        const prev = latestByYear.get(year);
        if (!prev || period > prev.period) {
          latestByYear.set(year, { period, val });
        }
      }

      for (const [year, entry] of latestByYear.entries()) {
        silver.push({
          territory_id: 'T_AUS',
          iso3: 'AUS',
          indicator_id: slice.indicatorId,
          indicator_name: slice.indicatorName,
          module_id: 2,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: year,
          value_numeric: Number(entry.val.toFixed(2)),
          unit: slice.unit,
          valuation_basis: slice.basis,
          methodology_id: 'ABS_CPI_SDMX_110',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    } finally {
      safeUnlink(filePath);
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestStatcanWds(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const url = 'https://www150.statcan.gc.ca/t1/wds/rest/getDataFromVectorsAndLatestNPeriods';
  const payload = JSON.stringify([
    { vectorId: 2062815, latestN: 24 },
    { vectorId: 41690973, latestN: 24 },
  ]);

  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    method: 'POST',
    body: payload,
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    bypassConditionalCache: true,
    destPrefix: 'statcan_wds_vectors',
    timeoutMs: 20_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const dedupKeys = new Set<string>();

  try {
    const items = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as Array<{
      status?: string;
      object?: {
        vectorId?: number;
        vectorDataPoint?: Array<{ refPer?: string; value?: number | null }>;
      };
    }>;

    const pushCanObs = (
      indicatorId: string,
      indicatorName: string,
      year: number,
      value: number,
      unit: string,
      basis: ObservationContract['valuation_basis']
    ) => {
      const key = `T_CAN|${indicatorId}|${year}`;
      if (dedupKeys.has(key)) return;
      dedupKeys.add(key);
      silver.push({
        territory_id: 'T_CAN',
        iso3: 'CAN',
        indicator_id: indicatorId,
        indicator_name: indicatorName,
        module_id: 2,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: year,
        value_numeric: Number(value.toFixed(2)),
        unit,
        valuation_basis: basis,
        methodology_id: 'STATCAN_WDS_REST_VECTORS',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    };

    for (const item of Array.isArray(items) ? items : []) {
      if (item.status !== 'SUCCESS' || !item.object?.vectorId) continue;
      const vid = item.object.vectorId;
      const points = (item.object.vectorDataPoint ?? [])
        .filter((p) => p.refPer && typeof p.value === 'number' && Number.isFinite(p.value))
        .sort((a, b) => String(a.refPer).localeCompare(String(b.refPer)));

      for (const p of points) {
        rawRows.push({ vectorId: vid, refPer: p.refPer, value: p.value });
      }

      if (vid === 2062815) {
        const latestByYear = new Map<number, { refPer: string; val: number }>();
        for (const p of points) {
          const refPer = String(p.refPer);
          const year = Number(refPer.slice(0, 4));
          const val = p.value as number;
          if (!Number.isInteger(year) || year > 2026) continue;
          const prev = latestByYear.get(year);
          if (!prev || refPer > prev.refPer) {
            latestByYear.set(year, { refPer, val });
          }
        }
        for (const [year, entry] of latestByYear.entries()) {
          pushCanObs(
            'STATCAN.UNEMPLOYMENT_PCT',
            `Canada Unemployment Rate, Monthly SA (${entry.refPer}, StatCan WDS)`,
            year,
            entry.val,
            '%',
            'percent'
          );
        }
      } else if (vid === 41690973) {
        const byMonth = new Map<string, number>();
        const latestIdxByYear = new Map<number, { refPer: string; val: number }>();
        const latestYoyByYear = new Map<number, { refPer: string; val: number }>();

        for (const p of points) {
          const refPer = String(p.refPer);
          const val = p.value as number;
          const ym = refPer.slice(0, 7);
          const year = Number(refPer.slice(0, 4));
          byMonth.set(ym, val);
          if (!Number.isInteger(year) || year > 2026) continue;
          const prevIdx = latestIdxByYear.get(year);
          if (!prevIdx || refPer > prevIdx.refPer) {
            latestIdxByYear.set(year, { refPer, val });
          }
          const prevYm = `${year - 1}${ym.slice(4)}`;
          const priorVal = byMonth.get(prevYm);
          if (typeof priorVal === 'number' && priorVal > 0) {
            const yoy = ((val / priorVal) - 1) * 100;
            const prevYoy = latestYoyByYear.get(year);
            if (!prevYoy || refPer > prevYoy.refPer) {
              latestYoyByYear.set(year, { refPer, val: yoy });
            }
          }
        }

        for (const [year, entry] of latestIdxByYear.entries()) {
          pushCanObs(
            'STATCAN.CPI_INDEX',
            `Canada CPI All-Items Index 2002=100 (${entry.refPer}, StatCan WDS)`,
            year,
            entry.val,
            'index (2002=100)',
            'index_score'
          );
        }
        for (const [year, entry] of latestYoyByYear.entries()) {
          pushCanObs(
            'STATCAN.CPI_YOY_PCT',
            `Canada CPI YoY Inflation Rate % (${entry.refPer}, StatCan WDS)`,
            year,
            entry.val,
            '%',
            'percent'
          );
        }
      }
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

const ONS_MONTH_INDEX: Record<string, number> = {
  Jan: 1,
  Feb: 2,
  Mar: 3,
  Apr: 4,
  May: 5,
  Jun: 6,
  Jul: 7,
  Aug: 8,
  Sep: 9,
  Oct: 10,
  Nov: 11,
  Dec: 12,
};

function parseOnsMmmYy(label: string): { year: number; month: number; monthOrd: number } | null {
  const m = label.trim().match(/^([A-Za-z]{3})-(\d{2})$/);
  if (!m) return null;
  const mon = ONS_MONTH_INDEX[m[1].slice(0, 1).toUpperCase() + m[1].slice(1, 3).toLowerCase()];
  if (!mon) return null;
  const yy = Number(m[2]);
  const year = yy <= 49 ? 2000 + yy : 1900 + yy;
  return { year, month: mon, monthOrd: year * 12 + mon };
}

export async function ingestUkOnsApi(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);

  const metaUrl = 'https://api.beta.ons.gov.uk/v1/datasets/cpih01/editions/time-series/versions?limit=1';
  const metaRes = await fetchWithCitizenship({
    url: metaUrl,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: true,
    destPrefix: 'uk_ons_cpih01_meta',
    timeoutMs: 15_000,
  });

  let csvUrl: string | undefined;
  if (metaRes.filePath) {
    try {
      const json = JSON.parse(fs.readFileSync(metaRes.filePath, 'utf-8')) as {
        items?: Array<{ downloads?: { csv?: { href?: string } } }>;
      };
      csvUrl = json.items?.[0]?.downloads?.csv?.href;
    } finally {
      safeUnlink(metaRes.filePath);
    }
  }
  if (!csvUrl) {
    throw new Error('UK ONS API returned no downloadable CSV href for cpih01');
  }

  const downloadHost = new URL(csvUrl).host;
  const csvRes = await fetchWithCitizenship({
    url: csvUrl,
    host: downloadHost,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'uk_ons_cpih01_csv',
    timeoutMs: 30_000,
  });

  if (!csvRes.filePath) {
    return { rawRows: [], silver: [], etag: csvRes.etag, dedupHit: metaRes.dedupHit || csvRes.dedupHit, notModified: csvRes.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  try {
    const csvRows = await withDuckDBConnection(async (conn) => {
      const reader = await conn.runAndReadAll(`
        SELECT TRY_CAST(v4_0 AS DOUBLE) AS val, "mmm-yy" AS period_label
        FROM read_csv_auto(${sqlQuote(csvRes.filePath!)}, header=true)
        WHERE "cpih1dim1aggid" = 'CP00' AND v4_0 IS NOT NULL;
      `);
      try {
        return reader.getRowObjectsJson() as Array<{ val?: number | null; period_label?: string | null }>;
      } finally {
        reader.closeSync();
      }
    });

    const byMonthOrd = new Map<number, { year: number; label: string; val: number }>();
    for (const r of csvRows) {
      if (typeof r.val !== 'number' || !Number.isFinite(r.val) || !r.period_label) continue;
      const parsed = parseOnsMmmYy(String(r.period_label));
      if (!parsed || parsed.year < 2019 || parsed.year > 2026) continue;
      rawRows.push(r);
      byMonthOrd.set(parsed.monthOrd, { year: parsed.year, label: String(r.period_label), val: r.val });
    }

    const latestIdxByYear = new Map<number, { monthOrd: number; label: string; val: number }>();
    const latestYoyByYear = new Map<number, { monthOrd: number; label: string; val: number }>();

    for (const [ord, entry] of byMonthOrd.entries()) {
      if (entry.year >= 2021) {
        const prevIdx = latestIdxByYear.get(entry.year);
        if (!prevIdx || ord > prevIdx.monthOrd) {
          latestIdxByYear.set(entry.year, { monthOrd: ord, label: entry.label, val: entry.val });
        }
        const priorYearEntry = byMonthOrd.get(ord - 12);
        if (priorYearEntry && priorYearEntry.val > 0) {
          const yoy = ((entry.val / priorYearEntry.val) - 1) * 100;
          const prevYoy = latestYoyByYear.get(entry.year);
          if (!prevYoy || ord > prevYoy.monthOrd) {
            latestYoyByYear.set(entry.year, { monthOrd: ord, label: entry.label, val: yoy });
          }
        }
      }
    }

    for (const [year, entry] of latestIdxByYear.entries()) {
      silver.push({
        territory_id: 'T_GBR',
        iso3: 'GBR',
        indicator_id: 'UKONS.CPIH_INDEX',
        indicator_name: `UK CPIH Overall Index 2015=100 (${entry.label}, UK ONS v1)`,
        module_id: 2,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: year,
        value_numeric: Number(entry.val.toFixed(2)),
        unit: 'index (2015=100)',
        valuation_basis: 'index_score',
        methodology_id: 'UK_ONS_CPIH01_V1',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }

    for (const [year, entry] of latestYoyByYear.entries()) {
      silver.push({
        territory_id: 'T_GBR',
        iso3: 'GBR',
        indicator_id: 'UKONS.CPIH_PCT_YOY',
        indicator_name: `UK CPIH Inflation Rate YoY % (${entry.label}, UK ONS v1)`,
        module_id: 2,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: year,
        value_numeric: Number(entry.val.toFixed(2)),
        unit: '%',
        valuation_basis: 'percent',
        methodology_id: 'UK_ONS_CPIH01_V1',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  } finally {
    safeUnlink(csvRes.filePath);
  }

  return { rawRows, silver, etag: csvRes.etag, dedupHit: metaRes.dedupHit || csvRes.dedupHit };
}

export async function ingestIbgeSidra(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const url = 'https://apisidra.ibge.gov.br/values/t/1737/n1/all/v/2265/p/last%206/f/n';
  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: shouldBypassConditionalCache(source.source_id),
    destPrefix: 'ibge_sidra_1737',
    timeoutMs: 15_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  try {
    const rows = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as Array<{
      V?: string;
      D3C?: string;
      D3N?: string;
    }>;

    const latestByYear = new Map<number, { code: string; val: number }>();
    for (const r of Array.isArray(rows) ? rows.slice(1) : []) {
      rawRows.push(r);
      const val = Number(r.V);
      if (!Number.isFinite(val)) continue;
      const code = String(r.D3C ?? '');
      const yearMatch = code.slice(0, 4).match(/^(20\d{2})$/) ?? String(r.D3N ?? '').match(/\b(20\d{2})\b/);
      if (!yearMatch) continue;
      const year = Number(yearMatch[1]);
      if (!Number.isInteger(year)) continue;

      const prev = latestByYear.get(year);
      if (!prev || code > prev.code) {
        latestByYear.set(year, { code, val });
      }
    }

    for (const [year, entry] of latestByYear.entries()) {
      silver.push({
        territory_id: 'T_BRA',
        iso3: 'BRA',
        indicator_id: 'IBGE.IPCA_12M_PCT',
        indicator_name: 'Brazil Official IPCA 12-Month Inflation (IBGE SIDRA t/1737)',
        module_id: 2,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: year,
        value_numeric: Number(entry.val.toFixed(2)),
        unit: '%',
        valuation_basis: 'percent',
        methodology_id: 'IBGE_SIDRA_T1737_V2265',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export function ingestWidWorld(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  return ingestOwidDatasets(source, [
    {
      slug: 'income-share-held-by-richest-10',
      indicatorId: 'WID.TOP10_INCOME_SHARE_PCT',
      indicatorName: 'Income Share Held by Richest 10% (Pre-Tax, WID.world)',
      moduleId: 2,
      unit: '%',
      valuationBasis: 'percent',
      methodologyId: 'WID_WORLD_TOP10_SHARE_CSV',
      columnName: 'Share (richest decile)',
      minYear: 2018,
      decimals: 2,
      rawValueKey: 'top10_share_pct',
    },
  ]);
}

export function ingestPwtPennWorldTable(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  return ingestOwidDatasets(source, [
    {
      slug: 'gdp-per-capita-penn-world-table',
      indicatorId: 'PWT.REAL_GDP_PER_CAPITA',
      indicatorName: 'Expenditure-Side Real GDP per Capita, Chained PPP (Penn World Table)',
      moduleId: 2,
      unit: 'Intl$ (PWT 10.01)',
      valuationBasis: 'constant_2021_ppp',
      methodologyId: 'PENN_WORLD_TABLE_10_01_RGDP',
      columnName: 'GDP per capita',
      minYear: 2015,
      decimals: 0,
      rawValueKey: 'pwt_gdp_per_capita',
    },
  ]);
}

export async function ingestStatfinPxweb(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const url = 'https://pxdata.stat.fi/PxWeb/api/v1/en/StatFin/khi/11xc.px';
  const payload = JSON.stringify({
    query: [
      { code: 'coicop_38_20160101', selection: { filter: 'item', values: ['0'] } },
      { code: 'contentscode', selection: { filter: 'item', values: ['indeksipisteluku', 'khi-vuosimuutos'] } },
      { code: 'timeperiod_y', selection: { filter: 'item', values: ['2021', '2022', '2023', '2024', '2025'] } },
    ],
    response: { format: 'json-stat2' },
  });

  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    method: 'POST',
    body: payload,
    headers: { 'Content-Type': 'application/json' },
    bypassConditionalCache: bypassCache,
    destPrefix: 'statfin_pxweb_cpi',
    timeoutMs: 20_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const finTerritory = resolveTerritoryByCodeOrName('FIN');
  const territoryId = finTerritory?.territory_id ?? 'T_FIN';

  try {
    const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
      id?: string[];
      size?: number[];
      value?: Array<number | null>;
      dimension?: Record<
        string,
        {
          category?: {
            index?: Record<string, number>;
          };
        }
      >;
    };

    const dimIds = json.id ?? [];
    const sizes = json.size ?? [];
    const values = json.value ?? [];
    const yearPos = dimIds.indexOf('timeperiod_y');
    const metricPos = dimIds.indexOf('contentscode');

    if (yearPos >= 0 && metricPos >= 0 && values.length > 0 && sizes.length === dimIds.length) {
      const yearIndex = json.dimension?.timeperiod_y?.category?.index ?? {};
      const metricIndex = json.dimension?.contentscode?.category?.index ?? {};

      // Compute row-major strides
      const strides = new Array<number>(sizes.length).fill(1);
      for (let i = sizes.length - 2; i >= 0; i--) {
        strides[i] = strides[i + 1] * sizes[i + 1];
      }

      for (const [yearStr, yIdx] of Object.entries(yearIndex)) {
        const year = Number(yearStr);
        if (!Number.isInteger(year)) continue;

        for (const [metricCode, mIdx] of Object.entries(metricIndex)) {
          const flatIdx = yIdx * strides[yearPos] + mIdx * strides[metricPos];
          const val = values[flatIdx];
          if (typeof val !== 'number' || !Number.isFinite(val)) continue;

          rawRows.push({ iso3: 'FIN', year, metricCode, value: val });
          if (metricCode === 'khi-vuosimuutos') {
            silver.push({
              territory_id: territoryId,
              iso3: 'FIN',
              indicator_id: 'STATFIN.CPI_PCT_YOY',
              indicator_name: 'Finland Official CPI Inflation Annual Change % (StatFin PxWeb)',
              module_id: 2,
              source_id: source.source_id,
              dataset_id: source.dataset_id,
              period_year: year,
              value_numeric: Number(val.toFixed(2)),
              unit: '%',
              valuation_basis: 'percent',
              methodology_id: 'STATFIN_PXWEB_KHI_11XC',
              commercial_use_allowed: source.commercial_use_allowed,
              asserted_at: assertedAt,
            });
          } else if (metricCode === 'indeksipisteluku') {
            silver.push({
              territory_id: territoryId,
              iso3: 'FIN',
              indicator_id: 'STATFIN.CPI_INDEX',
              indicator_name: 'Finland Consumer Price Index (2015=100, StatFin PxWeb)',
              module_id: 2,
              source_id: source.source_id,
              dataset_id: source.dataset_id,
              period_year: year,
              value_numeric: Number(val.toFixed(2)),
              unit: 'index (2015=100)',
              valuation_basis: 'index_score',
              methodology_id: 'STATFIN_PXWEB_KHI_11XC',
              commercial_use_allowed: source.commercial_use_allowed,
              asserted_at: assertedAt,
            });
          }
        }
      }
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestUsCensusApi(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const censusKey = (process.env.US_CENSUS_API_KEY ?? '').trim();

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const dedupKeys = new Set<string>();
  let lastEtag: string | null = null;
  let dedupHit = false;

  const pushUnique = (rec: ObservationContract) => {
    const key = `${rec.territory_id}|${rec.indicator_id}|${rec.period_year}`;
    if (dedupKeys.has(key)) return;
    dedupKeys.add(key);
    silver.push(rec);
  };

  // 1. Official U.S. Census Bureau Population Estimates Program bulk CSV (always keyless)
  const popEstUrl =
    'https://www2.census.gov/programs-surveys/popest/datasets/2020-2023/state/totals/NST-EST2023-ALLDATA.csv';
  let csvRes = await fetchWithCitizenship({
    url: popEstUrl,
    host: 'www2.census.gov',
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'us_census_popest_2023',
    timeoutMs: 25_000,
  });
  dedupHit = dedupHit || csvRes.dedupHit;
  if (csvRes.etag) lastEtag = csvRes.etag;

  if (!csvRes.filePath && !censusKey) {
    return { rawRows: [], silver: [], etag: lastEtag, dedupHit, notModified: csvRes.status === 'NOT_MODIFIED' };
  }

  let acsResFilePath: string | null = null;
  if (censusKey) {
    try {
      const acsUrl = `https://api.census.gov/data/2023/acs/acs1?get=NAME,B01003_001E,B19013_001E&for=us:1&key=${encodeURIComponent(censusKey)}`;
      const acsRes = await fetchWithCitizenship({
        url: acsUrl,
        host: 'api.census.gov',
        rateLimitRpm: source.rate_limit_rpm,
        maxConcurrency: source.max_concurrency,
        bypassConditionalCache: bypassCache,
        destPrefix: 'us_census_acs1_2023',
        timeoutMs: 15_000,
      });
      acsResFilePath = acsRes.filePath;
      if (!csvRes.filePath && acsResFilePath) {
        csvRes = await fetchWithCitizenship({
          url: popEstUrl,
          host: 'www2.census.gov',
          rateLimitRpm: source.rate_limit_rpm,
          maxConcurrency: source.max_concurrency,
          bypassConditionalCache: true,
          destPrefix: 'us_census_popest_2023_full',
          timeoutMs: 25_000,
        });
      } else if (!csvRes.filePath && !acsResFilePath) {
        return { rawRows: [], silver: [], etag: lastEtag, dedupHit, notModified: csvRes.status === 'NOT_MODIFIED' && acsRes.status === 'NOT_MODIFIED' };
      }
    } catch {
      if (!csvRes.filePath) {
        return { rawRows: [], silver: [], etag: lastEtag, dedupHit };
      }
    }
  }

  if (csvRes.filePath) {
    try {
      const { usRows, stateCount } = await withDuckDBConnection(async (conn) => {
        const natReader = await conn.runAndReadAll(`
          SELECT
            SUMLEV,
            NAME,
            TRY_CAST(POPESTIMATE2020 AS DOUBLE) AS pop_2020,
            TRY_CAST(POPESTIMATE2021 AS DOUBLE) AS pop_2021,
            TRY_CAST(POPESTIMATE2022 AS DOUBLE) AS pop_2022,
            TRY_CAST(POPESTIMATE2023 AS DOUBLE) AS pop_2023
          FROM read_csv_auto(${sqlQuote(csvRes.filePath!)}, header=true, all_varchar=true)
          WHERE SUMLEV = '010'
          LIMIT 1;
        `);
        const stateReader = await conn.runAndReadAll(`
          SELECT COUNT(*)::INTEGER AS state_count
          FROM read_csv_auto(${sqlQuote(csvRes.filePath!)}, header=true, all_varchar=true)
          WHERE SUMLEV = '040';
        `);
        try {
          const us = natReader.getRowObjectsJson() as Array<Record<string, unknown>>;
          const st = stateReader.getRowObjectsJson() as Array<{ state_count?: number }>;
          return { usRows: us, stateCount: Number(st[0]?.state_count ?? 0) };
        } finally {
          natReader.closeSync();
          stateReader.closeSync();
        }
      });

      const usRow = usRows[0];
      if (usRow) {
        rawRows.push({ feed: 'NST-EST2023-ALLDATA', ...usRow, state_count: stateCount });
        const years: Array<[number, unknown]> = [
          [2020, usRow.pop_2020],
          [2021, usRow.pop_2021],
          [2022, usRow.pop_2022],
          [2023, usRow.pop_2023],
        ];
        for (const [year, valRaw] of years) {
          const val = Number(valRaw);
          if (!Number.isFinite(val) || val <= 0) continue;
          pushUnique({
            territory_id: 'T_USA',
            iso3: 'USA',
            indicator_id: 'USCENSUS.US_POP_ESTIMATE',
            indicator_name: 'U.S. Resident Population Official Vintage Estimate (U.S. Census Bureau)',
            module_id: 3,
            source_id: source.source_id,
            dataset_id: source.dataset_id,
            period_year: year,
            value_numeric: Math.round(val),
            unit: 'persons',
            valuation_basis: 'count',
            methodology_id: 'US_CENSUS_NST_EST2023',
            commercial_use_allowed: source.commercial_use_allowed,
            asserted_at: assertedAt,
          });
        }
      }

      if (Number.isFinite(stateCount) && stateCount > 0) {
        pushUnique({
          territory_id: 'T_USA',
          iso3: 'USA',
          indicator_id: 'USCENSUS.US_SUBNATIONAL_UNITS',
          indicator_name: 'U.S. States, DC & Puerto Rico Subnational Census Units (SUMLEV 040)',
          module_id: 3,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: 2023,
          value_numeric: stateCount,
          unit: 'jurisdictions',
          valuation_basis: 'count',
          methodology_id: 'US_CENSUS_NST_EST2023',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    } finally {
      safeUnlink(csvRes.filePath);
    }
  }

  // 2. Optional ACS 1-Year API enrichment when US_CENSUS_API_KEY is configured
  if (acsResFilePath) {
    try {
      const text = fs.readFileSync(acsResFilePath, 'utf-8');
      if (!text.trimStart().startsWith('<')) {
        const matrix = JSON.parse(text) as unknown[][];
        const row = Array.isArray(matrix) && Array.isArray(matrix[1]) ? matrix[1] : null;
        const medianIncome = row ? Number(row[2]) : NaN;
        if (Number.isFinite(medianIncome) && medianIncome > 0) {
          rawRows.push({ feed: 'ACS1_2023', median_household_income_usd: medianIncome });
          pushUnique({
            territory_id: 'T_USA',
            iso3: 'USA',
            indicator_id: 'USCENSUS.US_MEDIAN_HOUSEHOLD_INCOME_USD',
            indicator_name: 'U.S. Median Household Income (2023 ACS 1-Year, U.S. Census Bureau)',
            module_id: 2,
            source_id: source.source_id,
            dataset_id: source.dataset_id,
            period_year: 2023,
            value_numeric: Math.round(medianIncome),
            unit: 'USD',
            valuation_basis: 'nominal_usd',
            methodology_id: 'US_CENSUS_ACS1_B19013',
            commercial_use_allowed: source.commercial_use_allowed,
            asserted_at: assertedAt,
          });
        }
      }
    } finally {
      safeUnlink(acsResFilePath);
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

const MONTH_ORDER: Record<string, number> = {
  january: 1,
  february: 2,
  march: 3,
  april: 4,
  may: 5,
  june: 6,
  july: 7,
  august: 8,
  september: 9,
  october: 10,
  november: 11,
  december: 12,
};

export async function ingestIndiaOgdPlatform(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const ogdKey = (process.env.INDIA_OGD_API_KEY ?? '').trim();

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const dedupKeys = new Set<string>();
  let lastEtag: string | null = null;
  let dedupHit = false;

  const indTerritory = resolveTerritoryByCodeOrName('IND');
  const territoryId = indTerritory?.territory_id ?? 'T_IND';

  // 1. Official Government of India MoSPI REST API (keyless live Index of Industrial Production)
  const mospiUrl = 'https://api.mospi.gov.in/api/iip/getIipData?frequency=Monthly&limit=100';
  let mospiRes = await fetchWithCitizenship({
    url: mospiUrl,
    host: 'api.mospi.gov.in',
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'india_mospi_iip',
    timeoutMs: 20_000,
  });
  dedupHit = dedupHit || mospiRes.dedupHit;
  if (mospiRes.etag) lastEtag = mospiRes.etag;

  if (!mospiRes.filePath && !ogdKey) {
    return { rawRows: [], silver: [], etag: lastEtag, dedupHit, notModified: mospiRes.status === 'NOT_MODIFIED' };
  }

  let ogdResFilePath: string | null = null;
  let ogdResStatus: string | null = null;
  if (ogdKey) {
    try {
      const ogdUrl = `https://api.data.gov.in/resource/9ef84268-d588-465a-a308-a864a43d0070?api-key=${encodeURIComponent(ogdKey)}&format=json&limit=5`;
      const ogdRes = await fetchWithCitizenship({
        url: ogdUrl,
        host: 'api.data.gov.in',
        rateLimitRpm: source.rate_limit_rpm,
        maxConcurrency: 1,
        bypassConditionalCache: bypassCache,
        destPrefix: 'india_ogd_key_probe',
        timeoutMs: 12_000,
      });
      ogdResFilePath = ogdRes.filePath;
      ogdResStatus = ogdRes.status;
      if (!mospiRes.filePath && ogdResFilePath) {
        mospiRes = await fetchWithCitizenship({
          url: mospiUrl,
          host: 'api.mospi.gov.in',
          rateLimitRpm: source.rate_limit_rpm,
          maxConcurrency: source.max_concurrency,
          bypassConditionalCache: true,
          destPrefix: 'india_mospi_iip_full',
          timeoutMs: 20_000,
        });
      } else if (!mospiRes.filePath && !ogdResFilePath) {
        return { rawRows: [], silver: [], etag: lastEtag, dedupHit, notModified: mospiRes.status === 'NOT_MODIFIED' && ogdResStatus === 'NOT_MODIFIED' };
      }
    } catch {
      if (!mospiRes.filePath) {
        return { rawRows: [], silver: [], etag: lastEtag, dedupHit };
      }
    }
  }

  if (mospiRes.filePath) {
    try {
      const json = JSON.parse(fs.readFileSync(mospiRes.filePath, 'utf-8')) as {
        data?: Array<{
          base_year?: string;
          year?: number | string;
          month?: string;
          type?: string;
          category?: string;
          index?: number | string | null;
          growth_rate?: number | string | null;
        }>;
      };

      const latestByYear = new Map<
        number,
        { monthOrder: number; monthName: string; indexVal: number | null; growthVal: number | null }
      >();

      for (const row of json.data ?? []) {
        if (row.type !== 'General' && row.category !== 'General') continue;
        const year = Number(row.year);
        const monthName = String(row.month ?? '').trim();
        const mOrd = MONTH_ORDER[monthName.toLowerCase()] ?? 0;
        const idxNum = row.index !== null && row.index !== undefined ? Number(row.index) : NaN;
        const grNum = row.growth_rate !== null && row.growth_rate !== undefined ? Number(row.growth_rate) : NaN;
        if (!Number.isInteger(year) || year < 2015 || year > 2026) continue;

        rawRows.push(row);
        const prev = latestByYear.get(year);
        if (!prev || mOrd >= prev.monthOrder) {
          latestByYear.set(year, {
            monthOrder: mOrd,
            monthName,
            indexVal: Number.isFinite(idxNum) ? idxNum : null,
            growthVal: Number.isFinite(grNum) ? grNum : null,
          });
        }
      }

      for (const [year, entry] of latestByYear.entries()) {
        if (entry.indexVal !== null) {
          const k = `${territoryId}|INDIA.IIP_INDEX|${year}`;
          if (!dedupKeys.has(k)) {
            dedupKeys.add(k);
            silver.push({
              territory_id: territoryId,
              iso3: 'IND',
              indicator_id: 'INDIA.IIP_INDEX',
              indicator_name: `India Index of Industrial Production General (${entry.monthName || 'Latest'}, Base 2022-23=100, MoSPI)`,
              module_id: 2,
              source_id: source.source_id,
              dataset_id: source.dataset_id,
              period_year: year,
              value_numeric: Number(entry.indexVal.toFixed(2)),
              unit: 'index (2022-23=100)',
              valuation_basis: 'index_score',
              methodology_id: 'INDIA_MOSPI_IIP_MONTHLY',
              commercial_use_allowed: source.commercial_use_allowed,
              asserted_at: assertedAt,
            });
          }
        }
        if (entry.growthVal !== null) {
          const k = `${territoryId}|INDIA.IIP_GROWTH_PCT|${year}`;
          if (!dedupKeys.has(k)) {
            dedupKeys.add(k);
            silver.push({
              territory_id: territoryId,
              iso3: 'IND',
              indicator_id: 'INDIA.IIP_GROWTH_PCT',
              indicator_name: `India Industrial Production YoY Growth Rate % (${entry.monthName || 'Latest'}, MoSPI)`,
              module_id: 2,
              source_id: source.source_id,
              dataset_id: source.dataset_id,
              period_year: year,
              value_numeric: Number(entry.growthVal.toFixed(2)),
              unit: '%',
              valuation_basis: 'percent',
              methodology_id: 'INDIA_MOSPI_IIP_MONTHLY',
              commercial_use_allowed: source.commercial_use_allowed,
              asserted_at: assertedAt,
            });
          }
        }
      }
    } finally {
      safeUnlink(mospiRes.filePath);
    }
  }

  // 2. Optional data.gov.in resource verification when INDIA_OGD_API_KEY is configured
  if (ogdResFilePath) {
    try {
      const parsed = JSON.parse(fs.readFileSync(ogdResFilePath, 'utf-8')) as { total?: number };
      if (typeof parsed.total === 'number' && Number.isFinite(parsed.total) && parsed.total > 0) {
        rawRows.push({ feed: 'api.data.gov.in', total: parsed.total });
        silver.push({
          territory_id: territoryId,
          iso3: 'IND',
          indicator_id: 'INDIA.OGD_RESOURCE_RECORDS',
          indicator_name: 'India OGD data.gov.in Live Resource Record Count',
          module_id: 12,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: new Date().getUTCFullYear(),
          value_numeric: Math.round(parsed.total),
          unit: 'records',
          valuation_basis: 'count',
          methodology_id: 'INDIA_OGD_DATA_GOV_IN_V1',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    } finally {
      safeUnlink(ogdResFilePath);
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

