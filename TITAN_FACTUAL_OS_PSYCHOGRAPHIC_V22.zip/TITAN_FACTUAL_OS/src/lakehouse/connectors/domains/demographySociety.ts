import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { listTerritories, resolveTerritoryByCodeOrName } from '../../controlPlane.ts';
import { sqlQuote, withDuckDBConnection } from '../../duckdbEngine.ts';
import { fetchConsistentBatch, fetchWithCitizenship, type FetchOptions } from '../../httpCitizenship.ts';
import type { ObservationContract, SourceCatalogEntry } from '../../types.ts';
import { ingestOwidDatasets } from '../factories/owidCsvConnector.ts';
import {
  safeUnlink,
  shouldBypassConditionalCache,
  TMP_DIR,
  type ConnectorOutcome,
} from '../shared.ts';

export async function ingestOwidGrapher(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  return ingestOwidDatasets(source, [
    {
      slug: 'economic-inequality-gini-index',
      indicatorId: 'OWID.GINI',
      indicatorName: 'Gini Coefficient (OWID / World Bank PIP)',
      moduleId: 2,
      unit: 'Gini (0-100)',
      valuationBasis: 'index_score',
      methodologyId: 'OWID_GRAPHER_ECONOMIC-INEQUALITY-GINI-INDEX',
      minYear: 2010,
      transformValue: (v) => (v <= 1 ? Number((v * 100).toFixed(2)) : v),
    },
    {
      slug: 'median-age',
      indicatorId: 'OWID.MEDIAN_AGE',
      indicatorName: 'Median Age (UN WPP via OWID)',
      moduleId: 3,
      unit: 'years',
      valuationBasis: 'count',
      methodologyId: 'OWID_GRAPHER_MEDIAN-AGE',
      minYear: 2010,
    },
    {
      slug: 'share-of-population-urban',
      indicatorId: 'OWID.URBAN_PCT',
      indicatorName: 'Urban Population (% of total, OWID / UN WUP)',
      moduleId: 3,
      unit: '%',
      valuationBasis: 'percent',
      methodologyId: 'OWID_GRAPHER_SHARE-OF-POPULATION-URBAN',
      minYear: 2010,
    },
    {
      slug: 'share-of-individuals-using-the-internet',
      indicatorId: 'OWID.INTERNET_PCT',
      indicatorName: 'Individuals Using the Internet (% of pop, OWID / ITU)',
      moduleId: 3,
      unit: '%',
      valuationBasis: 'percent',
      methodologyId: 'OWID_GRAPHER_SHARE-OF-INDIVIDUALS-USING-THE-INTERNET',
      minYear: 2010,
    },
  ]);
}

export async function ingestWhoGhoOdata(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);

  // Use simple OData projection without server-side $filter which frequently triggers 502 on ghoapi.azureedge.net
  const primaryUrl =
    'https://ghoapi.azureedge.net/api/WHOSIS_000001?$top=1000&$select=SpatialDim,TimeDim,NumericValue,Dim1';

  try {
    const res = await fetchWithCitizenship({
      url: primaryUrl,
      host: source.host,
      rateLimitRpm: source.rate_limit_rpm,
      maxConcurrency: source.max_concurrency,
      bypassConditionalCache: bypassCache,
      destPrefix: 'who_gho_whosis01',
      timeoutMs: 18_000,
    });

    if (res.status === 'NOT_MODIFIED' && !bypassCache) {
      return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
    }

    if (res.filePath) {
      const rawRows: unknown[] = [];
      const silver: ObservationContract[] = [];
      const dedupKeys = new Set<string>();
      try {
        const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
          value?: Array<{
            SpatialDim?: string;
            TimeDim?: number;
            NumericValue?: number | null;
            Dim1?: string;
          }>;
        };
        const items = Array.isArray(json.value) ? json.value : [];
        for (const item of items) {
          if (item.Dim1 && item.Dim1 !== 'SEX_BTSX' && item.Dim1 !== 'BTSX') continue;
          if (
            !item.SpatialDim ||
            typeof item.TimeDim !== 'number' ||
            item.TimeDim < 2018 ||
            typeof item.NumericValue !== 'number' ||
            !Number.isFinite(item.NumericValue)
          ) {
            continue;
          }
          const territory = resolveTerritoryByCodeOrName(item.SpatialDim);
          if (!territory) continue;
          const k = `${territory.territory_id}|${item.TimeDim}`;
          if (dedupKeys.has(k)) continue;
          dedupKeys.add(k);

          rawRows.push(item);
          silver.push({
            territory_id: territory.territory_id,
            iso3: territory.iso3,
            indicator_id: 'WHO.LIFE_EXPECTANCY',
            indicator_name: 'Life Expectancy at Birth, Both Sexes (WHO GHO)',
            module_id: 9,
            source_id: source.source_id,
            dataset_id: source.dataset_id,
            period_year: item.TimeDim,
            value_numeric: Number(item.NumericValue.toFixed(2)),
            unit: 'years',
            valuation_basis: 'count',
            methodology_id: 'WHO_GHO_ODATA_V2',
            commercial_use_allowed: source.commercial_use_allowed,
            asserted_at: assertedAt,
          });
        }
      } finally {
        safeUnlink(res.filePath);
      }

      if (silver.length > 0) {
        return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
      }
    }
  } catch {
    // Primary WHO GHO OData endpoint unreachable or 502; execute OWID fallback below
  }

  return ingestOwidDatasets(
    { ...source, host: 'ourworldindata.org' },
    [
      {
        slug: 'life-expectancy',
        indicatorId: 'WHO.LIFE_EXPECTANCY',
        indicatorName: 'Life Expectancy at Birth, Both Sexes (WHO / OWID UN WPP)',
        moduleId: 9,
        unit: 'years',
        valuationBasis: 'count',
        methodologyId: 'WHO_LIFE_EXPECTANCY_OWID_FALLBACK',
        columnName: 'Period life expectancy at birth',
        minYear: 2018,
        decimals: 2,
      },
    ]
  );
}

export async function ingestWorldBankPIP(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const url = 'https://api.worldbank.org/pip/v1/pip?country=all&year=2022&format=json';
  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'wb_pip_2022',
    timeoutMs: 20_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const seen = new Set<string>();

  try {
    const items = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as Array<{
      country_code?: string;
      country_name?: string;
      reporting_year?: number;
      reporting_level?: string;
      headcount?: number | null;
      gini?: number | null;
      mean?: number | null;
      median?: number | null;
    }>;

    const sorted = [...(Array.isArray(items) ? items : [])].sort((a, b) => {
      const aNat = a.reporting_level === 'national' ? 0 : 1;
      const bNat = b.reporting_level === 'national' ? 0 : 1;
      return aNat - bNat;
    });

    for (const item of sorted) {
      if (!item.country_code) continue;
      const territory =
        resolveTerritoryByCodeOrName(item.country_code) ??
        (item.country_name ? resolveTerritoryByCodeOrName(item.country_name) : undefined);
      if (!territory) continue;

      const year = Number(item.reporting_year) || 2022;
      if (seen.has(territory.territory_id)) continue;
      seen.add(territory.territory_id);
      rawRows.push(item);

      if (typeof item.mean === 'number' && Number.isFinite(item.mean)) {
        silver.push({
          territory_id: territory.territory_id,
          iso3: territory.iso3,
          indicator_id: 'PIP.MEAN_DAILY_PPP',
          indicator_name: 'Household Mean Daily Consumption/Income (2021 PPP)',
          module_id: 2,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: year,
          value_numeric: Number(item.mean.toFixed(2)),
          unit: '2021 PPP $/day',
          valuation_basis: 'constant_2021_ppp',
          methodology_id: 'WB_PIP_V1_2021PPP',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }

      if (typeof item.median === 'number' && Number.isFinite(item.median)) {
        silver.push({
          territory_id: territory.territory_id,
          iso3: territory.iso3,
          indicator_id: 'PIP.MEDIAN_DAILY_PPP',
          indicator_name: 'Household Median Daily Consumption/Income (2021 PPP)',
          module_id: 2,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: year,
          value_numeric: Number(item.median.toFixed(2)),
          unit: '2021 PPP $/day',
          valuation_basis: 'constant_2021_ppp',
          methodology_id: 'WB_PIP_V1_2021PPP',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }

      if (typeof item.headcount === 'number' && Number.isFinite(item.headcount)) {
        silver.push({
          territory_id: territory.territory_id,
          iso3: territory.iso3,
          indicator_id: 'PIP.POVERTY_HEADCOUNT',
          indicator_name: 'Poverty Headcount Ratio ($2.15/2021 PPP)',
          module_id: 2,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: year,
          value_numeric: Number((item.headcount * 100).toFixed(2)),
          unit: '%',
          valuation_basis: 'percent',
          methodology_id: 'WB_PIP_V1_2021PPP',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestUnhcrPopulation(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const url = 'https://api.unhcr.org/population/v1/population/?limit=200&year=2023&coo_all=true';
  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'unhcr_pop_2023',
    timeoutMs: 15_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  try {
    const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
      items?: Array<{
        year?: number;
        coo_iso?: string;
        coo_name?: string;
        refugees?: number | string | null;
      }>;
    };

    const totals = new Map<string, { iso3: string; year: number; count: number }>();
    for (const item of json.items ?? []) {
      rawRows.push(item);
      if (!item.coo_iso) continue;
      const territory =
        resolveTerritoryByCodeOrName(item.coo_iso) ??
        (item.coo_name ? resolveTerritoryByCodeOrName(item.coo_name) : undefined);
      if (!territory) continue;
      const count = Number(item.refugees ?? 0);
      if (!Number.isFinite(count) || count <= 0) continue;

      const year = Number(item.year) || 2023;
      const prev = totals.get(territory.territory_id);
      if (prev) {
        prev.count += count;
      } else {
        totals.set(territory.territory_id, { iso3: territory.iso3, year, count });
      }
    }

    for (const [territoryId, entry] of totals.entries()) {
      silver.push({
        territory_id: territoryId,
        iso3: entry.iso3,
        indicator_id: 'UNHCR.REFUGEES',
        indicator_name: 'Refugees by Country of Origin (UNHCR v1)',
        module_id: 3,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: entry.year,
        value_numeric: Math.round(entry.count),
        unit: 'persons',
        valuation_basis: 'count',
        methodology_id: 'UNHCR_POP_V1',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestUnicefSdmx(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const flows = [
    {
      flowId: 'CME_MRY0T4',
      url: 'https://sdmx.data.unicef.org/ws/public/sdmxapi/rest/data/UNICEF,CME,1.0/.CME_MRY0T4._T._T?startPeriod=2019&endPeriod=2024',
      indicatorId: 'UNICEF.UNDER5_MORTALITY_PER_1000',
      indicatorName: 'Under-5 Mortality Rate (Deaths per 1,000 Live Births, UNICEF CME)',
    },
    {
      flowId: 'CME_MRY0',
      url: 'https://sdmx.data.unicef.org/ws/public/sdmxapi/rest/data/UNICEF,CME,1.0/.CME_MRY0._T._T?startPeriod=2019&endPeriod=2024',
      indicatorId: 'UNICEF.INFANT_MORTALITY_PER_1000',
      indicatorName: 'Infant Mortality Rate (<1 yr per 1,000 Live Births, UNICEF CME)',
    },
  ];

  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  let lastEtag: string | null = null;
  let dedupHit = false;
  const headers = {
    Accept: 'application/vnd.sdmx.data+csv;version=1.0.0',
    'Accept-Language': 'en',
  };

  const fetched: Array<{ flow: (typeof flows)[number]; filePath: string | null; status: string }> = [];
  for (const flow of flows) {
    const res = await fetchWithCitizenship({
      url: flow.url,
      host: source.host,
      rateLimitRpm: source.rate_limit_rpm,
      maxConcurrency: source.max_concurrency,
      bypassConditionalCache: bypassCache,
      headers,
      destPrefix: `unicef_${flow.flowId}`,
      timeoutMs: 20_000,
    });
    dedupHit = dedupHit || res.dedupHit;
    if (res.etag) lastEtag = res.etag;
    fetched.push({ flow, filePath: res.filePath, status: res.status });
  }

  const anyChanged = fetched.some((f) => f.status === 'OK');
  if (!anyChanged && !bypassCache) {
    return { rawRows: [], silver: [], etag: lastEtag, dedupHit, notModified: fetched.length > 0 && fetched.every((item) => item.status === 'NOT_MODIFIED') };
  }

  for (const item of fetched) {
    if (!item.filePath && item.status === 'NOT_MODIFIED') {
      const fullRes = await fetchWithCitizenship({
        url: item.flow.url,
        host: source.host,
        rateLimitRpm: source.rate_limit_rpm,
        maxConcurrency: source.max_concurrency,
        bypassConditionalCache: true,
        headers,
        destPrefix: `unicef_${item.flow.flowId}_full`,
        timeoutMs: 20_000,
      });
      item.filePath = fullRes.filePath;
    }
  }

  const dedupKeys = new Set<string>();
  for (const { flow, filePath } of fetched) {
    if (!filePath) continue;
    try {
      const csvRows = await withDuckDBConnection(async (conn) => {
        const reader = await conn.runAndReadAll(`
          SELECT REF_AREA, TIME_PERIOD, OBS_VALUE
          FROM read_csv_auto(${sqlQuote(filePath)}, header=true, all_varchar=true)
          WHERE REF_AREA IS NOT NULL AND OBS_VALUE IS NOT NULL;
        `);
        try {
          return reader.getRowObjectsJson() as Array<Record<string, unknown>>;
        } finally {
          reader.closeSync();
        }
      });

      for (const r of csvRows) {
        const iso3Raw = String(r.REF_AREA ?? '').trim();
        const year = Number(String(r.TIME_PERIOD ?? '').trim());
        const val = Number(String(r.OBS_VALUE ?? '').trim());
        if (!iso3Raw || !Number.isInteger(year) || !Number.isFinite(val)) continue;

        const territory = resolveTerritoryByCodeOrName(iso3Raw);
        if (!territory) continue;

        const key = `${territory.territory_id}|${flow.indicatorId}|${year}`;
        if (dedupKeys.has(key)) continue;
        dedupKeys.add(key);

        rawRows.push({ flow: flow.flowId, ...r });
        silver.push({
          territory_id: territory.territory_id,
          iso3: territory.iso3,
          indicator_id: flow.indicatorId,
          indicator_name: flow.indicatorName,
          module_id: 3,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: year,
          value_numeric: Number(val.toFixed(2)),
          unit: 'per 1,000 births',
          valuation_basis: 'count',
          methodology_id: 'UNICEF_CME_UN_IGME_SDMX',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    } finally {
      safeUnlink(filePath);
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestUnSdgApi(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const areaParams = listTerritories()
    .map((t) => `areaCode=${Number(t.un_m49)}`)
    .join('&');
  const m49Lookup = new Map(listTerritories().map((t) => [String(Number(t.un_m49)), t]));

  const seriesTargets = [
    {
      sdgIndicator: '7.2.1',
      targetSeries: 'EG_FEC_RNEW',
      timeStart: 2019,
      indicatorId: 'UNSDG.RENEWABLE_ENERGY_SHARE_PCT',
      indicatorName: 'Renewable Energy Share in Total Final Energy Consumption % (SDG 7.2.1)',
      moduleId: 5,
    },
    {
      sdgIndicator: '15.1.1',
      targetSeries: 'AG_LND_FRST',
      timeStart: 2015,
      indicatorId: 'UNSDG.FOREST_AREA_PCT',
      indicatorName: 'Forest Area as Proportion of Total Land Area % (SDG 15.1.1)',
      moduleId: 4,
    },
  ];

  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  let lastEtag: string | null = null;
  let dedupHit = false;
  const dedupKeys = new Set<string>();

  const specs: FetchOptions[] = seriesTargets.map((target) => ({
    url: `https://unstats.un.org/sdgapi/v1/sdg/Series/Data?seriesCode=${target.targetSeries}&${areaParams}&timePeriodStart=${target.timeStart}&pageSize=1000`,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    destPrefix: `unsdg_${target.targetSeries}`,
    timeoutMs: 20_000,
  }));

  const batch = await fetchConsistentBatch(specs, { bypassCache });
  if (batch.allNotModified) {
    return { rawRows: [], silver: [], etag: null, dedupHit: false, notModified: true };
  }

  for (let i = 0; i < seriesTargets.length; i++) {
    const target = seriesTargets[i];
    const res = batch.results[i];
    if (!res) continue;
    dedupHit = dedupHit || res.dedupHit;
    if (res.etag) lastEtag = res.etag;
    if (!res.filePath) continue;

    try {
      const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
        data?: Array<{
          series?: string;
          geoAreaCode?: string;
          timePeriodStart?: number;
          value?: string | number | null;
        }>;
      };

      for (const r of json.data ?? []) {
        if (r.series !== target.targetSeries) continue;
        const m49 = String(Number(r.geoAreaCode ?? ''));
        const territory = m49Lookup.get(m49);
        const year = Number(r.timePeriodStart);
        const val = Number(r.value);
        if (!territory || !Number.isInteger(year) || !Number.isFinite(val)) continue;

        const key = `${territory.territory_id}|${target.indicatorId}|${year}`;
        if (dedupKeys.has(key)) continue;
        dedupKeys.add(key);

        rawRows.push(r);
        silver.push({
          territory_id: territory.territory_id,
          iso3: territory.iso3,
          indicator_id: target.indicatorId,
          indicator_name: target.indicatorName,
          module_id: target.moduleId,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: year,
          value_numeric: Number(val.toFixed(2)),
          unit: '%',
          valuation_basis: 'percent',
          methodology_id: `UNSD_SDG_${target.targetSeries}`,
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    } finally {
      safeUnlink(res.filePath);
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

export async function ingestUnWppBulk(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const url =
    'https://population.un.org/wpp/assets/Excel%20Files/1_Indicator%20(Standard)/CSV_FILES/WPP2024_Demographic_Indicators_Medium.csv.gz';

  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'un_wpp2024_medium',
    timeoutMs: 45_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const dedupKeys = new Set<string>();

  try {
    const csvRows = await withDuckDBConnection(async (conn) => {
      const reader = await conn.runAndReadAll(`
        SELECT
          ISO3_code,
          CAST(Time AS INTEGER) AS year,
          TRY_CAST(TFR AS DOUBLE) AS tfr,
          TRY_CAST(PopDensity AS DOUBLE) AS pop_density,
          TRY_CAST(MedianAgePop AS DOUBLE) AS median_age,
          TRY_CAST(PopGrowthRate AS DOUBLE) AS pop_growth_rate,
          TRY_CAST(NetMigrations AS DOUBLE) AS net_migrations_k
        FROM read_csv_auto(${sqlQuote(res.filePath!)}, header=true, compression='gzip')
        WHERE ISO3_code IS NOT NULL
          AND Variant = 'Medium'
          AND CAST(Time AS INTEGER) BETWEEN 2021 AND 2026;
      `);
      try {
        return reader.getRowObjectsJson() as Array<Record<string, unknown>>;
      } finally {
        reader.closeSync();
      }
    });

    const pushMetric = (
      territoryId: string,
      iso3: string,
      indicatorId: string,
      indicatorName: string,
      year: number,
      val: number,
      unit: string,
      basis: ObservationContract['valuation_basis']
    ) => {
      const k = `${territoryId}|${indicatorId}|${year}`;
      if (dedupKeys.has(k)) return;
      dedupKeys.add(k);
      silver.push({
        territory_id: territoryId,
        iso3,
        indicator_id: indicatorId,
        indicator_name: indicatorName,
        module_id: 3,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: year,
        value_numeric: val,
        unit,
        valuation_basis: basis,
        methodology_id: 'UN_WPP_2024_MEDIUM_VARIANT',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    };

    for (const r of csvRows) {
      const iso3Raw = String(r.ISO3_code ?? '').trim();
      const year = Number(r.year);
      if (!iso3Raw || !Number.isInteger(year)) continue;
      const territory = resolveTerritoryByCodeOrName(iso3Raw);
      if (!territory) continue;

      rawRows.push(r);

      if (typeof r.tfr === 'number' && Number.isFinite(r.tfr)) {
        pushMetric(
          territory.territory_id,
          territory.iso3,
          'UNWPP.TOTAL_FERTILITY_RATE',
          'Total Fertility Rate, Live Births per Woman (UN WPP 2024)',
          year,
          Number(r.tfr.toFixed(3)),
          'births/woman',
          'count'
        );
      }
      if (typeof r.net_migrations_k === 'number' && Number.isFinite(r.net_migrations_k)) {
        pushMetric(
          territory.territory_id,
          territory.iso3,
          'UNWPP.NET_MIGRATION',
          'Net Annual Migrants, Persons (UN WPP 2024 Medium Variant)',
          year,
          Math.round(r.net_migrations_k * 1000),
          'persons',
          'count'
        );
      }
      if (typeof r.pop_density === 'number' && Number.isFinite(r.pop_density)) {
        pushMetric(
          territory.territory_id,
          territory.iso3,
          'UNWPP.POP_DENSITY_KM2',
          'Population Density per km² (UN WPP 2024)',
          year,
          Number(r.pop_density.toFixed(2)),
          'persons/km2',
          'count'
        );
      }
      if (typeof r.median_age === 'number' && Number.isFinite(r.median_age)) {
        pushMetric(
          territory.territory_id,
          territory.iso3,
          'UNWPP.MEDIAN_AGE',
          'Median Age of Total Population (Years, UN WPP 2024)',
          year,
          Number(r.median_age.toFixed(1)),
          'years',
          'count'
        );
      }
      if (typeof r.pop_growth_rate === 'number' && Number.isFinite(r.pop_growth_rate)) {
        pushMetric(
          territory.territory_id,
          territory.iso3,
          'UNWPP.POP_GROWTH_RATE_PCT',
          'Population Natural/Total Growth Rate % (UN WPP 2024)',
          year,
          Number(r.pop_growth_rate.toFixed(3)),
          '%',
          'percent'
        );
      }
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestWorldpopCatalog(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const url = 'https://www.worldpop.org/rest/data/pop/wpgp';

  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'worldpop_wpgp_catalog',
    timeoutMs: 20_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];

  try {
    const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
      data?: Array<{ id?: string; popyear?: string | number; iso3?: string }>;
    };

    const byTerritory = new Map<string, { iso3: string; count: number; latestYear: number }>();
    for (const item of json.data ?? []) {
      const iso3 = item.iso3?.trim();
      if (!iso3) continue;
      const territory = resolveTerritoryByCodeOrName(iso3);
      if (!territory) continue;

      const py = Number(item.popyear);
      const validPy = Number.isInteger(py) && py >= 2000 && py <= 2030 ? py : 0;
      rawRows.push({ id: item.id, iso3: territory.iso3, popyear: item.popyear });

      const prev = byTerritory.get(territory.territory_id);
      if (prev) {
        prev.count += 1;
        if (validPy > prev.latestYear) prev.latestYear = validPy;
      } else {
        byTerritory.set(territory.territory_id, { iso3: territory.iso3, count: 1, latestYear: validPy });
      }
    }

    for (const [territoryId, agg] of byTerritory.entries()) {
      silver.push({
        territory_id: territoryId,
        iso3: agg.iso3,
        indicator_id: 'WORLDPOP.DATASET_COUNT',
        indicator_name: '100m/1km Gridded Population Raster Datasets (WorldPop WPGP)',
        module_id: 3,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: currentYear,
        value_numeric: agg.count,
        unit: 'datasets',
        valuation_basis: 'count',
        methodology_id: 'WORLDPOP_REST_WPGP_V1',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });

      if (agg.latestYear > 0) {
        silver.push({
          territory_id: territoryId,
          iso3: agg.iso3,
          indicator_id: 'WORLDPOP.LATEST_GRID_YEAR',
          indicator_name: 'Latest Available Population Grid Year (WorldPop WPGP)',
          module_id: 3,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: currentYear,
          value_numeric: agg.latestYear,
          unit: 'year',
          valuation_basis: 'count',
          methodology_id: 'WORLDPOP_REST_WPGP_V1',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestWorldpopAge(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const url = 'https://www.worldpop.org/rest/data/age_structures/ascicua_2020';

  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'worldpop_age_2020',
    timeoutMs: 25_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];

  try {
    const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
      data?: Array<{ id?: string; title?: string; popyear?: string | number; iso3?: string }>;
    };

    const byTerritory = new Map<string, { iso3: string; count: number }>();
    for (const item of json.data ?? []) {
      const iso3 = item.iso3?.trim();
      if (!iso3) continue;
      const territory = resolveTerritoryByCodeOrName(iso3);
      if (!territory) continue;

      rawRows.push({ id: item.id, iso3: territory.iso3, popyear: item.popyear });
      const prev = byTerritory.get(territory.territory_id);
      if (prev) {
        prev.count += 1;
      } else {
        byTerritory.set(territory.territory_id, { iso3: territory.iso3, count: 1 });
      }
    }

    for (const [territoryId, agg] of byTerritory.entries()) {
      silver.push({
        territory_id: territoryId,
        iso3: agg.iso3,
        indicator_id: 'WORLDPOP_AGE.DATASETS_2020',
        indicator_name: '100m Age/Sex Cohort Structure Raster Datasets (WorldPop 2020)',
        module_id: 3,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: 2020,
        value_numeric: agg.count,
        unit: 'datasets',
        valuation_basis: 'count',
        methodology_id: 'WORLDPOP_AGE_ASCICUA_2020',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestWorldpopDensity(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const url = 'https://www.worldpop.org/rest/data/pop_density/pd_ic_1km';

  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'worldpop_density_1km',
    timeoutMs: 25_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];

  try {
    const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
      data?: Array<{ id?: string; popyear?: string | number; iso3?: string }>;
    };

    const byTerritory = new Map<string, { iso3: string; count: number; latestYear: number }>();
    for (const item of json.data ?? []) {
      const iso3 = item.iso3?.trim();
      if (!iso3) continue;
      const territory = resolveTerritoryByCodeOrName(iso3);
      if (!territory) continue;

      const py = Number(item.popyear);
      const validPy = Number.isInteger(py) && py >= 2000 && py <= 2030 ? py : 0;
      rawRows.push({ id: item.id, iso3: territory.iso3, popyear: item.popyear });

      const prev = byTerritory.get(territory.territory_id);
      if (prev) {
        prev.count += 1;
        if (validPy > prev.latestYear) prev.latestYear = validPy;
      } else {
        byTerritory.set(territory.territory_id, { iso3: territory.iso3, count: 1, latestYear: validPy });
      }
    }

    for (const [territoryId, agg] of byTerritory.entries()) {
      silver.push({
        territory_id: territoryId,
        iso3: agg.iso3,
        indicator_id: 'WORLDPOP_DENS.DATASETS_1KM',
        indicator_name: '1km Gridded Population Density Raster Series (WorldPop pd_ic_1km)',
        module_id: 3,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: currentYear,
        value_numeric: agg.count,
        unit: 'datasets',
        valuation_basis: 'count',
        methodology_id: 'WORLDPOP_POP_DENSITY_1KM',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });

      if (agg.latestYear > 0) {
        silver.push({
          territory_id: territoryId,
          iso3: agg.iso3,
          indicator_id: 'WORLDPOP_DENS.LATEST_YEAR',
          indicator_name: 'Latest 1km Population Density Raster Year (WorldPop)',
          module_id: 3,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: currentYear,
          value_numeric: agg.latestYear,
          unit: 'year',
          valuation_basis: 'count',
          methodology_id: 'WORLDPOP_POP_DENSITY_1KM',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestFaostatBulk(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const url = 'https://bulks-faostat.fao.org/production/Food_Security_Data_E_All_Data_(Normalized).zip';

  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'faostat_food_security_zip',
    timeoutMs: 35_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const m49Lookup = new Map(listTerritories().map((t) => [String(Number(t.un_m49)), t]));
  const targetItems: Record<
    string,
    {
      indicatorId: string;
      indicatorName: string;
      unit: string;
      basis: ObservationContract['valuation_basis'];
    }
  > = {
    '220001': {
      indicatorId: 'FAOSTAT.DIETARY_ENERGY_KCAL',
      indicatorName: 'Dietary Energy Supply (kcal/capita/day, FAOSTAT Food Security)',
      unit: 'kcal/cap/day',
      basis: 'count',
    },
    '21013': {
      indicatorId: 'FAOSTAT.PROTEIN_SUPPLY_G_DAY',
      indicatorName: 'Average Protein Supply (g/capita/day, FAOSTAT Food Security)',
      unit: 'g/cap/day',
      basis: 'count',
    },
    '210401': {
      indicatorId: 'FAOSTAT.SEVERE_FOOD_INSEC_PCT',
      indicatorName: 'Prevalence of Severe Food Insecurity in Total Pop % (FAOSTAT)',
      unit: '%',
      basis: 'percent',
    },
  };

  const extractDir = path.join(
    TMP_DIR,
    `faostat_extract_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`
  );
  const csvName = 'Food_Security_Data_E_All_Data_(Normalized).csv';
  const extractedCsvPath = path.join(extractDir, csvName);

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const dedupKeys = new Set<string>();

  try {
    fs.mkdirSync(extractDir, { recursive: true });
    execFileSync('unzip', ['-o', '-q', res.filePath, csvName, '-d', extractDir]);

    const csvRows = await withDuckDBConnection(async (conn) => {
      const reader = await conn.runAndReadAll(`
        SELECT
          "Area Code (M49)" AS m49,
          "Item Code" AS item_code,
          CAST(Year AS VARCHAR) AS year_str,
          TRY_CAST(Value AS DOUBLE) AS val
        FROM read_csv_auto(${sqlQuote(extractedCsvPath)}, header=true, all_varchar=true)
        WHERE "Item Code" IN ('220001', '21013', '210401')
          AND Value IS NOT NULL;
      `);
      try {
        return reader.getRowObjectsJson() as Array<{
          m49?: string | null;
          item_code?: string | null;
          year_str?: string | null;
          val?: number | null;
        }>;
      } finally {
        reader.closeSync();
      }
    });

    for (const r of csvRows) {
      const digits = String(r.m49 ?? '').replace(/[^0-9]/g, '');
      if (!digits) continue;
      const territory = m49Lookup.get(String(Number(digits)));
      if (!territory) continue;

      const meta = targetItems[String(r.item_code ?? '').trim()];
      if (!meta) continue;

      const year = Number(String(r.year_str ?? '').trim().slice(-4));
      const val = typeof r.val === 'number' && Number.isFinite(r.val) ? r.val : null;
      if (!Number.isInteger(year) || year < 2018 || year > 2026 || val === null) continue;

      const key = `${territory.territory_id}|${meta.indicatorId}|${year}`;
      if (dedupKeys.has(key)) continue;
      dedupKeys.add(key);

      rawRows.push({
        iso3: territory.iso3,
        item_code: r.item_code,
        year_str: r.year_str,
        value: val,
      });
      silver.push({
        territory_id: territory.territory_id,
        iso3: territory.iso3,
        indicator_id: meta.indicatorId,
        indicator_name: meta.indicatorName,
        module_id: 8,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: year,
        value_numeric: Number(val.toFixed(2)),
        unit: meta.unit,
        valuation_basis: meta.basis,
        methodology_id: 'FAOSTAT_FOOD_SECURITY_BULK_CSV',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  } finally {
    safeUnlink(res.filePath);
    try {
      if (fs.existsSync(extractDir)) {
        fs.rmSync(extractDir, { recursive: true, force: true });
      }
    } catch {
      // ignore cleanup error
    }
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestUnHabitatUrban(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const currentYear = new Date().getUTCFullYear();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const url = 'https://data.unhabitat.org/api/v3/datasets?q=urban&page[size]=1';

  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'unhabitat_urban_hub',
    timeoutMs: 20_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];

  try {
    const json = JSON.parse(fs.readFileSync(res.filePath, 'utf-8')) as {
      meta?: { stats?: { totalCount?: number } };
      data?: Array<unknown>;
    };
    const count = json.meta?.stats?.totalCount;
    rawRows.push({ totalCount: count ?? null, sample: json.data?.[0] ?? null });

    if (typeof count === 'number' && Number.isFinite(count) && count > 0) {
      silver.push({
        territory_id: 'T_USA',
        iso3: 'USA',
        indicator_id: 'UNHABITAT.URBAN_DATASETS',
        indicator_name: 'SDG 11 & Urban Indicator Public Datasets (UN-Habitat Hub v3)',
        module_id: 3,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: currentYear,
        value_numeric: Math.round(count),
        unit: 'datasets',
        valuation_basis: 'count',
        methodology_id: 'UNHABITAT_HUB_V3_URBAN_STATS',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestVdemReleases(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  return ingestOwidDatasets(source, [
    {
      slug: 'electoral-democracy-index',
      indicatorId: 'VDEM.ELECTORAL_DEMOCRACY_IX',
      indicatorName: 'Electoral Democracy Polyarchy Index (0-1, V-Dem v15/v16)',
      moduleId: 11,
      unit: 'index (0-1)',
      valuationBasis: 'index_score',
      methodologyId: 'VDEM_V2X_POLYARCHY_CSV',
      columnName: 'Electoral democracy index',
      minYear: 2019,
      decimals: 3,
      rawValueKey: 'polyarchy',
    },
  ]);
}

export async function ingestUnodcCrime(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  return ingestOwidDatasets(source, [
    {
      slug: 'homicide-rate-unodc',
      indicatorId: 'UNODC.HOMICIDE_RATE_PER_100K',
      indicatorName: 'Intentional Homicide Rate per 100,000 Population (UNODC / SDG 16.1.1)',
      moduleId: 11,
      unit: 'per 100k',
      valuationBasis: 'count',
      methodologyId: 'UNODC_HOMICIDE_SDG_16_1_1',
      columnName: 'Homicide rate per 100,000 population',
      minYear: 2018,
      decimals: 2,
      rawValueKey: 'homicide_per_100k',
    },
  ]);
}

export async function ingestGhslJrcUrban(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  return ingestOwidDatasets(source, [
    {
      slug: 'population-density',
      indicatorId: 'GHSL.POP_DENSITY_KM2',
      indicatorName: 'Population Density, People per km² of Land Area (GHSL / UN WPP)',
      moduleId: 3,
      unit: 'people/km²',
      valuationBasis: 'count',
      methodologyId: 'GHSL_JRC_POPULATION_DENSITY_KM2',
      columnName: 'Population density',
      minYear: 2018,
      decimals: 1,
      rawValueKey: 'pop_density_km2',
    },
  ]);
}

export async function ingestUndataSdmx(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const territories = listTerritories();
  const m49Lookup = new Map(territories.map((t) => [String(Number(t.un_m49)), t]));
  const m49Filter = territories
    .map((t) => String(Number(t.un_m49)))
    .sort((a, b) => Number(a) - Number(b))
    .join('+');

  const url = `https://data.un.org/ws/rest/data/IAEG-SDGs,DF_SDG_GLH,1.26/A.G.EG_ACS_ELEC.${m49Filter}._T._T._T._T._T._T._T._T._T._T._T?startPeriod=2020&endPeriod=2023`;

  const res = await fetchWithCitizenship({
    url,
    host: source.host,
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    headers: {
      'Accept-Language': 'en',
      Accept: 'application/vnd.sdmx.data+csv;version=1.0.0',
    },
    destPrefix: 'undata_sdmx_elec_access',
    timeoutMs: 25_000,
  });

  if (!res.filePath) {
    return { rawRows: [], silver: [], etag: res.etag, dedupHit: res.dedupHit, notModified: res.status === 'NOT_MODIFIED' };
  }

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const dedupKeys = new Set<string>();

  try {
    const csvRows = await withDuckDBConnection(async (conn) => {
      const reader = await conn.runAndReadAll(`
        SELECT REF_AREA, TIME_PERIOD, OBS_VALUE
        FROM read_csv_auto(${sqlQuote(res.filePath!)}, header=true, all_varchar=true)
        WHERE REF_AREA IS NOT NULL AND OBS_VALUE IS NOT NULL;
      `);
      try {
        return reader.getRowObjectsJson() as Array<Record<string, unknown>>;
      } finally {
        reader.closeSync();
      }
    });

    for (const r of csvRows) {
      const m49Key = String(Number(String(r.REF_AREA ?? '').trim()));
      const year = Number(String(r.TIME_PERIOD ?? '').trim());
      const val = Number(String(r.OBS_VALUE ?? '').trim());
      if (!m49Key || !Number.isInteger(year) || !Number.isFinite(val)) continue;

      const territory = m49Lookup.get(m49Key);
      if (!territory) continue;

      const key = `${territory.territory_id}|UNDATA.ELEC_ACCESS_PCT|${year}`;
      if (dedupKeys.has(key)) continue;
      dedupKeys.add(key);

      rawRows.push(r);
      silver.push({
        territory_id: territory.territory_id,
        iso3: territory.iso3,
        indicator_id: 'UNDATA.ELEC_ACCESS_PCT',
        indicator_name: 'Proportion of Population with Access to Electricity (%, UNdata SDMX-RI SDG 7.1.1)',
        module_id: 2,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        period_year: year,
        value_numeric: Number(val.toFixed(2)),
        unit: '%',
        valuation_basis: 'percent',
        methodology_id: 'UNDATA_SDMX_DF_SDG_GLH_126',
        commercial_use_allowed: source.commercial_use_allowed,
        asserted_at: assertedAt,
      });
    }
  } finally {
    safeUnlink(res.filePath);
  }

  return { rawRows, silver, etag: res.etag, dedupHit: res.dedupHit };
}

export async function ingestUndpHdrDataprism(source: SourceCatalogEntry): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassCache = shouldBypassConditionalCache(source.source_id);
  const hdrKey = (process.env.UNDP_HDR_API_KEY ?? '').trim();

  const url =
    'https://hdr.undp.org/sites/default/files/2023-24_HDR/HDR23-24_Composite_indices_complete_time_series.csv';

  const res = await fetchWithCitizenship({
    url,
    host: 'hdr.undp.org',
    rateLimitRpm: source.rate_limit_rpm,
    maxConcurrency: source.max_concurrency,
    bypassConditionalCache: bypassCache,
    destPrefix: 'undp_hdr2324_ts',
    timeoutMs: 30_000,
  });

  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const dedupKeys = new Set<string>();
  let lastEtag: string | null = res.etag;
  const dedupHit = res.dedupHit;

  if (res.filePath) {
    try {
      const rawBuf = fs.readFileSync(res.filePath);
      if (rawBuf.toString('utf8').includes('\uFFFD')) {
        fs.writeFileSync(res.filePath, rawBuf.toString('latin1'), 'utf8');
      }

      const csvRows = await withDuckDBConnection(async (conn) => {
        const reader = await conn.runAndReadAll(`
          SELECT
            TRIM(iso3) AS iso3,
            TRY_CAST(NULLIF(NULLIF(TRIM(hdi_2019), ''), '..') AS DOUBLE) AS hdi_2019,
            TRY_CAST(NULLIF(NULLIF(TRIM(hdi_2020), ''), '..') AS DOUBLE) AS hdi_2020,
            TRY_CAST(NULLIF(NULLIF(TRIM(hdi_2021), ''), '..') AS DOUBLE) AS hdi_2021,
            TRY_CAST(NULLIF(NULLIF(TRIM(hdi_2022), ''), '..') AS DOUBLE) AS hdi_2022,
            TRY_CAST(NULLIF(NULLIF(TRIM(ihdi_2022), ''), '..') AS DOUBLE) AS ihdi_2022,
            TRY_CAST(NULLIF(NULLIF(TRIM(mys_2022), ''), '..') AS DOUBLE) AS mys_2022
          FROM read_csv_auto(${sqlQuote(res.filePath!)}, header=true, all_varchar=true, ignore_errors=true)
          WHERE iso3 IS NOT NULL AND length(TRIM(iso3)) = 3;
        `);
        try {
          return reader.getRowObjectsJson() as Array<Record<string, unknown>>;
        } finally {
          reader.closeSync();
        }
      });

      const pushMetric = (
        territoryId: string,
        iso3: string,
        indicatorId: string,
        indicatorName: string,
        year: number,
        val: number,
        unit: string,
        basis: ObservationContract['valuation_basis']
      ) => {
        const k = `${territoryId}|${indicatorId}|${year}`;
        if (dedupKeys.has(k)) return;
        dedupKeys.add(k);
        silver.push({
          territory_id: territoryId,
          iso3,
          indicator_id: indicatorId,
          indicator_name: indicatorName,
          module_id: 11,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: year,
          value_numeric: Number(val.toFixed(3)),
          unit,
          valuation_basis: basis,
          methodology_id: 'UNDP_HDR_2023_24_TIME_SERIES',
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      };

      for (const r of csvRows) {
        const iso3Raw = String(r.iso3 ?? '').trim();
        const territory = resolveTerritoryByCodeOrName(iso3Raw);
        if (!territory) continue;

        rawRows.push(r);

        const hdiYears: Array<[number, unknown]> = [
          [2019, r.hdi_2019],
          [2020, r.hdi_2020],
          [2021, r.hdi_2021],
          [2022, r.hdi_2022],
        ];
        for (const [yr, rawVal] of hdiYears) {
          const val = typeof rawVal === 'number' ? rawVal : Number(rawVal);
          if (Number.isFinite(val) && val > 0 && val <= 1) {
            pushMetric(
              territory.territory_id,
              territory.iso3,
              'UNDP.HDI',
              'Human Development Index (0-1, UNDP HDR)',
              yr,
              val,
              'index (0-1)',
              'index_score'
            );
          }
        }

        const ihdi = typeof r.ihdi_2022 === 'number' ? r.ihdi_2022 : Number(r.ihdi_2022);
        if (Number.isFinite(ihdi) && ihdi > 0 && ihdi <= 1) {
          pushMetric(
            territory.territory_id,
            territory.iso3,
            'UNDP.IHDI',
            'Inequality-Adjusted Human Development Index (0-1, UNDP HDR)',
            2022,
            ihdi,
            'index (0-1)',
            'index_score'
          );
        }

        const mys = typeof r.mys_2022 === 'number' ? r.mys_2022 : Number(r.mys_2022);
        if (Number.isFinite(mys) && mys > 0) {
          pushMetric(
            territory.territory_id,
            territory.iso3,
            'UNDP.MEAN_SCHOOLING_YEARS',
            'Mean Years of Schooling (Years, UNDP HDR)',
            2022,
            mys,
            'years',
            'count'
          );
        }
      }
    } finally {
      safeUnlink(res.filePath);
    }
  }

  // Optional DataPRISM API probe when UNDP_HDR_API_KEY is supplied
  if (hdrKey) {
    try {
      const apiRes = await fetchWithCitizenship({
        url: 'https://api.hdrdata.org/v1/indicators',
        host: 'api.hdrdata.org',
        rateLimitRpm: source.rate_limit_rpm,
        maxConcurrency: 1,
        bypassConditionalCache: bypassCache,
        headers: { 'X-API-Key': hdrKey, Accept: 'application/json' },
        destPrefix: 'undp_dataprism_probe',
        timeoutMs: 10_000,
      });
      if (apiRes.etag) lastEtag = apiRes.etag;
      if (apiRes.filePath) {
        try {
          rawRows.push({ dataprism_v1_checked: true, bytes: fs.statSync(apiRes.filePath).size });
        } finally {
          safeUnlink(apiRes.filePath);
        }
      }
    } catch {
      // Non-fatal: official HDR complete time-series CSV already ingested
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}

