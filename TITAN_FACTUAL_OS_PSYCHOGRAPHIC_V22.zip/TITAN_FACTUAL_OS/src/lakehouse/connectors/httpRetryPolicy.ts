/** HTTP retry policy shared by the fetch layer and its dependency-free tests. */
export function isRetryableHttpStatus(status: number): boolean {
  return status === 408 || status === 429 || (status >= 500 && status <= 599);
}

export function parseRetryAfter(headerValue: string | null, nowMs = Date.now()): number | null {
  if (!headerValue) return null;
  const seconds = Number(headerValue);
  if (Number.isFinite(seconds) && seconds >= 0) {
    return Math.min(30_000, seconds * 1000);
  }
  const dateMs = Date.parse(headerValue);
  if (!Number.isNaN(dateMs)) {
    return Math.max(0, Math.min(30_000, dateMs - nowMs));
  }
  return null;
}

export function retryBackoffMs(attempt: number, randomValue = Math.random()): number {
  if (!Number.isInteger(attempt) || attempt < 0) throw new Error('attempt must be a non-negative integer');
  const random = Math.min(0.999999999, Math.max(0, randomValue));
  return Math.floor(random * Math.min(10_000, 600 * 2 ** attempt));
}

export function retryNetworkBackoffMs(attempt: number, randomValue = Math.random()): number {
  if (!Number.isInteger(attempt) || attempt < 0) throw new Error('attempt must be a non-negative integer');
  const random = Math.min(0.999999999, Math.max(0, randomValue));
  return Math.floor(random * Math.min(8_000, 500 * 2 ** attempt));
}

export function isRetryableFetchFailure(error: unknown): boolean {
  if (!(error instanceof Error)) return false;
  if (error.name === 'AbortError' || error.name === 'TimeoutError') return true;
  const cause = (error as Error & { cause?: unknown }).cause;
  const code = (error as NodeJS.ErrnoException).code
    ?? (cause && typeof cause === 'object' ? (cause as NodeJS.ErrnoException).code : undefined);
  if (['ECONNRESET', 'ECONNREFUSED', 'ETIMEDOUT', 'EAI_AGAIN', 'ENOTFOUND', 'ENETUNREACH', 'EHOSTUNREACH', 'UND_ERR_CONNECT_TIMEOUT'].includes(code ?? '')) return true;
  // Node's fetch wraps socket/DNS failures in TypeError("fetch failed").
  // Other TypeErrors, such as malformed URLs or invalid request configuration,
  // are deterministic and should not be retried.
  return error instanceof TypeError && /^fetch failed$/i.test(error.message.trim());
}
