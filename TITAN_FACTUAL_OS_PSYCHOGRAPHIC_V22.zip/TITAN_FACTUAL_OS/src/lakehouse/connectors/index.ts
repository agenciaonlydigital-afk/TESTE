import { randomUUID } from 'node:crypto';
import {
  acquireSourceIngestionLease,
  finishLineageRun,
  getCircuitBreaker,
  getDataSource,
  logUnresolvedEntity,
  releaseSourceIngestionLease,
  renewSourceIngestionLease,
  startLineageRun,
} from '../controlPlane.ts';
import { materializeAllGoldMarts } from '../goldMaterializer.ts';
import { runWithForceRefresh } from '../httpCitizenship.ts';
import { getImplementedWave1SourceIds } from '../sourceInventory.ts';
import { applySourceDomainToObservations } from '../domainRegistry.ts';
import { classifyEmptyConnectorOutcome } from '../ingestionOutcome.ts';
import { INGESTION_LEASE_HEARTBEAT_MS } from '../ingestionLease.ts';
import type { SourceCatalogEntry } from '../types.ts';
import {
  ingestFaostatBulk,
  ingestGhslJrcUrban,
  ingestOwidGrapher,
  ingestUnHabitatUrban,
  ingestUnSdgApi,
  ingestUnWppBulk,
  ingestUndataSdmx,
  ingestUndpHdrDataprism,
  ingestUnhcrPopulation,
  ingestUnicefSdmx,
  ingestUnodcCrime,
  ingestVdemReleases,
  ingestWhoGhoOdata,
  ingestWorldBankPIP,
  ingestWorldpopAge,
  ingestWorldpopCatalog,
  ingestWorldpopDensity,
} from './domains/demographySociety.ts';
import {
  ingestCkanActionFederation,
  ingestCrossrefPolite,
  ingestDataciteRest,
  ingestItuDatahub,
  ingestListenBrainz,
  ingestMusicBrainzApi,
  ingestOpenAlexWorks,
  ingestSocrataSoda,
  ingestUkDatagovCkan,
  ingestUnescoUis,
  ingestUnescoUisBulk,
  ingestUsDatagovCkan,
  ingestWikimediaPageviews,
  ingestWipoIpStats,
} from './domains/knowledgeCivic.ts';
import {
  ingestAbsSdmx,
  ingestBisSdmxV2,
  ingestEcbSdmx,
  ingestEurostatCatalogue,
  ingestEurostatMacro,
  ingestEurostatSdmx3,
  ingestEurostatStatsApi,
  ingestIbgeSidra,
  ingestIlostatSdmx,
  ingestImfDataMapper,
  ingestImfSdmx3,
  ingestIndiaOgdPlatform,
  ingestOecdSdmx,
  ingestPwtPennWorldTable,
  ingestStatcanWds,
  ingestStatfinPxweb,
  ingestUkOnsApi,
  ingestUsCensusApi,
  ingestWidWorld,
  ingestWorldBankSdmx,
  ingestWorldBankWDI,
} from './domains/macroEconomics.ts';
import {
  ingestArcgisHub,
  ingestClimateTrace,
  ingestEiaApiV2,
  ingestEmberEnergy,
  ingestGadmBoundaries,
  ingestGbifOccurrence,
  ingestGeoBoundariesMeta,
  ingestGeonamesDumps,
  ingestGlobalForestWatch,
  ingestNasaCmr,
  ingestNasaPowerClimatology,
  ingestNaturalEarthBulk,
  ingestNoaaNceiCdo,
  ingestObisV3,
  ingestOgcStacIndex,
  ingestOsmOverpass,
  ingestOvertureStac,
  ingestProtectedPlanetWdpa,
  ingestUndrrDatum,
  ingestUnsdEnergySdmx,
  ingestUsgsEarthquakes,
  ingestWikidataSparql,
} from './domains/spatialEnvironment.ts';
import {
  ingestIcaoApiService,
  ingestUnComtradePreview,
  ingestUnLocodeBulk,
  ingestUnctadStat,
  ingestWbWitsRest,
} from './domains/tradeLogistics.ts';
import {
  activeIngestionLocks,
  getActiveIngestionLocks,
  persistBronzeAndSilver,
  type ConnectorOutcome,
  type IngestionExecutionResult,
} from './shared.ts';

export { getActiveIngestionLocks, type IngestionExecutionResult };

export type ConnectorHandler = (source: SourceCatalogEntry) => Promise<ConnectorOutcome>;

export const CONNECTOR_REGISTRY: ReadonlyMap<string, ConnectorHandler> = new Map<string, ConnectorHandler>([
  // Macro-economics & Official Statistics (18)
  ['world_bank_wdi', ingestWorldBankWDI],
  ['world_bank_sdmx', ingestWorldBankSdmx],
  ['imf_datamapper', ingestImfDataMapper],
  ['imf_sdmx_3', ingestImfSdmx3],
  ['ilostat_sdmx', ingestIlostatSdmx],
  ['oecd_sdmx', ingestOecdSdmx],
  ['eurostat_sdmx', ingestEurostatMacro],
  ['eurostat_sdmx_3', ingestEurostatSdmx3],
  ['eurostat_stats_api', ingestEurostatStatsApi],
  ['eurostat_catalogue', ingestEurostatCatalogue],
  ['ecb_sdmx', ingestEcbSdmx],
  ['bis_sdmx_v2', ingestBisSdmxV2],
  ['abs_data_api', ingestAbsSdmx],
  ['statcan_wds', ingestStatcanWds],
  ['uk_ons_api', ingestUkOnsApi],
  ['ibge_sidra', ingestIbgeSidra],
  ['statfin_pxweb', ingestStatfinPxweb],
  ['us_census_api', ingestUsCensusApi],
  ['india_ogd_platform', ingestIndiaOgdPlatform],
  ['wid_world_bulk', ingestWidWorld],
  ['pwt_penn_world_table', ingestPwtPennWorldTable],

  // Trade & Logistics (5)
  ['wb_wits_rest', ingestWbWitsRest],
  ['unctad_stat', ingestUnctadStat],
  ['un_comtrade_full', ingestUnComtradePreview],
  ['un_locode_bulk', ingestUnLocodeBulk],
  ['icao_api_service', ingestIcaoApiService],

  // Demography, Health, Governance & SDGs (17)
  ['owid_inequality_demo', ingestOwidGrapher],
  ['who_gho_odata', ingestWhoGhoOdata],
  ['world_bank_pip', ingestWorldBankPIP],
  ['unicef_sdmx', ingestUnicefSdmx],
  ['un_sdg_api', ingestUnSdgApi],
  ['undata_sdmx', ingestUndataSdmx],
  ['undp_hdr_dataprism', ingestUndpHdrDataprism],
  ['unhcr_population_v1', ingestUnhcrPopulation],
  ['un_wpp_bulk', ingestUnWppBulk],
  ['worldpop_catalog', ingestWorldpopCatalog],
  ['worldpop_adv_v1', ingestWorldpopAge],
  ['worldpop_global2_v2', ingestWorldpopDensity],
  ['faostat_bulk', ingestFaostatBulk],
  ['un_habitat_urban', ingestUnHabitatUrban],
  ['vdem_releases', ingestVdemReleases],
  ['unodc_data_portal', ingestUnodcCrime],
  ['ghsl_jrc_bulk', ingestGhslJrcUrban],

  // Spatial, Climate, Energy & Biodiversity (22)
  ['geoboundaries_open', ingestGeoBoundariesMeta],
  ['gadm_boundaries', ingestGadmBoundaries],
  ['natural_earth_bulk', ingestNaturalEarthBulk],
  ['geonames_dumps', ingestGeonamesDumps],
  ['wikidata_sparql', ingestWikidataSparql],
  ['overture_maps_geoparquet', ingestOvertureStac],
  ['arcgis_rest_platform', ingestArcgisHub],
  ['ogc_stac_ecosystem', ingestOgcStacIndex],
  ['osm_overpass', ingestOsmOverpass],
  ['nasa_open_apis', ingestNasaPowerClimatology],
  ['nasa_cmr', ingestNasaCmr],
  ['noaa_ncei_cdo', ingestNoaaNceiCdo],
  ['global_forest_watch', ingestGlobalForestWatch],
  ['protected_planet_wdpa', ingestProtectedPlanetWdpa],
  ['climate_trace_v7', ingestClimateTrace],
  ['eia_api_v2', ingestEiaApiV2],
  ['ember_energy_bulk', ingestEmberEnergy],
  ['unsd_energy_sdmx', ingestUnsdEnergySdmx],
  ['gbif_occurrence', ingestGbifOccurrence],
  ['obis_v3', ingestObisV3],
  ['undrr_datum', ingestUndrrDatum],
  ['usgs_earthquake_v1', ingestUsgsEarthquakes],

  // Knowledge, Media, Civic Open Data & ICT (14)
  ['unesco_uis_api', ingestUnescoUis],
  ['unesco_uis_bulk', ingestUnescoUisBulk],
  ['openalex_works_v1', ingestOpenAlexWorks],
  ['crossref_polite', ingestCrossrefPolite],
  ['datacite_rest', ingestDataciteRest],
  ['wikimedia_pageviews', ingestWikimediaPageviews],
  ['musicbrainz_api', ingestMusicBrainzApi],
  ['listenbrainz_api', ingestListenBrainz],
  ['us_datagov_ckan', ingestUsDatagovCkan],
  ['uk_datagov_ckan', ingestUkDatagovCkan],
  ['ckan_action_api', ingestCkanActionFederation],
  ['socrata_soda', ingestSocrataSoda],
  ['wipo_ip_stats', ingestWipoIpStats],
  ['itu_datahub', ingestItuDatahub],
]);

export const ALL_WAVE1_SOURCE_IDS: readonly string[] = getImplementedWave1SourceIds();
export const CORE_BATCH_SOURCE_IDS: readonly string[] = ALL_WAVE1_SOURCE_IDS;

export function getConnectorRegistryCoverage() {
  const expected = new Set(ALL_WAVE1_SOURCE_IDS);
  const registered = new Set(CONNECTOR_REGISTRY.keys());
  const missingHandlers = [...expected].filter((id) => !registered.has(id)).sort();
  const additionalHandlers = [...registered].filter((id) => !expected.has(id)).sort();
  return { implemented_keyless_sources: expected.size, registered_handlers: registered.size, missing_handlers: missingHandlers, additional_handlers: additionalHandlers, coverage_complete: missingHandlers.length === 0 && additionalHandlers.length === 0 };
}

const PROCESS_INGESTION_OWNER = `${process.pid}:${randomUUID()}`;
let batchSyncInProgress = false;

export function isBatchSyncRunning(): boolean {
  return batchSyncInProgress;
}

export async function runConnectorIngestion(
  sourceId: string,
  options?: { force?: boolean; skipGoldMaterialize?: boolean }
): Promise<IngestionExecutionResult> {
  const source = getDataSource(sourceId);
  if (!source) {
    throw new Error(`Unknown source_id: ${sourceId}`);
  }
  if (source.access_tier !== 'tier0_keyless') {
    throw new Error(
      `Source ${sourceId} is ${source.access_tier} and requires credentials (${source.known_block_reason ?? 'key required'}).`
    );
  }
  if (activeIngestionLocks.has(sourceId)) {
    throw new Error(`Ingestion already in progress for ${sourceId} (overlap lock active).`);
  }

  // SQLite is the cross-process source of truth. The in-memory Set remains a
  // fast local guard, while the lease prevents concurrent capture by replicas.
  const runId = `run_${sourceId}_${randomUUID()}`;
  const lease = { sourceId, runId, ownerId: PROCESS_INGESTION_OWNER };
  const startedMs = Date.now();
  const force = Boolean(options?.force);
  let leaseAcquired = false;
  let leaseLost = false;
  let heartbeat: NodeJS.Timeout | undefined;

  try {
    leaseAcquired = acquireSourceIngestionLease(lease);
    if (!leaseAcquired) {
      throw new Error(`Ingestion already in progress for ${sourceId} (durable SQLite lease active).`);
    }
    activeIngestionLocks.add(sourceId);

    heartbeat = setInterval(() => {
      try {
        if (!renewSourceIngestionLease(lease)) leaseLost = true;
      } catch {
        leaseLost = true;
      }
    }, INGESTION_LEASE_HEARTBEAT_MS);
    heartbeat.unref();

    const breaker = getCircuitBreaker(source.host);
    startLineageRun({
      run_id: runId,
      source_id: source.source_id,
      job_name: `ingest_${source.source_id}`,
      status: 'RUNNING',
      input_etag: breaker.last_etag,
      output_snapshot_id: null,
      rows_in: 0,
      rows_out: 0,
      duration_ms: 0,
      details_json: JSON.stringify({
        host: source.host,
        mode: source.preferred_mode,
        force,
        lease_owner: PROCESS_INGESTION_OWNER,
      }),
      started_at: new Date().toISOString(),
    });

    if (breaker.state === 'OPEN') {
      const duration = Date.now() - startedMs;
      finishLineageRun(runId, {
        status: 'BLOCKED_CB',
        duration_ms: duration,
        details_json: JSON.stringify({ cooldown_until: breaker.cooldown_until, last_error: breaker.last_error }),
      });
      return {
        run_id: runId,
        source_id: sourceId,
        status: 'BLOCKED_CB',
        snapshot_id: null,
        rows_in: 0,
        rows_out: 0,
        duration_ms: duration,
        dedup_hit: false,
        qa_notes: `Circuit Breaker OPEN until ${breaker.cooldown_until ?? 'cooldown'}`,
      };
    }

    try {
      const handler = CONNECTOR_REGISTRY.get(sourceId);
      if (!handler) {
        logUnresolvedEntity(
          sourceId,
          sourceId,
          source.source_name,
          'Wave 1 adapter not enabled (deferred bulk/Wave 2)'
        );
        throw new Error(
          `Connector ${sourceId} is cataloged for Wave 1/2 bulk execution and not yet wired to interactive REST.`
        );
      }

      const outcome = await runWithForceRefresh(force, () => handler(source));

      // A worker whose durable lease expired may finish downloading data, but
      // it must not be allowed to promote a new Silver snapshot afterwards.
      if (leaseLost || !renewSourceIngestionLease(lease)) {
        throw new Error(`Ingestion lease for ${sourceId} was lost before snapshot promotion; capture discarded.`);
      }

      if (outcome.silver.length === 0) {
        const emptyDisposition = classifyEmptyConnectorOutcome({
          rawRowCount: outcome.rawRows.length,
          notModified: outcome.notModified === true,
        });
        if (emptyDisposition.status === 'UP_TO_DATE_304') {
          const duration = Date.now() - startedMs;
          finishLineageRun(runId, {
            status: 'UP_TO_DATE_304', duration_ms: duration,
            details_json: JSON.stringify({ reason: emptyDisposition.reason, etag: outcome.etag, force }),
          });
          return { run_id: runId, source_id: sourceId, status: 'UP_TO_DATE_304', snapshot_id: null,
            rows_in: 0, rows_out: 0, duration_ms: duration, dedup_hit: outcome.dedupHit,
            qa_notes: `Up-to-date: ${emptyDisposition.reason}` };
        }
        throw new Error(`Empty connector outcome is not a successful 304: ${emptyDisposition.reason}`);
      }

      const canonicalSilver = applySourceDomainToObservations(source.source_id, source.module_id, outcome.silver);
      const { snapshotId, rowsOut, qaNotes } = await persistBronzeAndSilver(source, outcome.rawRows, canonicalSilver);

      let servingWarning: string | null = null;
      if (!options?.skipGoldMaterialize) {
        try {
          await materializeAllGoldMarts();
        } catch (err) {
          servingWarning = err instanceof Error ? err.message : String(err);
        }
      }

      const finalQaNotes = servingWarning
        ? `${qaNotes} | GOLD MATERIALIZATION WARNING: ${servingWarning}`
        : qaNotes;
      const duration = Date.now() - startedMs;
      finishLineageRun(runId, {
        status: 'COMPLETED',
        output_snapshot_id: snapshotId,
        rows_in: outcome.rawRows.length,
        rows_out: rowsOut,
        duration_ms: duration,
        details_json: JSON.stringify({
          qaNotes: finalQaNotes,
          servingWarning,
          etag: outcome.etag,
          dedupHit: outcome.dedupHit,
          force,
        }),
      });

      return {
        run_id: runId,
        source_id: sourceId,
        status: 'COMPLETED',
        snapshot_id: snapshotId,
        rows_in: outcome.rawRows.length,
        rows_out: rowsOut,
        duration_ms: duration,
        dedup_hit: outcome.dedupHit,
        qa_notes: finalQaNotes,
      };
    } catch (err) {
      const duration = Date.now() - startedMs;
      const message = err instanceof Error ? err.message : String(err);
      finishLineageRun(runId, {
        status: 'FAILED',
        duration_ms: duration,
        details_json: JSON.stringify({ error: message }),
      });
      return {
        run_id: runId,
        source_id: sourceId,
        status: 'FAILED',
        snapshot_id: null,
        rows_in: 0,
        rows_out: 0,
        duration_ms: duration,
        dedup_hit: false,
        qa_notes: message,
      };
    }
  } finally {
    if (heartbeat) clearInterval(heartbeat);
    activeIngestionLocks.delete(sourceId);
    if (leaseAcquired) {
      try {
        releaseSourceIngestionLease(lease);
      } catch (err) {
        console.error(`Unable to release ingestion lease for ${sourceId}:`, err);
      }
    }
  }
}

export async function runCoreBatchIngestion(options?: { force?: boolean }): Promise<IngestionExecutionResult[]> {
  if (batchSyncInProgress) {
    throw new Error('Batch Wave-1 ingestion already in progress (batch lock active).');
  }
  batchSyncInProgress = true;
  try {
    const sourceIds = getImplementedWave1SourceIds();
    const results: IngestionExecutionResult[] = new Array(sourceIds.length);
    const concurrency = Math.min(6, Math.max(1, sourceIds.length));
    let cursor = 0;

    async function worker() {
      while (true) {
        const idx = cursor++;
        if (idx >= sourceIds.length) break;
        const id = sourceIds[idx];
        results[idx] = await runConnectorIngestion(id, { ...options, skipGoldMaterialize: true }).catch((err) => ({
          run_id: `run_${id}_err_${Date.now()}`,
          source_id: id,
          status: 'FAILED' as const,
          snapshot_id: null,
          rows_in: 0,
          rows_out: 0,
          duration_ms: 0,
          dedup_hit: false,
          qa_notes: err instanceof Error ? err.message : String(err),
        }));
      }
    }

    await Promise.all(Array.from({ length: concurrency }, () => worker()));

    if (results.some((r) => r?.status === 'COMPLETED')) {
      try {
        await materializeAllGoldMarts();
      } catch (err) {
        const warning = err instanceof Error ? err.message : String(err);
        for (const result of results) {
          if (result?.status === 'COMPLETED') {
            result.qa_notes = `${result.qa_notes} | GOLD MATERIALIZATION WARNING: ${warning}`;
          }
        }
      }
    }

    return results;
  } finally {
    batchSyncInProgress = false;
  }
}
