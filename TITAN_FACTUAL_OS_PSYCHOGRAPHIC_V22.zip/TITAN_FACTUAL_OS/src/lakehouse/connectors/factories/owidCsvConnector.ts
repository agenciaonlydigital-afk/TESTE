import { resolveTerritoryByCodeOrName } from '../../controlPlane.ts';
import { sqlQuote, withDuckDBConnection } from '../../duckdbEngine.ts';
import { fetchWithCitizenship } from '../../httpCitizenship.ts';
import type { ObservationContract, SourceCatalogEntry } from '../../types.ts';
import { safeUnlink, shouldBypassConditionalCache, type ConnectorOutcome } from '../shared.ts';

export interface OwidDatasetSpec {
  slug: string;
  indicatorId: string;
  indicatorName: string;
  moduleId: number;
  unit: string;
  valuationBasis: ObservationContract['valuation_basis'];
  methodologyId: string;
  columnName?: string;
  minYear: number;
  maxYear?: number;
  decimals?: number;
  transformValue?: (raw: number) => number;
  rawValueKey?: string;
}

export async function ingestOwidDatasets(
  source: SourceCatalogEntry,
  specs: readonly OwidDatasetSpec[]
): Promise<ConnectorOutcome> {
  const assertedAt = new Date().toISOString();
  const bypassInitialOrForce = shouldBypassConditionalCache(source.source_id);
  const rawRows: unknown[] = [];
  const silver: ObservationContract[] = [];
  const dedupKeys = new Set<string>();
  let lastEtag: string | null = null;
  let dedupHit = false;

  const fetched: Array<{ spec: OwidDatasetSpec; filePath: string | null; status: string }> = [];
  for (const spec of specs) {
    const url = `https://ourworldindata.org/grapher/${spec.slug}.csv`;
    const res = await fetchWithCitizenship({
      url,
      host: source.host,
      rateLimitRpm: source.rate_limit_rpm,
      maxConcurrency: source.max_concurrency,
      bypassConditionalCache: bypassInitialOrForce,
      destPrefix: `owid_${spec.slug}`,
      timeoutMs: 25_000,
    });
    dedupHit = dedupHit || res.dedupHit;
    if (res.etag) lastEtag = res.etag;
    fetched.push({ spec, filePath: res.filePath, status: res.status });
  }

  const anyChanged = fetched.some((f) => f.status === 'OK');
  if (!anyChanged && !bypassInitialOrForce) {
    return { rawRows: [], silver: [], etag: lastEtag, dedupHit, notModified: fetched.length > 0 && fetched.every((item) => item.status === 'NOT_MODIFIED') };
  }

  for (const item of fetched) {
    if (!item.filePath && item.status === 'NOT_MODIFIED') {
      const url = `https://ourworldindata.org/grapher/${item.spec.slug}.csv`;
      const fullRes = await fetchWithCitizenship({
        url,
        host: source.host,
        rateLimitRpm: source.rate_limit_rpm,
        maxConcurrency: source.max_concurrency,
        bypassConditionalCache: true,
        destPrefix: `owid_${item.spec.slug}_full`,
        timeoutMs: 25_000,
      });
      item.filePath = fullRes.filePath;
    }
  }

  for (const { spec, filePath } of fetched) {
    if (!filePath) continue;
    const maxYear = spec.maxYear ?? 2026;
    try {
      const csvRows = await withDuckDBConnection(async (conn) => {
        const reader = await conn.runAndReadAll(`
          SELECT * FROM read_csv_auto(${sqlQuote(filePath)}, header=true)
          WHERE Code IS NOT NULL
            AND length(Code) = 3
            AND TRY_CAST(Year AS INTEGER) BETWEEN ${spec.minYear} AND ${maxYear};
        `);
        try {
          const cols = reader.columnNames();
          const preferredCol = spec.columnName && cols.includes(spec.columnName) ? spec.columnName : null;
          const valueCols = preferredCol ? [preferredCol, ...cols.slice(3).filter((c) => c !== preferredCol)] : cols.slice(3);
          const objects = reader.getRowObjectsJson() as Array<Record<string, unknown>>;
          return objects.map((obj) => {
            let picked: number | null = null;
            for (const vc of valueCols) {
              const raw = obj[vc];
              if (raw === null || raw === undefined) continue;
              if (typeof raw === 'string' && raw.trim() === '') continue;
              const num = Number(raw);
              if (Number.isFinite(num)) {
                picked = num;
                break;
              }
            }
            return {
              Entity: String(obj.Entity ?? ''),
              Code: String(obj.Code ?? ''),
              Year: Number(obj.Year),
              Value: picked,
            };
          });
        } finally {
          reader.closeSync();
        }
      });

      for (const r of csvRows) {
        if (r.Value === null || !Number.isFinite(r.Value) || !Number.isInteger(r.Year)) continue;
        const territory = resolveTerritoryByCodeOrName(r.Code) ?? resolveTerritoryByCodeOrName(r.Entity);
        if (!territory) continue;

        const key = `${territory.territory_id}|${spec.indicatorId}|${r.Year}`;
        if (dedupKeys.has(key)) continue;
        dedupKeys.add(key);

        const transformed = spec.transformValue ? spec.transformValue(r.Value) : r.Value;
        const rounded =
          spec.decimals !== undefined ? Number(transformed.toFixed(spec.decimals)) : transformed;

        rawRows.push(
          spec.rawValueKey
            ? { iso3: territory.iso3, year: r.Year, [spec.rawValueKey]: r.Value }
            : { slug: spec.slug, ...r }
        );
        silver.push({
          territory_id: territory.territory_id,
          iso3: territory.iso3,
          indicator_id: spec.indicatorId,
          indicator_name: spec.indicatorName,
          module_id: spec.moduleId,
          source_id: source.source_id,
          dataset_id: source.dataset_id,
          period_year: r.Year,
          value_numeric: rounded,
          unit: spec.unit,
          valuation_basis: spec.valuationBasis,
          methodology_id: spec.methodologyId,
          commercial_use_allowed: source.commercial_use_allowed,
          asserted_at: assertedAt,
        });
      }
    } finally {
      safeUnlink(filePath);
    }
  }

  return { rawRows, silver, etag: lastEtag, dedupHit };
}
