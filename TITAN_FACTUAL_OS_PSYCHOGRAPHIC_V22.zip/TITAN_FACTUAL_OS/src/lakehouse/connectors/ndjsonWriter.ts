import fs from 'node:fs';
import path from 'node:path';
import { once } from 'node:events';
import { finished } from 'node:stream/promises';

type RecordSource<T> = Iterable<T> | AsyncIterable<T>;

/** Writes sync or async iterables with bounded stream buffering and deterministic ordering. */
export async function writeNdjsonRecords<T>(
  filePath: string,
  records: RecordSource<T>,
  mapRecord: (record: T, index: number) => unknown = (record) => record,
): Promise<number> {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const stream = fs.createWriteStream(filePath, { flags: 'wx' });
  const done = finished(stream);
  void done.catch(() => undefined);
  let index = 0;
  try {
    for await (const record of records) {
      const line = `${JSON.stringify(mapRecord(record, index))}\n`;
      if (!stream.write(line)) await once(stream, 'drain');
      index++;
    }
    stream.end();
    await done;
    return index;
  } catch (error) {
    stream.destroy();
    await done.catch(() => undefined);
    throw error;
  }
}
