import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import {
  getActiveSilverSnapshot,
  listActiveSourceIngestionLeases,
  listTerritories,
  registerAndPromoteSnapshot,
} from '../controlPlane.ts';
import { writeRecordsToParquet } from '../duckdbEngine.ts';
import { isForceRefreshActive, releaseFetchedTempFile } from '../httpCitizenship.ts';
import { invalidateQueryCache } from '../queries.ts';
import { runSilverQaGate } from '../qaContracts.ts';
import { writeNdjsonRecords } from './ndjsonWriter.ts';
import type { ObservationContract, SourceCatalogEntry } from '../types.ts';

export interface IngestionExecutionResult {
  run_id: string;
  source_id: string;
  status: 'COMPLETED' | 'UP_TO_DATE_304' | 'SKIPPED_304' | 'BLOCKED_CB' | 'FAILED';
  snapshot_id: string | null;
  rows_in: number;
  rows_out: number;
  duration_ms: number;
  dedup_hit: boolean;
  qa_notes: string;
}

export interface ConnectorOutcome {
  rawRows: unknown[];
  silver: ObservationContract[];
  etag: string | null;
  dedupHit: boolean;
  /** True only when every required request returned an explicit HTTP 304. */
  notModified?: boolean;
}

export const BRONZE_DIR = path.resolve(process.cwd(), 'data', 'lakehouse', 'bronze');
export const SILVER_DIR = path.resolve(process.cwd(), 'data', 'lakehouse', 'silver');
export const GOLD_DIR = path.resolve(process.cwd(), 'data', 'lakehouse', 'gold');
export const TMP_DIR = path.resolve(process.cwd(), 'data', 'tmp');

export const activeIngestionLocks = new Set<string>();

export function getActiveIngestionLocks(): string[] {
  const durable = listActiveSourceIngestionLeases().map((lease) => lease.source_id);
  return Array.from(new Set([...activeIngestionLocks.values(), ...durable])).sort();
}

export function shouldBypassConditionalCache(sourceId: string): boolean {
  return isForceRefreshActive() || !getActiveSilverSnapshot(sourceId);
}

export function makeSnapshotId(sourceId: string): string {
  const ts = new Date().toISOString().replace(/[:.]/g, '-');
  const rand = crypto.randomBytes(3).toString('hex');
  return `${sourceId}_${ts}_${rand}`;
}

export function safeUnlink(filePath: string | null): void {
  if (!filePath) return;
  // HTTP in-flight deduplication may share one downloaded file among callers;
  // the last consumer performs the unlink, never the first one to finish.
  releaseFetchedTempFile(filePath);
}

export async function computeFileSha256(filePath: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = fs.createReadStream(filePath);
    stream.on('data', (chunk) => hash.update(chunk));
    stream.on('error', reject);
    stream.on('end', () => resolve(hash.digest('hex')));
  });
}

export function getCanonicalIso3Filter(separator = '+'): string {
  return listTerritories()
    .map((t) => t.iso3)
    .sort()
    .join(separator);
}

export function getCanonicalIso3List(): string[] {
  return listTerritories()
    .map((t) => t.iso3)
    .sort();
}

export async function persistBronzeAndSilver(
  source: SourceCatalogEntry,
  rawRows: unknown[],
  silverRecords: ObservationContract[]
): Promise<{ snapshotId: string; rowsOut: number; qaNotes: string }> {
  const snapshotId = makeSnapshotId(source.source_id);
  const bronzeNdjson = path.join(TMP_DIR, `${snapshotId}_bronze.ndjson`);
  const silverNdjson = path.join(TMP_DIR, `${snapshotId}_silver.ndjson`);

  const bronzePath = path.join(BRONZE_DIR, source.source_id, `${snapshotId}.parquet`);
  const silverPath = path.join(SILVER_DIR, source.source_id, `${snapshotId}.parquet`);

  try {
    // 1. Write Uniform Bronze Medallion Envelope NDJSON -> Atomic ZSTD Parquet
    const ingestTs = new Date().toISOString();
    await writeNdjsonRecords(bronzeNdjson, rawRows, (rawRow, idx) => ({
      _ingest_timestamp: ingestTs, _batch_id: snapshotId, _source_id: source.source_id,
      _dataset_id: source.dataset_id, _row_index: idx, _payload_json: JSON.stringify(rawRow ?? null),
    }));

    if (rawRows.length > 0) {
      const bronzeStats = await writeRecordsToParquet(bronzeNdjson, bronzePath);
      const bronzeSha = await computeFileSha256(bronzePath);
      registerAndPromoteSnapshot({
        snapshot_id: `${snapshotId}_bronze`,
        source_id: source.source_id,
        dataset_id: source.dataset_id,
        layer: 'bronze',
        parquet_path: bronzePath,
        sha256: bronzeSha,
        row_count: bronzeStats.rowCount,
        byte_size: bronzeStats.byteSize,
        qa_status: 'PASSED',
        qa_notes: `Immutable raw envelope landing (${rawRows.length} records)`,
        created_at: ingestTs,
      });
    }

    // 2. Enforce Silver Data Contracts, Commercial Gate, Key Deduplication & Regression Check
    const prevSnapshot = getActiveSilverSnapshot(source.source_id);
    const qaResult = runSilverQaGate(source, silverRecords, prevSnapshot);

    // 3. Write Silver NDJSON -> Atomic Sorted ZSTD Parquet
    await writeNdjsonRecords(silverNdjson, qaResult.validated);

    const silverStats = await writeRecordsToParquet(
      silverNdjson,
      silverPath,
      'indicator_id ASC, territory_id ASC, period_year ASC'
    );
    const silverSha = await computeFileSha256(silverPath);
    // Do not infer the expected country universe from the current territorial
    // dimension: it is an enriched seed registry, not yet a complete ISO/M49
    // registry nor a source-specific expected-country manifest. Scoring against
    // that partial set would create false global-coverage confidence.
    const territoryRegistryCount = listTerritories().length;
    const coverageNotes = ` · geographic coverage not scored: source-specific expected territory set is not configured (current enriched registry: ${territoryRegistryCount} countries; baseline incomplete)`;
    const qaNotes = `${qaResult.qaNotes}${coverageNotes} · ${(silverStats.byteSize / 1024).toFixed(1)} KB ZSTD Parquet`;

    registerAndPromoteSnapshot({
      snapshot_id: snapshotId,
      source_id: source.source_id,
      dataset_id: source.dataset_id,
      layer: 'silver',
      parquet_path: silverPath,
      sha256: silverSha,
      row_count: silverStats.rowCount,
      byte_size: silverStats.byteSize,
      qa_status: 'PASSED',
      qa_notes: qaNotes,
      created_at: new Date().toISOString(),
    });

    invalidateQueryCache();

    return { snapshotId, rowsOut: silverStats.rowCount, qaNotes };
  } finally {
    safeUnlink(bronzeNdjson);
    safeUnlink(silverNdjson);
  }
}
