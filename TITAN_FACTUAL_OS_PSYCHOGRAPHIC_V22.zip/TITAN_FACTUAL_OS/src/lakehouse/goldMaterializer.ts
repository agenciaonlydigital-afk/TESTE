import fs from 'node:fs';
import path from 'node:path';
import {
  getActiveGoldSnapshotCount,
  listActiveSilverParquetPaths,
  registerAndPromoteSnapshot,
} from './controlPlane.ts';
import { writeRecordsToParquet } from './duckdbEngine.ts';
import {
  computeFileSha256,
  GOLD_DIR,
  makeSnapshotId,
  safeUnlink,
  TMP_DIR,
} from './connectors/shared.ts';
import { writeNdjsonRecords } from './connectors/ndjsonWriter.ts';
import {
  getBrandMarketProfiles,
  getH3MacroRollup,
  getMacroEconomicOverview,
  invalidateQueryCache,
} from './queries.ts';

export interface GoldMartBuildSummary {
  mart_id: string;
  snapshot_id: string;
  row_count: number;
  byte_size: number;
  parquet_path: string;
}

export interface GoldMaterializationReport {
  marts: GoldMartBuildSummary[];
  duration_ms: number;
  silver_snapshot_count: number;
}

let inFlightMaterialization: Promise<GoldMaterializationReport> | null = null;

async function writeGoldMartParquet(
  martId: string,
  datasetId: string,
  rows: object[],
  orderByClause: string
): Promise<GoldMartBuildSummary | null> {
  if (rows.length === 0) return null;

  const snapshotId = makeSnapshotId(martId);
  const ndjsonTmp = path.join(TMP_DIR, `${snapshotId}.ndjson`);
  const parquetPath = path.join(GOLD_DIR, martId, `${snapshotId}.parquet`);

  try {
    fs.mkdirSync(TMP_DIR, { recursive: true });
    await writeNdjsonRecords(ndjsonTmp, rows);

    const stats = await writeRecordsToParquet(ndjsonTmp, parquetPath, orderByClause);
    const sha256 = await computeFileSha256(parquetPath);
    const createdAt = new Date().toISOString();

    registerAndPromoteSnapshot({
      snapshot_id: snapshotId,
      source_id: martId,
      dataset_id: datasetId,
      layer: 'gold',
      parquet_path: parquetPath,
      sha256,
      row_count: stats.rowCount,
      byte_size: stats.byteSize,
      qa_status: 'PASSED',
      qa_notes: `Gold mart materialized (${stats.rowCount} rows, ${(stats.byteSize / 1024).toFixed(1)} KB ZSTD Parquet)`,
      created_at: createdAt,
    });

    return {
      mart_id: martId,
      snapshot_id: snapshotId,
      row_count: stats.rowCount,
      byte_size: stats.byteSize,
      parquet_path: parquetPath,
    };
  } finally {
    safeUnlink(ndjsonTmp);
  }
}

async function executeGoldMaterialization(): Promise<GoldMaterializationReport> {
  const startedMs = Date.now();
  const silverPaths = listActiveSilverParquetPaths();
  if (silverPaths.length === 0) {
    return {
      marts: [],
      duration_ms: Date.now() - startedMs,
      silver_snapshot_count: 0,
    };
  }

  invalidateQueryCache();

  const [macroRes, brandMassRes, brandPremRes, h3Res] = await Promise.all([
    getMacroEconomicOverview(),
    getBrandMarketProfiles('mass_market'),
    getBrandMarketProfiles('premium'),
    getH3MacroRollup(),
  ]);

  const built: GoldMartBuildSummary[] = [];

  const macroMart = await writeGoldMartParquet(
    'gold_macro_economic_overview',
    'TITAN_GOLD_MACRO_OVERVIEW',
    macroRes.data,
    'iso3 ASC'
  );
  if (macroMart) built.push(macroMart);

  const combinedBrandRows = [
    ...brandMassRes.data.map((row) => ({
      mode: 'mass_market',
      territory_id: row.territory_id,
      iso3: row.iso3,
      name_en: row.name_en,
      continent: row.continent,
      region: row.region,
      h3_res2: row.h3_res2,
      currency_iso4217: row.currency_iso4217,
      primary_language_iso639: row.primary_language_iso639,
      timezone: row.timezone,
      population_total: row.population_total,
      population_total_year: row.population_total_year,
      median_age: row.median_age,
      median_age_year: row.median_age_year,
      life_expectancy_years: row.life_expectancy_years,
      life_expectancy_years_year: row.life_expectancy_years_year,
      gdp_per_capita_ppp_2021: row.gdp_per_capita_ppp_2021,
      gdp_per_capita_ppp_2021_year: row.gdp_per_capita_ppp_2021_year,
      gini_index: row.gini_index,
      gini_index_year: row.gini_index_year,
      urbanization_pct: row.urbanization_pct,
      urbanization_pct_year: row.urbanization_pct_year,
      internet_users_pct: row.internet_users_pct,
      internet_users_pct_year: row.internet_users_pct_year,
      inflation_cpi_pct: row.inflation_cpi_pct,
      inflation_cpi_pct_year: row.inflation_cpi_pct_year,
      purchasing_power_tier: row.purchasing_power_tier,
      digital_addressable_pop: row.digital_addressable_pop,
      demographic_score: row.mai.demographic_score,
      purchasing_power_score: row.mai.purchasing_power_score,
      inflation_risk_multiplier: row.mai.inflation_risk_multiplier,
      market_attractiveness_score: row.mai.market_attractiveness_score,
      mai_methodology_version: row.mai.methodology_version,
      mai_data_coverage_pct: row.mai.data_coverage_pct,
      mai_temporal_status: row.mai.temporal_status,
      mai_oldest_data_year: row.mai.oldest_data_year,
      mai_newest_data_year: row.mai.newest_data_year,
      mai_missing_or_invalid_fields: row.mai.missing_or_invalid_fields.join(';'),
      psychographic_profile_version: row.psychographics.model_version,
      psychographic_validation_status: row.psychographics.validation_status,
      psychographic_data_coverage_pct: row.psychographics.data_coverage_pct,
      psychographic_data_fields_available: row.psychographics.data_fields_available,
      psychographic_data_fields_expected: row.psychographics.data_fields_expected,
      psychographic_invalid_fields: row.psychographics.invalid_fields.join(';'),
      psychographic_temporal_coverage_pct: row.psychographics.temporal_coverage_pct,
      psychographic_temporal_status: row.psychographics.temporal_status,
      psychographic_oldest_evidence_year: row.psychographics.oldest_evidence_year,
      psychographic_newest_evidence_year: row.psychographics.newest_evidence_year,
      psychographic_temporal_span_years: row.psychographics.temporal_span_years,
      psychographic_survey_evidence_count: row.psychographics.survey_evidence_count,
      psychographic_measured_survey_measures_json: JSON.stringify(row.psychographics.measured_survey_measures),
      psychographic_population_share_estimated: row.psychographics.population_share_estimated,
      psychographic_digital_discovery_score: row.psychographics.signals.find((signal) => signal.signal_id === 'digital_discovery')?.score ?? null,
      psychographic_value_sensitivity_score: row.psychographics.signals.find((signal) => signal.signal_id === 'value_sensitivity')?.score ?? null,
      psychographic_urban_cultural_access_score: row.psychographics.signals.find((signal) => signal.signal_id === 'urban_cultural_access')?.score ?? null,
      psychographic_economic_pressure_score: row.psychographics.signals.find((signal) => signal.signal_id === 'economic_pressure')?.score ?? null,
      psychographic_age_structure_score: row.psychographics.signals.find((signal) => signal.signal_id === 'age_structure_context')?.score ?? null,
      psychographic_human_development_context_score: row.psychographics.signals.find((signal) => signal.signal_id === 'human_development_context')?.score ?? null,
      license_clearance: row.license_clearance,
    })),
    ...brandPremRes.data.map((row) => ({
      mode: 'premium',
      territory_id: row.territory_id,
      iso3: row.iso3,
      name_en: row.name_en,
      continent: row.continent,
      region: row.region,
      h3_res2: row.h3_res2,
      currency_iso4217: row.currency_iso4217,
      primary_language_iso639: row.primary_language_iso639,
      timezone: row.timezone,
      population_total: row.population_total,
      population_total_year: row.population_total_year,
      median_age: row.median_age,
      median_age_year: row.median_age_year,
      life_expectancy_years: row.life_expectancy_years,
      life_expectancy_years_year: row.life_expectancy_years_year,
      gdp_per_capita_ppp_2021: row.gdp_per_capita_ppp_2021,
      gdp_per_capita_ppp_2021_year: row.gdp_per_capita_ppp_2021_year,
      gini_index: row.gini_index,
      gini_index_year: row.gini_index_year,
      urbanization_pct: row.urbanization_pct,
      urbanization_pct_year: row.urbanization_pct_year,
      internet_users_pct: row.internet_users_pct,
      internet_users_pct_year: row.internet_users_pct_year,
      inflation_cpi_pct: row.inflation_cpi_pct,
      inflation_cpi_pct_year: row.inflation_cpi_pct_year,
      purchasing_power_tier: row.purchasing_power_tier,
      digital_addressable_pop: row.digital_addressable_pop,
      demographic_score: row.mai.demographic_score,
      purchasing_power_score: row.mai.purchasing_power_score,
      inflation_risk_multiplier: row.mai.inflation_risk_multiplier,
      market_attractiveness_score: row.mai.market_attractiveness_score,
      mai_methodology_version: row.mai.methodology_version,
      mai_data_coverage_pct: row.mai.data_coverage_pct,
      mai_temporal_status: row.mai.temporal_status,
      mai_oldest_data_year: row.mai.oldest_data_year,
      mai_newest_data_year: row.mai.newest_data_year,
      mai_missing_or_invalid_fields: row.mai.missing_or_invalid_fields.join(';'),
      psychographic_profile_version: row.psychographics.model_version,
      psychographic_validation_status: row.psychographics.validation_status,
      psychographic_data_coverage_pct: row.psychographics.data_coverage_pct,
      psychographic_data_fields_available: row.psychographics.data_fields_available,
      psychographic_data_fields_expected: row.psychographics.data_fields_expected,
      psychographic_invalid_fields: row.psychographics.invalid_fields.join(';'),
      psychographic_temporal_coverage_pct: row.psychographics.temporal_coverage_pct,
      psychographic_temporal_status: row.psychographics.temporal_status,
      psychographic_oldest_evidence_year: row.psychographics.oldest_evidence_year,
      psychographic_newest_evidence_year: row.psychographics.newest_evidence_year,
      psychographic_temporal_span_years: row.psychographics.temporal_span_years,
      psychographic_survey_evidence_count: row.psychographics.survey_evidence_count,
      psychographic_measured_survey_measures_json: JSON.stringify(row.psychographics.measured_survey_measures),
      psychographic_population_share_estimated: row.psychographics.population_share_estimated,
      psychographic_digital_discovery_score: row.psychographics.signals.find((signal) => signal.signal_id === 'digital_discovery')?.score ?? null,
      psychographic_value_sensitivity_score: row.psychographics.signals.find((signal) => signal.signal_id === 'value_sensitivity')?.score ?? null,
      psychographic_urban_cultural_access_score: row.psychographics.signals.find((signal) => signal.signal_id === 'urban_cultural_access')?.score ?? null,
      psychographic_economic_pressure_score: row.psychographics.signals.find((signal) => signal.signal_id === 'economic_pressure')?.score ?? null,
      psychographic_age_structure_score: row.psychographics.signals.find((signal) => signal.signal_id === 'age_structure_context')?.score ?? null,
      psychographic_human_development_context_score: row.psychographics.signals.find((signal) => signal.signal_id === 'human_development_context')?.score ?? null,
      license_clearance: row.license_clearance,
    })),
  ];

  const brandMart = await writeGoldMartParquet(
    'gold_brand_market_profiles',
    'TITAN_GOLD_BRAND_PROFILES',
    combinedBrandRows,
    'mode ASC, market_attractiveness_score DESC, iso3 ASC'
  );
  if (brandMart) built.push(brandMart);

  const h3Mart = await writeGoldMartParquet(
    'gold_h3_macro_rollup',
    'TITAN_GOLD_H3_MACRO',
    h3Res.data,
    'territory_count DESC, h3_res2 ASC'
  );
  if (h3Mart) built.push(h3Mart);

  return {
    marts: built,
    duration_ms: Date.now() - startedMs,
    silver_snapshot_count: silverPaths.length,
  };
}

export async function materializeAllGoldMarts(): Promise<GoldMaterializationReport> {
  if (inFlightMaterialization) {
    return inFlightMaterialization;
  }
  inFlightMaterialization = executeGoldMaterialization().finally(() => {
    inFlightMaterialization = null;
  });
  return inFlightMaterialization;
}

export async function ensureGoldMartsIfEmpty(): Promise<boolean> {
  const silverCount = listActiveSilverParquetPaths().length;
  const goldCount = getActiveGoldSnapshotCount();
  if (silverCount > 0 && goldCount === 0) {
    await materializeAllGoldMarts();
    return true;
  }
  return false;
}
