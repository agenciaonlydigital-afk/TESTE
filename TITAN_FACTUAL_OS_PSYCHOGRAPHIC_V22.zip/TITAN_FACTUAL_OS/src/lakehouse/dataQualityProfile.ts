import type { ObservationContract } from './types.ts';

export type QualityStatus = 'pass' | 'warning' | 'fail' | 'not_scored';
export interface DataQualityCheck {
  check_id: string;
  status: QualityStatus;
  observed: number | string | null;
  threshold: number | string | null;
  explanation: string;
}
export interface DataQualityProfile {
  raw_rows: number;
  validated_rows: number;
  schema_rejections: number;
  license_mismatches: number;
  duplicate_collisions: number;
  schema_acceptance_pct: number;
  duplicate_collision_pct: number;
  territory_count: number;
  indicator_count: number;
  period_year_min: number | null;
  period_year_max: number | null;
  latest_period_age_years: number | null;
  optional_field_completeness_pct: Record<string, number>;
  geographic_coverage_status: 'not_scored';
  checks: DataQualityCheck[];
  limitations: string[];
}

const OPTIONAL_FIELDS = [
  'survey_id', 'survey_wave_id', 'question_id', 'sample_size', 'effective_sample_size',
  'survey_weight', 'sampling_stratum', 'cluster_id', 'population_scope', 'weighting_method',
  'fieldwork_start', 'fieldwork_end', 'standard_error', 'questionnaire_url',
] as const;

function pct(numerator: number, denominator: number): number {
  return denominator === 0 ? 0 : Number(((numerator / denominator) * 100).toFixed(2));
}

/** Descriptive QA only. One-pass accumulation keeps memory and CPU bounded for large snapshots. */
export function buildDataQualityProfile(input: {
  rawRows: number;
  validated: readonly ObservationContract[];
  schemaRejections: number;
  licenseMismatches: number;
  duplicateCollisions: number;
  asOfYear?: number;
}): DataQualityProfile {
  const { rawRows, validated, schemaRejections, licenseMismatches, duplicateCollisions } = input;
  for (const [name, value] of Object.entries({ rawRows, schemaRejections, licenseMismatches, duplicateCollisions })) {
    if (!Number.isSafeInteger(value) || value < 0) throw new RangeError(`${name} must be a non-negative safe integer.`);
  }
  if (schemaRejections > rawRows) throw new RangeError('schema rejections cannot exceed raw rows.');
  if (licenseMismatches > rawRows - schemaRejections) throw new RangeError('license mismatches cannot exceed rows remaining after schema rejection.');
  if (duplicateCollisions > rawRows - schemaRejections - licenseMismatches) throw new RangeError('duplicate collisions cannot exceed rows remaining after schema and license rejection.');
  if (validated.length > rawRows - schemaRejections - licenseMismatches - duplicateCollisions) throw new RangeError('validated rows cannot exceed rows remaining after all rejection and deduplication counts.');
  const asOfYear = input.asOfYear ?? new Date().getUTCFullYear();
  if (!Number.isInteger(asOfYear) || asOfYear < 1900 || asOfYear > 2200) throw new RangeError('asOfYear is invalid.');

  const fieldCounts = new Array<number>(OPTIONAL_FIELDS.length).fill(0);
  const territories = new Set<string>();
  const indicators = new Set<string>();
  let minYear = Number.POSITIVE_INFINITY;
  let maxYear = Number.NEGATIVE_INFINITY;

  for (const row of validated) {
    if (typeof row.territory_id === 'string') territories.add(row.territory_id);
    if (typeof row.indicator_id === 'string') indicators.add(row.indicator_id);
    if (Number.isFinite(row.period_year)) {
      minYear = Math.min(minYear, row.period_year);
      maxYear = Math.max(maxYear, row.period_year);
    }
    for (let i = 0; i < OPTIONAL_FIELDS.length; i++) {
      const value = row[OPTIONAL_FIELDS[i]];
      if (value !== undefined && value !== null && value !== '') fieldCounts[i]++;
    }
  }

  const minPeriodYear = Number.isFinite(minYear) ? minYear : null;
  const maxPeriodYear = Number.isFinite(maxYear) ? maxYear : null;
  const periodAge = maxPeriodYear === null ? null : Math.max(0, asOfYear - maxPeriodYear);
  const optionalCompleteness = Object.fromEntries(OPTIONAL_FIELDS.map((field, index) => [
    field,
    pct(fieldCounts[index], validated.length),
  ]));
  const schemaAcceptance = pct(rawRows - schemaRejections, rawRows);
  const duplicateCollisionRate = pct(duplicateCollisions, rawRows);
  const checks: DataQualityCheck[] = [
    {
      check_id: 'non_empty_silver', status: validated.length > 0 ? 'pass' : 'fail', observed: validated.length,
      threshold: '> 0', explanation: 'At least one valid Silver record must survive schema and license validation.',
    },
    {
      check_id: 'schema_acceptance', status: schemaRejections === 0 ? 'pass' : schemaAcceptance >= 95 ? 'warning' : 'fail',
      observed: schemaAcceptance, threshold: '>= 95%', explanation: 'Share of raw rows that passed the observation schema; invalid rows are not silently repaired.',
    },
    {
      check_id: 'license_integrity', status: licenseMismatches === 0 ? 'pass' : 'fail', observed: licenseMismatches,
      threshold: 0, explanation: 'Rows with a commercial rights value inconsistent with the source catalog were rejected.',
    },
    {
      check_id: 'duplicate_collisions', status: duplicateCollisions === 0 ? 'pass' : 'warning', observed: duplicateCollisions,
      threshold: 0, explanation: 'Duplicate identity collisions were deterministically resolved using the newest assertion timestamp.',
    },
    {
      check_id: 'period_vintage', status: periodAge === null ? 'not_scored' : periodAge > 5 ? 'warning' : 'pass',
      observed: periodAge, threshold: '<= 5 years', explanation: 'Age of the newest observation period, not API fetch freshness.',
    },
    {
      check_id: 'geographic_coverage', status: 'not_scored', observed: null, threshold: 'source-specific expected territory set',
      explanation: 'No global coverage percentage is asserted without an explicit expected territory universe per indicator and period.',
    },
  ];

  return {
    raw_rows: rawRows,
    validated_rows: validated.length,
    schema_rejections: schemaRejections,
    license_mismatches: licenseMismatches,
    duplicate_collisions: duplicateCollisions,
    schema_acceptance_pct: schemaAcceptance,
    duplicate_collision_pct: duplicateCollisionRate,
    territory_count: territories.size,
    indicator_count: indicators.size,
    period_year_min: minPeriodYear,
    period_year_max: maxPeriodYear,
    latest_period_age_years: periodAge,
    optional_field_completeness_pct: optionalCompleteness,
    geographic_coverage_status: 'not_scored',
    checks,
    limitations: [
      'Completeness measures field presence, not correctness, representativeness or semantic validity.',
      'Period vintage is not a measure of source refresh latency.',
      'Geographic coverage is intentionally not scored without source-specific expected territories.',
    ],
  };
}
