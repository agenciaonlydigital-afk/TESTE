/** Canonical, exhaustive domain taxonomy for TITAN's 13-part data factory. */
export interface DomainModule { id: number; name: string; purpose: string; layer: 'data_domain' | 'derived_intelligence' | 'serving'; }

export const DOMAIN_MODULES: readonly DomainModule[] = [
  { id: 1, name: "Cadastro Territorial Global", purpose: "Cadastro, aliases, limites administrativos, geocodificação e referências territoriais.", layer: "data_domain" },
  { id: 2, name: "Economia Global", purpose: "Macroeconomia, finanças, renda, preços, trabalho e desigualdade econômica.", layer: "data_domain" },
  { id: 3, name: "Demografia Mundial", purpose: "População, estrutura etária, migração, urbanização, domicílios e distribuição populacional.", layer: "data_domain" },
  { id: 4, name: "Meio Ambiente e Clima", purpose: "Clima, ecossistemas, biodiversidade, cobertura terrestre e riscos naturais.", layer: "data_domain" },
  { id: 5, name: "Energia", purpose: "Produção, consumo, capacidade, matriz e transição energética.", layer: "data_domain" },
  { id: 6, name: "Comércio Internacional", purpose: "Fluxos bilaterais, comércio exterior, indústria e integração comercial.", layer: "data_domain" },
  { id: 7, name: "Transporte e Logística", purpose: "Aviação, navegação, redes de transporte, infraestrutura e conectividade física.", layer: "data_domain" },
  { id: 8, name: "Agricultura e Recursos Naturais", purpose: "Agricultura, produção agropecuária, alimentação, terra e recursos naturais.", layer: "data_domain" },
  { id: 9, name: "Saúde Global", purpose: "Saúde pública, epidemiologia, mortalidade e sistemas de saúde.", layer: "data_domain" },
  { id: 10, name: "Educação, Ciência e Tecnologia", purpose: "Educação, pesquisa, inovação, propriedade intelectual, TIC e sinais digitais/culturais de apoio.", layer: "data_domain" },
  { id: 11, name: "Governança e Desenvolvimento", purpose: "Instituições, desenvolvimento humano, segurança, conflitos e transparência pública.", layer: "data_domain" },
  { id: 12, name: "Feature Engineering e Inteligência Territorial", purpose: "Harmonização, variáveis derivadas, índices, agregações e inteligência territorial.", layer: "derived_intelligence" },
  { id: 13, name: "Data Warehouse, APIs e Dashboards", purpose: "Data products, armazenamento, APIs, dashboards, distribuição e observabilidade.", layer: "serving" },
] as const;

export const SOURCE_DOMAIN_MAP: Readonly<Record<string, number>> = {
  natural_earth_bulk: 1,
  geonames_dumps: 1,
  geonames_ws: 1,
  geoboundaries_open: 1,
  gadm_boundaries: 1,
  arcgis_rest_platform: 1,
  ogc_stac_ecosystem: 1,
  overture_maps_geoparquet: 1,
  wikidata_sparql: 1,
  world_bank_wdi: 2,
  world_bank_sdmx: 2,
  imf_datamapper: 2,
  imf_sdmx_3: 2,
  ilostat_sdmx: 2,
  oecd_sdmx: 2,
  eurostat_stats_api: 2,
  eurostat_sdmx: 2,
  eurostat_sdmx_3: 2,
  eurostat_catalogue: 2,
  bis_sdmx_v2: 2,
  ecb_sdmx: 2,
  statcan_wds: 2,
  uk_ons_api: 2,
  abs_data_api: 2,
  ibge_sidra: 2,
  statfin_pxweb: 2,
  undata_sdmx: 2,
  world_bank_pip: 2,
  wid_world_bulk: 2,
  unu_wider_wiid: 2,
  oecd_regional_sdmx: 2,
  pwt_penn_world_table: 2,
  us_census_api: 3,
  un_wpp_rest_api: 3,
  unicef_sdmx: 3,
  worldpop_catalog: 3,
  worldpop_adv_v1: 3,
  worldpop_global2_v2: 3,
  unhcr_population_v1: 3,
  owid_inequality_demo: 3,
  un_wpp_bulk: 3,
  ghsl_jrc_bulk: 3,
  sedac_gpw: 3,
  un_habitat_urban: 3,
  nasa_cmr: 4,
  nasa_open_apis: 4,
  noaa_ncei_cdo: 4,
  copernicus_cds: 4,
  copernicus_cdse: 4,
  global_forest_watch: 4,
  gbif_occurrence: 4,
  obis_v3: 4,
  undrr_datum: 4,
  emdat_disaster: 4,
  usgs_earthquake_v1: 4,
  climate_trace_v7: 4,
  protected_planet_wdpa: 4,
  eia_api_v2: 5,
  iea_releases_api: 5,
  unsd_energy_sdmx: 5,
  ember_energy_bulk: 5,
  un_comtrade_full: 6,
  wto_timeseries: 6,
  wb_wits_rest: 6,
  unido_stats: 6,
  unctad_stat: 6,
  cepii_baci_gravity: 6,
  imo_gisis: 7,
  osm_overpass: 7,
  icao_api_service: 7,
  un_locode_bulk: 7,
  faostat_api: 8,
  faostat_bulk: 8,
  who_gho_odata: 9,
  unesco_uis_api: 10,
  unesco_uis_bulk: 10,
  itu_datahub: 10,
  openalex_works_v1: 10,
  crossref_polite: 10,
  datacite_rest: 10,
  wipo_ip_stats: 10,
  wikimedia_pageviews: 10,
  musicbrainz_api: 10,
  listenbrainz_api: 10,
  undp_hdr_dataprism: 11,
  un_sdg_api: 11,
  vdem_releases: 11,
  unodc_data_portal: 11,
  ckan_action_api: 11,
  socrata_soda: 11,
  india_ogd_platform: 11,
  us_datagov_ckan: 11,
  uk_datagov_ckan: 11,
  gdelt_doc_v2: 11,
  ucdp_conflict: 11,
};

const moduleById = new Map(DOMAIN_MODULES.map((module) => [module.id, module]));

export function getDomainModule(moduleId: number): DomainModule | undefined {
  return moduleById.get(moduleId);
}

export function getSourceDomainId(sourceId: string, fallbackModuleId: number): number {
  return SOURCE_DOMAIN_MAP[sourceId] ?? fallbackModuleId;
}

export function getDomainModuleSummary() {
  const counts = new Map<number, number>();
  for (const moduleId of Object.values(SOURCE_DOMAIN_MAP)) counts.set(moduleId, (counts.get(moduleId) ?? 0) + 1);
  return DOMAIN_MODULES.map((module) => ({ ...module, catalogued_sources: counts.get(module.id) ?? 0 }));
}

/** Rewrites legacy connector module IDs only at the ingestion boundary; connector bodies stay untouched. */
export function applySourceDomainToObservations<T extends { module_id: number }>(sourceId: string, fallbackModuleId: number, observations: T[]): T[] {
  const moduleId = getSourceDomainId(sourceId, fallbackModuleId);
  return observations.map((observation) => ({ ...observation, module_id: moduleId }));
}
