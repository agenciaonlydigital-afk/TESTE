import { AsyncLocalStorage } from 'node:async_hooks';
import fs from 'node:fs';
import path from 'node:path';
import { streamBodyToDiskWithHash } from './connectors/httpStream.ts';
import { buildHttpRequestDedupKey } from './httpRequestIdentity.ts';
import { HttpTempFileReferenceTracker } from './httpTempFileReferences.ts';
import {
  isRetryableFetchFailure,
  isRetryableHttpStatus,
  parseRetryAfter,
  retryBackoffMs,
  retryNetworkBackoffMs,
} from './connectors/httpRetryPolicy.ts';
import {
  getCircuitBreaker,
  getHttpResourceCache,
  recordHostFailure,
  recordHostSuccess,
  upsertHttpResourceCache,
} from './controlPlane.ts';

const USER_AGENT = 'TITAN-FACTUAL-OS/1.0 (+mailto:research@titan-factual.local)';

class HttpStatusFailure extends Error {
  constructor(
    readonly status: number,
    statusText: string,
    readonly retryAfter: string | null,
    url: string,
  ) {
    super(`HTTP ${status}${statusText ? ` (${statusText})` : ''} from ${url}`);
    this.name = 'HttpStatusFailure';
  }
}

const refreshContext = new AsyncLocalStorage<{ forceRefresh: boolean }>();

export function isForceRefreshActive(): boolean {
  return Boolean(refreshContext.getStore()?.forceRefresh);
}

export function runWithForceRefresh<T>(forceRefresh: boolean, fn: () => Promise<T>): Promise<T> {
  if (!forceRefresh) return fn();
  return refreshContext.run({ forceRefresh: true }, fn);
}

interface HostLimiterState {
  tokens: number;
  maxTokens: number;
  refillPerMs: number;
  lastRefill: number;
  active: number;
  maxConcurrency: number;
  waitQueue: Array<() => void>;
}

const hostLimiters = new Map<string, HostLimiterState>();
interface InFlightRequest {
  promise: Promise<FetchStreamResult>;
  consumers: number;
}
const inFlightRequests = new Map<string, InFlightRequest>();
const tempFileReferences = new HttpTempFileReferenceTracker();
const hostLatencySamples = new Map<string, number[]>();

function recordHostLatency(host: string, durationMs: number): void {
  const arr = hostLatencySamples.get(host) ?? [];
  arr.push(durationMs);
  if (arr.length > 50) arr.shift();
  hostLatencySamples.set(host, arr);
}

export function getHostHttpMetrics(): Array<{
  host: string;
  sampleCount: number;
  avgMs: number;
  p95Ms: number;
}> {
  const out: Array<{ host: string; sampleCount: number; avgMs: number; p95Ms: number }> = [];
  for (const [host, samples] of hostLatencySamples.entries()) {
    if (samples.length === 0) continue;
    const sorted = [...samples].sort((a, b) => a - b);
    const sum = sorted.reduce((acc, v) => acc + v, 0);
    const p95Idx = Math.min(sorted.length - 1, Math.floor(sorted.length * 0.95));
    out.push({
      host,
      sampleCount: sorted.length,
      avgMs: Math.round(sum / sorted.length),
      p95Ms: Math.round(sorted[p95Idx]),
    });
  }
  return out.sort((a, b) => a.host.localeCompare(b.host));
}

export interface FetchOptions {
  url: string;
  host: string;
  rateLimitRpm: number;
  maxConcurrency: number;
  method?: 'GET' | 'POST';
  body?: string;
  etag?: string | null;
  lastModified?: string | null;
  bypassConditionalCache?: boolean;
  headers?: Record<string, string>;
  timeoutMs?: number;
  destPrefix: string;
}

export interface FetchStreamResult {
  status: 'OK' | 'NOT_MODIFIED' | 'CIRCUIT_OPEN';
  httpStatus: number;
  filePath: string | null;
  sha256: string | null;
  byteSize: number;
  etag: string | null;
  lastModified: string | null;
  dedupHit: boolean;
  responseHeaders?: Record<string, string>;
}

function getLimiter(host: string, rpm: number, maxConcurrency: number): HostLimiterState {
  const existing = hostLimiters.get(host);
  if (existing) {
    existing.maxTokens = Math.max(1, Math.min(10, Math.ceil(rpm / 12)));
    existing.refillPerMs = rpm / 60_000;
    existing.maxConcurrency = Math.max(1, maxConcurrency);
    return existing;
  }
  const initial: HostLimiterState = {
    tokens: Math.max(1, Math.min(10, Math.ceil(rpm / 12))),
    maxTokens: Math.max(1, Math.min(10, Math.ceil(rpm / 12))),
    refillPerMs: rpm / 60_000,
    lastRefill: Date.now(),
    active: 0,
    maxConcurrency: Math.max(1, maxConcurrency),
    waitQueue: [],
  };
  hostLimiters.set(host, initial);
  return initial;
}

function refillTokens(limiter: HostLimiterState): void {
  const now = Date.now();
  const elapsed = now - limiter.lastRefill;
  if (elapsed > 0) {
    limiter.tokens = Math.min(limiter.maxTokens, limiter.tokens + elapsed * limiter.refillPerMs);
    limiter.lastRefill = now;
  }
}

async function acquireSlot(host: string, rpm: number, maxConcurrency: number): Promise<() => void> {
  const limiter = getLimiter(host, rpm, maxConcurrency);

  while (true) {
    refillTokens(limiter);
    if (limiter.active < limiter.maxConcurrency && limiter.tokens >= 1) {
      limiter.tokens -= 1;
      limiter.active += 1;
      return () => {
        limiter.active = Math.max(0, limiter.active - 1);
        const next = limiter.waitQueue.shift();
        if (next) next();
      };
    }

    const waitMs =
      limiter.tokens < 1
        ? Math.max(40, Math.ceil((1 - limiter.tokens) / limiter.refillPerMs))
        : 60;

    await new Promise<void>((resolve) => {
      let settled = false;
      let wake: (() => void) | undefined;
      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        if (wake) {
          const queuedIndex = limiter.waitQueue.indexOf(wake);
          if (queuedIndex >= 0) limiter.waitQueue.splice(queuedIndex, 1);
        }
        resolve();
      }, waitMs);
      wake = () => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve();
      };
      limiter.waitQueue.push(wake);
    });
  }
}

export function releaseFetchedTempFile(filePath: string): void {
  if (!tempFileReferences.release(filePath)) return;
  try {
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
  } catch {
    // ignore cleanup error; maintenance removes stale temp artifacts later
  }
}

function safeUnlinkTmp(filePath: string): void {
  releaseFetchedTempFile(filePath);
}

export async function fetchWithCitizenship(options: FetchOptions): Promise<FetchStreamResult> {
  const method = options.method ?? 'GET';
  const bypassCache = Boolean(options.bypassConditionalCache) || isForceRefreshActive() || method !== 'GET';
  const cachedResource = bypassCache ? undefined : getHttpResourceCache(options.url);
  const effectiveEtag = bypassCache ? null : (options.etag ?? cachedResource?.etag ?? null);
  const effectiveLastModified = bypassCache
    ? null
    : (options.lastModified ?? cachedResource?.last_modified ?? null);

  const dedupKey = buildHttpRequestDedupKey({
    method,
    url: options.url,
    body: options.body,
    etag: effectiveEtag,
    lastModified: effectiveLastModified,
    bypassCache,
    headers: options.headers,
  });

  const existingRequest = inFlightRequests.get(dedupKey);
  if (existingRequest) {
    // Increment before awaiting: the first consumer may finish parsing and
    // request cleanup as soon as the shared response resolves.
    existingRequest.consumers += 1;
    const shared = await existingRequest.promise;
    return { ...shared, dedupHit: true };
  }

  const request: InFlightRequest = {
    promise: executeFetchWithResilience({
      ...options,
      method,
      etag: effectiveEtag,
      lastModified: effectiveLastModified,
    }),
    consumers: 1,
  };
  inFlightRequests.set(dedupKey, request);

  try {
    const result = await request.promise;
    if (result.filePath && request.consumers > 1) {
      tempFileReferences.register(result.filePath, request.consumers);
    }
    return result;
  } finally {
    if (inFlightRequests.get(dedupKey) === request) inFlightRequests.delete(dedupKey);
  }
}

export async function fetchWithFallback(
  primary: FetchOptions,
  fallbacks: FetchOptions[]
): Promise<{ result: FetchStreamResult; usedFallbackIndex: number }> {
  const candidates = [primary, ...fallbacks];
  let lastError: unknown = null;
  for (let i = 0; i < candidates.length; i++) {
    try {
      const res = await fetchWithCitizenship(candidates[i]);
      if (res.status === 'CIRCUIT_OPEN') {
        lastError = new Error(`Circuit breaker OPEN for ${candidates[i].host}`);
        continue;
      }
      return { result: res, usedFallbackIndex: i };
    } catch (err) {
      lastError = err;
    }
  }
  throw lastError instanceof Error ? lastError : new Error(String(lastError ?? 'All fetch candidates failed'));
}

export interface ConsistentBatchResult {
  allNotModified: boolean;
  results: Array<FetchStreamResult | null>;
  errors: Array<{ index: number; error: string }>;
  hydratedFromCacheBypass: number;
}

export async function fetchConsistentBatch(
  specs: FetchOptions[],
  options: { bypassCache?: boolean; allowPartialErrors?: boolean } = {}
): Promise<ConsistentBatchResult> {
  if (specs.length === 0) {
    return { allNotModified: false, results: [], errors: [], hydratedFromCacheBypass: 0 };
  }

  const results: Array<FetchStreamResult | null> = new Array(specs.length).fill(null);
  const errors: Array<{ index: number; error: string }> = [];

  try {
    for (let i = 0; i < specs.length; i++) {
      try {
        results[i] = await fetchWithCitizenship({
          ...specs[i],
          bypassConditionalCache: Boolean(options.bypassCache || specs[i].bypassConditionalCache),
        });
      } catch (err) {
        if (!options.allowPartialErrors) {
          throw err;
        }
        errors.push({
          index: i,
          error: err instanceof Error ? err.message : String(err),
        });
      }
    }

    const okCount = results.filter((r) => r?.status === 'OK').length;
    const notModifiedCount = results.filter((r) => r?.status === 'NOT_MODIFIED').length;
    const circuitOpenCount = results.filter((r) => r?.status === 'CIRCUIT_OPEN').length;

    if (
      !options.bypassCache &&
      okCount === 0 &&
      errors.length === 0 &&
      circuitOpenCount === 0 &&
      notModifiedCount === specs.length
    ) {
      return {
        allNotModified: true,
        results,
        errors,
        hydratedFromCacheBypass: 0,
      };
    }

    let hydratedFromCacheBypass = 0;
    if (notModifiedCount > 0 && (okCount > 0 || errors.length > 0 || Boolean(options.bypassCache))) {
      for (let i = 0; i < specs.length; i++) {
        if (results[i]?.status === 'NOT_MODIFIED') {
          try {
            results[i] = await fetchWithCitizenship({
              ...specs[i],
              bypassConditionalCache: true,
            });
            hydratedFromCacheBypass++;
          } catch (err) {
            if (!options.allowPartialErrors) {
              throw err;
            }
            errors.push({
              index: i,
              error: err instanceof Error ? err.message : String(err),
            });
          }
        }
      }
    }

    return {
      allNotModified: false,
      results,
      errors,
      hydratedFromCacheBypass,
    };
  } catch (err) {
    for (const r of results) {
      if (r?.filePath) {
        safeUnlinkTmp(r.filePath);
      }
    }
    throw err;
  }
}

async function executeFetchWithResilience(options: FetchOptions): Promise<FetchStreamResult> {
  const breaker = getCircuitBreaker(options.host);
  if (breaker.state === 'OPEN') {
    return {
      status: 'CIRCUIT_OPEN',
      httpStatus: 503,
      filePath: null,
      sha256: null,
      byteSize: 0,
      etag: options.etag ?? breaker.last_etag,
      lastModified: options.lastModified ?? breaker.last_modified,
      dedupHit: false,
    };
  }

  const maxAttempts = 3;
  let lastError = 'Unknown fetch failure';

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    const release = await acquireSlot(options.host, options.rateLimitRpm, options.maxConcurrency);
    const reqStartedMs = Date.now();
    let timeout: ReturnType<typeof setTimeout> | undefined;
    let retryDelayMs: number | null = null;

    try {
      const controller = new AbortController();
      timeout = setTimeout(() => {
        controller.abort(new DOMException('HTTP request/body timeout', 'TimeoutError'));
      }, options.timeoutMs ?? 25_000);

      const method = options.method ?? 'GET';
      const headers: Record<string, string> = {
        'User-Agent': USER_AGENT,
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept-Language': 'en',
        Accept: 'application/json, text/csv, */*;q=0.8',
        ...options.headers,
      };
      if (method === 'GET') {
        if (options.etag) headers['If-None-Match'] = options.etag;
        if (options.lastModified) headers['If-Modified-Since'] = options.lastModified;
      }

      const response = await fetch(options.url, {
        method,
        headers,
        body: method === 'POST' ? options.body : undefined,
        signal: controller.signal,
      });

      if (response.status === 304) {
        await response.body?.cancel().catch(() => undefined);
        recordHostLatency(options.host, Date.now() - reqStartedMs);
        const nextEtag = response.headers.get('etag') ?? options.etag ?? null;
        const nextLastModified = response.headers.get('last-modified') ?? options.lastModified ?? null;
        recordHostSuccess(options.host, nextEtag, nextLastModified);
        upsertHttpResourceCache({
          url: options.url,
          host: options.host,
          etag: nextEtag,
          lastModified: nextLastModified,
          contentSha256: null,
        });
        return {
          status: 'NOT_MODIFIED',
          httpStatus: 304,
          filePath: null,
          sha256: null,
          byteSize: 0,
          etag: nextEtag,
          lastModified: nextLastModified,
          dedupHit: false,
        };
      }

      if (!response.ok) {
        await response.body?.cancel().catch(() => undefined);
        throw new HttpStatusFailure(
          response.status,
          response.statusText,
          response.headers.get('retry-after'),
          options.url,
        );
      }
      if (!response.body) {
        throw new Error(`HTTP ${response.status} returned an empty response body from ${options.url}`);
      }

      const tmpDir = path.resolve(process.cwd(), 'data', 'tmp');
      const tmpFile = path.join(
        tmpDir,
        `${options.destPrefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}.tmp`
      );

      // The AbortController timeout is deliberately kept alive until the full
      // response body has been streamed and flushed to disk.
      const { sha256, byteSize } = await streamBodyToDiskWithHash(response.body, tmpFile, controller.signal);
      recordHostLatency(options.host, Date.now() - reqStartedMs);

      const etag = response.headers.get('etag');
      const lastModified = response.headers.get('last-modified');

      recordHostSuccess(options.host, etag, lastModified);
      if (method === 'GET') {
        upsertHttpResourceCache({
          url: options.url,
          host: options.host,
          etag,
          lastModified,
          contentSha256: sha256,
        });
      }

      return {
        status: 'OK',
        httpStatus: response.status,
        filePath: tmpFile,
        sha256,
        byteSize,
        etag,
        lastModified,
        dedupHit: false,
        responseHeaders: {
          ...(response.headers.get('cmr-hits') ? { 'cmr-hits': response.headers.get('cmr-hits')! } : {}),
          ...(response.headers.get('content-type') ? { 'content-type': response.headers.get('content-type')! } : {}),
        },
      };
    } catch (err) {
      lastError = err instanceof Error ? err.message : String(err);
      if (err instanceof HttpStatusFailure) {
        if (!isRetryableHttpStatus(err.status)) {
          // Authentication, permission, missing-resource and other permanent
          // 4xx responses are terminal and do not poison the host circuit.
          throw err;
        }
        if (attempt === maxAttempts - 1) {
          recordHostFailure(options.host, lastError);
          throw err;
        }
        retryDelayMs = parseRetryAfter(err.retryAfter) ?? retryBackoffMs(attempt);
      } else if (isRetryableFetchFailure(err)) {
        if (attempt === maxAttempts - 1) {
          recordHostFailure(options.host, lastError);
          throw err;
        }
        retryDelayMs = retryNetworkBackoffMs(attempt);
      } else {
        // Filesystem and programming errors are not remote-host failures.
        throw err;
      }
    } finally {
      if (timeout) clearTimeout(timeout);
      release();
    }

    // Do not hold a host concurrency slot while waiting for Retry-After/backoff.
    if (retryDelayMs !== null) {
      await new Promise((resolve) => setTimeout(resolve, retryDelayMs));
      continue;
    }
  }

  throw new Error(lastError);
}
