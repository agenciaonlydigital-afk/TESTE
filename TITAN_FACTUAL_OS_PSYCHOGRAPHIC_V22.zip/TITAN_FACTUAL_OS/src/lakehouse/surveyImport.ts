import { estimateSurveyWeightedDistribution, estimateSurveyWeightedMean, surveyDistributionToObservations, surveyMeanEstimateToObservation, type SurveyDistributionEstimate, type SurveyMeanEstimate, type SurveyMicrodataRecord, type SurveyObservationContext } from './surveyAnalytics.ts';
import type { ObservationContract, PsychographicConstructDomain } from './types.ts';

export type SurveyResponseTransform =
  | {
      kind: 'linear';
      source_min: number;
      source_max: number;
      target_min: number;
      target_max: number;
      reverse?: boolean;
      missing_values?: readonly string[];
    }
  | {
      kind: 'categorical';
      value_map: Readonly<Record<string, number>>;
      missing_values?: readonly string[];
    };

export interface SurveyQuestionHarmonization {
  source_question_id: string;
  construct_id: string;
  canonical_scale_id: string;
  mapping_version: string;
  construct_label?: string;
  construct_domain?: PsychographicConstructDomain;
  transform: SurveyResponseTransform;
}

export interface SurveyCsvColumnMap {
  country_iso3: string;
  question_id: string;
  response: string;
  final_weight: string;
  stratum_id?: string;
  psu_id?: string;
}

export interface SurveyCsvImportConfig {
  survey_id: string;
  wave_id: string;
  columns: SurveyCsvColumnMap;
  question_mappings: readonly SurveyQuestionHarmonization[];
  delimiter?: ',' | ';' | '\t' | '|';
  maximum_rows?: number;
  maximum_bytes?: number;
}

export interface HarmonizedSurveyMicrodataRecord extends SurveyMicrodataRecord {
  source_question_id: string;
  construct_id: string;
  canonical_scale_id: string;
  mapping_version: string;
  construct_label: string;
  construct_domain: PsychographicConstructDomain;
  canonical_scale_min: number;
  canonical_scale_max: number;
}

export interface SurveyCsvImportResult {
  records: HarmonizedSurveyMicrodataRecord[];
  input_rows: number;
  imported_rows: number;
  excluded_missing_response_rows: number;
  excluded_unmapped_question_rows: number;
  question_mapping_counts: Record<string, number>;
  warnings: string[];
}

function parseCsv(text: string, delimiter: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let quoted = false;
  let afterQuote = false;
  const input = text.charCodeAt(0) === 0xfeff ? text.slice(1) : text;

  const finishField = () => {
    row.push(field);
    field = '';
    afterQuote = false;
  };
  const finishRow = () => {
    finishField();
    if (row.some((value) => value.trim().length > 0)) rows.push(row);
    row = [];
  };

  for (let index = 0; index < input.length; index++) {
    const character = input[index]!;
    if (quoted) {
      if (character === '"') {
        if (input[index + 1] === '"') {
          field += '"';
          index++;
        } else {
          quoted = false;
          afterQuote = true;
        }
      } else {
        field += character;
      }
      continue;
    }
    if (afterQuote && character !== delimiter && character !== '\r' && character !== '\n') {
      throw new Error(`Invalid CSV: unexpected character after closing quote at offset ${index}.`);
    }
    if (character === '"') {
      if (field.length !== 0) throw new Error(`Invalid CSV: quote inside an unquoted field at offset ${index}.`);
      quoted = true;
    } else if (character === delimiter) {
      finishField();
    } else if (character === '\n') {
      finishRow();
    } else if (character === '\r') {
      if (input[index + 1] === '\n') index++;
      finishRow();
    } else {
      field += character;
    }
  }
  if (quoted) throw new Error('Invalid CSV: unterminated quoted field.');
  if (field.length > 0 || row.length > 0 || afterQuote) finishRow();
  return rows;
}

function finiteNumber(value: string, label: string): number {
  const parsed = Number(value.trim());
  if (!value.trim() || !Number.isFinite(parsed)) throw new Error(`${label} must contain a finite number.`);
  return parsed;
}

function validateQuestionMappings(mappings: readonly SurveyQuestionHarmonization[]): Map<string, SurveyQuestionHarmonization> {
  if (mappings.length === 0) throw new Error('At least one explicit question harmonization mapping is required.');
  const output = new Map<string, SurveyQuestionHarmonization>();
  for (const mapping of mappings) {
    if (!mapping.source_question_id?.trim() || mapping.source_question_id.length > 160
      || !mapping.construct_id?.trim() || mapping.construct_id.length > 120
      || !mapping.canonical_scale_id?.trim() || !mapping.mapping_version?.trim()) {
      throw new Error('Question mapping IDs, construct, canonical scale and mapping version are required.');
    }
    if (output.has(mapping.source_question_id)) throw new Error(`Duplicate question mapping for ${mapping.source_question_id}.`);
    if (mapping.construct_label !== undefined && (!mapping.construct_label.trim() || mapping.construct_label.length > 160)) throw new Error(`Construct label for ${mapping.source_question_id} must contain 1–160 characters.`);
    if (mapping.construct_domain !== undefined && !['values', 'attitudes', 'interests', 'lifestyle', 'motivations', 'identity', 'media_use', 'music_engagement', 'social_orientation', 'other'].includes(mapping.construct_domain)) throw new Error(`Construct domain for ${mapping.source_question_id} is unsupported.`);
    if (mapping.transform.kind === 'linear') {
      const { source_min, source_max, target_min, target_max } = mapping.transform;
      if (![source_min, source_max, target_min, target_max].every(Number.isFinite)
        || source_min >= source_max || target_min >= target_max) {
        throw new Error(`Linear question mapping ${mapping.source_question_id} has invalid source/target bounds.`);
      }
    } else if (mapping.transform.kind === 'categorical') {
      const values = Object.values(mapping.transform.value_map);
      if (values.length === 0 || values.some((value) => !Number.isFinite(value))) {
        throw new Error(`Categorical question mapping ${mapping.source_question_id} must map explicit response labels to finite numeric scores.`);
      }
    } else {
      throw new Error(`Unsupported response transform for ${mapping.source_question_id}.`);
    }
    canonicalScaleBounds(mapping);
    output.set(mapping.source_question_id, mapping);
  }
  return output;
}


function canonicalScaleBounds(mapping: SurveyQuestionHarmonization): { min: number; max: number } {
  if (mapping.transform.kind === 'linear') {
    return { min: mapping.transform.target_min, max: mapping.transform.target_max };
  }
  const values = [...new Set(Object.values(mapping.transform.value_map))];
  const min = Math.min(...values);
  const max = Math.max(...values);
  if (!Number.isFinite(min) || !Number.isFinite(max) || min >= max) {
    throw new Error(`Categorical question mapping ${mapping.source_question_id} must define at least two distinct ordered canonical response values.`);
  }
  return { min, max };
}

function transformResponse(rawValue: string, transform: SurveyResponseTransform): number | null {
  const normalized = rawValue.trim();
  if (!normalized || (transform.missing_values ?? []).some((value) => value.trim() === normalized)) return null;
  if (transform.kind === 'categorical') {
    if (!Object.prototype.hasOwnProperty.call(transform.value_map, normalized)) {
      throw new Error(`Response '${normalized}' is not present in the explicit categorical harmonization map.`);
    }
    return transform.value_map[normalized]!;
  }
  const value = finiteNumber(normalized, 'Numeric survey response');
  if (value < transform.source_min || value > transform.source_max) {
    throw new Error(`Numeric survey response ${value} falls outside the configured source scale.`);
  }
  const position = (value - transform.source_min) / (transform.source_max - transform.source_min);
  const alignedPosition = transform.reverse ? 1 - position : position;
  return transform.target_min + alignedPosition * (transform.target_max - transform.target_min);
}

/**
 * Imports a documented long-format CSV exchange file. It never guesses question
 * semantics: every imported question must have an explicit versioned mapping,
 * final survey weights are mandatory, and respondent identifiers are not retained.
 */
export function importHarmonizedSurveyCsv(text: string, config: SurveyCsvImportConfig): SurveyCsvImportResult {
  if (!config.survey_id?.trim() || config.survey_id.length > 120 || !config.wave_id?.trim() || config.wave_id.length > 120) {
    throw new Error('survey_id and wave_id are required and must fit the survey contract.');
  }
  const delimiter = config.delimiter ?? ',';
  if (![',', ';', '\t', '|'].includes(delimiter)) throw new Error('Unsupported CSV delimiter.');
  const maximumBytes = config.maximum_bytes ?? 100 * 1024 * 1024;
  const maximumRows = config.maximum_rows ?? 1_000_000;
  if (!Number.isInteger(maximumBytes) || maximumBytes < 1 || new TextEncoder().encode(text).byteLength > maximumBytes) {
    throw new RangeError('Survey CSV exceeds maximum_bytes.');
  }
  if (!Number.isInteger(maximumRows) || maximumRows < 1) throw new RangeError('maximum_rows must be a positive integer.');
  if (Boolean(config.columns.stratum_id) !== Boolean(config.columns.psu_id)) {
    throw new Error('stratum_id and psu_id columns must be configured together.');
  }
  const questionMappings = validateQuestionMappings(config.question_mappings);
  const table = parseCsv(text, delimiter);
  if (table.length < 2) throw new Error('Survey CSV must include a header and at least one data row.');
  const headers = table[0]!.map((header) => header.trim());
  if (headers.some((header) => !header)) throw new Error('Survey CSV headers cannot be empty.');
  if (new Set(headers).size !== headers.length) throw new Error('Survey CSV contains duplicate column names.');
  const requestedColumns = [config.columns.country_iso3, config.columns.question_id, config.columns.response, config.columns.final_weight,
    ...(config.columns.stratum_id ? [config.columns.stratum_id] : []), ...(config.columns.psu_id ? [config.columns.psu_id] : [])];
  const indices = new Map<string, number>();
  for (const name of requestedColumns) {
    const index = headers.indexOf(name);
    if (index < 0) throw new Error(`Survey CSV is missing required configured column '${name}'.`);
    indices.set(name, index);
  }
  const dataRows = table.slice(1);
  if (dataRows.length > maximumRows) throw new RangeError(`Survey CSV has ${dataRows.length} rows; maximum_rows is ${maximumRows}.`);

  const records: HarmonizedSurveyMicrodataRecord[] = [];
  let excludedMissingResponseRows = 0;
  let excludedUnmappedQuestionRows = 0;
  const questionMappingCountMap = new Map<string, number>();
  for (let rowIndex = 0; rowIndex < dataRows.length; rowIndex++) {
    const row = dataRows[rowIndex]!;
    if (row.length !== headers.length) throw new Error(`Survey CSV row ${rowIndex + 2} has ${row.length} fields; expected ${headers.length}.`);
    const get = (name: string) => row[indices.get(name)!] ?? '';
    const sourceQuestionId = get(config.columns.question_id).trim();
    if (!sourceQuestionId) throw new Error(`Survey CSV row ${rowIndex + 2} has an empty question ID.`);
    const mapping = questionMappings.get(sourceQuestionId);
    if (!mapping) {
      excludedUnmappedQuestionRows++;
      continue;
    }
    const responseNumeric = transformResponse(get(config.columns.response), mapping.transform);
    if (responseNumeric === null) {
      excludedMissingResponseRows++;
      continue;
    }
    const countryIso3 = get(config.columns.country_iso3).trim();
    if (!/^[A-Z]{3}$/.test(countryIso3)) throw new Error(`Survey CSV row ${rowIndex + 2} has invalid uppercase ISO alpha-3 country code.`);
    const finalWeight = finiteNumber(get(config.columns.final_weight), `Survey CSV row ${rowIndex + 2} final weight`);
    if (finalWeight <= 0) throw new Error(`Survey CSV row ${rowIndex + 2} final weight must be positive.`);
    let stratumId: string | undefined;
    let psuId: string | undefined;
    if (config.columns.stratum_id && config.columns.psu_id) {
      stratumId = get(config.columns.stratum_id).trim();
      psuId = get(config.columns.psu_id).trim();
      if (Boolean(stratumId) !== Boolean(psuId)) throw new Error(`Survey CSV row ${rowIndex + 2} must supply both stratum and PSU IDs or neither.`);
    }
    const scaleBounds = canonicalScaleBounds(mapping);
    records.push({
      survey_id: config.survey_id,
      wave_id: config.wave_id,
      country_iso3: countryIso3,
      question_id: sourceQuestionId,
      source_question_id: sourceQuestionId,
      construct_id: mapping.construct_id,
      canonical_scale_id: mapping.canonical_scale_id,
      mapping_version: mapping.mapping_version,
      construct_label: mapping.construct_label?.trim() || mapping.construct_id,
      construct_domain: mapping.construct_domain ?? 'other',
      canonical_scale_min: scaleBounds.min,
      canonical_scale_max: scaleBounds.max,
      response_numeric: responseNumeric,
      final_weight: finalWeight,
      ...(stratumId && psuId ? { stratum_id: stratumId, psu_id: psuId } : {}),
    });
    questionMappingCountMap.set(sourceQuestionId, (questionMappingCountMap.get(sourceQuestionId) ?? 0) + 1);
  }
  if (records.length === 0) throw new Error('Survey CSV produced zero harmonized responses; verify question maps and missing-value codes.');
  return {
    records,
    input_rows: dataRows.length,
    imported_rows: records.length,
    excluded_missing_response_rows: excludedMissingResponseRows,
    excluded_unmapped_question_rows: excludedUnmappedQuestionRows,
    question_mapping_counts: Object.fromEntries([...questionMappingCountMap.entries()].sort(([left], [right]) => left.localeCompare(right))),
    warnings: [
      'Input must already be long-format, source-validated microdata; this importer does not scrape provider portals or infer undocumented columns.',
      'Only aggregate estimates should be persisted to the shared analytical lake; respondent identifiers are not imported or returned.',
      'Question mappings must be independently validated for construct equivalence before comparing countries or survey waves.',
      'Question-level weighted response distributions are retained separately from weighted means so unlike response patterns are not collapsed into the same average.',
    ],
  };
}

/** Removes harmonization-only metadata before passing records to the strict estimator. */
export function toSurveyEstimationRecords(records: readonly HarmonizedSurveyMicrodataRecord[]): SurveyMicrodataRecord[] {
  return records.map((row) => ({
    survey_id: row.survey_id,
    wave_id: row.wave_id,
    country_iso3: row.country_iso3,
    question_id: row.question_id,
    response_numeric: row.response_numeric,
    final_weight: row.final_weight,
    ...(row.stratum_id && row.psu_id ? { stratum_id: row.stratum_id, psu_id: row.psu_id } : {}),
  }));
}


export interface ImportedSurveyQuestionEstimate {
  survey_id: string;
  wave_id: string;
  country_iso3: string;
  source_question_id: string;
  construct_id: string;
  canonical_scale_id: string;
  mapping_version: string;
  construct_label: string;
  construct_domain: PsychographicConstructDomain;
  canonical_scale_min: number;
  canonical_scale_max: number;
  estimate: SurveyMeanEstimate;
  distribution: SurveyDistributionEstimate;
}

/** Groups imported microdata by country/question before calling the strict estimator. */
export function estimateImportedSurveyCsv(
  imported: SurveyCsvImportResult,
  options: { minimumEffectiveSampleSize?: number } = {},
): ImportedSurveyQuestionEstimate[] {
  const groups = new Map<string, HarmonizedSurveyMicrodataRecord[]>();
  for (const row of imported.records) {
    const key = JSON.stringify([row.survey_id, row.wave_id, row.country_iso3, row.source_question_id, row.construct_id, row.canonical_scale_id, row.mapping_version, row.construct_label, row.construct_domain, row.canonical_scale_min, row.canonical_scale_max]);
    const group = groups.get(key) ?? [];
    group.push(row);
    groups.set(key, group);
  }
  return [...groups.entries()].sort(([left], [right]) => left.localeCompare(right)).map(([key, rows]) => {
    const [surveyId, waveId, countryIso3, sourceQuestionId, constructId, canonicalScaleId, mappingVersion, constructLabel, constructDomain, canonicalScaleMin, canonicalScaleMax] = JSON.parse(key) as string[];
    if (!surveyId || !waveId || !countryIso3 || !sourceQuestionId || !constructId || !canonicalScaleId || !mappingVersion || !constructLabel || !constructDomain || canonicalScaleMin === undefined || canonicalScaleMax === undefined) {
      throw new Error('Imported survey question group has incomplete harmonization metadata.');
    }
    return {
      survey_id: surveyId,
      wave_id: waveId,
      country_iso3: countryIso3,
      source_question_id: sourceQuestionId,
      construct_id: constructId,
      canonical_scale_id: canonicalScaleId,
      mapping_version: mappingVersion,
      construct_label: constructLabel,
      construct_domain: constructDomain as PsychographicConstructDomain,
      canonical_scale_min: Number(canonicalScaleMin),
      canonical_scale_max: Number(canonicalScaleMax),
      estimate: estimateSurveyWeightedMean(toSurveyEstimationRecords(rows), options),
      distribution: estimateSurveyWeightedDistribution(toSurveyEstimationRecords(rows), options),
    };
  });
}


/**
 * Runs the complete validated CSV-to-Silver-contract path. Context is supplied
 * by the caller because source license, methodology and fieldwork provenance
 * cannot safely be inferred from a CSV. Both the weighted mean and the separate
 * weighted response distribution are returned as canonical observations.
 */
export function estimateImportedSurveyObservations(
  imported: SurveyCsvImportResult,
  contextForQuestion: (estimate: ImportedSurveyQuestionEstimate) => SurveyObservationContext,
  options: { minimumEffectiveSampleSize?: number } = {},
): ObservationContract[] {
  if (typeof contextForQuestion !== 'function') throw new TypeError('A source/methodology context resolver is required for every survey question.');
  const output: ObservationContract[] = [];
  for (const estimate of estimateImportedSurveyCsv(imported, options)) {
    const supplied = contextForQuestion(estimate);
    const context: SurveyObservationContext = {
      ...supplied,
      territory_id: estimate.country_iso3,
      psychographic_construct_id: estimate.construct_id,
      psychographic_construct_label: estimate.construct_label,
      psychographic_construct_domain: estimate.construct_domain,
      canonical_scale_id: estimate.canonical_scale_id,
      canonical_scale_min: estimate.canonical_scale_min,
      canonical_scale_max: estimate.canonical_scale_max,
      question_mapping_version: estimate.mapping_version,
    };
    output.push(surveyMeanEstimateToObservation(estimate.estimate, context));
    output.push(...surveyDistributionToObservations(estimate.distribution, context));
  }
  return output;
}
