import { LRUCache } from 'lru-cache';
import {
  getControlPlaneDb,
  listActiveSilverParquetPaths,
} from './controlPlane.ts';
import { sqlQuote, withDuckDBConnection } from './duckdbEngine.ts';
import {
  buildGoldPivotSelectSql,
  mapDuckRowToGoldMetrics,
  mapEmptyGoldMetrics,
  mapDuckRowToGoldMetricYears,
  mapEmptyGoldMetricYears,
} from './indicatorRegistry.ts';
import { aggregateContinentalMacroRows } from './territorialAggregation.ts';
import { buildPsychographicProfile } from './psychographicProfiles.ts';
import { computeMarketAttractiveness } from './marketAttractiveness.ts';
import type {
  BrandMarketProfile,
  H3MacroCellRow,
  MacroEconomicRow,
  PsychographicSurveyObservation,
  PsychographicConstructDomain,
  PsychographicSurveyVarianceStatus,
} from './types.ts';

const CURRENT_YEAR = new Date().getUTCFullYear();

const queryCache = new LRUCache<string, object>({
  max: 200,
  ttl: 5 * 60 * 1000,
});

let cacheHits = 0;
let cacheMisses = 0;

export function invalidateQueryCache(): void {
  queryCache.clear();
}

export function getCacheStats(): {
  hits: number;
  misses: number;
  hitRatePct: number;
  keys: number;
} {
  const total = cacheHits + cacheMisses;
  return {
    hits: cacheHits,
    misses: cacheMisses,
    hitRatePct: total > 0 ? Number(((cacheHits / total) * 100).toFixed(1)) : 0,
    keys: queryCache.size,
  };
}

export interface CachedQueryResult<T> {
  data: T;
  cacheStatus: 'HIT' | 'MISS';
  snapshotCount: number;
  generatedAt: string;
}

function numOrNull(val: unknown): number | null {
  if (typeof val === 'number' && Number.isFinite(val)) return val;
  if (typeof val === 'string' && val.trim() !== '') {
    const parsed = Number(val);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}

function isRecentYear(value: number | null): value is number {
  return value !== null && Number.isInteger(value) && value <= CURRENT_YEAR && value >= CURRENT_YEAR - 5;
}

function isComparableYearPair(first: number | null, second: number | null): boolean {
  return isRecentYear(first) && isRecentYear(second) && Math.abs(first - second) <= 3;
}

export async function getMacroEconomicOverview(): Promise<CachedQueryResult<MacroEconomicRow[]>> {
  const cacheKey = 'gold:macro_economic_overview';
  const cached = queryCache.get(cacheKey) as CachedQueryResult<MacroEconomicRow[]> | undefined;
  if (cached) {
    cacheHits++;
    return { ...cached, cacheStatus: 'HIT' };
  }
  cacheMisses++;

  const parquetPaths = listActiveSilverParquetPaths();
  const db = getControlPlaneDb();
  const territories = db
    .prepare(
      `SELECT territory_id, iso2, iso3, name_en, continent, region, h3_res2, h3_res4
       FROM dim_territories
       ORDER BY name_en ASC`
    )
    .all() as Array<{
      territory_id: string;
      iso2: string;
      iso3: string;
      name_en: string;
      continent: string;
      region: string;
      h3_res2: string | null;
      h3_res4: string | null;
    }>;

  if (parquetPaths.length === 0) {
    const emptyRows: MacroEconomicRow[] = territories.map((t) => ({
      ...t,
      latest_year: null,
      ...mapEmptyGoldMetrics(),
      ...mapEmptyGoldMetricYears(),
    }));
    const result: CachedQueryResult<MacroEconomicRow[]> = {
      data: emptyRows,
      cacheStatus: 'MISS',
      snapshotCount: 0,
      generatedAt: new Date().toISOString(),
    };
    queryCache.set(cacheKey, result);
    return result;
  }

  const pathListSql = `[${parquetPaths.map((p) => sqlQuote(p)).join(', ')}]`;

  const aggregated = await withDuckDBConnection(async (conn) => {
    const reader = await conn.runAndReadAll(`
      WITH raw_obs AS (
        SELECT
          territory_id,
          iso3,
          indicator_id,
          source_id,
          dataset_id,
          period_year,
          value_numeric,
          asserted_at,
          ROW_NUMBER() OVER (
            PARTITION BY territory_id, indicator_id
            ORDER BY period_year DESC, asserted_at DESC, source_id ASC, dataset_id ASC
          ) AS rn
        FROM read_parquet(${pathListSql}, union_by_name=true)
        WHERE period_year >= 1900
          AND period_year <= ${CURRENT_YEAR}
          AND value_numeric IS NOT NULL
      ),
      latest AS (
        SELECT territory_id, iso3, indicator_id, source_id, dataset_id, period_year, value_numeric, asserted_at
        FROM raw_obs
        WHERE rn = 1
      )
      SELECT
        territory_id,
        MAX(period_year) AS latest_year,
        ${buildGoldPivotSelectSql()}
      FROM latest
      GROUP BY territory_id;
    `);
    try {
      return reader.getRowObjectsJson() as Array<Record<string, unknown>>;
    } finally {
      reader.closeSync();
    }
  });

  const byTerritory = new Map<string, Record<string, unknown>>();
  for (const row of aggregated) {
    if (typeof row.territory_id === 'string') {
      byTerritory.set(row.territory_id, row);
    }
  }

  const merged: MacroEconomicRow[] = territories.map((t) => {
    const m = byTerritory.get(t.territory_id);
    return {
      ...t,
      latest_year: numOrNull(m?.latest_year),
      ...mapDuckRowToGoldMetrics(m),
      ...mapDuckRowToGoldMetricYears(m),
    };
  });

  const result: CachedQueryResult<MacroEconomicRow[]> = {
    data: merged,
    cacheStatus: 'MISS',
    snapshotCount: parquetPaths.length,
    generatedAt: new Date().toISOString(),
  };
  queryCache.set(cacheKey, result);
  return result;
}

function isPsychographicDomain(value: unknown): value is PsychographicConstructDomain {
  return typeof value === 'string' && ['values', 'attitudes', 'interests', 'lifestyle', 'motivations', 'identity', 'media_use', 'music_engagement', 'social_orientation', 'other'].includes(value);
}

function isSurveyVarianceStatus(value: unknown): value is PsychographicSurveyVarianceStatus {
  return value === 'available_taylor_linearization_wr_first_stage'
    || value === 'unavailable_design_metadata'
    || value === 'unavailable_singleton_stratum';
}

async function loadPsychographicSurveyObservations(
  parquetPaths: readonly string[],
): Promise<Map<string, PsychographicSurveyObservation[]>> {
  if (parquetPaths.length === 0) return new Map();
  const pathListSql = `[${parquetPaths.map((path) => sqlQuote(path)).join(', ')}]`;
  return withDuckDBConnection(async (conn) => {
    const schemaReader = await conn.runAndReadAll(`DESCRIBE SELECT * FROM read_parquet(${pathListSql}, union_by_name=true)`);
    let columns: Set<string>;
    try {
      const description = schemaReader.getRowObjectsJson() as Array<Record<string, unknown>>;
      columns = new Set(description.map((row) => String(row.column_name ?? '')).filter(Boolean));
    } finally {
      schemaReader.closeSync();
    }
    const required = [
      'territory_id', 'iso3', 'survey_id', 'survey_wave_id', 'question_id', 'psychographic_construct_id',
      'canonical_scale_id', 'canonical_scale_min', 'canonical_scale_max', 'question_mapping_version',
      'survey_statistic', 'survey_variance_status', 'survey_minimum_effective_sample_size', 'sample_size',
      'effective_sample_size', 'population_scope', 'weighting_method', 'commercial_use_allowed',
      'methodology_id', 'source_id', 'dataset_id', 'asserted_at', 'period_year', 'value_numeric',
    ];
    if (!required.every((column) => columns.has(column))) return new Map();
    const optional = (column: string, alias = column, cast = 'VARCHAR') => columns.has(column)
      ? `CAST(${column} AS ${cast}) AS ${alias}`
      : `NULL::${cast} AS ${alias}`;
    const fields = [
      'territory_id', 'iso3', 'survey_id', 'survey_wave_id', 'question_id', 'psychographic_construct_id',
      optional('psychographic_construct_label'), optional('psychographic_construct_domain'),
      'canonical_scale_id', 'canonical_scale_min', 'canonical_scale_max', 'question_mapping_version',
      'survey_statistic', optional('response_category'), 'period_year', 'value_numeric', 'sample_size',
      'effective_sample_size', 'survey_minimum_effective_sample_size', optional('standard_error', 'standard_error', 'DOUBLE'),
      optional('confidence_interval_lower', 'confidence_interval_lower', 'DOUBLE'),
      optional('confidence_interval_upper', 'confidence_interval_upper', 'DOUBLE'), 'survey_variance_status',
      'population_scope', 'weighting_method', optional('fieldwork_start'), optional('fieldwork_end'),
      'source_id', 'dataset_id', 'methodology_id', 'commercial_use_allowed', 'asserted_at',
      optional('response_category_count', 'response_category_count', 'INTEGER'),
    ];
    const reader = await conn.runAndReadAll(`
      SELECT ${fields.join(', ')} FROM (
        SELECT ${fields.join(', ')},
          ROW_NUMBER() OVER (
            PARTITION BY territory_id, survey_id, survey_wave_id, question_id, source_id, dataset_id,
              psychographic_construct_id, canonical_scale_id, question_mapping_version, survey_statistic,
              COALESCE(CAST(${columns.has('response_category') ? 'response_category' : "NULL::VARCHAR"} AS VARCHAR), '')
            ORDER BY asserted_at DESC, period_year DESC
          ) AS rn
        FROM read_parquet(${pathListSql}, union_by_name=true)
        WHERE survey_id IS NOT NULL
          AND survey_wave_id IS NOT NULL
          AND question_id IS NOT NULL
          AND psychographic_construct_id IS NOT NULL
          AND survey_statistic IN ('weighted_mean', 'weighted_share')
      ) WHERE rn = 1
      ORDER BY territory_id, period_year DESC, survey_id, question_id, survey_statistic, response_category;
    `);
    let raw: Array<Record<string, unknown>>;
    try { raw = reader.getRowObjectsJson() as Array<Record<string, unknown>>; }
    finally { reader.closeSync(); }

    const grouped = new Map<string, PsychographicSurveyObservation[]>();
    for (const row of raw) {
      const numericFields = [
        'canonical_scale_min', 'canonical_scale_max', 'period_year', 'value_numeric', 'sample_size',
        'effective_sample_size', 'survey_minimum_effective_sample_size',
      ].map((field) => numOrNull(row[field]));
      if (numericFields.some((value) => value === null)) continue;
      const [scaleMin, scaleMax, year, value, sampleSize, effectiveSampleSize, minimumEffectiveSampleSize] = numericFields as number[];
      const strings = ['territory_id', 'iso3', 'survey_id', 'survey_wave_id', 'question_id', 'psychographic_construct_id',
        'canonical_scale_id', 'question_mapping_version', 'population_scope', 'weighting_method', 'source_id', 'dataset_id',
        'methodology_id', 'commercial_use_allowed', 'asserted_at'] as const;
      if (!strings.every((field) => typeof row[field] === 'string' && String(row[field]).trim().length > 0)) continue;
      if (!/^[A-Z]{3}$/.test(String(row.iso3)) || !Number.isInteger(year) || year < 1900 || year > CURRENT_YEAR
        || scaleMin >= scaleMax || !Number.isInteger(sampleSize) || sampleSize <= 0
        || effectiveSampleSize <= 0 || effectiveSampleSize > sampleSize + 1e-6 || minimumEffectiveSampleSize <= 0) continue;
      if (row.survey_statistic !== 'weighted_mean' && row.survey_statistic !== 'weighted_share') continue;
      if (!isSurveyVarianceStatus(row.survey_variance_status)) continue;
      if (row.commercial_use_allowed !== 'confirmed' && row.commercial_use_allowed !== 'denied' && row.commercial_use_allowed !== 'unknown') continue;
      const standardError = numOrNull(row.standard_error);
      const ciLower = numOrNull(row.confidence_interval_lower);
      const ciUpper = numOrNull(row.confidence_interval_upper);
      const responseCategory = row.response_category === null || row.response_category === undefined ? null : String(row.response_category);
      const observation: PsychographicSurveyObservation = {
        territory_id: String(row.territory_id), iso3: String(row.iso3), survey_id: String(row.survey_id),
        wave_id: String(row.survey_wave_id), question_id: String(row.question_id), construct_id: String(row.psychographic_construct_id),
        construct_label: typeof row.psychographic_construct_label === 'string' && row.psychographic_construct_label.trim()
          ? row.psychographic_construct_label : String(row.psychographic_construct_id),
        construct_domain: isPsychographicDomain(row.psychographic_construct_domain) ? row.psychographic_construct_domain : 'other',
        canonical_scale_id: String(row.canonical_scale_id), canonical_scale_min: scaleMin, canonical_scale_max: scaleMax,
        mapping_version: String(row.question_mapping_version), statistic: row.survey_statistic,
        response_category: responseCategory, period_year: year, value_numeric: value, sample_size: sampleSize,
        effective_sample_size: effectiveSampleSize, minimum_effective_sample_size: minimumEffectiveSampleSize,
        standard_error: standardError, confidence_interval_lower: ciLower, confidence_interval_upper: ciUpper,
        variance_status: row.survey_variance_status,
        population_scope: String(row.population_scope), weighting_method: String(row.weighting_method),
        fieldwork_start: row.fieldwork_start == null ? null : String(row.fieldwork_start),
        fieldwork_end: row.fieldwork_end == null ? null : String(row.fieldwork_end),
        source_id: String(row.source_id), dataset_id: String(row.dataset_id), methodology_id: String(row.methodology_id),
        commercial_use_allowed: row.commercial_use_allowed,
        asserted_at: String(row.asserted_at),
        response_category_count: numOrNull(row.response_category_count),
      } as PsychographicSurveyObservation;
      const bucket = grouped.get(observation.territory_id) ?? [];
      bucket.push(observation);
      grouped.set(observation.territory_id, bucket);
    }
    return grouped;
  });
}

export async function getBrandMarketProfiles(
  mode: 'mass_market' | 'premium' = 'mass_market'
): Promise<CachedQueryResult<BrandMarketProfile[]>> {
  const cacheKey = `gold:brand_market_profiles:${mode}`;
  const cached = queryCache.get(cacheKey) as CachedQueryResult<BrandMarketProfile[]> | undefined;
  if (cached) {
    cacheHits++;
    return { ...cached, cacheStatus: 'HIT' };
  }
  cacheMisses++;

  const macro = await getMacroEconomicOverview();
  const db = getControlPlaneDb();
  const territories = db
    .prepare(
      `SELECT territory_id, currency_iso4217, primary_language_iso639, timezone FROM dim_territories`
    )
    .all() as Array<{
      territory_id: string;
      currency_iso4217: string;
      primary_language_iso639: string;
      timezone: string;
    }>;

  const metaMap = new Map(territories.map((t) => [t.territory_id, t]));
  const parquetPaths = listActiveSilverParquetPaths();

  const medianAgeMap = new Map<string, { value: number; year: number | null }>();
  if (parquetPaths.length > 0) {
    const pathListSql = `[${parquetPaths.map((p) => sqlQuote(p)).join(', ')}]`;
    const ageRows = await withDuckDBConnection(async (conn) => {
      const reader = await conn.runAndReadAll(`
        SELECT territory_id, value_numeric, period_year
        FROM (
          SELECT
            territory_id,
            value_numeric,
            period_year,
            asserted_at,
            source_id,
            dataset_id,
            ROW_NUMBER() OVER (PARTITION BY territory_id ORDER BY period_year DESC, asserted_at DESC, source_id ASC, dataset_id ASC) AS rn
          FROM read_parquet(${pathListSql}, union_by_name=true)
          WHERE indicator_id = 'OWID.MEDIAN_AGE'
            AND period_year >= 1900
            AND period_year <= ${CURRENT_YEAR}
            AND value_numeric IS NOT NULL
        )
        WHERE rn = 1;
      `);
      try {
        return reader.getRowObjectsJson() as Array<Record<string, unknown>>;
      } finally {
        reader.closeSync();
      }
    });
    for (const r of ageRows) {
      const val = numOrNull(r.value_numeric);
      const year = numOrNull(r.period_year);
      const validObservationYear = year !== null && Number.isInteger(year) && year >= 1900 && year <= CURRENT_YEAR
        ? year
        : null;
      if (typeof r.territory_id === 'string' && val !== null && val >= 10 && val <= 80 && validObservationYear !== null) {
        medianAgeMap.set(r.territory_id, { value: val, year: validObservationYear });
      }
    }
  }
  const surveyObservations = await loadPsychographicSurveyObservations(parquetPaths);

  const profiles: BrandMarketProfile[] = macro.data.map((m) => {
    const meta = metaMap.get(m.territory_id);
    const ppp = m.gdp_per_capita_ppp_2021;
    const tier: BrandMarketProfile['purchasing_power_tier'] =
      ppp === null || !Number.isFinite(ppp) || ppp <= 0 || !isRecentYear(m.gdp_per_capita_ppp_2021_year)
        ? 'Insufficient data'
        : ppp >= 38_000
          ? 'Tier A (High PPP)'
          : ppp >= 15_000
            ? 'Tier B (Mid PPP)'
            : 'Tier C (Lower PPP)';

    const digitalAddressable =
      m.population_total !== null && Number.isFinite(m.population_total) && m.population_total > 0
        && m.internet_users_pct !== null && Number.isFinite(m.internet_users_pct)
        && m.internet_users_pct >= 0 && m.internet_users_pct <= 100
        && isComparableYearPair(m.population_total_year, m.internet_users_pct_year)
        ? Math.round(m.population_total * (m.internet_users_pct / 100))
        : null;

    return {
      territory_id: m.territory_id,
      iso3: m.iso3,
      name_en: m.name_en,
      continent: m.continent,
      region: m.region,
      h3_res2: m.h3_res2 ?? null,
      currency_iso4217: meta?.currency_iso4217 ?? 'USD',
      primary_language_iso639: meta?.primary_language_iso639 ?? 'en',
      timezone: meta?.timezone ?? 'UTC',
      population_total: m.population_total,
      population_total_year: m.population_total_year,
      median_age: medianAgeMap.get(m.territory_id)?.value ?? null,
      median_age_year: medianAgeMap.get(m.territory_id)?.year ?? null,
      life_expectancy_years: m.life_expectancy_years,
      life_expectancy_years_year: m.life_expectancy_years_year,
      gdp_per_capita_ppp_2021: m.gdp_per_capita_ppp_2021,
      gdp_per_capita_ppp_2021_year: m.gdp_per_capita_ppp_2021_year,
      gini_index: m.gini_index,
      gini_index_year: m.gini_index_year,
      urbanization_pct: m.urbanization_pct,
      urbanization_pct_year: m.urbanization_pct_year,
      internet_users_pct: m.internet_users_pct,
      internet_users_pct_year: m.internet_users_pct_year,
      inflation_cpi_pct: m.inflation_cpi_pct,
      inflation_cpi_pct_year: m.inflation_cpi_pct_year,
      purchasing_power_tier: tier,
      digital_addressable_pop: digitalAddressable,
      mai: computeMarketAttractiveness(m, mode),
      psychographics: buildPsychographicProfile({
        ...m,
        median_age: medianAgeMap.get(m.territory_id)?.value ?? null,
        median_age_year: medianAgeMap.get(m.territory_id)?.year ?? null,
      }, surveyObservations.get(m.territory_id) ?? []),
      // A market profile combines multiple sources; data presence is not proof of commercial clearance.
      license_clearance: 'unknown',
    };
  });

  const result: CachedQueryResult<BrandMarketProfile[]> = {
    data: profiles,
    cacheStatus: 'MISS',
    snapshotCount: macro.snapshotCount,
    generatedAt: new Date().toISOString(),
  };
  queryCache.set(cacheKey, result);
  return result;
}

export async function getH3MacroRollup(): Promise<CachedQueryResult<H3MacroCellRow[]>> {
  const cacheKey = 'gold:h3_macro_rollup';
  const cached = queryCache.get(cacheKey) as CachedQueryResult<H3MacroCellRow[]> | undefined;
  if (cached) {
    cacheHits++;
    return { ...cached, cacheStatus: 'HIT' };
  }
  cacheMisses++;

  const macro = await getMacroEconomicOverview();
  const withH3 = macro.data.filter((r) => typeof r.h3_res2 === 'string' && r.h3_res2.length > 0);

  if (withH3.length === 0) {
    const empty: CachedQueryResult<H3MacroCellRow[]> = {
      data: [],
      cacheStatus: 'MISS',
      snapshotCount: macro.snapshotCount,
      generatedAt: new Date().toISOString(),
    };
    queryCache.set(cacheKey, empty);
    return empty;
  }

  // Vectorized H3 Res-2 spatial rollup inside DuckDB
  const valuesSql = withH3
    .map(
      (r) =>
        `(${sqlQuote(r.h3_res2 as string)}, ${sqlQuote(r.iso3)}, ${
          r.population_total ?? 'NULL::DOUBLE'
        }, ${r.gdp_per_capita_ppp_2021 ?? 'NULL::DOUBLE'}, ${r.urbanization_pct ?? 'NULL::DOUBLE'})`
    )
    .join(', ');

  const rows = await withDuckDBConnection(async (conn) => {
    const reader = await conn.runAndReadAll(`
      WITH cells(h3_res2, iso3, pop, ppp, urban) AS (VALUES ${valuesSql})
      SELECT
        h3_res2,
        COUNT(*)::INTEGER AS territory_count,
        STRING_AGG(iso3, ', ' ORDER BY iso3) AS territories_csv,
        SUM(pop) AS total_population,
        SUM(ppp * pop) / NULLIF(SUM(CASE WHEN ppp IS NOT NULL THEN pop END), 0) AS population_weighted_gdp_per_capita_ppp_2021,
        SUM(urban * pop) / NULLIF(SUM(CASE WHEN urban IS NOT NULL THEN pop END), 0) AS population_weighted_urbanization_pct
      FROM cells
      GROUP BY h3_res2
      ORDER BY territory_count DESC, total_population DESC NULLS LAST;
    `);
    try {
      return reader.getRowObjectsJson() as Array<Record<string, unknown>>;
    } finally {
      reader.closeSync();
    }
  });

  const formatted: H3MacroCellRow[] = rows.map((r) => ({
    h3_res2: String(r.h3_res2 ?? ''),
    spatial_basis: 'country_centroid_assignment',
    territory_count: Number(r.territory_count ?? 0),
    territories_csv: String(r.territories_csv ?? ''),
    total_population: numOrNull(r.total_population),
    population_weighted_gdp_per_capita_ppp_2021: numOrNull(r.population_weighted_gdp_per_capita_ppp_2021),
    population_weighted_urbanization_pct: numOrNull(r.population_weighted_urbanization_pct),
  }));

  const result: CachedQueryResult<H3MacroCellRow[]> = {
    data: formatted,
    cacheStatus: 'MISS',
    snapshotCount: macro.snapshotCount,
    generatedAt: new Date().toISOString(),
  };
  queryCache.set(cacheKey, result);
  return result;
}

export async function getTerritoryDeepDive(iso3: string) {
  const upper = iso3.trim().toUpperCase();
  const cacheKey = `gold:territory:${upper}`;
  const cached = queryCache.get(cacheKey);
  if (cached) {
    cacheHits++;
    return { ...(cached as Record<string, unknown>), cacheStatus: 'HIT' };
  }
  cacheMisses++;

  const db = getControlPlaneDb();
  const territory = db
    .prepare('SELECT * FROM dim_territories WHERE iso3 = ?')
    .get(upper);

  if (!territory) {
    return null;
  }

  const parquetPaths = listActiveSilverParquetPaths();
  let series: Array<Record<string, unknown>> = [];

  if (parquetPaths.length > 0) {
    const pathListSql = `[${parquetPaths.map((p) => sqlQuote(p)).join(', ')}]`;
    series = await withDuckDBConnection(async (conn) => {
      const stmt = await conn.prepare(`
        SELECT
          indicator_id,
          indicator_name,
          source_id,
          period_year,
          value_numeric,
          unit,
          valuation_basis,
          methodology_id,
          asserted_at
        FROM read_parquet(${pathListSql}, union_by_name=true)
        WHERE iso3 = $1 AND period_year <= ${CURRENT_YEAR}
        ORDER BY indicator_id ASC, period_year DESC;
      `);
      try {
        stmt.bindVarchar(1, upper);
        const reader = await stmt.runAndReadAll();
        try {
          return reader.getRowObjectsJson() as Array<Record<string, unknown>>;
        } finally {
          reader.closeSync();
        }
      } finally {
        stmt.destroySync();
      }
    });
  }

  const payload = {
    territory,
    series,
    cacheStatus: 'MISS',
    generatedAt: new Date().toISOString(),
  };
  queryCache.set(cacheKey, payload);
  return payload;
}

export async function getSourceSilverPreview(sourceId: string) {
  const cleanId = sourceId.trim();
  const db = getControlPlaneDb();
  const source = db.prepare('SELECT * FROM dim_data_sources WHERE source_id = ?').get(cleanId);
  if (!source) {
    return null;
  }

  // DEVELOPMENT DASHBOARD MODE: show Silver observations for every catalogued
  // source, regardless of its commercial clearance metadata. Before external
  // commercial distribution, add an explicit serving policy here and to every
  // Gold product; do not confuse this internal preview with redistribution rights.
  const cacheKey = `gold:source_preview:${cleanId}`;
  const cached = queryCache.get(cacheKey);
  if (cached) {
    cacheHits++;
    return { ...(cached as Record<string, unknown>), source, cacheStatus: 'HIT' };
  }
  cacheMisses++;

  const snapshot = db
    .prepare(
      `SELECT * FROM snapshot_manifest
       WHERE source_id = ? AND layer = 'silver' AND is_active = 1
       ORDER BY created_at DESC LIMIT 1`
    )
    .get(cleanId) as { parquet_path?: string; snapshot_id?: string; row_count?: number } | undefined;

  if (!snapshot?.parquet_path) {
    const emptyPayload = {
      source,
      snapshotId: null,
      totalRows: 0,
      indicators: [] as Array<Record<string, unknown>>,
      rows: [] as Array<Record<string, unknown>>,
      cacheStatus: 'MISS',
      generatedAt: new Date().toISOString(),
    };
    queryCache.set(cacheKey, emptyPayload);
    return emptyPayload;
  }

  const { indicators, rows, totalRows } = await withDuckDBConnection(async (conn) => {
    const parquet = sqlQuote(snapshot.parquet_path!);
    type Reader = { getRowObjectsJson: () => unknown[]; closeSync: () => void };
    let indReader: Reader | null = null;
    let rowReader: Reader | null = null;
    let countReader: Reader | null = null;
    try {
      indReader = await conn.runAndReadAll(`
        SELECT
          indicator_id,
          MAX(indicator_name) AS indicator_name,
          MAX(unit) AS unit,
          MAX(valuation_basis) AS valuation_basis,
          MAX(methodology_id) AS methodology_id,
          COUNT(*)::INTEGER AS obs_count,
          COUNT(DISTINCT iso3)::INTEGER AS territory_count,
          MIN(period_year)::INTEGER AS min_year,
          MAX(period_year)::INTEGER AS max_year
        FROM read_parquet(${parquet})
        GROUP BY indicator_id
        ORDER BY indicator_id ASC;
      `);
      rowReader = await conn.runAndReadAll(`
        SELECT
          iso3,
          indicator_id,
          indicator_name,
          period_year,
          value_numeric,
          unit,
          valuation_basis,
          methodology_id
        FROM read_parquet(${parquet})
        ORDER BY period_year DESC, indicator_id ASC, iso3 ASC
        LIMIT 120;
      `);
      countReader = await conn.runAndReadAll(`
        SELECT COUNT(*)::INTEGER AS total_rows
        FROM read_parquet(${parquet});
      `);
      const countRows = countReader.getRowObjectsJson() as Array<Record<string, unknown>>;
      return {
        indicators: indReader.getRowObjectsJson() as Array<Record<string, unknown>>,
        rows: rowReader.getRowObjectsJson() as Array<Record<string, unknown>>,
        totalRows: numOrNull(countRows[0]?.total_rows) ?? 0,
      };
    } finally {
      indReader?.closeSync();
      rowReader?.closeSync();
      countReader?.closeSync();
    }
  });

  const payload = {
    source,
    snapshotId: snapshot.snapshot_id ?? null,
    totalRows,
    indicators,
    rows,
    accessStatus: 'development_preview_all_sources',
    cacheStatus: 'MISS',
    generatedAt: new Date().toISOString(),
  };
  queryCache.set(cacheKey, payload);
  return payload;
}

/** Country-to-continent aggregate. Non-additive indices/rates are not averaged. */
export async function getContinentalMacroOverview(): Promise<CachedQueryResult<ReturnType<typeof aggregateContinentalMacroRows>[number][]>> {
  const cacheKey = 'gold:continental_macro_overview';
  const cached = queryCache.get(cacheKey) as CachedQueryResult<ReturnType<typeof aggregateContinentalMacroRows>[number][]> | undefined;
  if (cached) { cacheHits++; return { ...cached, cacheStatus: 'HIT' }; }
  cacheMisses++;
  const macro = await getMacroEconomicOverview();
  const result: CachedQueryResult<ReturnType<typeof aggregateContinentalMacroRows>[number][]> = {
    data: aggregateContinentalMacroRows(macro.data), cacheStatus: 'MISS', snapshotCount: macro.snapshotCount,
    generatedAt: new Date().toISOString(),
  };
  queryCache.set(cacheKey, result);
  return result;
}
