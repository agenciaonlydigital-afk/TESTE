import type { ObservationContract, PsychographicConstructDomain } from './types.ts';

/**
 * A harmonized numeric response. Categorical answers must be mapped to a numeric
 * construct score by a documented, versioned question harmonization first.
 */
export interface SurveyMicrodataRecord {
  survey_id: string;
  wave_id: string;
  country_iso3: string;
  question_id: string;
  response_numeric: number;
  final_weight: number;
  stratum_id?: string;
  psu_id?: string;
}

function parseSurveyMicrodataRecord(value: unknown, index: number): SurveyMicrodataRecord {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error(`Invalid survey microdata row ${index}: expected an object.`);
  }
  const row = value as Record<string, unknown>;
  const requiredStrings = ['survey_id', 'wave_id', 'country_iso3', 'question_id'] as const;
  for (const field of requiredStrings) {
    if (typeof row[field] !== 'string' || !row[field].trim()) throw new Error(`Invalid survey microdata row ${index}: ${field} is required.`);
    const maxLength = field === 'survey_id' ? 120 : field === 'wave_id' ? 120 : field === 'question_id' ? 160 : 3;
    if ((row[field] as string).trim().length > maxLength) throw new Error(`Invalid survey microdata row ${index}: ${field} exceeds ${maxLength} characters.`);
  }
  if (typeof row.country_iso3 !== 'string' || !/^[A-Z]{3}$/.test(row.country_iso3)) {
    throw new Error(`Invalid survey microdata row ${index}: country_iso3 must be uppercase ISO alpha-3.`);
  }
  if (typeof row.response_numeric !== 'number' || !Number.isFinite(row.response_numeric)) {
    throw new Error(`Invalid survey microdata row ${index}: response_numeric must be finite.`);
  }
  if (typeof row.final_weight !== 'number' || !Number.isFinite(row.final_weight) || row.final_weight <= 0) {
    throw new Error(`Invalid survey microdata row ${index}: final_weight must be finite and positive.`);
  }
  const hasStratum = typeof row.stratum_id === 'string' && row.stratum_id.trim().length > 0;
  const hasPsu = typeof row.psu_id === 'string' && row.psu_id.trim().length > 0;
  if ((row.stratum_id !== undefined || row.psu_id !== undefined) && hasStratum !== hasPsu) {
    throw new Error(`Invalid survey microdata row ${index}: stratum_id and psu_id must be supplied together.`);
  }
  const allowed = new Set([...requiredStrings, 'response_numeric', 'final_weight', 'stratum_id', 'psu_id']);
  const unexpected = Object.keys(row).filter((key) => !allowed.has(key));
  if (unexpected.length) throw new Error(`Invalid survey microdata row ${index}: unsupported fields ${unexpected.join(', ')}.`);
  return {
    survey_id: row.survey_id as string,
    wave_id: row.wave_id as string,
    country_iso3: row.country_iso3 as string,
    question_id: row.question_id as string,
    response_numeric: row.response_numeric,
    final_weight: row.final_weight,
    ...(hasStratum ? { stratum_id: row.stratum_id as string, psu_id: row.psu_id as string } : {}),
  };
}


export type SurveyVarianceStatus =
  | 'available_taylor_linearization_wr_first_stage'
  | 'unavailable_design_metadata'
  | 'unavailable_singleton_stratum';

export interface SurveyMeanEstimate {
  survey_id: string;
  wave_id: string;
  country_iso3: string;
  question_id: string;
  sample_size: number;
  weighted_mean: number;
  sum_weights: number;
  kish_effective_sample_size: number;
  strata_count: number;
  psu_count: number;
  standard_error: number | null;
  confidence_interval_95: { lower: number; upper: number } | null;
  variance_status: SurveyVarianceStatus;
  variance_method: string;
  minimum_effective_sample_size: number;
  meets_effective_sample_threshold: boolean;
  warnings: string[];
  estimation_notes: string[];
}

function round(value: number, digits = 8): number {
  return Number(value.toFixed(digits));
}

/**
 * Estimates a weighted mean for one survey wave/question/country. If complete
 * strata + PSU identifiers are present, estimates a first-stage, with-replacement
 * Taylor-linearized variance. This is intentionally not a substitute for a full
 * survey package: FPCs, replicate weights, calibration, nonresponse adjustments,
 * multistage designs and domain estimation must be supplied/validated separately.
 */
export function estimateSurveyWeightedMean(
  input: readonly unknown[],
  options: { minimumEffectiveSampleSize?: number } = {},
): SurveyMeanEstimate {
  if (input.length === 0) throw new Error('Cannot estimate a survey mean from zero records.');
  const minimumEffectiveSampleSize = options.minimumEffectiveSampleSize ?? 30;
  if (!Number.isFinite(minimumEffectiveSampleSize) || minimumEffectiveSampleSize <= 0) {
    throw new RangeError('minimumEffectiveSampleSize must be finite and greater than zero.');
  }

  const records = input.map(parseSurveyMicrodataRecord);

  const first = records[0]!;
  const sameWave = records.every((row) =>
    row.survey_id === first.survey_id
    && row.wave_id === first.wave_id
    && row.country_iso3 === first.country_iso3
    && row.question_id === first.question_id,
  );
  if (!sameWave) throw new Error('A survey estimate must contain exactly one survey, wave, country and question.');

  const sumWeights = records.reduce((sum, row) => sum + row.final_weight, 0);
  if (!Number.isFinite(sumWeights) || sumWeights <= 0) {
    throw new Error('Sum of final survey weights overflowed or is not finite.');
  }
  // Normalize by the largest weight before moments. Kish n_eff and the weighted
  // ratio are invariant to a common weight scale; normalization avoids squaring
  // extremely small/large survey weights and avoids avoidable intermediate overflow.
  const maximumWeight = records.reduce((maximum, row) => Math.max(maximum, row.final_weight), 0);
  const normalizedWeights = records.map((row) => row.final_weight / maximumWeight);
  const normalizedWeightSum = normalizedWeights.reduce((sum, weight) => sum + weight, 0);
  const normalizedSquaredWeightSum = normalizedWeights.reduce((sum, weight) => sum + weight ** 2, 0);
  const weightedTotal = records.reduce((sum, row, index) => sum + normalizedWeights[index]! * row.response_numeric, 0);
  if (!Number.isFinite(normalizedWeightSum) || normalizedWeightSum <= 0 || !Number.isFinite(normalizedSquaredWeightSum)
    || normalizedSquaredWeightSum <= 0 || !Number.isFinite(weightedTotal)) {
    throw new Error('Normalized survey moments are not finite.');
  }
  const weightedMean = weightedTotal / normalizedWeightSum;
  if (!Number.isFinite(weightedMean)) throw new Error('Weighted mean is not finite.');
  const kishEffectiveSampleSize = (normalizedWeightSum ** 2) / normalizedSquaredWeightSum;
  if (!Number.isFinite(kishEffectiveSampleSize) || kishEffectiveSampleSize <= 0 || kishEffectiveSampleSize > records.length + 1e-6) {
    throw new Error('Kish effective sample size is not finite or exceeds the observed sample size.');
  }

  const completeDesign = records.every((row) => row.stratum_id !== undefined && row.psu_id !== undefined);
  const warnings: string[] = [];
  const estimationNotes = [
    'Point estimate is a final-weighted arithmetic mean of the harmonized numeric response.',
    'Kish effective sample size reflects unequal weights only; it is not adjusted for clustering or stratification.',
    'No individual-level or unobserved psychological trait is inferred from this aggregate estimate.',
  ];

  let standardError: number | null = null;
  let confidenceInterval: { lower: number; upper: number } | null = null;
  let varianceStatus: SurveyVarianceStatus = 'unavailable_design_metadata';
  let strataCount = 0;
  let psuCount = 0;

  if (!completeDesign) {
    warnings.push('No design-based standard error: complete stratum and PSU identifiers are not available for every record.');
  } else {
    const strata = new Map<string, Map<string, number>>();
    for (let recordIndex = 0; recordIndex < records.length; recordIndex++) {
      const row = records[recordIndex]!;
      const stratumId = row.stratum_id!;
      const psuId = row.psu_id!;
      const psus = strata.get(stratumId) ?? new Map<string, number>();
      psus.set(psuId, (psus.get(psuId) ?? 0) + normalizedWeights[recordIndex]! * (row.response_numeric - weightedMean));
      strata.set(stratumId, psus);
    }
    strataCount = strata.size;
    psuCount = [...strata.values()].reduce((sum, psus) => sum + psus.size, 0);
    const hasSingletonStratum = [...strata.values()].some((psus) => psus.size < 2);

    if (hasSingletonStratum) {
      varianceStatus = 'unavailable_singleton_stratum';
      warnings.push('At least one stratum has fewer than two sampled PSUs; variance is withheld because certainty-PSU metadata/FPC was not supplied.');
    } else {
      let varianceNumerator = 0;
      for (const psus of strata.values()) {
        const totals = [...psus.values()];
        const meanPsuTotal = totals.reduce((sum, value) => sum + value, 0) / totals.length;
        const sumSquaredDeviations = totals.reduce((sum, value) => sum + (value - meanPsuTotal) ** 2, 0);
        varianceNumerator += (totals.length / (totals.length - 1)) * sumSquaredDeviations;
      }
      const variance = varianceNumerator / (normalizedWeightSum ** 2);
      if (!Number.isFinite(variance) || variance < 0) throw new Error('Design-based variance overflowed or is invalid.');
      standardError = Math.sqrt(variance);
      if (!Number.isFinite(standardError)) throw new Error('Design-based standard error is not finite.');
      confidenceInterval = {
        lower: round(weightedMean - 1.96 * standardError),
        upper: round(weightedMean + 1.96 * standardError),
      };
      varianceStatus = 'available_taylor_linearization_wr_first_stage';
      estimationNotes.push('Variance uses first-stage Taylor linearization with a with-replacement PSU approximation and normal 1.96 interval; no FPC or higher-stage correction is applied.');
    }
  }

  const meetsEffectiveSampleThreshold = kishEffectiveSampleSize >= minimumEffectiveSampleSize;
  if (!meetsEffectiveSampleThreshold) warnings.push(`Kish effective sample size ${round(kishEffectiveSampleSize, 2)} is below the configured minimum ${minimumEffectiveSampleSize}.`);

  return {
    survey_id: first.survey_id,
    wave_id: first.wave_id,
    country_iso3: first.country_iso3,
    question_id: first.question_id,
    sample_size: records.length,
    weighted_mean: round(weightedMean),
    sum_weights: round(sumWeights),
    kish_effective_sample_size: kishEffectiveSampleSize,
    strata_count: strataCount,
    psu_count: psuCount,
    standard_error: standardError === null ? null : round(standardError),
    confidence_interval_95: confidenceInterval,
    variance_status: varianceStatus,
    variance_method: varianceStatus === 'available_taylor_linearization_wr_first_stage'
      ? 'Taylor linearization; first-stage PSU totals; with-replacement approximation'
      : 'not estimated',
    minimum_effective_sample_size: minimumEffectiveSampleSize,
    meets_effective_sample_threshold: meetsEffectiveSampleThreshold,
    warnings,
    estimation_notes: estimationNotes,
  };
}


export interface SurveyDistributionCategoryEstimate {
  response_value: number;
  unweighted_count: number;
  weighted_share_pct: number;
  standard_error_pct: number | null;
  confidence_interval_95_pct: { lower: number; upper: number } | null;
}

export interface SurveyDistributionEstimate {
  survey_id: string;
  wave_id: string;
  country_iso3: string;
  question_id: string;
  sample_size: number;
  sum_weights: number;
  kish_effective_sample_size: number;
  strata_count: number;
  psu_count: number;
  variance_status: SurveyVarianceStatus;
  minimum_effective_sample_size: number;
  meets_effective_sample_threshold: boolean;
  categories: SurveyDistributionCategoryEstimate[];
  warnings: string[];
  estimation_notes: string[];
}

/**
 * Estimates a design-aware weighted response distribution for an ordinal or
 * categorical question after an explicit, versioned mapping to numeric values.
 * Shares are not inferred from the weighted mean. Variance uses the same
 * first-stage with-replacement Taylor/PSU approximation as the weighted mean;
 * when design metadata are incomplete or singleton strata occur, intervals are
 * withheld rather than replaced with naive independent-observation intervals.
 */
export function estimateSurveyWeightedDistribution(
  input: readonly unknown[],
  options: { minimumEffectiveSampleSize?: number; maximumCategories?: number } = {},
): SurveyDistributionEstimate {
  if (input.length === 0) throw new Error('Cannot estimate a survey distribution from zero records.');
  const minimumEffectiveSampleSize = options.minimumEffectiveSampleSize ?? 30;
  const maximumCategories = options.maximumCategories ?? 100;
  if (!Number.isFinite(minimumEffectiveSampleSize) || minimumEffectiveSampleSize <= 0) {
    throw new RangeError('minimumEffectiveSampleSize must be finite and greater than zero.');
  }
  if (!Number.isInteger(maximumCategories) || maximumCategories < 2 || maximumCategories > 1_000) {
    throw new RangeError('maximumCategories must be an integer between 2 and 1000.');
  }

  const records = input.map(parseSurveyMicrodataRecord);
  const first = records[0]!;
  if (!records.every((row) => row.survey_id === first.survey_id
    && row.wave_id === first.wave_id
    && row.country_iso3 === first.country_iso3
    && row.question_id === first.question_id)) {
    throw new Error('A survey distribution must contain exactly one survey, wave, country and question.');
  }

  const categories = [...new Set(records.map((row) => row.response_numeric))].sort((a, b) => a - b);
  if (categories.length > maximumCategories) {
    throw new RangeError(`Survey question has ${categories.length} distinct mapped responses; maximumCategories is ${maximumCategories}. Map continuous responses to a documented scale or increase the bounded limit.`);
  }

  const sumWeights = records.reduce((sum, row) => sum + row.final_weight, 0);
  if (!Number.isFinite(sumWeights) || sumWeights <= 0) throw new Error('Sum of final survey weights overflowed or is not finite.');
  const maximumWeight = records.reduce((maximum, row) => Math.max(maximum, row.final_weight), 0);
  const normalizedWeights = records.map((row) => row.final_weight / maximumWeight);
  const normalizedWeightSum = normalizedWeights.reduce((sum, weight) => sum + weight, 0);
  const normalizedSquaredWeightSum = normalizedWeights.reduce((sum, weight) => sum + weight ** 2, 0);
  if (!Number.isFinite(normalizedWeightSum) || normalizedWeightSum <= 0
    || !Number.isFinite(normalizedSquaredWeightSum) || normalizedSquaredWeightSum <= 0) {
    throw new Error('Normalized survey distribution weights are not finite.');
  }
  const kishEffectiveSampleSize = (normalizedWeightSum ** 2) / normalizedSquaredWeightSum;
  if (!Number.isFinite(kishEffectiveSampleSize) || kishEffectiveSampleSize <= 0 || kishEffectiveSampleSize > records.length + 1e-6) {
    throw new Error('Kish effective sample size is not finite or exceeds the observed sample size.');
  }

  const completeDesign = records.every((row) => row.stratum_id !== undefined && row.psu_id !== undefined);
  let varianceStatus: SurveyVarianceStatus = 'unavailable_design_metadata';
  let strataCount = 0;
  let psuCount = 0;
  const designByCategory = new Map<number, Map<string, Map<string, number>>>();
  const warnings: string[] = [];
  if (!completeDesign) {
    warnings.push('No design-based confidence intervals: complete stratum and PSU identifiers are not available for every record.');
  } else {
    const stratumCounts = new Map<string, Set<string>>();
    for (const row of records) {
      const psus = stratumCounts.get(row.stratum_id!) ?? new Set<string>();
      psus.add(row.psu_id!);
      stratumCounts.set(row.stratum_id!, psus);
    }
    strataCount = stratumCounts.size;
    psuCount = [...stratumCounts.values()].reduce((total, psus) => total + psus.size, 0);
    if ([...stratumCounts.values()].some((psus) => psus.size < 2)) {
      varianceStatus = 'unavailable_singleton_stratum';
      warnings.push('At least one stratum has fewer than two sampled PSUs; design-based confidence intervals are withheld because certainty-PSU metadata/FPC was not supplied.');
    } else {
      varianceStatus = 'available_taylor_linearization_wr_first_stage';
      for (const category of categories) {
        const share = records.reduce((sum, row, index) => sum + (row.response_numeric === category ? normalizedWeights[index]! : 0), 0) / normalizedWeightSum;
        const strata = new Map<string, Map<string, number>>();
        for (let index = 0; index < records.length; index++) {
          const row = records[index]!;
          const residual = (row.response_numeric === category ? 1 : 0) - share;
          const psus = strata.get(row.stratum_id!) ?? new Map<string, number>();
          psus.set(row.psu_id!, (psus.get(row.psu_id!) ?? 0) + normalizedWeights[index]! * residual);
          strata.set(row.stratum_id!, psus);
        }
        designByCategory.set(category, strata);
      }
    }
  }

  const distribution = categories.map((category): SurveyDistributionCategoryEstimate => {
    let weightedCategoryTotal = 0;
    let unweightedCount = 0;
    for (let index = 0; index < records.length; index++) {
      if (records[index]!.response_numeric === category) {
        weightedCategoryTotal += normalizedWeights[index]!;
        unweightedCount++;
      }
    }
    const share = weightedCategoryTotal / normalizedWeightSum;
    let standardError: number | null = null;
    let confidenceInterval: { lower: number; upper: number } | null = null;
    if (varianceStatus === 'available_taylor_linearization_wr_first_stage') {
      const strata = designByCategory.get(category)!;
      let varianceNumerator = 0;
      for (const psus of strata.values()) {
        const totals = [...psus.values()];
        const meanPsuTotal = totals.reduce((sum, value) => sum + value, 0) / totals.length;
        const sumSquaredDeviations = totals.reduce((sum, value) => sum + (value - meanPsuTotal) ** 2, 0);
        varianceNumerator += (totals.length / (totals.length - 1)) * sumSquaredDeviations;
      }
      const variance = varianceNumerator / (normalizedWeightSum ** 2);
      if (!Number.isFinite(variance) || variance < 0) throw new Error('Design-based response-share variance is invalid.');
      standardError = Math.sqrt(variance);
      if (!Number.isFinite(standardError)) throw new Error('Design-based response-share standard error is invalid.');
      confidenceInterval = {
        lower: Math.max(0, (share - 1.96 * standardError) * 100),
        upper: Math.min(100, (share + 1.96 * standardError) * 100),
      };
    }
    return {
      response_value: category,
      unweighted_count: unweightedCount,
      weighted_share_pct: round(share * 100),
      standard_error_pct: standardError === null ? null : round(standardError * 100),
      confidence_interval_95_pct: confidenceInterval ? {
        lower: round(confidenceInterval.lower),
        upper: round(confidenceInterval.upper),
      } : null,
    };
  });

  const meetsEffectiveSampleThreshold = kishEffectiveSampleSize >= minimumEffectiveSampleSize;
  if (!meetsEffectiveSampleThreshold) {
    warnings.push(`Kish effective sample size ${round(kishEffectiveSampleSize, 2)} is below the configured minimum ${minimumEffectiveSampleSize}.`);
  }
  return {
    survey_id: first.survey_id,
    wave_id: first.wave_id,
    country_iso3: first.country_iso3,
    question_id: first.question_id,
    sample_size: records.length,
    sum_weights: round(sumWeights),
    kish_effective_sample_size: kishEffectiveSampleSize,
    strata_count: strataCount,
    psu_count: psuCount,
    variance_status: varianceStatus,
    minimum_effective_sample_size: minimumEffectiveSampleSize,
    meets_effective_sample_threshold: meetsEffectiveSampleThreshold,
    categories: distribution,
    warnings,
    estimation_notes: [
      'Weighted shares are calculated separately for each explicitly harmonized response value; they are not inferred from the question mean.',
      'Kish effective sample size reflects unequal weights only and is not a substitute for design effect or domain-specific effective sample size.',
      'Intervals use first-stage Taylor linearization with a with-replacement PSU approximation; FPC, replicate weights, calibration variance and higher-stage corrections are not estimated.',
      'No respondent-level segments, preferences or latent traits are assigned by this aggregate distribution.',
    ],
  };
}

export interface SurveyObservationContext {
  territory_id: string;
  indicator_id: string;
  indicator_name: string;
  psychographic_construct_id?: string;
  psychographic_construct_label?: string;
  psychographic_construct_domain?: PsychographicConstructDomain;
  canonical_scale_id?: string;
  canonical_scale_min?: number;
  canonical_scale_max?: number;
  question_mapping_version?: string;
  module_id: number;
  source_id: string;
  dataset_id: string;
  period_year: number;
  unit: string;
  valuation_basis: ObservationContract['valuation_basis'];
  methodology_id: string;
  commercial_use_allowed: ObservationContract['commercial_use_allowed'];
  asserted_at: string;
  population_scope: string;
  weighting_method: string;
  fieldwork_start?: string;
  fieldwork_end?: string;
  questionnaire_url?: string;
}

function isRealIsoCalendarDate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [year, month, day] = value.split('-').map(Number);
  const date = new Date(Date.UTC(year!, month! - 1, day!));
  return date.getUTCFullYear() === year && date.getUTCMonth() === month! - 1 && date.getUTCDate() === day;
}

/** Converts a validated aggregate estimate into the canonical Silver observation contract. */
export function surveyMeanEstimateToObservation(
  estimate: SurveyMeanEstimate,
  context: SurveyObservationContext,
): ObservationContract {
  if (!/^[A-Z]{3}$/.test(estimate.country_iso3)) throw new Error('Survey estimate country code is invalid.');
  if (context.territory_id !== estimate.country_iso3) throw new Error('Country-level survey estimates must be assigned to the matching canonical country territory, not a subnational territory.');
  if (!context.territory_id || context.territory_id.trim().length < 2 || context.territory_id.length > 16
    || !context.indicator_id || context.indicator_id.trim().length < 2 || context.indicator_id.length > 120
    || !context.indicator_name?.trim() || !context.source_id?.trim() || context.source_id.trim().length < 2
    || !context.dataset_id?.trim() || context.dataset_id.trim().length < 2 || !context.methodology_id?.trim()
    || !context.unit?.trim()) {
    throw new Error('Observation context identifiers and names are required and must fit the Silver contract.');
  }
  if (!Number.isInteger(context.module_id) || context.module_id < 1 || context.module_id > 13) {
    throw new RangeError('module_id must be an integer between 1 and 13.');
  }
  if (!context.asserted_at || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?(?:Z|[+-]\d{2}:\d{2})$/.test(context.asserted_at)
    || !Number.isFinite(Date.parse(context.asserted_at))) throw new Error('asserted_at must be an ISO-8601 timestamp with an explicit timezone.');
  if (!context.population_scope?.trim() || context.population_scope.length > 500 || !context.weighting_method?.trim() || context.weighting_method.length > 500) throw new Error('population_scope and weighting_method are required and must fit the Silver contract.');
  for (const [name, value] of [['fieldwork_start', context.fieldwork_start], ['fieldwork_end', context.fieldwork_end]] as const) {
    if (value !== undefined && !isRealIsoCalendarDate(value)) {
      throw new Error(`${name} must be a valid ISO calendar date.`);
    }
  }
  // Both values are canonical YYYY-MM-DD dates, so lexical order is chronological.
  if (context.fieldwork_start && context.fieldwork_end && context.fieldwork_start > context.fieldwork_end) {
    throw new Error('fieldwork_start must be on or before fieldwork_end.');
  }
  if (context.questionnaire_url !== undefined) {
    try { const url = new URL(context.questionnaire_url); if (url.protocol !== 'https:' && url.protocol !== 'http:') throw new Error(); }
    catch { throw new Error('questionnaire_url must be an HTTP(S) URL.'); }
  }
  if (!estimate.survey_id?.trim() || estimate.survey_id.length > 120 || !estimate.wave_id?.trim() || estimate.wave_id.length > 120
    || !estimate.question_id?.trim() || estimate.question_id.length > 160
    || !Number.isInteger(estimate.sample_size) || estimate.sample_size <= 0
    || !Number.isFinite(estimate.minimum_effective_sample_size) || estimate.minimum_effective_sample_size <= 0
    || !Number.isInteger(estimate.strata_count) || estimate.strata_count < 0
    || !Number.isInteger(estimate.psu_count) || estimate.psu_count < 0 || estimate.strata_count > estimate.psu_count || estimate.psu_count > estimate.sample_size
    || !Number.isFinite(estimate.weighted_mean) || !Number.isFinite(estimate.sum_weights) || estimate.sum_weights <= 0
    || !Number.isFinite(estimate.kish_effective_sample_size)
    || estimate.kish_effective_sample_size <= 0 || estimate.kish_effective_sample_size > estimate.sample_size + 1e-6) {
    throw new Error('Survey estimate totals or effective sample size are invalid.');
  }
  if (!Number.isInteger(context.period_year) || context.period_year < 1900 || context.period_year > 2100) {
    throw new RangeError('period_year must be an integer between 1900 and 2100.');
  }
  if (estimate.meets_effective_sample_threshold !== (estimate.kish_effective_sample_size >= estimate.minimum_effective_sample_size)) {
    throw new Error('Survey estimate threshold flag is inconsistent with its Kish effective sample size.');
  }
  if (estimate.meets_effective_sample_threshold === false) {
    throw new Error('Survey estimate is below its minimum effective sample-size release threshold.');
  }
  if ((estimate.standard_error === null) !== (estimate.confidence_interval_95 === null)) {
    throw new Error('Survey standard error and confidence interval must either both be available or both be null.');
  }
  if (estimate.variance_status === 'available_taylor_linearization_wr_first_stage'
    ? estimate.standard_error === null || estimate.confidence_interval_95 === null || estimate.strata_count < 1 || estimate.psu_count <= estimate.strata_count
    : estimate.standard_error !== null || estimate.confidence_interval_95 !== null) {
    throw new Error('Survey variance status, design counts and interval fields are inconsistent.');
  }
  if (estimate.standard_error !== null && (!Number.isFinite(estimate.standard_error) || estimate.standard_error < 0)) {
    throw new Error('Survey standard_error must be finite and non-negative.');
  }
  if (estimate.confidence_interval_95 && (!Number.isFinite(estimate.confidence_interval_95.lower)
    || !Number.isFinite(estimate.confidence_interval_95.upper)
    || estimate.confidence_interval_95.lower > estimate.confidence_interval_95.upper)) {
    throw new Error('Survey confidence interval is invalid.');
  }
  const validValuationBases: readonly string[] = ['nominal_usd', 'constant_2015_usd', 'constant_2021_ppp', 'percent', 'count', 'index_score'];
  if (!validValuationBases.includes(context.valuation_basis)
    || !['confirmed', 'denied', 'unknown'].includes(context.commercial_use_allowed)) {
    throw new Error('valuation_basis or commercial_use_allowed is invalid.');
  }
  const psychographicFields = [context.psychographic_construct_id, context.canonical_scale_id, context.canonical_scale_min, context.canonical_scale_max, context.question_mapping_version];
  if (psychographicFields.some((value) => value !== undefined) && !(context.psychographic_construct_id?.trim() && context.canonical_scale_id?.trim() && typeof context.canonical_scale_min === 'number' && Number.isFinite(context.canonical_scale_min) && typeof context.canonical_scale_max === 'number' && Number.isFinite(context.canonical_scale_max) && context.canonical_scale_min < context.canonical_scale_max && context.question_mapping_version?.trim())) {
    throw new Error('Psychographic survey mapping requires a construct ID, canonical scale, ordered scale bounds and mapping version.');
  }
  const observation: ObservationContract = {
    territory_id: context.territory_id,
    iso3: estimate.country_iso3,
    indicator_id: context.indicator_id,
    indicator_name: context.indicator_name,
    module_id: context.module_id,
    source_id: context.source_id,
    dataset_id: context.dataset_id,
    period_year: context.period_year,
    survey_id: estimate.survey_id,
    survey_wave_id: estimate.wave_id,
    question_id: estimate.question_id,
    survey_statistic: 'weighted_mean',
    survey_variance_status: estimate.variance_status,
    survey_minimum_effective_sample_size: estimate.minimum_effective_sample_size,
    ...(context.psychographic_construct_id ? {
      psychographic_construct_id: context.psychographic_construct_id,
      psychographic_construct_label: context.psychographic_construct_label?.trim() || context.psychographic_construct_id,
      psychographic_construct_domain: context.psychographic_construct_domain ?? 'other',
      canonical_scale_id: context.canonical_scale_id!,
      canonical_scale_min: context.canonical_scale_min!,
      canonical_scale_max: context.canonical_scale_max!,
      question_mapping_version: context.question_mapping_version!,
    } : {}),
    sample_size: estimate.sample_size,
    effective_sample_size: estimate.kish_effective_sample_size,
    population_scope: context.population_scope,
    weighting_method: context.weighting_method,
    value_numeric: estimate.weighted_mean,
    unit: context.unit,
    valuation_basis: context.valuation_basis,
    methodology_id: context.methodology_id,
    commercial_use_allowed: context.commercial_use_allowed,
    asserted_at: context.asserted_at,
    ...(estimate.standard_error !== null ? { standard_error: estimate.standard_error } : {}),
    ...(estimate.confidence_interval_95 ? {
      confidence_interval_lower: estimate.confidence_interval_95.lower,
      confidence_interval_upper: estimate.confidence_interval_95.upper,
    } : {}),
    ...(context.fieldwork_start ? { fieldwork_start: context.fieldwork_start } : {}),
    ...(context.fieldwork_end ? { fieldwork_end: context.fieldwork_end } : {}),
    ...(context.questionnaire_url ? { questionnaire_url: context.questionnaire_url } : {}),
  };
  return observation;
}

/** Converts a design-aware response distribution to one aggregate Silver row per answer category. */
export function surveyDistributionToObservations(
  estimate: SurveyDistributionEstimate,
  context: SurveyObservationContext,
): ObservationContract[] {
  if (!/^[A-Z]{3}$/.test(estimate.country_iso3)) throw new Error('Survey distribution country code is invalid.');
  if (context.territory_id !== estimate.country_iso3) throw new Error('Country-level survey distributions must be assigned to the matching canonical country territory, not a subnational territory.');
  if (!context.psychographic_construct_id?.trim() || !context.canonical_scale_id?.trim()
    || typeof context.canonical_scale_min !== 'number' || !Number.isFinite(context.canonical_scale_min)
    || typeof context.canonical_scale_max !== 'number' || !Number.isFinite(context.canonical_scale_max)
    || context.canonical_scale_min >= context.canonical_scale_max || !context.question_mapping_version?.trim()) {
    throw new Error('Survey response distributions require complete versioned psychographic construct and canonical scale metadata.');
  }
  if (!context.indicator_id?.trim() || context.indicator_id.length > 120 || !context.indicator_name?.trim()
    || !context.source_id?.trim() || context.source_id.length < 2 || !context.dataset_id?.trim() || context.dataset_id.length < 2
    || !context.methodology_id?.trim() || !context.unit?.trim()
    || !context.population_scope?.trim() || context.population_scope.length > 500
    || !context.weighting_method?.trim() || context.weighting_method.length > 500) {
    throw new Error('Survey distribution context identifiers, unit, population scope and weighting method are required.');
  }
  if (!Number.isInteger(context.module_id) || context.module_id < 1 || context.module_id > 13) {
    throw new RangeError('module_id must be an integer between 1 and 13.');
  }
  if (!Number.isInteger(context.period_year) || context.period_year < 1900 || context.period_year > 2100) {
    throw new RangeError('period_year must be an integer between 1900 and 2100.');
  }
  if (!context.asserted_at || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?(?:Z|[+-]\d{2}:\d{2})$/.test(context.asserted_at)
    || !Number.isFinite(Date.parse(context.asserted_at))) throw new Error('asserted_at must be an ISO-8601 timestamp with an explicit timezone.');
  for (const [name, value] of [['fieldwork_start', context.fieldwork_start], ['fieldwork_end', context.fieldwork_end]] as const) {
    if (value !== undefined && !isRealIsoCalendarDate(value)) throw new Error(`${name} must be a valid ISO calendar date.`);
  }
  if (context.fieldwork_start && context.fieldwork_end && context.fieldwork_start > context.fieldwork_end) {
    throw new Error('fieldwork_start must be on or before fieldwork_end.');
  }
  if (context.questionnaire_url !== undefined) {
    try { const url = new URL(context.questionnaire_url); if (url.protocol !== 'https:' && url.protocol !== 'http:') throw new Error(); }
    catch { throw new Error('questionnaire_url must be an HTTP(S) URL.'); }
  }
  if (!['confirmed', 'denied', 'unknown'].includes(context.commercial_use_allowed)) {
    throw new Error('commercial_use_allowed is invalid.');
  }
  if (!estimate.survey_id?.trim() || estimate.survey_id.length > 120 || !estimate.wave_id?.trim() || estimate.wave_id.length > 120
    || !estimate.question_id?.trim() || estimate.question_id.length > 160
    || !Number.isInteger(estimate.sample_size) || estimate.sample_size <= 0
    || !Number.isFinite(estimate.sum_weights) || estimate.sum_weights <= 0
    || !Number.isFinite(estimate.kish_effective_sample_size) || estimate.kish_effective_sample_size <= 0
    || estimate.kish_effective_sample_size > estimate.sample_size + 1e-6
    || !Number.isFinite(estimate.minimum_effective_sample_size) || estimate.minimum_effective_sample_size <= 0
    || !Number.isInteger(estimate.strata_count) || estimate.strata_count < 0
    || !Number.isInteger(estimate.psu_count) || estimate.psu_count < 0
    || estimate.psu_count > estimate.sample_size || estimate.strata_count > estimate.psu_count) {
    throw new Error('Survey distribution totals, sample size or design counts are invalid.');
  }
  if (estimate.meets_effective_sample_threshold !== (estimate.kish_effective_sample_size >= estimate.minimum_effective_sample_size)) {
    throw new Error('Survey distribution threshold flag is inconsistent with Kish effective sample size.');
  }
  if (!estimate.meets_effective_sample_threshold) {
    throw new Error('Survey distribution is below its minimum effective sample-size release threshold.');
  }
  if (!['available_taylor_linearization_wr_first_stage', 'unavailable_design_metadata', 'unavailable_singleton_stratum'].includes(estimate.variance_status)) {
    throw new Error('Survey distribution variance status is invalid.');
  }
  if (estimate.categories.length === 0 || estimate.categories.some((item) => !Number.isFinite(item.response_value)
    || item.response_value < context.canonical_scale_min! || item.response_value > context.canonical_scale_max!
    || !Number.isInteger(item.unweighted_count) || item.unweighted_count <= 0
    || !Number.isFinite(item.weighted_share_pct) || item.weighted_share_pct < 0 || item.weighted_share_pct > 100
    || (item.standard_error_pct !== null && (!Number.isFinite(item.standard_error_pct) || item.standard_error_pct < 0))
    || (item.confidence_interval_95_pct !== null && (!Number.isFinite(item.confidence_interval_95_pct.lower)
      || !Number.isFinite(item.confidence_interval_95_pct.upper)
      || item.confidence_interval_95_pct.lower < 0 || item.confidence_interval_95_pct.upper > 100
      || item.confidence_interval_95_pct.lower > item.confidence_interval_95_pct.upper)))) {
    throw new Error('Survey distribution contains invalid categories, counts, confidence intervals or weighted shares for its canonical scale.');
  }
  if (new Set(estimate.categories.map((item) => item.response_value)).size !== estimate.categories.length) {
    throw new Error('Survey distribution response categories must be unique.');
  }
  if (estimate.categories.reduce((sum, item) => sum + item.unweighted_count, 0) !== estimate.sample_size) {
    throw new Error('Survey response-category counts must reconcile exactly to the valid-response sample size.');
  }
  const shareTotal = estimate.categories.reduce((sum, item) => sum + item.weighted_share_pct, 0);
  if (Math.abs(shareTotal - 100) > 0.02) throw new Error('Survey weighted response distribution must sum to 100 percent.');
  if (estimate.variance_status === 'available_taylor_linearization_wr_first_stage'
    ? estimate.categories.some((item) => item.standard_error_pct === null || item.confidence_interval_95_pct === null)
    : estimate.categories.some((item) => item.standard_error_pct !== null || item.confidence_interval_95_pct !== null)) {
    throw new Error('Survey distribution intervals must match the reported variance status.');
  }

  return estimate.categories.map((item): ObservationContract => ({
    territory_id: context.territory_id,
    iso3: estimate.country_iso3,
    indicator_id: context.indicator_id,
    indicator_name: context.indicator_name,
    module_id: context.module_id,
    source_id: context.source_id,
    dataset_id: context.dataset_id,
    period_year: context.period_year,
    survey_id: estimate.survey_id,
    survey_wave_id: estimate.wave_id,
    question_id: estimate.question_id,
    response_category: String(item.response_value),
    response_category_count: item.unweighted_count,
    psychographic_construct_id: context.psychographic_construct_id!,
    psychographic_construct_label: context.psychographic_construct_label?.trim() || context.psychographic_construct_id!,
    psychographic_construct_domain: context.psychographic_construct_domain ?? 'other',
    canonical_scale_id: context.canonical_scale_id!,
    canonical_scale_min: context.canonical_scale_min!,
    canonical_scale_max: context.canonical_scale_max!,
    question_mapping_version: context.question_mapping_version!,
    survey_statistic: 'weighted_share',
    survey_variance_status: estimate.variance_status,
    survey_minimum_effective_sample_size: estimate.minimum_effective_sample_size,
    sample_size: estimate.sample_size,
    effective_sample_size: estimate.kish_effective_sample_size,
    population_scope: context.population_scope,
    weighting_method: context.weighting_method,
    value_numeric: item.weighted_share_pct,
    unit: '%',
    valuation_basis: 'percent',
    methodology_id: context.methodology_id,
    commercial_use_allowed: context.commercial_use_allowed,
    asserted_at: context.asserted_at,
    ...(item.standard_error_pct !== null ? { standard_error: item.standard_error_pct } : {}),
    ...(item.confidence_interval_95_pct ? {
      confidence_interval_lower: item.confidence_interval_95_pct.lower,
      confidence_interval_upper: item.confidence_interval_95_pct.upper,
    } : {}),
    ...(context.fieldwork_start ? { fieldwork_start: context.fieldwork_start } : {}),
    ...(context.fieldwork_end ? { fieldwork_end: context.fieldwork_end } : {}),
    ...(context.questionnaire_url ? { questionnaire_url: context.questionnaire_url } : {}),
  }));
}

