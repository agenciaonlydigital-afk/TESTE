/** Reference counter for one downloaded response shared by in-flight callers. */
export class HttpTempFileReferenceTracker {
  private readonly references = new Map<string, number>();

  register(filePath: string, consumers: number): void {
    if (!filePath || !Number.isInteger(consumers) || consumers < 1) {
      throw new RangeError('A file path and a positive integer consumer count are required');
    }
    this.references.set(filePath, consumers);
  }

  /**
   * Returns true when the caller should unlink now. Shared paths remain until
   * every consumer has completed its read/parse and released its reference.
   */
  release(filePath: string): boolean {
    const count = this.references.get(filePath);
    if (count === undefined) return true;
    if (count > 1) {
      this.references.set(filePath, count - 1);
      return false;
    }
    this.references.delete(filePath);
    return true;
  }

  getConsumerCount(filePath: string): number | null {
    return this.references.get(filePath) ?? null;
  }
}
