/** Readiness of the canonical territory dimension for global country analytics.
 * A count alone never proves the registry is complete: the enriched registry
 * must be broad enough and each global source must declare its own denominator.
 */
export const MINIMUM_GLOBAL_COUNTRY_ENTITIES = 190;

export interface TerritoryRegistryReadiness {
  enrichedTerritoryCount: number;
  minimumGlobalCountryEntities: number;
  expectedCountrySetConfigured: boolean;
  globalCountryCoverageReady: boolean;
  status: 'BLOCKED' | 'READY';
  reason: string;
}

export function assessTerritoryRegistryReadiness(
  enrichedTerritoryCount: number,
  expectedCountrySetConfigured: boolean,
): TerritoryRegistryReadiness {
  if (!Number.isInteger(enrichedTerritoryCount) || enrichedTerritoryCount < 0) {
    throw new RangeError('enrichedTerritoryCount must be a non-negative integer');
  }
  const registryBroadEnough = enrichedTerritoryCount >= MINIMUM_GLOBAL_COUNTRY_ENTITIES;
  const ready = registryBroadEnough && expectedCountrySetConfigured;
  return {
    enrichedTerritoryCount,
    minimumGlobalCountryEntities: MINIMUM_GLOBAL_COUNTRY_ENTITIES,
    expectedCountrySetConfigured,
    globalCountryCoverageReady: ready,
    status: ready ? 'READY' : 'BLOCKED',
    reason: ready
      ? 'An explicit, source-specific expected territory set is configured and the enriched country registry meets the minimum breadth check.'
      : `Global country coverage is not certifiable: ${enrichedTerritoryCount}/${MINIMUM_GLOBAL_COUNTRY_ENTITIES} minimum enriched country entities are present and ${expectedCountrySetConfigured ? 'the source-specific expected territory set is configured' : 'no source-specific expected territory set has been configured'}.`,
  };
}
