import type { MacroEconomicRow, MarketAttractivenessBreakdown, PsychographicTemporalStatus } from './types.ts';

export type MarketMode = 'mass_market' | 'premium';

type RequiredMetric =
  | 'population_total'
  | 'urbanization_pct'
  | 'internet_users_pct'
  | 'gdp_per_capita_ppp_2021'
  | 'inflation_cpi_pct';

const REQUIRED_FIELDS: readonly RequiredMetric[] = [
  'population_total',
  'urbanization_pct',
  'internet_users_pct',
  'gdp_per_capita_ppp_2021',
  'inflation_cpi_pct',
];

const YEAR_FIELD: Record<RequiredMetric, keyof MacroEconomicRow> = {
  population_total: 'population_total_year',
  urbanization_pct: 'urbanization_pct_year',
  internet_users_pct: 'internet_users_pct_year',
  gdp_per_capita_ppp_2021: 'gdp_per_capita_ppp_2021_year',
  inflation_cpi_pct: 'inflation_cpi_pct_year',
};

const CURRENT_YEAR = new Date().getUTCFullYear();

function finiteInRange(value: number | null | undefined, min: number, max: number): number | null {
  return typeof value === 'number' && Number.isFinite(value) && value >= min && value <= max
    ? value
    : null;
}

function validYear(value: unknown): number | null {
  return typeof value === 'number'
    && Number.isInteger(value)
    && value >= 1900
    && value <= CURRENT_YEAR
    ? value
    : null;
}

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

function round(value: number): number {
  return Number(value.toFixed(1));
}

function temporalStatus(
  years: number[],
  allValuesPresent: boolean,
  allYearsPresent: boolean
): PsychographicTemporalStatus {
  if (!allValuesPresent) return years.length === 0 ? 'unknown' : 'incomplete';
  if (!allYearsPresent) return 'incomplete';
  if (years.length === 0) return 'unknown';
  const oldest = Math.min(...years);
  const newest = Math.max(...years);
  if (CURRENT_YEAR - newest > 5) return 'stale';
  if (newest - oldest > 3) return 'mixed_periods';
  return 'aligned';
}

/**
 * Computes an explicitly heuristic market-context index.
 * It never imputes missing metrics and withholds the composite if inputs are
 * incomplete, outside accepted ranges, or not sufficiently time-aligned.
 */
export function computeMarketAttractiveness(
  row: Pick<MacroEconomicRow,
    | RequiredMetric
    | 'population_total_year'
    | 'urbanization_pct_year'
    | 'internet_users_pct_year'
    | 'gdp_per_capita_ppp_2021_year'
    | 'inflation_cpi_pct_year'
  >,
  mode: MarketMode,
): MarketAttractivenessBreakdown {
  const values: Record<RequiredMetric, number | null> = {
    population_total: finiteInRange(row.population_total, 1, Number.MAX_SAFE_INTEGER),
    urbanization_pct: finiteInRange(row.urbanization_pct, 0, 100),
    internet_users_pct: finiteInRange(row.internet_users_pct, 0, 100),
    gdp_per_capita_ppp_2021: finiteInRange(row.gdp_per_capita_ppp_2021, 1, 1_000_000),
    inflation_cpi_pct: finiteInRange(row.inflation_cpi_pct, -100, 1_000),
  };

  const availableFields = REQUIRED_FIELDS.filter((field) => values[field] !== null).length;
  const coveragePct = round((availableFields / REQUIRED_FIELDS.length) * 100);
  const years = REQUIRED_FIELDS.map((field) => validYear(row[YEAR_FIELD[field]])).filter(
    (year): year is number => year !== null
  );
  const allValuesPresent = availableFields === REQUIRED_FIELDS.length;
  const allYearsPresent = years.length === REQUIRED_FIELDS.length;
  const status = temporalStatus(years, allValuesPresent, allYearsPresent);
  const oldestYear = years.length ? Math.min(...years) : null;
  const newestYear = years.length ? Math.max(...years) : null;

  // Population scale and two independent market-access proxies are combined
  // additively; multiplying urbanization × internet would assume unobserved
  // independence between those populations and overstate true addressable reach.
  const population = values.population_total;
  const urbanization = values.urbanization_pct;
  const internet = values.internet_users_pct;
  const populationScale = population === null
    ? null
    : round(clamp(((Math.log10(population) - 4) / 5) * 100, 0, 100));
  const demographicScore = populationScale !== null && urbanization !== null && internet !== null
    ? round(0.45 * populationScale + 0.25 * urbanization + 0.30 * internet)
    : null;

  const ppp = values.gdp_per_capita_ppp_2021;
  const purchasingPowerScore = ppp === null ? null : round(clamp((ppp / 80_000) * 100, 0, 100));

  const inflation = values.inflation_cpi_pct;
  const inflationRiskMultiplier = inflation === null
    ? null
    : Number((1 / (1 + Math.max(0, (inflation - 3) / 100))).toFixed(3));

  const componentsAvailable = demographicScore !== null
    && purchasingPowerScore !== null
    && inflationRiskMultiplier !== null;
  const marketAttractivenessScore = componentsAvailable && status === 'aligned'
    ? round(clamp(
      (mode === 'mass_market'
        ? 0.45 * demographicScore + 0.55 * purchasingPowerScore
        : 0.25 * demographicScore + 0.75 * purchasingPowerScore)
        * inflationRiskMultiplier,
      0,
      100,
    ))
    : null;

  const missingOrInvalidFields = REQUIRED_FIELDS.flatMap((field) => {
    const metricMissing = values[field] === null;
    const yearMissing = validYear(row[YEAR_FIELD[field]]) === null;
    return [
      ...(metricMissing ? [field] : []),
      ...(yearMissing ? [`${field}_year`] : []),
    ];
  });

  if (status === 'stale' || status === 'mixed_periods') {
    missingOrInvalidFields.push('temporal_alignment');
  }

  let interpretation = 'Heuristic contextual index; not observed demand, sales forecast, willingness to pay, or market share.';
  if (marketAttractivenessScore === null) {
    interpretation = `Composite withheld: data are incomplete or temporally incomparable (status: ${status}).`;
  }

  return {
    methodology_version: '2.1.0',
    demographic_score: demographicScore,
    purchasing_power_score: purchasingPowerScore,
    inflation_risk_multiplier: inflationRiskMultiplier,
    market_attractiveness_score: marketAttractivenessScore,
    data_fields_available: availableFields,
    data_fields_expected: REQUIRED_FIELDS.length,
    data_coverage_pct: coveragePct,
    temporal_status: status,
    oldest_data_year: oldestYear,
    newest_data_year: newestYear,
    missing_or_invalid_fields: missingOrInvalidFields,
    interpretation,
  };
}
