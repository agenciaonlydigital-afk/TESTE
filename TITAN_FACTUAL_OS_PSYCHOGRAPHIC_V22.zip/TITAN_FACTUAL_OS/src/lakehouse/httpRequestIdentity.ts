import { createHash } from 'node:crypto';

export interface HttpRequestIdentityInput {
  method: string;
  url: string;
  body?: string;
  etag?: string | null;
  lastModified?: string | null;
  bypassCache: boolean;
  headers?: Record<string, string>;
}

/**
 * In-flight request coalescing must not cross authorization or representation
 * boundaries. Normalize header names and sort entries before hashing.
 */
export function buildHttpRequestDedupKey(input: HttpRequestIdentityInput): string {
  const headers = Object.entries(input.headers ?? {})
    .map(([name, value]) => [name.toLowerCase(), value] as const)
    .sort(([aName, aValue], [bName, bValue]) =>
      aName.localeCompare(bName) || aValue.localeCompare(bValue)
    );
  const identity = JSON.stringify([
    input.method.toUpperCase(),
    input.url,
    input.body ?? '',
    input.etag ?? '',
    input.lastModified ?? '',
    input.bypassCache ? 'bypass' : 'conditional',
    headers,
  ]);
  return createHash('sha256').update(identity).digest('hex');
}
