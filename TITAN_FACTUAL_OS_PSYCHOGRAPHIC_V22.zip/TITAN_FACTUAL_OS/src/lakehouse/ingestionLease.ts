export const INGESTION_LEASE_SCHEMA_SQL = `
  CREATE TABLE IF NOT EXISTS ingestion_leases (
    source_id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL UNIQUE,
    owner_id TEXT NOT NULL,
    acquired_at TEXT NOT NULL,
    heartbeat_at TEXT NOT NULL,
    lease_expires_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_ingestion_leases_expiry
    ON ingestion_leases(lease_expires_at);
`;

export const INGESTION_LEASE_TTL_MS = 5 * 60_000;
export const INGESTION_LEASE_HEARTBEAT_MS = 45_000;

interface SqliteRunResult {
  changes: number;
}

interface SqliteStatementLike {
  run(...params: unknown[]): SqliteRunResult;
  all(...params: unknown[]): unknown[];
}

export interface SqliteLeaseDatabase {
  prepare(sql: string): SqliteStatementLike;
}

export interface ActiveIngestionLease {
  source_id: string;
  run_id: string;
  owner_id: string;
  acquired_at: string;
  heartbeat_at: string;
  lease_expires_at: string;
}

function isoTime(value: number): string {
  if (!Number.isFinite(value)) throw new RangeError('Lease time must be finite');
  return new Date(value).toISOString();
}

function validateLeaseDuration(leaseMs: number): void {
  if (!Number.isInteger(leaseMs) || leaseMs < 1_000 || leaseMs > 24 * 60 * 60_000) {
    throw new RangeError('leaseMs must be an integer between 1 second and 24 hours');
  }
}

/**
 * Atomically claims a source lease. An unexpired lease is never overwritten;
 * an expired lease can be taken over after a crashed worker or server restart.
 */
export function acquireIngestionLease(
  db: SqliteLeaseDatabase,
  input: { sourceId: string; runId: string; ownerId: string; nowMs?: number; leaseMs?: number },
): boolean {
  const nowMs = input.nowMs ?? Date.now();
  const leaseMs = input.leaseMs ?? INGESTION_LEASE_TTL_MS;
  validateLeaseDuration(leaseMs);
  const now = isoTime(nowMs);
  const expiresAt = isoTime(nowMs + leaseMs);
  const result = db.prepare(`
    INSERT INTO ingestion_leases (
      source_id, run_id, owner_id, acquired_at, heartbeat_at, lease_expires_at
    ) VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(source_id) DO UPDATE SET
      run_id = excluded.run_id,
      owner_id = excluded.owner_id,
      acquired_at = excluded.acquired_at,
      heartbeat_at = excluded.heartbeat_at,
      lease_expires_at = excluded.lease_expires_at
    WHERE ingestion_leases.lease_expires_at <= excluded.acquired_at
  `).run(input.sourceId, input.runId, input.ownerId, now, now, expiresAt);
  return result.changes === 1;
}

/** Extends only a lease still owned by this run and not already expired. */
export function renewIngestionLease(
  db: SqliteLeaseDatabase,
  input: { sourceId: string; runId: string; ownerId: string; nowMs?: number; leaseMs?: number },
): boolean {
  const nowMs = input.nowMs ?? Date.now();
  const leaseMs = input.leaseMs ?? INGESTION_LEASE_TTL_MS;
  validateLeaseDuration(leaseMs);
  const now = isoTime(nowMs);
  const expiresAt = isoTime(nowMs + leaseMs);
  const result = db.prepare(`
    UPDATE ingestion_leases
    SET heartbeat_at = ?, lease_expires_at = ?
    WHERE source_id = ? AND run_id = ? AND owner_id = ? AND lease_expires_at > ?
  `).run(now, expiresAt, input.sourceId, input.runId, input.ownerId, now);
  return result.changes === 1;
}

/** Owner-checked release prevents an old worker from deleting a replacement lease. */
export function releaseIngestionLease(
  db: SqliteLeaseDatabase,
  input: { sourceId: string; runId: string; ownerId: string },
): boolean {
  const result = db.prepare(`
    DELETE FROM ingestion_leases
    WHERE source_id = ? AND run_id = ? AND owner_id = ?
  `).run(input.sourceId, input.runId, input.ownerId);
  return result.changes === 1;
}

export function listActiveIngestionLeases(
  db: SqliteLeaseDatabase,
  nowMs = Date.now(),
): ActiveIngestionLease[] {
  const now = isoTime(nowMs);
  return db.prepare(`
    SELECT source_id, run_id, owner_id, acquired_at, heartbeat_at, lease_expires_at
    FROM ingestion_leases
    WHERE lease_expires_at > ?
    ORDER BY source_id ASC
  `).all(now) as ActiveIngestionLease[];
}
