import type {
  MacroEconomicRow,
  PsychographicProfile,
  PsychographicSignal,
  PsychographicTemporalStatus,
  PsychographicSurveyMeasure,
  PsychographicSurveyObservation,
} from './types.ts';

type PsychographicInput = Pick<MacroEconomicRow,
  | 'gdp_per_capita_ppp_2021'
  | 'gdp_per_capita_ppp_2021_year'
  | 'urbanization_pct'
  | 'urbanization_pct_year'
  | 'internet_users_pct'
  | 'internet_users_pct_year'
  | 'inflation_cpi_pct'
  | 'inflation_cpi_pct_year'
  | 'unemployment_pct'
  | 'unemployment_pct_year'
  | 'itu_mobile_per_100'
  | 'itu_mobile_per_100_year'
  | 'undp_hdi'
  | 'undp_hdi_year'
  | 'unwpp_tfr'
  | 'unwpp_tfr_year'
> & {
  median_age: number | null;
  median_age_year: number | null;
};

type MetricKey =
  | 'median_age'
  | 'gdp_per_capita_ppp_2021'
  | 'urbanization_pct'
  | 'internet_users_pct'
  | 'inflation_cpi_pct'
  | 'unemployment_pct'
  | 'itu_mobile_per_100'
  | 'undp_hdi'
  | 'unwpp_tfr';

type MetricEvidence = {
  metric: MetricKey;
  value: number;
  unit: string;
  period_year: number | null;
};

type MetricDefinition = {
  metric: MetricKey;
  value: number | null;
  year: number | null;
  unit: string;
  min: number;
  max: number;
  scaleMin: number;
  scaleMax: number;
};

type WeightedInput = {
  value: number | null;
  weight: number;
  evidence: MetricEvidence | null;
};

const CURRENT_YEAR = new Date().getUTCFullYear();
const EXPECTED_FIELDS = 9;
const round = (value: number): number => Number(value.toFixed(1));
const clamp = (value: number, min = 0, max = 100): number => Math.max(min, Math.min(max, value));

function validYear(value: number | null): number | null {
  return typeof value === 'number'
    && Number.isInteger(value)
    && value >= 1900
    && value <= CURRENT_YEAR
    ? value
    : null;
}

function metricDefinitions(row: PsychographicInput): MetricDefinition[] {
  return [
    { metric: 'median_age', value: row.median_age, year: row.median_age_year, unit: 'years', min: 10, max: 80, scaleMin: 15, scaleMax: 55 },
    { metric: 'gdp_per_capita_ppp_2021', value: row.gdp_per_capita_ppp_2021, year: row.gdp_per_capita_ppp_2021_year, unit: '2021 Int$ PPP', min: 1, max: 1_000_000, scaleMin: 0, scaleMax: 80_000 },
    { metric: 'urbanization_pct', value: row.urbanization_pct, year: row.urbanization_pct_year, unit: '%', min: 0, max: 100, scaleMin: 0, scaleMax: 100 },
    { metric: 'internet_users_pct', value: row.internet_users_pct, year: row.internet_users_pct_year, unit: '%', min: 0, max: 100, scaleMin: 0, scaleMax: 100 },
    { metric: 'inflation_cpi_pct', value: row.inflation_cpi_pct, year: row.inflation_cpi_pct_year, unit: '%', min: -100, max: 1_000, scaleMin: 0, scaleMax: 15 },
    { metric: 'unemployment_pct', value: row.unemployment_pct, year: row.unemployment_pct_year, unit: '%', min: 0, max: 100, scaleMin: 0, scaleMax: 20 },
    { metric: 'itu_mobile_per_100', value: row.itu_mobile_per_100, year: row.itu_mobile_per_100_year, unit: 'subscriptions per 100 people', min: 0, max: 500, scaleMin: 0, scaleMax: 200 },
    { metric: 'undp_hdi', value: row.undp_hdi, year: row.undp_hdi_year, unit: 'index 0–1', min: 0, max: 1, scaleMin: 0, scaleMax: 1 },
    { metric: 'unwpp_tfr', value: row.unwpp_tfr, year: row.unwpp_tfr_year, unit: 'births per woman', min: 0, max: 15, scaleMin: 0, scaleMax: 6 },
  ];
}

function normalizedMetric(value: number | null, min: number, max: number, invert = false): number | null {
  if (value === null) return null;
  const score = clamp(((value - min) / (max - min)) * 100);
  return round(invert ? 100 - score : score);
}

function computeTemporalQuality(
  evidence: MetricEvidence[],
  invalidFields: string[]
): Pick<PsychographicProfile,
  'temporal_coverage_pct' | 'temporal_status' | 'oldest_evidence_year' | 'newest_evidence_year' | 'temporal_span_years'
> {
  const years = evidence
    .map((item) => item.period_year)
    .filter((year): year is number => year !== null);
  const oldest = years.length > 0 ? Math.min(...years) : null;
  const newest = years.length > 0 ? Math.max(...years) : null;
  const temporalCoverage = evidence.length > 0 ? round((years.length / evidence.length) * 100) : 0;
  let status: PsychographicTemporalStatus = 'unknown';

  if (evidence.length > 0 || invalidFields.length > 0) {
    if (years.length < evidence.length || invalidFields.length > 0) {
      status = 'incomplete';
    } else if (newest !== null && CURRENT_YEAR - newest > 5) {
      status = 'stale';
    } else if (oldest !== null && newest !== null && newest - oldest > 3) {
      status = 'mixed_periods';
    } else {
      status = 'aligned';
    }
  }

  return {
    temporal_coverage_pct: temporalCoverage,
    temporal_status: status,
    oldest_evidence_year: oldest,
    newest_evidence_year: newest,
    temporal_span_years: oldest !== null && newest !== null ? newest - oldest : null,
  };
}

function classifySignalTemporalStatus(evidence: MetricEvidence[]): PsychographicTemporalStatus {
  if (evidence.length === 0) return 'unknown';
  const years = evidence
    .map((item) => item.period_year)
    .filter((year): year is number => year !== null);
  if (years.length < evidence.length) return 'incomplete';
  const oldest = Math.min(...years);
  const newest = Math.max(...years);
  if (CURRENT_YEAR - newest > 5) return 'stale';
  if (newest - oldest > 3) return 'mixed_periods';
  return 'aligned';
}

function buildSignal(
  inputs: WeightedInput[],
  definition: Omit<PsychographicSignal, 'score' | 'level' | 'evidence' | 'interpretation' | 'temporal_status' | 'evidence_fields_available' | 'evidence_fields_expected' | 'data_coverage_pct'>
): PsychographicSignal {
  const available = inputs.filter(
    (input): input is WeightedInput & { value: number; evidence: MetricEvidence } =>
      input.value !== null && input.evidence !== null
  );
  const expected = inputs.length;
  const minimumEvidence = expected === 1 ? 1 : 2;
  const coveragePct = round((available.length / expected) * 100);
  const evidence = available.map((item) => item.evidence);
  const signalTemporalStatus = classifySignalTemporalStatus(evidence);

  const base = {
    ...definition,
    evidence_fields_available: available.length,
    evidence_fields_expected: expected,
    data_coverage_pct: coveragePct,
    temporal_status: signalTemporalStatus,
    evidence,
  };

  if (available.length < minimumEvidence) {
    return {
      ...base,
      score: null,
      level: 'insufficient_data',
      interpretation: `Evidência insuficiente: ${available.length}/${expected} indicadores disponíveis; o escore exige ao menos ${minimumEvidence}.`,
    };
  }

  if (signalTemporalStatus !== 'aligned') {
    return {
      ...base,
      score: null,
      level: 'insufficient_data',
      interpretation: `Escore retido: qualidade temporal ${signalTemporalStatus}; exige datas completas, recentes e alinhadas em até três anos.`,
    };
  }

  const totalWeight = available.reduce((sum, item) => sum + item.weight, 0);
  const score = round(
    available.reduce((sum, item) => sum + clamp(item.value) * item.weight, 0) / totalWeight
  );
  const level = score >= 67 ? 'high' : score >= 34 ? 'moderate' : 'low';
  const levelText = level === 'high' ? 'elevado' : level === 'moderate' ? 'moderado' : 'baixo';

  return {
    ...base,
    score,
    level,
    interpretation: `Sinal contextual ${levelText} (${score}/100), derivado apenas de indicadores agregados disponíveis. Não mede atitudes nem preferências psicológicas.`,
  };
}

/**
 * Converts independently harmonized survey question aggregates into measured
 * question-level evidence. It never combines different waves, questions, scales,
 * methods, samples or data providers into a synthetic persona score.
 */
export function buildMeasuredSurveyMeasures(
  territoryId: string,
  observations: readonly PsychographicSurveyObservation[],
): PsychographicSurveyMeasure[] {
  const groups = new Map<string, PsychographicSurveyObservation[]>();
  for (const row of observations) {
    if (row.territory_id !== territoryId || row.iso3 !== territoryId) continue;
    const key = JSON.stringify([
      row.survey_id, row.wave_id, row.question_id, row.construct_id, row.canonical_scale_id,
      row.mapping_version, row.period_year, row.source_id, row.dataset_id, row.methodology_id,
    ]);
    const group = groups.get(key) ?? [];
    group.push(row);
    groups.set(key, group);
  }

  const measures: PsychographicSurveyMeasure[] = [];
  for (const [key, rows] of groups) {
    const means = rows.filter((row) => row.statistic === 'weighted_mean');
    if (means.length !== 1) continue;
    const mean = means[0]!;
    const shares = rows.filter((row) => row.statistic === 'weighted_share');
    const numeric = [mean.canonical_scale_min, mean.canonical_scale_max, mean.value_numeric,
      mean.effective_sample_size, mean.minimum_effective_sample_size];
    if (numeric.some((value) => !Number.isFinite(value))
      || mean.canonical_scale_min >= mean.canonical_scale_max
      || mean.value_numeric < mean.canonical_scale_min || mean.value_numeric > mean.canonical_scale_max
      || !Number.isInteger(mean.period_year) || mean.period_year < 1900 || mean.period_year > CURRENT_YEAR
      || !Number.isInteger(mean.sample_size) || mean.sample_size <= 0
      || mean.effective_sample_size <= 0 || mean.effective_sample_size > mean.sample_size + 1e-6
      || mean.minimum_effective_sample_size <= 0 || !mean.construct_id || !mean.construct_label
      || !['available_taylor_linearization_wr_first_stage', 'unavailable_design_metadata', 'unavailable_singleton_stratum'].includes(mean.variance_status)
      || !mean.canonical_scale_id || !mean.mapping_version || !mean.survey_id || !mean.wave_id || !mean.question_id
      || !mean.source_id || !mean.dataset_id || !mean.methodology_id || !mean.population_scope || !mean.weighting_method) continue;

    const uniqueCategories = new Set<string>();
    const counts = shares.map((item) => item.response_category_count);
    const hasCounts = counts.some((count) => count !== null);
    if (hasCounts && (counts.some((count) => count === null || !Number.isInteger(count) || count <= 0)
      || counts.reduce<number>((total, count) => total + (count ?? 0), 0) !== mean.sample_size)) continue;
    const sourceShareTotal = shares.reduce((total, item) => total + item.value_numeric, 0);
    const sourceDistributionMean = shares.reduce((total, item) => {
      const responseValue = item.response_category === null ? Number.NaN : Number(item.response_category);
      return total + (Number.isFinite(responseValue) ? responseValue * item.value_numeric / 100 : 0);
    }, 0);
    if (shares.length > 0 && (Math.abs(sourceShareTotal - 100) > 0.02 || Math.abs(sourceDistributionMean - mean.value_numeric) > 0.1)) continue;
    const responseDistribution = shares.map((item) => {
      if (item.response_category === null || item.response_category.trim() === '' || uniqueCategories.has(item.response_category)) return null;
      uniqueCategories.add(item.response_category);
      const responseValue = Number(item.response_category);
      if (!Number.isFinite(responseValue) || responseValue < mean.canonical_scale_min || responseValue > mean.canonical_scale_max
        || !Number.isFinite(item.value_numeric) || item.value_numeric < 0 || item.value_numeric > 100
        || (item.standard_error !== null && (!Number.isFinite(item.standard_error) || item.standard_error < 0))
        || item.sample_size !== mean.sample_size || Math.abs(item.effective_sample_size - mean.effective_sample_size) > 1e-5
        || item.minimum_effective_sample_size !== mean.minimum_effective_sample_size
        || item.variance_status !== mean.variance_status || item.construct_id !== mean.construct_id
        || item.construct_label !== mean.construct_label || item.construct_domain !== mean.construct_domain
        || item.canonical_scale_id !== mean.canonical_scale_id || item.canonical_scale_min !== mean.canonical_scale_min
        || item.canonical_scale_max !== mean.canonical_scale_max || item.mapping_version !== mean.mapping_version
        || item.period_year !== mean.period_year || item.iso3 !== mean.iso3
        || item.population_scope !== mean.population_scope || item.weighting_method !== mean.weighting_method
        || item.fieldwork_start !== mean.fieldwork_start || item.fieldwork_end !== mean.fieldwork_end
        || item.methodology_id !== mean.methodology_id || item.commercial_use_allowed !== mean.commercial_use_allowed) return null;
      const lower = item.confidence_interval_lower;
      const upper = item.confidence_interval_upper;
      const validInterval = lower !== null && upper !== null && Number.isFinite(lower) && Number.isFinite(upper)
        && lower >= 0 && upper <= 100 && lower <= upper;
      if (mean.variance_status === 'available_taylor_linearization_wr_first_stage'
        ? item.standard_error === null || !Number.isFinite(item.standard_error) || item.standard_error < 0 || !validInterval
        : item.standard_error !== null || validInterval) return null;
      const interval = validInterval
        ? { lower: round(clamp(lower!)), upper: round(clamp(upper!)) }
        : null;
      return {
        response_value: responseValue,
        weighted_share_pct: round(item.value_numeric),
        confidence_interval_95: interval,
        unweighted_count: item.response_category_count ?? null,
      };
    });
    if (responseDistribution.some((item) => item === null)) continue;
    const distribution = responseDistribution.filter((item): item is NonNullable<typeof item> => item !== null)
      .sort((a, b) => a.response_value - b.response_value);
    const hasInterval = mean.confidence_interval_lower !== null && mean.confidence_interval_upper !== null
      && Number.isFinite(mean.confidence_interval_lower) && Number.isFinite(mean.confidence_interval_upper)
      && mean.confidence_interval_lower <= mean.confidence_interval_upper;
    const confidenceInterval = hasInterval
      ? {
          lower: round(clamp(((mean.confidence_interval_lower! - mean.canonical_scale_min) / (mean.canonical_scale_max - mean.canonical_scale_min)) * 100)),
          upper: round(clamp(((mean.confidence_interval_upper! - mean.canonical_scale_min) / (mean.canonical_scale_max - mean.canonical_scale_min)) * 100)),
        }
      : null;
    if ((mean.standard_error === null) !== !hasInterval) continue;
    if (mean.variance_status === 'available_taylor_linearization_wr_first_stage' && (!hasInterval || mean.standard_error === null)) continue;
    if (mean.variance_status !== 'available_taylor_linearization_wr_first_stage' && (hasInterval || mean.standard_error !== null)) continue;

    const qualityFlags: PsychographicSurveyMeasure['quality_flags'] = [];
    if (CURRENT_YEAR - mean.period_year > 5) qualityFlags.push('stale');
    if (mean.effective_sample_size < mean.minimum_effective_sample_size) qualityFlags.push('small_effective_sample');
    if (mean.variance_status !== 'available_taylor_linearization_wr_first_stage') qualityFlags.push('variance_unavailable');
    if (mean.commercial_use_allowed === 'unknown') qualityFlags.push('license_unknown');
    if (mean.commercial_use_allowed === 'denied') qualityFlags.push('license_denied');

    measures.push({
      measure_id: key,
      construct_id: mean.construct_id,
      construct_label: mean.construct_label,
      construct_domain: mean.construct_domain,
      survey_id: mean.survey_id,
      wave_id: mean.wave_id,
      question_id: mean.question_id,
      canonical_scale_id: mean.canonical_scale_id,
      canonical_scale_min: mean.canonical_scale_min,
      canonical_scale_max: mean.canonical_scale_max,
      mapping_version: mean.mapping_version,
      period_year: mean.period_year,
      weighted_mean: round(mean.value_numeric),
      score_0_100: round(((mean.value_numeric - mean.canonical_scale_min) / (mean.canonical_scale_max - mean.canonical_scale_min)) * 100),
      confidence_interval_95_score: confidenceInterval,
      sample_size: mean.sample_size,
      effective_sample_size: round(mean.effective_sample_size),
      minimum_effective_sample_size: mean.minimum_effective_sample_size,
      standard_error: mean.standard_error === null ? null : round(mean.standard_error),
      variance_status: mean.variance_status,
      response_distribution: distribution,
      population_scope: mean.population_scope,
      weighting_method: mean.weighting_method,
      fieldwork_start: mean.fieldwork_start,
      fieldwork_end: mean.fieldwork_end,
      source_id: mean.source_id,
      dataset_id: mean.dataset_id,
      methodology_id: mean.methodology_id,
      commercial_use_allowed: mean.commercial_use_allowed,
      quality_flags: qualityFlags,
    });
  }
  return measures.sort((a, b) => b.period_year - a.period_year || a.construct_label.localeCompare(b.construct_label) || a.measure_id.localeCompare(b.measure_id)).slice(0, 100);
}

/**
 * Builds six transparent market-context hypotheses from aggregate data. These
 * are not measured psychographics, individual predictions, or audience shares.
 * Inputs outside the documented ranges are discarded rather than clamped into
 * plausible-looking evidence. Missing values are not imputed.
 */
export function buildPsychographicProfile(
  row: PsychographicInput,
  surveyObservations: readonly PsychographicSurveyObservation[] = [],
): PsychographicProfile {
  const definitions = metricDefinitions(row);
  const invalidFields: string[] = [];
  const metrics = new Map<MetricKey, { normalized: number; evidence: MetricEvidence }>();

  for (const item of definitions) {
    if (typeof item.value !== 'number' || !Number.isFinite(item.value)) continue;
    if (item.value < item.min || item.value > item.max) {
      invalidFields.push(item.metric);
      continue;
    }
    metrics.set(item.metric, {
      normalized: normalizedMetric(item.value, item.scaleMin, item.scaleMax) ?? 0,
      evidence: {
        metric: item.metric,
        value: item.value,
        unit: item.unit,
        period_year: validYear(item.year),
      },
    });
  }

  const get = (metric: MetricKey, invert = false): { value: number | null; evidence: MetricEvidence | null } => {
    const found = metrics.get(metric);
    if (!found) return { value: null, evidence: null };
    return { value: invert ? 100 - found.normalized : found.normalized, evidence: found.evidence };
  };
  const add = (metric: MetricKey, weight: number, invert = false): WeightedInput => {
    const item = get(metric, invert);
    return { value: item.value, weight, evidence: item.evidence };
  };
  const allEvidence = [...metrics.values()].map((item) => item.evidence);
  const availableFields = allEvidence.length;

  const signals: PsychographicSignal[] = [
    buildSignal(
      [add('internet_users_pct', 0.4), add('itu_mobile_per_100', 0.35), add('urbanization_pct', 0.25)],
      {
        signal_id: 'digital_discovery',
        label: 'Contexto de conectividade e descoberta digital',
        research_hypothesis: 'Avaliar canais digitais, streaming e campanhas mobile-first. O sinal representa infraestrutura e acesso agregados, não uso de plataformas nem preferência musical observada.',
        validation_action: 'Validar com alcance efetivo por plataforma, audiência agregada, consumo musical e pesquisas de hábitos digitais.',
      }
    ),
    buildSignal(
      [add('gdp_per_capita_ppp_2021', 0.5, true), add('inflation_cpi_pct', 0.25), add('unemployment_pct', 0.25)],
      {
        signal_id: 'value_sensitivity',
        label: 'Contexto econômico de preço e valor',
        research_hypothesis: 'Formar hipóteses para faixas de preço, bundles e ofertas de entrada; indicadores macroeconômicos não medem elasticidade ou disposição individual a pagar.',
        validation_action: 'Validar com conversão, elasticidade observada, pesquisas de disposição a pagar e dados transacionais agregados.',
      }
    ),
    buildSignal(
      [add('urbanization_pct', 0.55), add('internet_users_pct', 0.45)],
      {
        signal_id: 'urban_cultural_access',
        label: 'Contexto de acesso urbano e cultural conectado',
        research_hypothesis: 'Avaliar viabilidade de distribuição digital e ativações urbanas. O indicador não mede participação cultural, presença de equipamentos ou interesse por eventos.',
        validation_action: 'Cruzar com dados territoriais de eventos, equipamentos culturais, streaming e cobertura de distribuição local.',
      }
    ),
    buildSignal(
      [add('gdp_per_capita_ppp_2021', 0.4, true), add('inflation_cpi_pct', 0.3), add('unemployment_pct', 0.3)],
      {
        signal_id: 'economic_pressure',
        label: 'Contexto de pressão econômica',
        research_hypothesis: 'Identificar mercados onde propostas de menor barreira de entrada merecem teste; não é diagnóstico da situação financeira dos indivíduos.',
        validation_action: 'Validar com renda disponível, custo de vida, emprego, consumo real e pesquisas locais recentes.',
      }
    ),
    buildSignal(
      [add('median_age', 0.65, true), add('unwpp_tfr', 0.35)],
      {
        signal_id: 'age_structure_context',
        label: 'Contexto de estrutura etária e transição demográfica',
        research_hypothesis: 'Usar medianas e fecundidade apenas para decidir quais coortes e estudos populacionais merecem análise detalhada; não atribui gostos a grupos etários.',
        validation_action: 'Validar com distribuição etária completa, coortes, dados de consumo e metadados temporais comparáveis.',
      }
    ),
    buildSignal(
      [add('undp_hdi', 1)],
      {
        signal_id: 'human_development_context',
        label: 'Contexto de desenvolvimento humano',
        research_hypothesis: 'Usar o contexto de desenvolvimento para formular perguntas de pesquisa sobre condições estruturais; HDI não mede abertura cultural, valores ou comportamento do consumidor.',
        validation_action: 'Cruzar com educação, renda, saúde agregada, pesquisas sociais e indicadores culturais diretamente observados.',
      }
    ),
  ];

  const temporal = computeTemporalQuality(allEvidence, invalidFields);
  const measuredSurveyMeasures = buildMeasuredSurveyMeasures(row.territory_id, surveyObservations);
  return {
    model_version: '2.2.0',
    evidence_type: 'aggregated_demographic_proxy',
    validation_status: 'survey_validation_required',
    data_coverage_pct: round((availableFields / EXPECTED_FIELDS) * 100),
    data_fields_available: availableFields,
    data_fields_expected: EXPECTED_FIELDS,
    invalid_fields: invalidFields.sort(),
    ...temporal,
    survey_evidence_count: measuredSurveyMeasures.length,
    measured_survey_measures: measuredSurveyMeasures,
    population_share_estimated: false,
    signals,
    limitations: [
      'São hipóteses de contexto de mercado calculadas com indicadores agregados, não psicografias medidas.',
      'A cobertura representa disponibilidade de 9 indicadores, não percentual da população coberta nem confiança psicológica.',
      'Os indicadores podem pertencer a anos diferentes; temporal_status explicita alinhamento, mistura, desatualização ou ausência de datas.',
      'Não estima participação, tamanho ou prevalência de segmentos na população.',
      'Não infere personalidade, preferências musicais, religião, orientação política, saúde ou outros atributos sensíveis.',
      'Gini permanece como indicador descritivo de desigualdade no painel macroeconômico e não entra nos sinais de preço, valor ou pressão econômica; desigualdade nacional não mede sensibilidade individual a preços.' ,
      'Correlação demográfica não demonstra motivação, preferência ou causalidade.',
      'Medidas de pesquisa são mantidas por pergunta, onda, escala e amostra; não são combinadas em uma persona latente.',
      'Uma medida só aparece quando há média ponderada e metadados compatíveis; distribuição de respostas permanece separada da média.',
      'Amostras efetivas pequenas, intervalos indisponíveis, dados antigos e licenças desconhecidas/negadas são sinalizados individualmente.',
      'Validação exige pesquisas representativas licenciadas, comportamento agregado observado e metadados de amostragem.',
    ],
  };
}
