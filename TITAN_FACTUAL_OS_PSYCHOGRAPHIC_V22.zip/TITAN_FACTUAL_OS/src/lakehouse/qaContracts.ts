import {
  ObservationContractSchema,
  type ObservationContract,
  type SnapshotManifest,
  type SourceCatalogEntry,
} from './types.ts';
import { buildObservationIdentity } from './observationIdentity.ts';
import { buildDataQualityProfile, type DataQualityProfile } from './dataQualityProfile.ts';

export interface SilverQaGateResult {
  validated: ObservationContract[];
  schemaRejections: number;
  licenseMismatches: number;
  duplicateCollisions: number;
  qaNotes: string;
  qualityProfile: DataQualityProfile;
}

/**
 * Silver Data Quality Gate (inspired by dlt, Great Expectations & LakeLogic contracts):
 * 1. Validates every record against the Zod ObservationContractSchema.
 * 2. Enforces commercial license integrity (blocks privilege escalation above catalog source tier).
 * 3. Deduplicates by territory/indicator/year plus every available survey and analytical dimension.
 * 4. Runs snapshot regression guard against the prior active Silver snapshot (>50% drop block).
 */
export function runSilverQaGate(
  source: SourceCatalogEntry,
  silverRecords: ObservationContract[],
  prevSnapshot?: SnapshotManifest
): SilverQaGateResult {
  let schemaRejections = 0;
  let licenseMismatches = 0;
  const dedupMap = new Map<string, ObservationContract>();
  let duplicateCollisions = 0;

  for (const rec of silverRecords) {
    const parsed = ObservationContractSchema.safeParse(rec);
    if (!parsed.success) {
      schemaRejections++;
      continue;
    }

    const row = parsed.data;
    if (row.commercial_use_allowed !== source.commercial_use_allowed) {
      licenseMismatches++;
      continue;
    }

    const compositeKey = buildObservationIdentity(row);
    const existing = dedupMap.get(compositeKey);
    if (existing) {
      duplicateCollisions++;
      if (row.asserted_at >= existing.asserted_at) {
        dedupMap.set(compositeKey, row);
      }
    } else {
      dedupMap.set(compositeKey, row);
    }
  }

  const validated = Array.from(dedupMap.values());

  if (validated.length === 0) {
    throw new Error(
      `QA Gate failed: 0 valid records after contract & license checks (${schemaRejections} schema drops, ${licenseMismatches} license drops).`
    );
  }

  if (prevSnapshot && prevSnapshot.row_count > 10 && validated.length < prevSnapshot.row_count * 0.5) {
    throw new Error(
      `QA Gate regression block: row count dropped from ${prevSnapshot.row_count} to ${validated.length} (>50% drop).`
    );
  }

  const qualityProfile = buildDataQualityProfile({
    rawRows: silverRecords.length,
    validated,
    schemaRejections,
    licenseMismatches,
    duplicateCollisions,
  });
  const failedChecks = qualityProfile.checks.filter((check) => check.status === 'fail').map((check) => check.check_id);
  const warningChecks = qualityProfile.checks.filter((check) => check.status === 'warning').map((check) => check.check_id);
  const qualityStatus = failedChecks.length ? `QUALITY FLAGS: ${failedChecks.join(', ')}` : warningChecks.length ? `QUALITY WARNINGS: ${warningChecks.join(', ')}` : 'QUALITY PROFILE: no failed checks';
  const qaNotes = `QA GATE PASSED: ${validated.length} unique rows (${schemaRejections} schema drops, ${duplicateCollisions} key dedups, ${licenseMismatches} license checks) · schema acceptance ${qualityProfile.schema_acceptance_pct}% · territories ${qualityProfile.territory_count} · indicators ${qualityProfile.indicator_count} · newest period ${qualityProfile.period_year_max ?? 'unknown'} · ${qualityStatus}`;

  return {
    validated,
    schemaRejections,
    licenseMismatches,
    duplicateCollisions,
    qaNotes,
    qualityProfile,
  };
}
