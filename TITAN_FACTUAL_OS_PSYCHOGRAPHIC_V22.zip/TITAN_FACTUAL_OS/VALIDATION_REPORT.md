# TITAN FACTUAL OS — Validation, critique and remaining release gates

**Review date:** 2026-11-22  
**Baseline:** user-supplied original `untitled.zip`; current package retains the original acquisition code.  
**Status:** dependency-free regression suite passes. Full type-check, production build, live API capture and app-level DuckDB integration remain unverified in this environment; this is not a production certification.

## Current release decision

The package is improved and regression-tested for **111 automated tests**. The dashboard remains an internal development view and exposes all ingested observations, regardless of source commercial-rights metadata. The 79 original connectors, function names, endpoint literals and source-specific parsing/extraction logic are preserved.

Do not interpret static preservation tests as proof that 79 live APIs currently work. Do not represent aggregate demographic proxies as validated psychographic segments. Do not claim global coverage or commercial redistribution rights that have not been established.

## Critical correctness decisions

1. **Preserve ingestion; do not gate the development dashboard.** All stored Silver observations remain visible in source previews and Gold analytics irrespective of `commercial_use_allowed`. Rights metadata stays attached. The optional `commercial_only=true` filter is limited to catalogue inspection. Brand Market derived profiles retain `license_clearance = unknown`. A future commercial-serving policy remains a separate inactive release gate.
2. **Freshest evidence wins.** The Gold pivot now selects the latest observation across alternative indicator IDs using period year, assertion timestamp and deterministic source priority, rather than static `COALESCE` preference.
3. **Null-safe latest observations.** Macro queries exclude null numeric observations before latest-row ranking. The median-age query now does the same, preventing a newer null row from hiding an older valid observation.
4. **No fabricated macro scores.** MAI has five mandatory inputs: population, urbanization, internet access, GDP per capita PPP and CPI inflation. It produces no composite unless all five values are valid, dated, sufficiently recent and period-aligned. GDP per capita PPP must be positive. Missing and invalid fields are surfaced.
5. **Avoid unsupported inequality assumptions.** Gini remains visible as a separate descriptive measure but is not used to reward premium markets or penalize mass-market markets. A national inequality statistic alone does not establish either opportunity direction.
6. **Psychographic label is explicitly provisional.** Six market-context hypotheses are derived from nine aggregate indicators. They are not measured attitudes, preferences, personalities, audience shares or validated personas. Each signal reports evidence coverage and its own temporal quality. No missing indicator is imputed.
7. **No spurious audience estimate.** Digital addressable population is withheld unless population and internet-use values are valid and their observation years are recent and within three years of one another.
8. **Global readiness is not overstated.** The enriched territory seed dimension currently has 34 countries, below the 190-country readiness minimum; 98% coverage scoring remains blocked until canonical geographic coverage and source-specific expected-territory manifests exist.

## Original functionality preservation

- Original source inventory: **95 records**.
- Original Wave-1 keyless sources marked implemented: **79**.
- Original connector registry: **79 IDs in original order**.
- Original ingest function names: **80/80 retained**.
- Original endpoint literal fragments: **103/103 retained**.
- Original connector extraction/parser logic: preservation fixture test passes.

The preservation contract is tested by `tests/connectorPreservation.test.ts`, comparing the present implementation to `tests/fixtures/original-connector-contract.json` extracted from the original user package. Do not replace the original source-specific handlers with generic connectors without an individual regression proof.

## Repository-based critique and design adoption

The matrix in `docs/ARCHITECTURE_CRITIQUE_MATRIX.md` covers connector preservation/lifecycle, incremental state, HTTP resilience, control plane, storage, freshness, temporal provenance, schemas, data quality, missingness, market index, proxy signals, surveys, behavioral data, causal inference, geospatial indexing/harmonization, global coverage, GeoParquet, streaming, security, commercial rights, build verification and operations.

Repository snapshots in that matrix prioritize established, directly relevant projects rather than indiscriminately selecting the largest repository. Patterns are used as engineering references, not imported runtimes. The psychographic algorithm remains deterministic TypeScript; adding a separate Python ML service, HDBSCAN, SHAP, DoWhy, Dagster or Kafka now would add dependencies without the representative evidence or scale requirement to justify them.

## Automated tests actually executed

Command: `node --experimental-strip-types --test tests/*.test.ts`.

| Suite | Tests | Result |
|---|---:|---|
| Acquisition planner | 4 | Passed |
| Administrative write guard | 5 | Passed |
| Compression negotiation | 1 | Passed |
| Original connector preservation | 4 | Passed |
| Coverage contracts | 2 | Passed |
| Domain registry | 4 | Passed |
| Gold SQL visibility, freshness and year metadata | 7 | Passed |
| HTTP request identity | 2 | Passed |
| HTTP retry policy | 4 | Passed |
| HTTP body streaming | 3 | Passed |
| Shared temporary-file references | 2 | Passed |
| Durable ingestion leases | 3 | Passed |
| Empty-ingestion outcome | 3 | Passed |
| World Bank 304 regression | 1 | Passed |
| Maintenance safety | 2 | Passed |
| Market Attractiveness Index | 6 | Passed |
| NDJSON writer (sync + async iterable) | 3 | Passed |
| DuckDB rolling latency metrics | 1 | Passed |
| Observation identity | 3 | Passed |
| Market-context proxy profiles | 11 | Passed |
| Continental aggregation | 2 | Passed |
| Territorial registry readiness | 3 | Passed |
| Survey analytics and canonical observation conversion | 9 | Passed |
| Survey CSV import and question harmonization | 5 | Passed |
| geoBoundaries ADM0–ADM2 catalog metadata | 4 | Passed |
| geoBoundaries batch discovery | 3 | Passed |
| GeoJSON Polygon/MultiPolygon point predicate | 4 | Passed |
| Versioned administrative boundary crosswalk | 9 | Passed |
| Silver data-quality profile (including 120,000-row stress case) | 4 | Passed |
| **Total** | **114** | **114 passed, 0 failed, 0 skipped** |

The regression checks also cover weighted survey means under extreme weight scales, explicit question-map CSV import, reverse coding, missing/unmapped question handling, Kish effective sample size, stratified first-stage variance/withheld singleton strata, numeric overflow rejection, strict country/date/timezone/fieldwork-order canonical Silver conversion, ADM0–ADM2 metadata discovery, batch concurrency/partial failures/cancellation and conservative attribution, insecure boundary URLs, Polygon/MultiPolygon holes and boundaries, antimeridian rejection, versioned crosswalk temporal intervals, period-separated allocations and denominator-weighted rates, zero-share destination omission, crosswalk overflow rejection, reconciled descriptive Silver QA, no Gini as a directional MAI multiplier, positive PPP validation, incomplete profiles, temporal alignment, dashboard visibility and original connector preservation.

## Static checks and limitations

The following static checks were executed after the final source edits:

- TypeScript/TSX syntax transpilation via the installed global TypeScript compiler API: **94 files, 0 syntax diagnostics** (including source, server and test files).
- Relative-import resolution scan across those files: **0 missing relative imports**.
- Targeted TypeScript type-check of survey CSV import/analytics, survey contracts, quality profile, Silver QA and spatial helpers: **passed** (a minimal temporary Zod declaration was used because dependencies are unavailable; this is not the full application type-check).
- Core and API `MacroEconomicRow`, `PsychographicSignal`, `PsychographicProfile`, `MarketAttractivenessBreakdown` and `BrandMarketProfile` interface parity.
- Registry and source-preservation regression tests.
- ZIP integrity verification.

**Not verified in this environment:**

- Full `tsc --noEmit` type-check: `vite/client` cannot resolve because package dependencies/type packages are not installed.
- Vite production build: `vite` executable is unavailable.
- Complete application dependency installation: package registry resolution was unavailable/timed out; `node_modules` is not present.
- Actual app runtime DuckDB SQL/materialization and persistent SQLite migration/restart recovery with the packaged `@duckdb/node-api` / `better-sqlite3` versions.
- Live API requests for all 79 original connectors. Network, credentials, rate limits, source changes and source-specific data freshness must be verified in the target environment.
- Browser smoke test and deployment/production security review.

Passing native Node tests is not a substitute for any of these.

## Remaining gates before broader deployment

1. Install the declared dependencies in a network-enabled environment and pass full TypeScript type-check, tests and Vite build.
2. Run actual SQLite migrations/restart recovery and DuckDB startup/read/write/materialization using a clean persistent data volume.
3. Execute all 79 connectors in controlled live batches; record status, pagination, continuation, row counts, freshness, parser outcomes, duplicate rates, QA and snapshot promotion evidence.
4. Expand the canonical territory dimension beyond 34 seed countries; validate ISO/M49 and administrative identities; define an expected territory manifest for every source before reporting 98% coverage.
5. Implement actual licensed survey acquisitions and harmonized questionnaire data for suitable programmes (WVS, ESS, EVS, Afrobarometer, Latinobarómetro, ISSP and regional barometers). Verify access, wave dictionaries, sampling, weights, fieldwork, geographic coverage and redistribution terms separately for each.
6. Add separate observed cultural/behavioral evidence with denominators, observation windows and sampling/coverage metadata. Do not conflate listening or pageviews with representative attitudes.
7. Complete async-iterable/batched connector processing end-to-end. The NDJSON writer applies backpressure, but current connector handlers still materialize arrays.
8. Acquire authoritative administrative geometries and implement tested polygon intersection, population allocation and boundary-version crosswalks. H3 centroid assignment is not polygon coverage.
9. Before any external commercial serving, implement and test a rights-aware policy across API, Gold, exports, downloads, caches and derived-data lineage. Keep ingestion separate. Review source/dataset terms; catalogue status is not legal advice.
10. Before public multi-user operation, add identity-aware SSO/roles, edge rate limiting, token rotation, XSS protections, backup/restore, monitoring, alerting and incident-recovery exercises.

## Final assessment

The current development baseline is stronger in preservation, temporal correctness, transparent missingness and honest claims. It is **not** yet a complete global demographic dataset, a measured psychographic segmentation product or a fully verified production data factory. These limitations are explicit and should remain visible until the corresponding evidence and runtime tests exist.


## November 22 performance and repository review addendum

- Data-quality profiling now uses one pass over each Silver result and no argument-spread min/max operations; a 120,000-row stress regression passes.
- NDJSON persistence accepts sync and async iterables while retaining backpressure and completion/error handling. Existing source connectors still return arrays, so this is not represented as end-to-end streaming.
- DuckDB latency sampling uses a bounded rolling ring buffer; invalid durations are ignored.
- DuckDB threads, memory limit and spill directory can be configured with `TITAN_DUCKDB_THREADS`, `TITAN_DUCKDB_MEMORY_LIMIT` and `TITAN_DUCKDB_TEMP_DIRECTORY`; defaults remain conservative.
- See `docs/REPOSITORY_RESEARCH_AND_PERFORMANCE_REVIEW_2026-11-22.md` for the repository selection matrix and explicit non-completion boundaries.
- Latest native test run: **114 passed, 0 failed**. TypeScript/TSX transpilation: **94 files, 0 syntax diagnostics**.
- `npm install --ignore-scripts --no-audit --no-fund` timed out; therefore full project type-check and Vite production build remain unverified.
