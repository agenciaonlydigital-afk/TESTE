
export interface OpenMetabolicsPowerSample {
  timestampMs: number;
  estimatedPowerW: number;
}

export interface OpenMetabolicsSessionInput {
  modelId: 'openmetabolics_xgboost';
  modelVersion: string;
  modelArtifactSha256: string;
  placement: 'front_pocket' | 'other';
  sensorSamplingHz: number;
  sensorCoveragePercent: number;
  durationSeconds: number;
  /** Standing baseline power produced by the same pinned OpenMetabolics model/profile implementation. */
  modelBaselinePowerW: number;
  samples: readonly OpenMetabolicsPowerSample[];
}

export interface OpenMetabolicsSessionEstimate {
  grossKcal: number;
  netKcal: number;
  durationSeconds: number;
  averagePowerW: number;
  baselinePowerW: number;
  modelArtifactSha256: string;
  sampleCount: number;
  source: 'openmetabolics_native_model_output';
  nativeRuntimeStatus: 'provider_required';
  warnings: string[];
}

/**
 * Validates and integrates per-stride power outputs from a separately validated
 * native OpenMetabolics provider. This is NOT the XGBoost model itself: the
 * published model is Python/XGBoost and must be ported and benchmarked natively
 * before a mobile app can produce these samples.
 */
export function integrateOpenMetabolicsPower(input: OpenMetabolicsSessionInput): OpenMetabolicsSessionEstimate {
  if (input.modelId !== 'openmetabolics_xgboost' || !input.modelVersion.trim() || !/^[a-f0-9]{64}$/i.test(input.modelArtifactSha256)) {
    throw new RangeError('Identificação do modelo OpenMetabolics inválida.');
  }
  if (input.placement !== 'front_pocket') {
    throw new RangeError('O modelo OpenMetabolics consultado foi desenvolvido para smartphone no bolso frontal; esta sessão não pode ser estimada com esse modelo.');
  }
  if (!Number.isFinite(input.sensorSamplingHz) || input.sensorSamplingHz < 45 || input.sensorSamplingHz > 55) {
    throw new RangeError('A frequência de sensores deve estar próxima de 50 Hz.');
  }
  if (!Number.isFinite(input.sensorCoveragePercent) || input.sensorCoveragePercent < 90 || input.sensorCoveragePercent > 100) {
    throw new RangeError('Cobertura de sensores insuficiente para aceitar a estimativa.');
  }
  if (!Number.isFinite(input.durationSeconds) || input.durationSeconds < 60 || input.durationSeconds > 36_000) {
    throw new RangeError('Duração da sessão fora da faixa suportada.');
  }
  if (!Number.isFinite(input.modelBaselinePowerW) || input.modelBaselinePowerW < 10 || input.modelBaselinePowerW > 500) {
    throw new RangeError('Baseline de potência do modelo inválida.');
  }
  if (input.samples.length < 2) throw new RangeError('A sessão precisa de pelo menos duas previsões de potência.');

  let energyJoules = 0;
  let integratedSeconds = 0;
  let powerSum = 0;
  for (let index = 0; index < input.samples.length; index += 1) {
    const sample = input.samples[index]!;
    if (!Number.isFinite(sample.timestampMs) || !Number.isFinite(sample.estimatedPowerW) || sample.estimatedPowerW < 0 || sample.estimatedPowerW > 2500) {
      throw new RangeError('Amostra de potência ou timestamp inválido.');
    }
    if (index === 0) { powerSum += sample.estimatedPowerW; continue; }
    const previous = input.samples[index - 1]!;
    const deltaSeconds = (sample.timestampMs - previous.timestampMs) / 1000;
    if (deltaSeconds <= 0 || deltaSeconds > 10) throw new RangeError('Amostras fora de ordem ou com lacuna excessiva.');
    energyJoules += ((previous.estimatedPowerW + sample.estimatedPowerW) / 2) * deltaSeconds;
    integratedSeconds += deltaSeconds;
    powerSum += sample.estimatedPowerW;
  }
  if (integratedSeconds < input.durationSeconds * 0.8 || integratedSeconds > input.durationSeconds * 1.2) {
    throw new RangeError('Duração integrada não corresponde à duração declarada.');
  }
  const grossKcal = energyJoules / 4184;
  // The native provider must supply the exact standing baseline from the pinned
  // OpenMetabolics implementation (published pipeline: Mifflin RMR × 1.41).
  const baselinePowerW = input.modelBaselinePowerW;
  const baselineKcal = baselinePowerW * integratedSeconds / 4184;
  const averagePowerW = powerSum / input.samples.length;
  return {
    grossKcal: Math.round(grossKcal),
    netKcal: Math.round(Math.max(0, grossKcal - baselineKcal)),
    durationSeconds: Math.round(integratedSeconds),
    averagePowerW: Number(averagePowerW.toFixed(2)),
    baselinePowerW: Number(baselinePowerW.toFixed(2)),
    modelArtifactSha256: input.modelArtifactSha256.toLowerCase(),
    sampleCount: input.samples.length,
    source: 'openmetabolics_native_model_output',
    nativeRuntimeStatus: 'provider_required',
    warnings: [
      'O resultado só é válido se estimatedPowerW vier do modelo OpenMetabolics original ou de um port validado contra o conjunto de referência.',
      'O modelo publicado usa acelerômetro e giroscópio a 50 Hz, posicionamento no bolso e pipeline de marcha; não é aplicável a musculação, natação, bicicleta ou celular apoiado.',
      'A integração converte potência média em energia (W × s / 4.184) e subtrai a linha de base em pé (RMR × 1,41) usada no pipeline publicado; não substitui validação independente no aparelho-alvo.',
    ],
  };
}
