import assert from 'node:assert/strict';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { useNavigationStore } from '@/src/app-core/navigation/navigation.store';
import { useAnatomyStore } from '@/src/domains/anatomy/state/anatomy.store';
import {
  computeEvolutionCockpitIndicator,
  useEvolutionStore,
} from '@/src/domains/evolution/application/evolution-public';
import {
  computeDailyMacroAndEnergyBreakdown,
  computeDayPlanSummary,
  computeNutritionTotals,
  getDailyMicronutrientDisplays,
  useNutritionStore,
} from '@/src/domains/nutrition/application/nutrition-public';
import { useProfileStore } from '@/src/domains/profile/application/profile-public';
import {
  computePlanMuscleHighlights,
  focusWorkoutExercise,
  useTrainingSessionStore,
} from '@/src/domains/training/application/training-public';
import { CockpitScreen } from '../screens/CockpitScreen';
import { NextMeal } from '../components/NextMeal';
import { DailyStatusStrip } from '../components/DailyStatusStrip';

const TEST_DATE = useNutritionStore.getState().activeDateKey;

// 1. Nutrition summary separates planned vs recorded meals accurately
{
  const seededMeals = useNutritionStore.getState().meals;
  const seededSummary = computeDayPlanSummary(seededMeals, TEST_DATE);
  assert.ok(seededSummary.totalMealsCount >= 1);
  assert.equal(seededSummary.recordedMealsCount, 2);
  assert.equal(seededSummary.plannedMealsCount, seededSummary.totalMealsCount - 2);
  assert.ok(computeNutritionTotals(seededMeals, TEST_DATE).kcal > 0);

  const initialMeals = seededMeals.map((meal) => ({
    ...meal,
    status: 'planned' as const,
    consumed_quantity: 0,
    consumed_foods: [],
  }));
  const initialSummary = computeDayPlanSummary(initialMeals, TEST_DATE);
  assert.ok(initialSummary.totalMealsCount >= 1);
  assert.equal(initialSummary.recordedMealsCount, 0);
  assert.equal(initialSummary.plannedMealsCount, initialSummary.totalMealsCount);
  assert.ok(initialSummary.plannedRemainingKcal > 0);
  assert.equal(initialSummary.nextPlannedMeal?.status, 'planned');
  assert.equal(initialSummary.latestRecordedMeal, undefined);

  const initialTotals = computeNutritionTotals(initialMeals, TEST_DATE);
  assert.equal(initialTotals.kcal, 0);

  // Confirm all planned meals for the day -> nextPlannedMeal must become undefined
  const consumedAllMeals = initialMeals.map((meal) =>
    meal.dateKey === TEST_DATE
      ? {
          ...meal,
          status: 'consumed' as const,
          consumed_quantity: meal.planned_quantity,
          consumed_foods: [...meal.planned_foods],
        }
      : meal,
  );
  const closedSummary = computeDayPlanSummary(consumedAllMeals, TEST_DATE);
  assert.equal(closedSummary.plannedMealsCount, 0);
  assert.equal(closedSummary.plannedRemainingKcal, 0);
  assert.equal(closedSummary.nextPlannedMeal, undefined);
  assert.ok(closedSummary.latestRecordedMeal);
  assert.equal(closedSummary.recordedMealsCount, closedSummary.totalMealsCount);

  const closedTotals = computeNutritionTotals(consumedAllMeals, TEST_DATE);
  assert.ok(closedTotals.kcal > 0);

  // Check partial micronutrient flagging when unquantified foods contribute to the day
  const micros = getDailyMicronutrientDisplays(consumedAllMeals, TEST_DATE, 'adult_male_19_50');
  const vitD = micros.find((m) => m.nutrientId === 'vitamin_d');
  assert.ok(vitD);
  assert.equal(typeof vitD.hasUnquantifiedSources, 'boolean');

  // Check strict planned vs consumed separation in daily breakdown
  const mixedMeals = initialMeals.map((meal, index) =>
    meal.dateKey === TEST_DATE && index === 0
      ? {
          ...meal,
          status: 'consumed' as const,
          consumed_quantity: meal.planned_quantity,
          consumed_foods: [...meal.planned_foods],
        }
      : meal,
  );
  const breakdown = computeDailyMacroAndEnergyBreakdown(mixedMeals, TEST_DATE);
  assert.ok(breakdown.plannedTotals.kcal > breakdown.consumedTotals.kcal);
  assert.equal(breakdown.meals.filter((m) => m.isRecorded).length, 1);
  assert.ok(breakdown.consumedFoods.length >= 1);

  // Open Food Facts missing vs canonical TBCA status semantics must not be conflated
  const offMissingDisplay = getDailyMicronutrientDisplays(
    [
      {
        id: 'test-off-meal',
        dateKey: TEST_DATE,
        time: '16:00',
        title: 'Lanche teste',
        description: 'Iogurte comercial',
        status: 'consumed',
        planned_quantity: 100,
        consumed_quantity: 100,
        planned_foods: [{ foodId: 'off-iogurte-proteico', quantityG: 100 }],
        consumed_foods: [{ foodId: 'off-iogurte-proteico', quantityG: 100 }],
      },
    ],
    TEST_DATE,
    'adult_male_19_50',
  );
  const offVitD = offMissingDisplay.find((m) => m.nutrientId === 'vitamin_d');
  assert.equal(offVitD?.dataStatus, 'missing');

  const tbcaCanonicalDisplay = getDailyMicronutrientDisplays(
    [
      {
        id: 'test-tbca-meal',
        dateKey: TEST_DATE,
        time: '08:00',
        title: 'Café teste',
        description: 'Ovos mexidos',
        status: 'consumed',
        planned_quantity: 100,
        consumed_quantity: 100,
        planned_foods: [{ foodId: 'tbca-ovo-mexido', quantityG: 100 }],
        consumed_foods: [{ foodId: 'tbca-ovo-mexido', quantityG: 100 }],
      },
    ],
    TEST_DATE,
    'adult_male_19_50',
  );
  const tbcaVitC = tbcaCanonicalDisplay.find((m) => m.nutrientId === 'vitamin_c');
  assert.equal(tbcaVitC?.dataStatus, 'quantified');
  assert.equal(tbcaVitC?.consumedValue, 0);
  const tbcaVitK = tbcaCanonicalDisplay.find((m) => m.nutrientId === 'vitamin_k');
  assert.equal(tbcaVitK?.dataStatus, 'not_analyzed');
}

// 2. Training exercise focus propagates muscle highlights to Anatomy 3D store
{
  const plan = useTrainingSessionStore.getState().plans[0];
  assert.ok(plan);
  const firstExercise = plan.exercises[0];
  assert.ok(firstExercise);

  focusWorkoutExercise(firstExercise.id);
  assert.equal(useTrainingSessionStore.getState().focusedExerciseId, firstExercise.id);

  const highlights = useAnatomyStore.getState().workoutHighlights;
  for (const primaryMuscle of firstExercise.muscles.primary) {
    assert.ok(highlights.primary.includes(primaryMuscle));
  }

  const fullPlanHighlights = computePlanMuscleHighlights(plan);
  assert.ok(fullPlanHighlights.primary.includes('pectoralis'));
  assert.ok(fullPlanHighlights.primary.includes('lateral_deltoid'));
  assert.ok(fullPlanHighlights.primary.includes('triceps'));
}

// 3. Contextual navigation shortcuts route directly to target module & context
{
  const nav = useNavigationStore.getState();

  nav.openNutrition('receitas');
  assert.equal(useNavigationStore.getState().activeTab, 'cardapio');
  assert.equal(useNavigationStore.getState().subView, null);
  assert.equal(useNavigationStore.getState().nutritionSection, 'receitas');

  nav.openNutrition('alimentos');
  assert.equal(useNavigationStore.getState().nutritionSection, 'alimentos');

  nav.openExerciseLibrary('pectoralis');
  assert.equal(useNavigationStore.getState().subView, 'exercise-library');
  assert.equal(useNavigationStore.getState().libraryMuscleFilter, 'pectoralis');

  nav.openSubView('exercise-library');
  assert.equal(useNavigationStore.getState().libraryMuscleFilter, 'all');

  nav.setTab('evolucao');
  assert.equal(useNavigationStore.getState().activeTab, 'evolucao');
  assert.equal(useNavigationStore.getState().subView, null);

  nav.setTab('cockpit');
}

// 4. Evolution empty vs observed indicator state
{
  const emptyIndicator = computeEvolutionCockpitIndicator([], 'gain_muscle');
  assert.equal(emptyIndicator.deltaKg, 0);

  const observed = computeEvolutionCockpitIndicator(
    [
      { id: '1', dateKey: '2026-10-01', dateLabel: '01/10/2026', weightKg: 75.0 },
      { id: '2', dateKey: '2026-10-15', dateLabel: '15/10/2026', weightKg: 76.2 },
    ],
    'gain_muscle',
  );
  assert.equal(observed.deltaKg, 1.2);
  assert.equal(observed.formattedDelta, '+1.2 kg');
  assert.equal(observed.direction, 'up');
  assert.equal(observed.isAlignedWithGoal, true);

  const opposedLoss = computeEvolutionCockpitIndicator(
    [
      { id: '1', dateKey: '2026-10-01', dateLabel: '01/10/2026', weightKg: 75.0 },
      { id: '2', dateKey: '2026-10-15', dateLabel: '15/10/2026', weightKg: 76.2 },
    ],
    'lose_weight',
  );
  assert.equal(opposedLoss.direction, 'up');
  assert.equal(opposedLoss.isAlignedWithGoal, false);
}

// 5. Dashboard SSR component rendering & state consistency verification
{
  // Initial seeded state populates upper-left evolution indicators & cockpit cards,
  // with the 4-item status strip removed above the 3D body.
  const cockpitHtml = renderToStaticMarkup(
    createElement(CockpitScreen, {
      onOpenTraining: () => {},
      onOpenTrainingPlans: () => {},
      onOpenExerciseLibrary: () => {},
      onOpenNutrition: () => {},
    }),
  );

  // Preserved & evolved Dashboard sections must render cleanly without removed noise/cards
  assert.doesNotMatch(cockpitHtml, /Estado consolidado do dia/);
  assert.match(cockpitHtml, /Modelo anatômico 3D/);
  assert.match(cockpitHtml, /Indicadores de evolução corporal/);
  assert.match(cockpitHtml, /\+0\.40 kg\/sem/);
  assert.doesNotMatch(cockpitHtml, /Ganhar Massa/);
  assert.doesNotMatch(cockpitHtml, /Tendência 30d/);
  assert.doesNotMatch(cockpitHtml, /Composição/);
  assert.doesNotMatch(cockpitHtml, /14\.8% GC/);
  assert.doesNotMatch(cockpitHtml, /Cintura 80\.5/);
  assert.doesNotMatch(cockpitHtml, /Ajustar hipertrofia da meta/);
  assert.doesNotMatch(cockpitHtml, /Energia · Prot/);
  assert.doesNotMatch(cockpitHtml, /Anatomia do treino/);
  assert.doesNotMatch(cockpitHtml, /Estimado por perfil/);
  assert.doesNotMatch(cockpitHtml, /Sobreposto · Atual × Meta/);
  assert.doesNotMatch(cockpitHtml, /ENERGIA CONSUMIDA/);
  assert.doesNotMatch(cockpitHtml, /Parcial ·/);
  assert.doesNotMatch(cockpitHtml, /Meta 2\.550 kcal/);
  assert.doesNotMatch(cockpitHtml, /Meta 285 g/);
  assert.match(cockpitHtml, />Energia</);
  assert.match(cockpitHtml, /Detalhar consumo energético/);
  assert.match(cockpitHtml, />Macronutrientes</);
  assert.match(cockpitHtml, /Detalhar Carboidratos/);
  assert.doesNotMatch(cockpitHtml, /Planejado restante/);
  assert.doesNotMatch(cockpitHtml, /refs\./);
  assert.doesNotMatch(cockpitHtml, /planej\./);
  assert.doesNotMatch(cockpitHtml, /Consumido vs meta/);
  assert.ok(cockpitHtml.indexOf('>Energia<') < cockpitHtml.indexOf('Modelo anatômico 3D'));
  assert.ok(cockpitHtml.indexOf('>Macronutrientes<') < cockpitHtml.indexOf('Modelo anatômico 3D'));
  assert.doesNotMatch(cockpitHtml, /Peso e tendência observada/);
  assert.doesNotMatch(cockpitHtml, /Variação acumulada/);
  assert.match(cockpitHtml, /Treino de hoje/);
  assert.match(cockpitHtml, /6\/19 séries executadas/);
  assert.match(cockpitHtml, /Trocar ficha/);
  assert.match(cockpitHtml, /Biblioteca de Exercícios/);
  assert.match(cockpitHtml, /Hidratação/);
  assert.match(cockpitHtml, /aria-label="Registrar água"/);
  assert.doesNotMatch(cockpitHtml, /\+250 ml/);
  assert.match(cockpitHtml, /Taxa de suor no exercício/);
  assert.match(cockpitHtml, /Próxima refeição/);
  assert.match(cockpitHtml, /Micronutrientes/);
  assert.match(cockpitHtml, /Principais/);
  assert.match(cockpitHtml, /TBCA · DRI/);
  assert.match(cockpitHtml, /Metas/);

  // Empty/reset client store mutations remain valid for live state
  useProfileStore.setState({ profileConfigured: false });
  useEvolutionStore.setState({ records: [] });
  assert.equal(useProfileStore.getState().profileConfigured, false);
  assert.equal(useEvolutionStore.getState().records.length, 0);

  // DailyStatusStrip must reflect real empty/planned states accurately
  const summary = computeDayPlanSummary(
    useNutritionStore.getState().meals.map((meal) => ({
      ...meal,
      status: 'planned' as const,
      consumed_quantity: 0,
      consumed_foods: [],
    })),
    TEST_DATE,
  );
  const stripHtml = renderToStaticMarkup(
    createElement(DailyStatusStrip, {
      activeDateKey: TEST_DATE,
      daySummary: summary,
      onOpenTraining: () => {},
    }),
  );
  assert.match(stripHtml, /Treino · Em andamento/);
  assert.match(stripHtml, /0\/4 registradas/);

  // NextMeal when all day meals are already consumed must NOT show Confirmar button
  const closedDayMeals = useNutritionStore.getState().meals.map((meal) => ({
    ...meal,
    status: 'consumed' as const,
    consumed_quantity: meal.planned_quantity,
    consumed_foods: [...meal.planned_foods],
  }));
  const closedSummary = computeDayPlanSummary(closedDayMeals, TEST_DATE);
  const closedMealHtml = renderToStaticMarkup(
    createElement(NextMeal, {
      meal: closedSummary.nextPlannedMeal,
      daySummary: closedSummary,
      onOpenNutrition: () => {},
    }),
  );
  assert.match(closedMealHtml, /Planejamento do dia encerrado/);
  assert.match(closedMealHtml, /Gerenciar no Cardápio/);
  assert.doesNotMatch(closedMealHtml, /Próxima refeição/);
}

console.log('Cockpit integration & shortcut tests passed.');
