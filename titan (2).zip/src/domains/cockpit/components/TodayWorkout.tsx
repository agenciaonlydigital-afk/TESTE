import { memo, useCallback, useEffect, useState } from 'react';
import { BookOpen, Check, Dumbbell, ListChecks, Play, Timer } from 'lucide-react';
import { getMuscleLabels, setWorkoutMuscleHighlights } from '@/src/domains/anatomy/application/anatomy-public';
import {
  computePlanMuscleHighlights,
  focusWorkoutExercise,
  useActiveWorkoutProgress,
  useRestTimerSnapshot,
  useTrainingSessionStore,
} from '@/src/domains/training/application/training-public';
import { AnimatePresence, motion, TITAN_DURATIONS, TITAN_EASE } from '@/src/shared/motion/titan-motion';
import type { MuscleGroupId } from '@/src/shared/types/common';
import { Surface } from '@/src/shared/ui/Surface';
import { formatSecondsClock } from '@/src/shared/utils/formatters';

interface DraftNumberInputProps {
  value: number;
  min: number;
  step?: string;
  inputMode: 'decimal' | 'numeric';
  ariaLabel: string;
  onCommit: (nextValue: number) => void;
}

function DraftNumberInput({
  value,
  min,
  step,
  inputMode,
  ariaLabel,
  onCommit,
}: DraftNumberInputProps) {
  const [draft, setDraft] = useState(String(value));

  useEffect(() => {
    setDraft(String(value));
  }, [value]);

  const handleChange = (rawText: string) => {
    setDraft(rawText);
    // Commit only on blur/Enter to preserve intermediate decimal input and avoid store updates per keystroke.
  };

  const handleBlur = () => {
    const parsed = Number(draft.replace(',', '.'));
    if (draft.trim() === '' || !Number.isFinite(parsed) || parsed < min) {
      setDraft(String(value));
      return;
    }
    const normalized = inputMode === 'numeric' ? Math.round(parsed) : parsed;
    setDraft(String(normalized));
    if (normalized !== value) onCommit(normalized);
  };

  return (
    <input
      type="number"
      inputMode={inputMode}
      min={min}
      step={step}
      value={draft}
      aria-label={ariaLabel}
      aria-invalid={draft.trim() !== '' && (!Number.isFinite(Number(draft.replace(',', '.'))) || Number(draft.replace(',', '.')) < min)}
      onChange={(e) => handleChange(e.target.value)}
      onBlur={handleBlur}
      onKeyDown={(e) => {
        if (e.key === 'Enter') e.currentTarget.blur();
      }}
      className="w-full min-h-[38px] px-2 rounded-lg bg-[var(--titan-surface-inset)] border border-[rgba(193,204,196,0.12)] text-xs font-mono-metric text-[var(--titan-text-primary)] text-center transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
    />
  );
}

interface InlineRestTimerProps {
  onNextSet: () => void;
}

const InlineRestTimer = memo(function InlineRestTimer({ onNextSet }: InlineRestTimerProps) {
  const { restTimer, snapshot, stopRestTimer } = useRestTimerSnapshot();
  if (!restTimer?.active || !snapshot) return null;

  return (
    <div
      className={`mt-3 p-3 rounded-2xl border flex items-center justify-between gap-3 ${
        snapshot.isOvertime
          ? 'bg-[linear-gradient(160deg,rgba(40,64,53,0.48),rgba(13,20,17,0.92))] border-[var(--titan-accent)]/45 shadow-[inset_0_1px_0_rgba(160,183,168,0.18)]'
          : 'bg-[var(--titan-surface-inset)] border-[rgba(193,204,196,0.10)] shadow-[inset_0_1px_0_rgba(241,240,232,0.04)]'
      }`}
      role="status"
      aria-live="off"
    >
      <span className="sr-only" aria-live="polite">
        Descanso iniciado para {restTimer.exerciseName}; alvo de {formatSecondsClock(snapshot.targetSeconds)}.
      </span>
      <div className="flex items-center gap-2.5 min-w-0">
        <Timer className="w-4 h-4 text-[var(--titan-accent)] shrink-0" aria-hidden="true" />
        <div className="min-w-0">
          <div className="text-xs text-[var(--titan-text-muted)] truncate">
            Descanso · {restTimer.exerciseName}
          </div>
          <div className="flex items-baseline gap-2 font-mono-metric">
            <span className="text-lg font-semibold text-[var(--titan-text-primary)]">
              {formatSecondsClock(snapshot.elapsedSeconds)}
            </span>
            <span className="text-xs text-[var(--titan-text-muted)]">
              / {formatSecondsClock(snapshot.targetSeconds)}
            </span>
          </div>
        </div>
      </div>

      <button
        type="button"
        onClick={() => {
          stopRestTimer();
          onNextSet();
        }}
        className="titan-button titan-button--primary !min-h-[44px] !px-3.5 !text-xs whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/80"
      >
        Próxima Série
      </button>
    </div>
  );
});

interface TodayWorkoutProps {
  onOpenTraining: () => void;
  onOpenTrainingPlans?: () => void;
  onOpenExerciseLibrary?: (muscleId?: MuscleGroupId) => void;
}

export const TodayWorkout = memo(function TodayWorkout({
  onOpenTraining,
  onOpenTrainingPlans,
  onOpenExerciseLibrary,
}: TodayWorkoutProps) {
  const { plan, completedSets, totalSets } = useActiveWorkoutProgress();
  const updateSetValues = useTrainingSessionStore((s) => s.updateSetValues);
  const markSetCompleted = useTrainingSessionStore((s) => s.markSetCompleted);
  const startRestTimer = useTrainingSessionStore((s) => s.startRestTimer);

  const [expandedExerciseId, setExpandedExerciseId] = useState<string | null>(null);

  useEffect(() => {
    setWorkoutMuscleHighlights(computePlanMuscleHighlights(plan));
  }, [plan]);

  useEffect(() => {
    setExpandedExerciseId(null);
  }, [plan.id]);

  const handleCompleteSet = (
    exerciseId: string,
    exerciseName: string,
    setId: string,
    targetRestSeconds: number,
  ) => {
    markSetCompleted(exerciseId, setId);
    startRestTimer(exerciseName, targetRestSeconds);
  };

  const handleNextSet = useCallback(() => {
    const nextPendingExercise =
      plan.exercises.find((ex) => ex.sets.some((s) => !s.completed)) ??
      plan.exercises[0];
    if (nextPendingExercise) {
      focusWorkoutExercise(nextPendingExercise.id);
      setExpandedExerciseId(nextPendingExercise.id);
    }
  }, [plan.exercises]);

  const categoryTag =
    plan.id === 'upper-a'
      ? 'Hipertrofia'
      : plan.id === 'lower-a'
      ? 'Força'
      : 'Personalizado';

  const isCompleted =
    plan.status === 'completed' || (totalSets > 0 && completedSets === totalSets);
  const isInProgress = !isCompleted && (plan.status === 'in_progress' || completedSets > 0);
  const statusLabel = isCompleted
    ? 'Concluído'
    : isInProgress
    ? 'Em andamento'
    : 'Planejado';
  const actionLabel = isCompleted
    ? 'Revisar'
    : isInProgress
    ? 'Continuar'
    : 'Iniciar';

  return (
    <Surface className="p-4 sm:p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="titan-card-eyebrow">
            Treino de hoje · <span className="text-[var(--titan-accent)]">{categoryTag}</span> · {statusLabel}
          </div>
          <h2 className="text-xl font-semibold text-[var(--titan-text-primary)] mt-0.5 truncate">
            {plan.title}
          </h2>
        </div>

        <Dumbbell className="w-4 h-4 text-[var(--titan-accent)] shrink-0 mt-1" aria-hidden="true" />
      </div>

      <div className="mt-1.5 flex items-center justify-between gap-3 pb-3.5 border-b border-[rgba(193,204,196,0.08)]">
        <div className="min-w-0">
          <p className="text-xs text-[var(--titan-text-secondary)] truncate">{plan.splitLabel}</p>
          <p className="text-[11px] font-mono-metric text-[var(--titan-text-muted)] mt-0.5">
            {completedSets}/{totalSets} séries executadas
          </p>
        </div>
        <button
          type="button"
          onClick={onOpenTraining}
          className="titan-button titan-button--primary !min-h-[44px] !px-4 !text-xs shrink-0 whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/80"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>{actionLabel}</span>
        </button>
      </div>

      {/* O timer atualiza isoladamente; a lista de exercícios não re-renderiza a cada 500 ms. */}
      <InlineRestTimer onNextSet={handleNextSet} />

      <div className="divide-y divide-[rgba(193,204,196,0.06)] mt-1">
        {plan.exercises.map((exercise, index) => {
          const isExpanded = expandedExerciseId === exercise.id;
          const setsCount = exercise.sets.length;
          const completedCount = exercise.sets.filter((s) => s.completed).length;
          const repsRange = exercise.sets[0]?.targetReps ?? '10';
          const num = String(index + 1).padStart(2, '0');

          return (
            <div key={exercise.id}>
              <button
                type="button"
                onClick={() => {
                  const willCollapse = expandedExerciseId === exercise.id;
                  if (willCollapse) {
                    setWorkoutMuscleHighlights(computePlanMuscleHighlights(plan));
                  } else {
                    focusWorkoutExercise(exercise.id);
                  }
                  setExpandedExerciseId(willCollapse ? null : exercise.id);
                }}
                aria-expanded={isExpanded}
                className={`w-full min-h-[46px] py-2.5 px-2.5 rounded-2xl flex items-center justify-between gap-2 text-left transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70 ${
                  isExpanded
                    ? 'bg-[linear-gradient(170deg,rgba(32,42,38,0.85),rgba(18,24,21,0.94))] border border-[rgba(193,204,196,0.12)] shadow-[inset_0_1px_0_rgba(241,240,232,0.05)] my-1'
                    : 'hover:bg-[rgba(241,240,232,0.025)]'
                }`}
              >
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-medium text-[var(--titan-text-primary)] truncate">
                    <span className="font-mono-metric text-[var(--titan-text-muted)] mr-1.5">
                      {num} ·
                    </span>
                    {exercise.name}
                  </div>
                  {completedCount > 0 && (
                    <div className="text-xs font-mono-metric text-[var(--titan-status-success)] mt-0.5 pl-6">
                      {completedCount}/{setsCount} séries registradas
                    </div>
                  )}
                </div>

                {/* Alinhamento tabular aprimorado de séries × repetições e descanso */}
                <div className="grid grid-cols-[68px_38px] items-center gap-2 shrink-0 font-mono-metric text-xs">
                  <span className="text-right text-[var(--titan-text-primary)]/95 font-medium tabular-nums">
                    {setsCount} × {repsRange}
                  </span>
                  <span className="text-right text-[var(--titan-text-muted)] tabular-nums">
                    {exercise.targetRestSeconds}s
                  </span>
                </div>
              </button>

              <AnimatePresence initial={false}>
                {isExpanded && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: TITAN_DURATIONS.quick, ease: TITAN_EASE }}
                    className="overflow-hidden"
                  >
                    <div className="px-2 pb-3 pt-1.5 space-y-2">
                      <div className="text-xs text-[var(--titan-text-muted)] px-1">
                        {exercise.equipment} ·{' '}
                        {getMuscleLabels(exercise.muscles.primary).join(', ')}
                      </div>

                      <div className="space-y-1.5">
                        {exercise.sets.map((set) => (
                          <div
                            key={set.id}
                            className={`p-2 rounded-xl border grid grid-cols-[54px_1fr_1fr_44px] items-center gap-2 transition-colors ${
                              set.completed
                                ? 'bg-[rgba(48,73,62,0.22)] border-[var(--titan-status-success)]/35'
                                : 'bg-[var(--titan-surface-inset)] border-[rgba(193,204,196,0.08)]'
                            }`}
                          >
                            <span className="text-xs font-mono-metric text-[var(--titan-text-secondary)]">
                              S{String(set.setNumber).padStart(2, '0')}
                            </span>

                            <label className="flex items-center gap-1 min-w-0">
                              <DraftNumberInput
                                value={set.weightKg}
                                min={0}
                                step="0.5"
                                inputMode="decimal"
                                ariaLabel={`Carga da série ${set.setNumber} em kg`}
                                onCommit={(nextWeight) =>
                                  updateSetValues(exercise.id, set.id, nextWeight, set.reps)
                                }
                              />
                              <span className="text-xs text-[var(--titan-text-muted)] shrink-0">kg</span>
                            </label>

                            <label className="flex items-center gap-1 min-w-0">
                              <DraftNumberInput
                                value={set.reps}
                                min={1}
                                inputMode="numeric"
                                ariaLabel={`Repetições da série ${set.setNumber}`}
                                onCommit={(nextReps) =>
                                  updateSetValues(exercise.id, set.id, set.weightKg, nextReps)
                                }
                              />
                              <span className="text-xs text-[var(--titan-text-muted)] shrink-0">rep</span>
                            </label>

                            <button
                              type="button"
                              onClick={() =>
                                handleCompleteSet(
                                  exercise.id,
                                  exercise.name,
                                  set.id,
                                  exercise.targetRestSeconds,
                                )
                              }
                              aria-label={`Registrar série ${set.setNumber}`}
                              className={`min-h-[38px] min-w-[38px] rounded-xl border flex items-center justify-center transition-all active:scale-95 ${
                                set.completed
                                  ? 'bg-[linear-gradient(145deg,#B2C9BA,var(--titan-accent))] border-[rgba(224,237,228,0.45)] text-[var(--titan-bg-canvas)] shadow-[0_4px_12px_rgba(143,182,159,0.28)]'
                                  : 'bg-[var(--titan-surface-raised)] border-[rgba(193,204,196,0.14)] text-[var(--titan-text-primary)] hover:border-[var(--titan-accent)]/40'
                              }`}
                            >
                              <Check className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>

      {(onOpenTrainingPlans || onOpenExerciseLibrary) && (
        <div className="mt-3 pt-3 border-t border-[rgba(193,204,196,0.08)] flex flex-wrap items-center justify-between gap-2">
          {onOpenTrainingPlans && (
            <button
              type="button"
              onClick={onOpenTrainingPlans}
              className="titan-button titan-button--ghost !min-h-[40px] !px-2.5 !text-xs"
            >
              <ListChecks className="w-3.5 h-3.5 text-[var(--titan-accent)]" aria-hidden="true" />
              <span>Trocar ficha</span>
            </button>
          )}
          {onOpenExerciseLibrary && (
            <button
              type="button"
              onClick={() => onOpenExerciseLibrary()}
              className="titan-button titan-button--ghost !min-h-[40px] !px-2.5 !text-xs"
            >
              <BookOpen className="w-3.5 h-3.5 text-[var(--titan-accent)]" aria-hidden="true" />
              <span>Biblioteca de Exercícios</span>
            </button>
          )}
        </div>
      )}
    </Surface>
  );
});
