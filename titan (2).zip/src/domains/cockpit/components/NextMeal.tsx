import { memo, useEffect, useMemo, useState } from 'react';
import { ArrowRight, Check, Search, SkipForward, Utensils } from 'lucide-react';
import { toast } from 'sonner';
import {
  getMealMacros,
  searchSubstitutionRecipes,
  type DayPlanSummary,
  type MealConsumptionStatus,
  type MealItem,
  useNutritionStore,
} from '@/src/domains/nutrition/application/nutrition-public';
import { colorTokens } from '@/src/shared/design-system/tokens';
import { BottomSheet } from '@/src/shared/ui/BottomSheet';
import { Button } from '@/src/shared/ui/Button';
import { Surface } from '@/src/shared/ui/Surface';

interface NextMealProps {
  meal: MealItem | undefined;
  daySummary?: DayPlanSummary;
  onOpenNutrition?: (section?: 'cardapio' | 'receitas' | 'alimentos') => void;
}

const STATUS_LABELS: Record<MealConsumptionStatus, string> = {
  planned: 'Planejada',
  consumed: 'Consumida',
  partial: 'Parcial',
  substituted: 'Substituída',
  skipped: 'Pulada',
};

export const NextMeal = memo(function NextMeal({
  meal,
  daySummary,
  onOpenNutrition,
}: NextMealProps) {
  const [sheetOpen, setSheetOpen] = useState(false);
  const [imgFailed, setImgFailed] = useState(false);
  const [heroImgFailed, setHeroImgFailed] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const confirmMealConsumed = useNutritionStore((s) => s.confirmMealConsumed);
  const setMealPartial = useNutritionStore((s) => s.setMealPartial);
  const skipMeal = useNutritionStore((s) => s.skipMeal);
  const substituteMealWithRecipe = useNutritionStore(
    (s) => s.substituteMealWithRecipe,
  );

  useEffect(() => {
    setImgFailed(false);
    setHeroImgFailed(false);
  }, [meal?.id, meal?.imageUrl]);

  const matchingRecipes = useMemo(
    () => searchSubstitutionRecipes(searchQuery, meal?.recipeId),
    [searchQuery, meal?.recipeId],
  );

  if (!meal) {
    const hasMealsInDay = Boolean(daySummary && daySummary.totalMealsCount > 0);
    const latestRecorded = daySummary?.latestRecordedMeal;

    return (
      <Surface className="p-4 sm:p-5 space-y-2.5">
        <div className="flex items-center justify-between gap-2">
          <span className="text-xs font-medium text-[var(--titan-text-muted)]">
            {hasMealsInDay ? 'Planejamento do dia encerrado' : 'Refeições do dia'}
          </span>
          {onOpenNutrition && (
            <button
              type="button"
              onClick={() => onOpenNutrition('cardapio')}
              className="text-xs font-medium text-[var(--titan-accent)] hover:underline inline-flex items-center gap-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70 rounded"
            >
              <span>{hasMealsInDay ? 'Gerenciar no Cardápio' : 'Abrir Cardápio'}</span>
              <ArrowRight className="w-3 h-3" aria-hidden="true" />
            </button>
          )}
        </div>

        {hasMealsInDay && daySummary ? (
          <div className="text-xs text-[var(--titan-text-secondary)] space-y-1">
            <p className="font-medium text-[var(--titan-text-primary)]">
              {daySummary.recordedMealsCount} registrada(s)
              {daySummary.skippedMealsCount > 0
                ? ` · ${daySummary.skippedMealsCount} pulada(s)`
                : ''}
            </p>
            {latestRecorded && (
              <p className="text-[var(--titan-text-muted)]">
                Última registrada · {latestRecorded.time}: {latestRecorded.title} ({STATUS_LABELS[latestRecorded.status]})
              </p>
            )}
          </div>
        ) : (
          <p className="text-xs text-[var(--titan-text-secondary)]">
            Nenhuma refeição programada para esta data.
          </p>
        )}
      </Surface>
    );
  }

  const macros = getMealMacros(meal);

  return (
    <>
      <section aria-label="Próxima refeição">
        <div className="mb-2 flex items-center justify-between gap-2 px-0.5">
          <span className="text-xs font-medium text-[var(--titan-text-muted)] font-mono-metric">
            Próxima refeição · {meal.time}
          </span>
          {onOpenNutrition && (
            <button
              type="button"
              onClick={() => onOpenNutrition('cardapio')}
              className="text-xs font-medium text-[var(--titan-accent)] hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70 rounded"
            >
              Cardápio
            </button>
          )}
        </div>

        <Surface className="overflow-hidden transition-[border-color,box-shadow] duration-200 hover:border-[rgba(193,204,196,0.16)]">
          <button
            type="button"
            onClick={() => {
              setSearchQuery('');
              setSheetOpen(true);
            }}
            className="w-full text-left p-3.5 sm:p-4 space-y-3 transition-transform duration-100 active:scale-[0.995] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
          >
            <div className="flex items-center gap-3 min-w-0">
              {meal.imageUrl && !imgFailed ? (
                <img
                  src={meal.imageUrl}
                  alt={meal.title}
                  referrerPolicy="no-referrer"
                  loading="lazy"
                  decoding="async"
                  onError={() => setImgFailed(true)}
                  className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover shrink-0 border border-[rgba(226,238,230,0.10)] shadow-[0_8px_18px_rgba(0,0,0,0.28)]"
                />
              ) : (
                <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-[var(--titan-surface-inset)] border border-[rgba(193,204,196,0.10)] flex items-center justify-center shrink-0">
                  <Utensils className="w-6 h-6 text-[var(--titan-accent)]" aria-hidden="true" />
                </div>
              )}

              <div className="min-w-0 flex-1">
                <h3 className="text-base font-semibold text-[var(--titan-text-primary)] leading-snug">
                  {meal.title}
                </h3>
                <p className="text-xs text-[var(--titan-text-secondary)] mt-0.5 line-clamp-2">
                  {meal.substitutionNote ?? meal.description}
                </p>
              </div>
            </div>

            {/* Macros ordenados exatamente como o gráfico: Carb · Prot · Gord · kcal, centralizados */}
            <div
              className="pt-2.5 border-t border-[rgba(193,204,196,0.08)] grid grid-cols-4 gap-2 text-center items-center"
              aria-label={`Carboidratos ${macros.carbsG} gramas, Proteínas ${macros.proteinG} gramas, Gorduras ${macros.fatG} gramas, ${macros.kcal} quilocalorias`}
            >
              <div>
                <div
                  className="text-sm font-semibold font-mono-metric"
                  style={{ color: colorTokens.macroCarbs }}
                >
                  {macros.carbsG} g
                </div>
                <div className="text-xs text-[var(--titan-text-muted)] mt-0.5">Carb</div>
              </div>

              <div>
                <div
                  className="text-sm font-semibold font-mono-metric"
                  style={{ color: colorTokens.macroProtein }}
                >
                  {macros.proteinG} g
                </div>
                <div className="text-xs text-[var(--titan-text-muted)] mt-0.5">Prot</div>
              </div>

              <div>
                <div
                  className="text-sm font-semibold font-mono-metric"
                  style={{ color: colorTokens.macroFat }}
                >
                  {macros.fatG} g
                </div>
                <div className="text-xs text-[var(--titan-text-muted)] mt-0.5">Gord</div>
              </div>

              <div className="border-l border-[rgba(193,204,196,0.10)] pl-1">
                <div className="text-base font-bold font-mono-metric text-[var(--titan-text-primary)] leading-tight">
                  {macros.kcal}
                </div>
                <div className="text-xs font-semibold uppercase tracking-wide text-[var(--titan-accent)] mt-0.5">
                  kcal
                </div>
              </div>
            </div>
          </button>

          <div className="px-3.5 sm:px-4 pb-3.5 pt-2 border-t border-[rgba(193,204,196,0.06)] flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                confirmMealConsumed(meal.id);
                toast.success('Refeição confirmada');
              }}
              className="titan-button titan-button--primary flex-1 !min-h-[44px] !px-3 !text-xs focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/80"
            >
              <Check className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Confirmar</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setMealPartial(meal.id, 0.5);
                toast.success('50% da refeição registrada');
              }}
              aria-label={`Registrar 50% de ${meal.title}`}
              className="titan-button titan-button--secondary !min-h-[44px] !px-3 !text-xs font-mono-metric focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
            >
              50%
            </button>
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setSheetOpen(true);
              }}
              className="titan-button titan-button--ghost !min-h-[44px] !px-3 !text-xs focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
            >
              Substituir
            </button>
          </div>
        </Surface>
      </section>

      <BottomSheet
        open={sheetOpen}
        onClose={() => setSheetOpen(false)}
        title={meal.title}
        subtitle={`${meal.time} · ${meal.substitutionNote ?? meal.description}`}
      >
        <div className="space-y-4">
          {meal.imageUrl && !heroImgFailed ? (
            <div className="overflow-hidden rounded-2xl border border-[var(--titan-border)]/70">
              <img
                src={meal.imageUrl}
                alt={meal.title}
                referrerPolicy="no-referrer"
                loading="lazy"
                decoding="async"
                onError={() => setHeroImgFailed(true)}
                className="w-full h-44 sm:h-52 object-cover"
              />
            </div>
          ) : (
            <div className="w-full h-40 rounded-2xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)]/70 flex flex-col items-center justify-center gap-2 text-[var(--titan-text-muted)]">
              <Utensils className="w-7 h-7 text-[var(--titan-accent)]" aria-hidden="true" />
              <span className="text-xs">{meal.title}</span>
            </div>
          )}

          <div className="flex flex-wrap gap-2">
            <Button
              variant="primary"
              className="flex-1 min-w-[140px]"
              onClick={() => {
                confirmMealConsumed(meal.id);
                toast.success('Refeição confirmada');
                setSheetOpen(false);
              }}
            >
              <Check className="w-4 h-4" />
              <span>Confirmar</span>
            </Button>

            <Button
              variant="secondary"
              onClick={() => {
                setMealPartial(meal.id, 0.5);
                toast.success('50% da refeição registrada');
                setSheetOpen(false);
              }}
            >
              <span>50%</span>
            </Button>

            <Button
              variant="ghost"
              onClick={() => {
                skipMeal(meal.id);
                toast('Refeição marcada como pulada');
                setSheetOpen(false);
              }}
            >
              <SkipForward className="w-4 h-4" />
              <span>Pular</span>
            </Button>
          </div>

          {onOpenNutrition && (
            <button
              type="button"
              onClick={() => {
                setSheetOpen(false);
                onOpenNutrition('cardapio');
              }}
              className="w-full min-h-[40px] text-xs font-medium text-[var(--titan-accent)] hover:underline text-center"
            >
              Ajustar porções ou montar refeição personalizada no Cardápio
            </button>
          )}

          {/* Barra de pesquisa para substituição direta por receita do catálogo */}
          <div className="space-y-2.5 pt-2 border-t border-[rgba(193,204,196,0.10)]">
            <label className="block">
              <span className="text-xs font-medium text-[var(--titan-text-secondary)]">
                Substituir refeição
              </span>
              <div className="relative mt-1.5">
                <Search
                  className="w-4 h-4 text-[var(--titan-text-muted)] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                  aria-hidden="true"
                />
                <input
                  type="search"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Buscar receita ou ingrediente substituto (ex.: salmão, frango, iogurte)..."
                  aria-label="Buscar receita substituta"
                  className="w-full min-h-[44px] pl-9 pr-3 rounded-xl bg-[var(--titan-surface-inset)] border border-[rgba(193,204,196,0.12)] text-sm text-[var(--titan-text-primary)] placeholder:text-[var(--titan-text-muted)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
                />
              </div>
            </label>

            <div className="space-y-2 max-h-56 overflow-y-auto pr-0.5">
              {matchingRecipes.length === 0 ? (
                <p className="text-xs text-[var(--titan-text-muted)] py-2">
                  Nenhuma receita encontrada para &ldquo;{searchQuery}&rdquo;.
                </p>
              ) : (
                matchingRecipes.map((summary) => (
                  <button
                    key={summary.recipe.id}
                    type="button"
                    onClick={() => {
                      substituteMealWithRecipe(meal.id, summary.recipe.id);
                      toast.success(`Substituída por ${summary.recipe.name}`);
                      setSheetOpen(false);
                    }}
                    className="titan-luxury-tile w-full min-h-[48px] px-3 py-2.5 text-left flex items-center justify-between gap-3 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-[var(--titan-text-primary)] truncate">
                        {summary.recipe.name}
                      </div>
                      <div className="text-xs text-[var(--titan-text-muted)] truncate mt-0.5">
                        C {summary.macros.carbsG}g · P {summary.macros.proteinG}g · G{' '}
                        {summary.macros.fatG}g
                      </div>
                    </div>
                    <span className="text-xs font-semibold font-mono-metric text-[var(--titan-accent)] shrink-0">
                      {summary.macros.kcal} kcal
                    </span>
                  </button>
                ))
              )}
            </div>
          </div>
        </div>
      </BottomSheet>
    </>
  );
});
