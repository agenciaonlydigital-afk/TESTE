import { memo, useMemo } from 'react';
import { Activity, Droplets, Dumbbell, Utensils } from 'lucide-react';
import { formatNumericDateBR } from '@/src/domains/calendar/application/calendar-days';
import { sortMeasurementsChronologically, useEvolutionStore } from '@/src/domains/evolution/application/evolution-public';
import { getHydrationSummary, useHydrationStore } from '@/src/domains/hydration/application/hydration-actions';
import type { DayPlanSummary } from '@/src/domains/nutrition/application/nutrition-public';
import { useProfileStore } from '@/src/domains/profile/application/profile-public';
import { useActiveWorkoutProgress } from '@/src/domains/training/application/training-public';
import { Surface } from '@/src/shared/ui/Surface';
import { formatMilliliters } from '@/src/shared/utils/formatters';

interface DailyStatusStripProps {
  activeDateKey: string;
  daySummary: DayPlanSummary;
  onOpenNutrition?: (section?: 'cardapio' | 'receitas' | 'alimentos') => void;
  onOpenTraining: () => void;
  onOpenEvolution?: () => void;
  onFocusHydration?: () => void;
  onOpenGoals?: () => void;
}

export const DailyStatusStrip = memo(function DailyStatusStrip({
  activeDateKey,
  daySummary,
  onOpenNutrition,
  onOpenTraining,
  onOpenEvolution,
  onFocusHydration,
  onOpenGoals,
}: DailyStatusStripProps) {
  const hydrationEntries = useHydrationStore((s) => s.entries);
  const dailyGoalMl = useHydrationStore((s) => s.dailyGoalMl);
  const profileConfigured = useProfileStore((s) => s.profileConfigured);
  const evolutionRecords = useEvolutionStore((s) => s.records);
  const { plan, completedSets, totalSets } = useActiveWorkoutProgress();

  const hydration = useMemo(
    () => getHydrationSummary(hydrationEntries, dailyGoalMl, activeDateKey),
    [hydrationEntries, dailyGoalMl, activeDateKey],
  );

  const latestWeight = useMemo(() => {
    const sorted = sortMeasurementsChronologically(evolutionRecords);
    return sorted[sorted.length - 1] ?? null;
  }, [evolutionRecords]);

  const workoutStatusLabel =
    totalSets > 0 && (plan.status === 'completed' || completedSets === totalSets)
      ? 'Concluído'
      : plan.status === 'in_progress' || completedSets > 0
      ? 'Em andamento'
      : 'Planejado';

  const mealsLabel =
    daySummary.totalMealsCount === 0
      ? 'Sem cardápio na data'
      : `${daySummary.recordedMealsCount}/${daySummary.totalMealsCount} registradas`;

  const mealsDetail =
    daySummary.totalMealsCount === 0
      ? 'Planejar refeições'
      : daySummary.plannedMealsCount > 0
      ? `${daySummary.plannedMealsCount} ${daySummary.plannedMealsCount === 1 ? 'pendente' : 'pendentes'}`
      : 'Dia encerrado';

  const hydrationDetail =
    hydration.goalMl <= 0
      ? 'Meta não definida'
      : hydration.currentMl >= hydration.goalMl
      ? 'Meta atingida'
      : `Restam ${formatMilliliters(hydration.goalMl - hydration.currentMl)}${!profileConfigured ? ' · inicial' : ''}`;

  const evolutionHeading = !profileConfigured ? 'Configuração' : 'Evolução';
  const evolutionValue = !profileConfigured
    ? 'Metas iniciais'
    : latestWeight
    ? `${latestWeight.weightKg.toFixed(1)} kg`
    : 'Sem medições';
  const evolutionDetail = !profileConfigured
    ? 'Calibrar perfil'
    : latestWeight
    ? `Obs. em ${formatNumericDateBR(latestWeight.dateKey)}`
    : 'Registrar peso';

  return (
    <Surface elevation={0} className="overflow-hidden border border-[var(--titan-border)]/70">
      <div
        role="region"
        aria-label="Estado consolidado do dia"
        className="grid grid-cols-2 lg:grid-cols-4 divide-y lg:divide-y-0 lg:divide-x divide-[var(--titan-border)]/50"
      >
        <button
          type="button"
          onClick={() => onOpenNutrition?.('cardapio')}
          className="min-h-[56px] px-3.5 py-2.5 text-left transition-colors hover:bg-[var(--titan-surface-raised)]/55 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[var(--titan-info)]/70"
        >
          <div className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-muted)]">
            <Utensils className="w-3 h-3 text-[var(--titan-accent)]" aria-hidden="true" />
            <span>Cardápio</span>
          </div>
          <div className="mt-0.5 text-xs sm:text-sm font-semibold font-mono-metric text-[var(--titan-text-primary)] truncate">
            {mealsLabel}
          </div>
          <div className="text-[11px] text-[var(--titan-text-secondary)] truncate">
            {mealsDetail}
          </div>
        </button>

        <button
          type="button"
          onClick={onOpenTraining}
          className="min-h-[56px] px-3.5 py-2.5 text-left transition-colors hover:bg-[var(--titan-surface-raised)]/55 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[var(--titan-info)]/70 border-l border-[var(--titan-border)]/50 lg:border-l-0"
        >
          <div className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-muted)]">
            <Dumbbell className="w-3 h-3 text-[var(--titan-accent)]" aria-hidden="true" />
            <span>Treino · {workoutStatusLabel}</span>
          </div>
          <div className="mt-0.5 text-xs sm:text-sm font-semibold font-mono-metric text-[var(--titan-text-primary)] truncate">
            {totalSets > 0 ? `${completedSets}/${totalSets} séries` : plan.title}
          </div>
          <div className="text-[11px] text-[var(--titan-text-secondary)] truncate">
            {plan.title}
          </div>
        </button>

        <button
          type="button"
          onClick={() => onFocusHydration?.()}
          className="min-h-[56px] px-3.5 py-2.5 text-left transition-colors hover:bg-[var(--titan-surface-raised)]/55 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[var(--titan-info)]/70"
        >
          <div className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-muted)]">
            <Droplets className="w-3 h-3 text-[var(--titan-info)]" aria-hidden="true" />
            <span>Hidratação</span>
          </div>
          <div className="mt-0.5 text-xs sm:text-sm font-semibold font-mono-metric text-[var(--titan-text-primary)] truncate">
            {formatMilliliters(hydration.currentMl)}
          </div>
          <div className="text-[11px] text-[var(--titan-text-secondary)] truncate">
            {hydrationDetail}
          </div>
        </button>

        <button
          type="button"
          onClick={() => {
            if (!profileConfigured && onOpenGoals) {
              onOpenGoals();
            } else {
              onOpenEvolution?.();
            }
          }}
          className="min-h-[56px] px-3.5 py-2.5 text-left transition-colors hover:bg-[var(--titan-surface-raised)]/55 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[var(--titan-info)]/70 border-l border-[var(--titan-border)]/50 lg:border-l-0"
        >
          <div className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-muted)]">
            <Activity className="w-3 h-3 text-[var(--titan-champagne)]" aria-hidden="true" />
            <span>{evolutionHeading}</span>
          </div>
          <div
            className={`mt-0.5 text-xs sm:text-sm font-semibold font-mono-metric truncate ${
              !profileConfigured
                ? 'text-[var(--titan-status-warning)]'
                : 'text-[var(--titan-text-primary)]'
            }`}
          >
            {evolutionValue}
          </div>
          <div className="text-[11px] text-[var(--titan-text-secondary)] truncate">
            {evolutionDetail}
          </div>
        </button>
      </div>
    </Surface>
  );
});
