import { memo, useMemo } from 'react';
import { Activity, ArrowDown, ArrowRight, ArrowUp, Minus } from 'lucide-react';
import { formatNumericDateBR } from '@/src/domains/calendar/application/calendar-days';
import {
  calculateWeightTrend,
  computeCumulativeComparison,
  computeEvolutionCockpitIndicator,
  sortMeasurementsChronologically,
  useEvolutionStore,
} from '@/src/domains/evolution/application/evolution-public';
import { GOAL_OPTIONS, useProfileStore } from '@/src/domains/profile/application/profile-public';
import { Surface } from '@/src/shared/ui/Surface';

interface EvolutionOverviewProps {
  onOpenEvolution?: () => void;
}

export const EvolutionOverview = memo(function EvolutionOverview({
  onOpenEvolution,
}: EvolutionOverviewProps) {
  const records = useEvolutionStore((s) => s.records);
  const profile = useProfileStore((s) => s.profile);
  const profileConfigured = useProfileStore((s) => s.profileConfigured);

  const { chronological, indicator, comparison, trend } = useMemo(() => {
    const sorted = sortMeasurementsChronologically(records);
    return {
      chronological: sorted,
      indicator: computeEvolutionCockpitIndicator(sorted, profile.goal),
      comparison: computeCumulativeComparison(sorted, profile.targetWeightKg),
      trend: calculateWeightTrend(sorted, 30),
    };
  }, [records, profile.goal, profile.targetWeightKg]);

  const latest = chronological[chronological.length - 1] ?? null;
  const goalLabel = GOAL_OPTIONS.find((opt) => opt.id === profile.goal)?.label ?? 'Objetivo';

  return (
    <Surface className="p-4 sm:p-5 space-y-3">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="titan-card-eyebrow">
            Evolução corporal · {goalLabel}
          </p>
          <h2 className="text-base font-semibold text-[var(--titan-text-primary)] mt-0.5">
            Peso e tendência observada
          </h2>
        </div>

        {onOpenEvolution && (
          <button
            type="button"
            onClick={onOpenEvolution}
            className="min-h-[40px] px-3 rounded-xl bg-[var(--titan-surface-raised)] border border-[var(--titan-border)] text-xs font-medium text-[var(--titan-text-primary)] flex items-center gap-1.5 shrink-0 hover:border-[var(--titan-champagne)]/45 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
          >
            <span>{latest ? 'Abrir Evolução' : 'Registrar medição'}</span>
            <ArrowRight className="w-3.5 h-3.5 text-[var(--titan-accent)]" aria-hidden="true" />
          </button>
        )}
      </div>

      {!latest ? (
        <div className="rounded-xl border border-[var(--titan-border)]/70 bg-[var(--titan-bg-canvas)]/70 p-3.5 flex items-start gap-2.5">
          <Activity className="w-4 h-4 text-[var(--titan-champagne)] shrink-0 mt-0.5" aria-hidden="true" />
          <div className="text-xs leading-relaxed text-[var(--titan-text-secondary)]">
            <p className="font-medium text-[var(--titan-text-primary)]">
              Sem medições registradas
            </p>
            <p className="mt-0.5 text-[var(--titan-text-muted)]">
              Registre sua primeira pesagem no módulo Evolução para acompanhar a variação real e calibrar o gasto energético.
            </p>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-3 pt-2 border-t border-[var(--titan-border)]/50">
          <div className="min-w-0">
            <div className="text-[11px] text-[var(--titan-text-muted)]">Último registro</div>
            <div className="mt-0.5 text-lg font-semibold font-mono-metric text-[var(--titan-text-primary)] tabular-nums">
              {latest.weightKg.toFixed(1)} kg
            </div>
            <div className="text-[11px] font-mono-metric text-[var(--titan-text-muted)] truncate">
              {formatNumericDateBR(latest.dateKey)}
            </div>
          </div>

          <div className="min-w-0">
            <div className="text-[11px] text-[var(--titan-text-muted)]">
              {chronological.length >= 2 ? 'Variação acumulada' : 'Histórico inicial'}
            </div>
            <div
              className={`mt-0.5 flex items-center gap-1 text-lg font-semibold font-mono-metric tabular-nums ${
                chronological.length < 2 || indicator.direction === 'flat'
                  ? 'text-[var(--titan-text-secondary)]'
                  : indicator.isAlignedWithGoal
                  ? 'text-[var(--titan-status-success)]'
                  : 'text-[var(--titan-status-error)]'
              }`}
            >
              {chronological.length >= 2 && (
                indicator.direction === 'up' ? (
                  <ArrowUp className="w-4 h-4 shrink-0" aria-hidden="true" />
                ) : indicator.direction === 'down' ? (
                  <ArrowDown className="w-4 h-4 shrink-0" aria-hidden="true" />
                ) : (
                  <Minus className="w-4 h-4 shrink-0" aria-hidden="true" />
                )
              )}
              <span>{chronological.length >= 2 ? indicator.formattedDelta : '—'}</span>
            </div>
            <div className="text-[11px] text-[var(--titan-text-muted)] truncate">
              {trend
                ? `Tendência 30d: ${trend.changePerWeekKg > 0 ? '+' : ''}${trend.changePerWeekKg.toFixed(2)} kg/sem`
                : 'Aguardando ≥2 datas'}
            </div>
          </div>

          <div className="min-w-0">
            <div className="text-[11px] text-[var(--titan-text-muted)]">Diferença da meta</div>
            <div className="mt-0.5 text-lg font-semibold font-mono-metric text-[var(--titan-text-primary)] tabular-nums">
              {profileConfigured
                ? `${comparison.remainingToTargetKg > 0 ? '+' : ''}${comparison.remainingToTargetKg.toFixed(1)} kg`
                : '—'}
            </div>
            <div className="text-[11px] text-[var(--titan-text-muted)] truncate">
              {profileConfigured
                ? `Alvo ${profile.targetWeightKg.toFixed(1)} kg`
                : 'Meta não configurada'}
            </div>
          </div>
        </div>
      )}
    </Surface>
  );
});
