import assert from 'node:assert/strict';
import {
  extractValidatedContinuousPrimalValues,
  extractValidatedBinarySlotSelections,
} from '../highs-solution-validation.ts';

const variables = [
  { minG: 0, maxG: 200, currentG: 100 },
  { minG: 10, maxG: 150, currentG: 50 },
];
assert.deepEqual(extractValidatedContinuousPrimalValues({
  x0: { Primal: 125 }, x1: { Primal: 49.5 },
}, variables), [125, 49.5]);
assert.equal(extractValidatedContinuousPrimalValues({ x0: { Primal: 125 } }, variables), null,
  'every expected continuous primal column must exist');
assert.equal(extractValidatedContinuousPrimalValues({ x0: { Primal: 125 }, x1: { Primal: Number.NaN } }, variables), null);
assert.equal(extractValidatedContinuousPrimalValues({ x0: { Primal: -0.001 }, x1: { Primal: 49.5 } }, variables), null);
assert.equal(extractValidatedContinuousPrimalValues({ x0: { Primal: 200.000001 }, x1: { Primal: 49.5 } }, variables)[0], 200,
  'small floating-point overshoot is clamped to the declared bound');
assert.equal(extractValidatedContinuousPrimalValues({}, []), null, 'an empty model is not a validated solution');

const selections = extractValidatedBinarySlotSelections({
  b_0_0: { Primal: 0 }, b_0_1: { Primal: 1 },
  b_1_0: { Primal: 1 },
}, [2, 1]);
assert.deepEqual(selections, [1, 0]);
assert.equal(extractValidatedBinarySlotSelections({ b_0_0: { Primal: 0 } }, [2]), null,
  'missing binary columns must not silently become zero');
assert.equal(extractValidatedBinarySlotSelections({ b_0_0: { Primal: 0.5 }, b_0_1: { Primal: 0.5 } }, [2]), null,
  'fractional binary columns are invalid');
assert.equal(extractValidatedBinarySlotSelections({ b_0_0: { Primal: 1 }, b_0_1: { Primal: 1 } }, [2]), null,
  'exactly one option per slot must be selected');
assert.equal(extractValidatedBinarySlotSelections({ b_0_0: { Primal: 0 } }, [1]), null,
  'each slot must have exactly one selected option');
assert.equal(extractValidatedBinarySlotSelections({}, []), null);
assert.equal(extractValidatedBinarySlotSelections({ b_0_0: { Primal: 1 } }, [1], -1), null);
console.log('HiGHS primal validation tests passed.');
