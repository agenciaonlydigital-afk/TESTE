import { z } from 'zod';

const MacroTotalsSchema = z.object({
  kcal: z.number().finite().min(0),
  proteinG: z.number().finite().min(0),
  carbsG: z.number().finite().min(0),
  fatG: z.number().finite().min(0),
});

const NutritionTargetsSchema = z.object({
  kcal: z.number().finite().min(0),
  proteinG: z.number().finite().min(0),
  carbsG: z.number().finite().min(0),
  fatG: z.number().finite().min(0),
  kcalMin: z.number().finite().nullable().optional(),
  kcalMax: z.number().finite().nullable().optional(),
  proteinMinG: z.number().finite().nullable().optional(),
  proteinMaxG: z.number().finite().nullable().optional(),
  carbsMinG: z.number().finite().nullable().optional(),
  carbsMaxG: z.number().finite().nullable().optional(),
  fatMinG: z.number().finite().nullable().optional(),
  fatMaxG: z.number().finite().nullable().optional(),
  sourceLabel: z.string().optional(),
});

const IngredientAdjustmentSchema = z.object({
  id: z.string().min(1),
  foodId: z.string().min(1),
  displayName: z.string().optional(),
  baseQuantityG: z.number().finite().positive().nullable(),
  currentQuantityG: z.number().finite().positive().nullable(),
  quantityStatus: z.enum(['known', 'missing', 'to_taste']),
  mode: z.enum(['proportional', 'locked', 'flexible']),
  minQuantityG: z.number().finite().nullable().optional(),
  maxQuantityG: z.number().finite().nullable().optional(),
  isCompositeDish: z.boolean().optional(),
});

const RecipeInstanceSchema = z.object({
  id: z.string().min(1),
  sourceRecipeId: z.string().optional(),
  name: z.string().min(1),
  description: z.string().optional(),
  category: z.enum(['cafe', 'almoco', 'lanche', 'jantar']),
  imageUrl: z.string().optional(),
  baseServings: z.number().finite().positive(),
  targetServings: z.number().finite().positive(),
  adjustmentMode: z.enum(['proportional', 'balanced', 'flexible']),
  ingredients: z.array(IngredientAdjustmentSchema),
});

const ComposerMealSlotSchema = z.object({
  id: z.string().min(1),
  time: z.string().min(1),
  title: z.string().min(1),
  linkedMealId: z.string().optional(),
  recipes: z.array(RecipeInstanceSchema),
});

const ComposerDayPlanSchema = z.object({
  dateKey: z.string().min(1),
  slots: z.array(ComposerMealSlotSchema),
});

const ProposedIngredientChangeSchema = z.object({
  slotId: z.string().min(1),
  slotTitle: z.string().min(1),
  recipeId: z.string().min(1),
  recipeName: z.string().min(1),
  ingredientId: z.string().min(1),
  foodId: z.string().min(1),
  foodName: z.string().min(1),
  currentQuantityG: z.number().finite().min(0),
  proposedQuantityG: z.number().finite().min(0),
  referenceQuantityG: z.number().finite().min(0),
  deltaG: z.number().finite(),
  atLowerBound: z.boolean(),
  atUpperBound: z.boolean(),
});

const RecipeScaleAppliedSummarySchema = z.object({
  slotId: z.string().min(1),
  slotTitle: z.string().min(1),
  recipeId: z.string().min(1),
  recipeName: z.string().min(1),
  continuousScale: z.number().finite().positive(),
  effectiveScale: z.number().finite().positive(),
  scalePercent: z.number().finite().min(1),
  minScale: z.number().finite().nonnegative(),
  maxScale: z.number().finite().positive(),
});

const OptimizationProposalSchema = z.object({
  id: z.string().min(1),
  certificate: z.enum(['optimal', 'feasible', 'approximate']),
  solverEngine: z.string().optional(),
  scaleMode: z.enum(['preserve_recipe_ratios', 'ingredient_flexible']).optional(),
  macroFitStatus: z.enum(['target_met', 'approximate_feasible', 'infeasible', 'insufficient_data']).optional(),
  recipeScales: z.array(RecipeScaleAppliedSummarySchema).optional(),
  explanation: z.string().min(1),
  beforeMacros: MacroTotalsSchema,
  afterMacros: MacroTotalsSchema,
  targets: NutritionTargetsSchema,
  weightedDeviationBeforePercent: z.number().finite().min(0),
  weightedDeviationAfterPercent: z.number().finite().min(0),
  adjustedCount: z.number().int().min(0),
  lockedCount: z.number().int().min(0),
  proportionalCount: z.number().int().min(0),
  micronutrientResults: z.array(z.unknown()).optional(),
  changes: z.array(ProposedIngredientChangeSchema),
  proposedDayPlan: ComposerDayPlanSchema,
  solveDurationMs: z.number().finite().min(0),
});

const MacroGapSnapshotSchema = z.object({
  kcalDiff: z.number().finite(),
  proteinDiffG: z.number().finite(),
  carbsDiffG: z.number().finite(),
  fatDiffG: z.number().finite(),
});

export const MacroFitQuantizationResultSchema = z.object({
  status: z.enum(['target_met', 'approximate_feasible', 'infeasible', 'insufficient_data']),
  proposal: OptimizationProposalSchema,
  beforeSummary: z.object({ macros: MacroTotalsSchema }).passthrough(),
  afterSummary: z.object({ macros: MacroTotalsSchema }).passthrough(),
  beforeGaps: MacroGapSnapshotSchema,
  afterGaps: MacroGapSnapshotSchema,
  recipeScales: z.array(RecipeScaleAppliedSummarySchema),
  blockReason: z.string().nullable(),
});

export const LegacyOptimizerWorkerResponseSchema = z.object({
  requestId: z.number().int().positive(),
  kind: z.literal('legacy_composer').optional(),
  proposal: OptimizationProposalSchema,
  substitutions: z.array(z.unknown()),
  jointCombination: z.unknown().nullable().optional(),
});

export const MacroFitWorkerResponseSchema = z.object({
  requestId: z.number().int().positive(),
  kind: z.literal('macro_target_fit'),
  result: MacroFitQuantizationResultSchema,
});
