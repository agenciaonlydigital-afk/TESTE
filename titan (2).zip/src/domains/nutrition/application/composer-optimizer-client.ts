import type {
  ComposerDayPlan,
  DiscreteCombinationProposal,
  DiscreteSubstitutionProposal,
  NutritionTargets,
  OptimizationProposal,
} from '../domain/entities/nutrient.ts';
import {
  proposeDiscreteSubstitutions,
  solveNutritionalBalanceQP,
  type OptimizeBalanceOptions,
} from '../domain/rules/cardapio-composer-engine.ts';
import {
  solveMacroTargetFitQP,
  type MacroTargetFitOptions,
} from '../domain/rules/macro-target-fit.ts';
import type { RecipeScaleQuantizationResult } from '../domain/rules/recipe-scale-quantization.ts';
import {
  LegacyOptimizerWorkerResponseSchema,
  MacroFitWorkerResponseSchema,
} from './composer-optimizer-schemas.ts';
import type {
  OptimizerWorkerRequest,
  OptimizerWorkerResponse,
} from './composer-optimizer.worker.ts';

const DEFAULT_OPTIMIZER_TIMEOUT_MS = 12_000;

let sharedWorker: Worker | null = null;
let workerUnavailable = false;
let nextRequestId = 1;

interface PendingEntry {
  expectedKind: 'legacy_composer' | 'macro_target_fit';
  resolve: (result: unknown) => void;
  reject: (reason: Error) => void;
  timer: ReturnType<typeof setTimeout>;
}

const pendingRequests = new Map<number, PendingEntry>();

function teardownWorkerWithError(worker: Worker, message: string): void {
  for (const [, pending] of pendingRequests) {
    clearTimeout(pending.timer);
    pending.reject(new Error(message));
  }
  pendingRequests.clear();
  try {
    worker.terminate();
  } catch {
    // Worker already terminated
  }
  if (sharedWorker === worker) {
    sharedWorker = null;
  }
}

export function resetComposerOptimizerClientForTests(): void {
  for (const [, pending] of pendingRequests) {
    clearTimeout(pending.timer);
    pending.reject(new Error('Worker reiniciado para testes.'));
  }
  pendingRequests.clear();
  if (sharedWorker) {
    try {
      sharedWorker.terminate();
    } catch {
      // Ignore cleanup failure
    }
    sharedWorker = null;
  }
  workerUnavailable = false;
}

function getOrCreateWorker(): Worker | null {
  if (workerUnavailable || typeof Worker === 'undefined') return null;
  if (sharedWorker) return sharedWorker;

  try {
    const worker = new Worker(
      new URL('./composer-optimizer.worker.ts', import.meta.url),
      { type: 'module' },
    );
    worker.onmessage = (event: MessageEvent<OptimizerWorkerResponse>) => {
      const data = event.data as unknown;
      if (!data || typeof data !== 'object') return;
      const maybeId = (data as { requestId?: unknown }).requestId;
      if (typeof maybeId !== 'number') return;
      const entry = pendingRequests.get(maybeId);
      if (!entry) return;
      pendingRequests.delete(maybeId);
      clearTimeout(entry.timer);

      if (entry.expectedKind === 'macro_target_fit') {
        const parsed = MacroFitWorkerResponseSchema.safeParse(data);
        if (!parsed.success) {
          entry.reject(new Error('Resposta do worker nutricional falhou na validação Zod.'));
          return;
        }
        entry.resolve(parsed.data.result);
        return;
      }

      const parsed = LegacyOptimizerWorkerResponseSchema.safeParse(data);
      if (!parsed.success) {
        entry.reject(new Error('Resposta do worker de otimização falhou na validação Zod.'));
        return;
      }
      entry.resolve({
        proposal: parsed.data.proposal as OptimizationProposal,
        substitutions: parsed.data.substitutions as DiscreteSubstitutionProposal[],
        jointCombination: (parsed.data.jointCombination as DiscreteCombinationProposal | null) ?? null,
      });
    };
    worker.onerror = () => {
      teardownWorkerWithError(worker, 'Falha no worker de otimização nutricional.');
    };
    worker.onmessageerror = () => {
      teardownWorkerWithError(worker, 'Erro ao desserializar resposta do worker nutricional.');
    };
    sharedWorker = worker;
    return worker;
  } catch {
    workerUnavailable = true;
    return null;
  }
}

export async function runComposerOptimizationAsync(
  dayPlan: ComposerDayPlan,
  targets: NutritionTargets,
  options: OptimizeBalanceOptions & { timeoutMs?: number } = {},
  includeSubstitutions = true,
): Promise<{
  proposal: OptimizationProposal;
  substitutions: DiscreteSubstitutionProposal[];
  jointCombination: DiscreteCombinationProposal | null;
}> {
  const { timeoutMs: requestedTimeoutMs, ...solverOptions } = options;
  const runSyncFallback = () => ({
    proposal: solveNutritionalBalanceQP(dayPlan, targets, solverOptions),
    substitutions: includeSubstitutions ? proposeDiscreteSubstitutions(dayPlan, targets, 4) : [],
    jointCombination: null,
  });

  const worker = getOrCreateWorker();
  if (!worker) {
    return runSyncFallback();
  }

  const timeoutMs =
    typeof requestedTimeoutMs === 'number' &&
    Number.isFinite(requestedTimeoutMs) &&
    requestedTimeoutMs > 0
      ? requestedTimeoutMs
      : DEFAULT_OPTIMIZER_TIMEOUT_MS;

  const requestId = nextRequestId++;
  return new Promise<{
    proposal: OptimizationProposal;
    substitutions: DiscreteSubstitutionProposal[];
    jointCombination: DiscreteCombinationProposal | null;
  }>((resolve, reject) => {
    const timer = setTimeout(() => {
      const pending = pendingRequests.get(requestId);
      if (!pending) return;
      pendingRequests.delete(requestId);
      teardownWorkerWithError(worker, 'Tempo limite excedido no worker de otimização nutricional.');
      reject(new Error('Tempo limite excedido no worker de otimização nutricional.'));
    }, timeoutMs);

    pendingRequests.set(requestId, {
      expectedKind: 'legacy_composer',
      resolve: resolve as (r: unknown) => void,
      reject,
      timer,
    });
    const payload: OptimizerWorkerRequest = {
      requestId,
      kind: 'legacy_composer',
      dayPlan,
      targets,
      options: solverOptions,
      includeSubstitutions,
    };
    try {
      worker.postMessage(payload);
    } catch {
      const pending = pendingRequests.get(requestId);
      if (pending) {
        clearTimeout(pending.timer);
        pendingRequests.delete(requestId);
      }
      teardownWorkerWithError(worker, 'Falha ao enviar carga para o worker nutricional.');
      reject(new Error('Falha ao enviar carga para o worker nutricional.'));
    }
  }).catch(() => runSyncFallback());
}

export async function runMacroTargetFitAsync(
  dayPlan: ComposerDayPlan,
  targets: NutritionTargets,
  options: MacroTargetFitOptions & { timeoutMs?: number } = {},
): Promise<RecipeScaleQuantizationResult> {
  const { timeoutMs: requestedTimeoutMs, ...solverOptions } = options;
  const runSyncFallback = () => solveMacroTargetFitQP(dayPlan, targets, solverOptions);

  const worker = getOrCreateWorker();
  if (!worker) {
    return runSyncFallback();
  }

  const timeoutMs =
    typeof requestedTimeoutMs === 'number' &&
    Number.isFinite(requestedTimeoutMs) &&
    requestedTimeoutMs > 0
      ? requestedTimeoutMs
      : DEFAULT_OPTIMIZER_TIMEOUT_MS;

  const requestId = nextRequestId++;
  return new Promise<RecipeScaleQuantizationResult>((resolve, reject) => {
    const timer = setTimeout(() => {
      const pending = pendingRequests.get(requestId);
      if (!pending) return;
      pendingRequests.delete(requestId);
      teardownWorkerWithError(worker, 'Tempo limite excedido no cálculo automático de cardápio.');
      reject(new Error('Tempo limite excedido no cálculo automático de cardápio.'));
    }, timeoutMs);

    pendingRequests.set(requestId, {
      expectedKind: 'macro_target_fit',
      resolve: resolve as (r: unknown) => void,
      reject,
      timer,
    });
    const payload: OptimizerWorkerRequest = {
      requestId,
      kind: 'macro_target_fit',
      dayPlan,
      targets,
      options: solverOptions,
    };
    try {
      worker.postMessage(payload);
    } catch {
      const pending = pendingRequests.get(requestId);
      if (pending) {
        clearTimeout(pending.timer);
        pendingRequests.delete(requestId);
      }
      teardownWorkerWithError(worker, 'Falha ao enviar carga para o worker de escala proporcional.');
      reject(new Error('Falha ao enviar carga para o worker de escala proporcional.'));
    }
  }).catch(() => runSyncFallback());
}
