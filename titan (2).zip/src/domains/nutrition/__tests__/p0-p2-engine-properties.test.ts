import assert from 'node:assert/strict';
import fc from 'fast-check';
import { deduplicateStepsAndWorkouts } from '../../activity/domain/rules/activity-reconciliation.ts';
import { validateAdaptiveEnergyCalibration, type AdaptiveCalibrationSample } from '../../profile/domain/rules/adaptive-energy.ts';
import { RECIPE_CATALOG, findRecipeById, LEGACY_COMPOSITE_RECIPE_ARCHIVE } from '../data/recipes/recipe-catalog.ts';
import { getOpenFoodFactsFoodById, OPEN_FOOD_FACTS_PRODUCTS } from '../data/sources/open-food-facts-adapter.ts';
import { TBCA_FOODS } from '../data/sources/tbca-adapter.ts';
import {
  evaluateCommercialExportGovernance,
  getSourceUsagePolicy,
  SOURCE_LICENSE_REGISTRY,
} from '../domain/rules/data-governance.ts';
import {
  derivePreparedFoodComposition,
  PUBLISHED_PREPARATION_TRANSFORMS,
} from '../domain/rules/food-preparation-transform.ts';
import {
  computeGs1CheckDigit,
  matchesExactGtin,
  validateAndNormalizeGtin,
} from '../domain/rules/gtin.ts';
import {
  buildSourceObservationFromFoodItem,
  deriveFoodRole,
  resolveFoodComposition,
} from '../domain/rules/hybrid-composition-resolver.ts';
import { planMultiDayCardapio } from '../domain/rules/multi-day-planner.ts';
import {
  evaluateUpperLimitExposure,
  resolveFoodById,
  resolveReferenceProfile,
} from '../domain/rules/nutrition-calculator.ts';
import { evaluateMealProteinQualityDiaas } from '../domain/rules/protein-quality.ts';
import { isEligibleRecipeTemplate } from '../domain/rules/recipe-engine.ts';
import {
  evaluateSemanticBlockers,
  exportMatchesToSssomTsv,
  matchFoodWithAbstention,
} from '../domain/rules/semantic-food-matcher.ts';
import {
  checkTemporalPlanMutation,
  classifyDateTemporalBand,
  evaluateTemporalDatePolicy,
} from '../domain/rules/temporal-policy.ts';
import { useNutritionStore } from '../state/nutrition.store.ts';

// 1. Property-based: GS1 GTIN-8/12/13/14 validation & leading zero preservation
fc.assert(
  fc.property(
    fc.constantFrom(7, 11, 12, 13),
    fc.array(fc.integer({ min: 0, max: 9 }), { minLength: 13, maxLength: 13 }),
    (payloadLen, digitsArr) => {
      const payload = digitsArr.slice(0, payloadLen).join('');
      if (/^0+$/.test(payload)) return; // skip all-zero synthetic payload
      const checkDigit = computeGs1CheckDigit(payload);
      const validCode = `${payload}${checkDigit}`;

      const result = validateAndNormalizeGtin(validCode);
      assert.equal(result.valid, true, `Valid GTIN ${validCode} must pass`);
      assert.equal(result.normalized, validCode, 'Leading zeros must be preserved');
      assert.equal(result.gtin14?.length, 14);
      assert.equal(matchesExactGtin(validCode, result.gtin14!), true);

      // Corrupting last digit must fail Mod-10 checksum
      const badDigit = (checkDigit + 1) % 10;
      const corrupted = `${payload}${badDigit}`;
      assert.equal(validateAndNormalizeGtin(corrupted).valid, false);
    },
  ),
  { numRuns: 150 },
);

// Non-digit / numeric coercion / path traversal rejection
assert.equal(validateAndNormalizeGtin(7891025118345 as unknown as string).valid, false);
assert.equal(validateAndNormalizeGtin('../etc/passwd').valid, false);
assert.equal(validateAndNormalizeGtin('0000000000000').valid, false);

// 2. Property-based: Hybrid Composition Resolver precedence, quantified 0 lock, 100ml density gate & state isolation
fc.assert(
  fc.property(
    fc.float({ min: 1, max: 500, noNaN: true }),
    fc.float({ min: 1, max: 200, noNaN: true }),
    (userKcal, proxyCalcium) => {
      const baseOff = getOpenFoodFactsFoodById('off-iogurte-proteico')!;
      const primary = buildSourceObservationFromFoodItem(
        {
          ...baseOff,
          micronutrients: {
            ...baseOff.micronutrients,
            // Explicit quantified ZERO sodium on primary label
            sodium: {
              original_value: 0,
              original_unit: 'mg',
              normalized_value: 0,
              normalized_unit: 'mg',
              basis_quantity: 100,
              data_status: 'quantified',
              conversion_method: 'direct',
            },
          },
        },
        { basisUnit: 'g' },
      );

      const proxyTarget = TBCA_FOODS['tbca:BRC0113F']!;
      const proxyObs = buildSourceObservationFromFoodItem({
        ...proxyTarget,
        state: 'as_sold',
        micronutrients: {
          ...proxyTarget.micronutrients,
          sodium: {
            original_value: 999,
            original_unit: 'mg',
            normalized_value: 999,
            normalized_unit: 'mg',
            basis_quantity: 100,
            data_status: 'quantified',
            conversion_method: 'direct',
          },
          iron: {
            original_value: Number(proxyCalcium.toFixed(2)),
            original_unit: 'mg',
            normalized_value: Number(proxyCalcium.toFixed(2)),
            normalized_unit: 'mg',
            basis_quantity: 100,
            data_status: 'quantified',
            conversion_method: 'direct',
          },
        },
      });

      const resolved = resolveFoodComposition({
        primary,
        matchedConceptProxy: {
          observation: proxyObs,
          edge: {
            edge_id: 'edge:test',
            source_food_id: primary.food_id,
            target_concept_id: `concept:${proxyTarget.food_id}`,
            target_food_id: proxyTarget.food_id,
            predicate_id: 'skos:closeMatch',
            confidence: 0.88,
            status: 'approved',
            blockers_triggered: [],
            justification: 'Approved dairy proxy for missing micronutrients only.',
          },
        },
        userCorrection: {
          correction_id: 'corr-prop',
          food_id: primary.food_id,
          corrected_at: '2026-11-27T00:00:00.000Z',
          facts: {
            energy_kcal: {
              value: Number(userKcal.toFixed(2)),
              unit: 'kcal',
              basis_unit: 'g',
              status: 'quantified',
            },
          },
        },
      });

      // Precedence: user correction beats primary OFF
      assert.equal(resolved.facts.energy_kcal.source_tier, 'user_correction');
      assert.equal(resolved.facts.energy_kcal.value, Number(userKcal.toFixed(2)));
      // Quantified zero is NEVER overwritten by proxy (999)
      assert.equal(resolved.facts.sodium.status, 'quantified');
      assert.equal(resolved.facts.sodium.value, 0);
      assert.equal(resolved.facts.sodium.source_tier, 'current_label');
      // Missing primary micronutrient (iron) can take approved proxy as 'proxy_estimated'
      assert.equal(resolved.facts.iron.status, 'proxy_estimated');
      assert.equal(resolved.facts.iron.source_tier, 'matched_concept_proxy');
    },
  ),
  { numRuns: 50 },
);

// 100ml vs 100g density guard & as_sold vs prepared guard
{
  const beverageObs = buildSourceObservationFromFoodItem(
    {
      ...OPEN_FOOD_FACTS_PRODUCTS['off-iogurte-proteico']!,
      food_id: 'off-bebida-test',
      name: 'Bebida Proteica 100ml',
      state: 'as_sold',
    },
    { basisUnit: 'ml', densityGPerMl: null },
  );
  const noDensity = resolveFoodComposition({
    primary: beverageObs,
    targetBasisUnit: 'g',
  });
  assert.equal(noDensity.facts.energy_kcal.status, 'unit_mismatch');
  assert.equal(noDensity.facts.energy_kcal.value, null);

  const withDensity = resolveFoodComposition({
    primary: { ...beverageObs, density_g_per_ml: 1.04 },
    targetBasisUnit: 'g',
  });
  assert.equal(withDensity.facts.energy_kcal.status, 'quantified');
  assert.ok(Math.abs((withDensity.facts.energy_kcal.value ?? 0) - 86 / 1.04) < 0.01);

  const mismatchedState = resolveFoodComposition({
    primary: beverageObs, // state: 'as_sold'
    targetPreparationState: 'prepared',
  });
  assert.equal(mismatchedState.facts.protein_g.status, 'indeterminate');
}

// 3. Semantic food matcher with blockers, abstention & SSSOM export
{
  const rawChicken = TBCA_FOODS['tbca:BRC0134F']!;
  const roastedChicken = TBCA_FOODS['tbca:BRC0113F']!;
  const blockers = evaluateSemanticBlockers(rawChicken, roastedChicken);
  assert.ok(blockers.some((b) => b.startsWith('thermal_state_mismatch')));

  const matchAbstain = matchFoodWithAbstention(rawChicken, [roastedChicken]);
  assert.equal(matchAbstain.status, 'abstain_blocked');
  assert.equal(matchAbstain.selectedEdge, null);

  const tsv = exportMatchesToSssomTsv(
    [
      {
        edge_id: 'e1',
        source_food_id: 'off-iogurte-proteico',
        target_concept_id: 'concept:tbca:BRC0113F',
        target_food_id: 'tbca:BRC0113F',
        predicate_id: 'skos:broadMatch',
        confidence: 0.75,
        status: 'needs_review',
        blockers_triggered: [],
        justification: 'Teste SSSOM',
      },
    ],
    (id) => resolveFoodById(id)?.name ?? id,
  );
  assert.ok(tsv.includes('subject_id\tsubject_label\tpredicate_id'));
  assert.ok(tsv.includes('skos:broadMatch'));
}

// 4. Data Governance & TBCA commercial export guard
{
  assert.equal(SOURCE_LICENSE_REGISTRY.TBCA.commercialDistributionAllowed, false);
  assert.equal(getSourceUsagePolicy('TBCA').commercial_export_allowed, false);
  const audit = evaluateCommercialExportGovernance([
    TBCA_FOODS['tbca:BRC0113F']!,
    OPEN_FOOD_FACTS_PRODUCTS['off-iogurte-proteico']!,
  ]);
  assert.equal(audit.allowed, false);
  assert.ok(audit.blockedSources.includes('TBCA'));
  assert.equal(deriveFoodRole(TBCA_FOODS['tbca:BRC0134F']!), 'raw_ingredient');
  assert.equal(deriveFoodRole(OPEN_FOOD_FACTS_PRODUCTS['off-pasta-amendoim']!), 'multi_ingredient_product');
}

// 5. Strict UL chemical-form / scope check (P1.1)
{
  const profile = resolveReferenceProfile('adult_male_19_50');
  const vitA = evaluateUpperLimitExposure(profile.entries.vitamin_a, {
    quantifiedFoodValue: 4000,
    quantifiedFoodUnit: 'µg RAE',
  });
  assert.equal(vitA.status, 'indeterminate');

  const mag = evaluateUpperLimitExposure(profile.entries.magnesium, {
    quantifiedFoodValue: 550,
    quantifiedFoodUnit: 'mg',
  });
  assert.equal(mag.status, 'indeterminate');

  const iron = evaluateUpperLimitExposure(profile.entries.iron, {
    quantifiedFoodValue: 48,
    quantifiedFoodUnit: 'mg',
    supplementScopedValue: 0,
  });
  assert.equal(iron.status, 'exceeded');
}

// 6. Canonical recipe catalog 8/8 eligible & legacy archive blocked (P1.2)
{
  assert.equal(RECIPE_CATALOG.length, 8);
  assert.equal(RECIPE_CATALOG.filter(isEligibleRecipeTemplate).length, 8);
  assert.ok(LEGACY_COMPOSITE_RECIPE_ARCHIVE.length >= 3);
  assert.equal(findRecipeById('legacy-rec-almoco-frango'), undefined);
  assert.ok(findRecipeById('legacy-rec-almoco-frango', { includeLegacyArchive: true }));
}

// 7. Temporal replanning policy & multi-day 7/14/28 planner (P1.3 & P2.1)
{
  assert.equal(classifyDateTemporalBand('2026-11-20', '2026-11-27'), 'past');
  assert.equal(classifyDateTemporalBand('2026-11-27', '2026-11-27'), 'today');
  assert.equal(classifyDateTemporalBand('2026-11-28', '2026-11-27'), 'future');

  assert.equal(
    evaluateTemporalDatePolicy('2026-11-20', '2026-11-27').isFrozenHistory,
    true,
  );
  assert.equal(
    checkTemporalPlanMutation('2026-11-20', 'multi_day_generate', {
      referenceTodayKey: '2026-11-27',
    }).allowed,
    false,
  );
  assert.equal(
    checkTemporalPlanMutation('2026-11-27', 'multi_day_generate', {
      referenceTodayKey: '2026-11-27',
      confirmedToday: false,
    }).requiresConfirmation,
    true,
  );

  const store = useNutritionStore.getState();
  const basePlan = store.composerPlans[0]!;
  const plan14 = planMultiDayCardapio({
    plan: basePlan,
    startDateKey: '2026-11-26',
    horizonDays: 14,
    referenceTodayKey: '2026-11-27',
    includeTodayConfirmed: false,
    lockedSlotIdsByDate: {
      '2026-11-28': [basePlan.days[store.activeDateKey]?.slots[0]?.id ?? 'slot-cafe'],
    },
  });

  assert.equal(plan14.frozenPastDates.includes('2026-11-26'), true);
  assert.equal(plan14.requiresTodayConfirmationDate, '2026-11-27');
  assert.equal(
    plan14.dailyMacroSummaries.filter((d) => d.band === 'future' && d.appliedRotation).length,
    12,
  );

  const applyResult = store.applyMultiDayPlan(plan14, { confirmedToday: false });
  assert.equal(applyResult.ok, true);
  if (applyResult.ok) {
    assert.equal(applyResult.appliedDates.includes('2026-11-26'), false);
    assert.equal(applyResult.appliedDates.includes('2026-11-27'), false);
    assert.equal(applyResult.appliedDates.length, 12);
  }
}

// 8. USDA Release 6 transforms & FAO/Muleya DIAAS evaluation (P1.4 & P1.5)
{
  const chickenTransform = PUBLISHED_PREPARATION_TRANSFORMS[0]!;
  const rawChicken = resolveFoodById(chickenTransform.sourceFoodId)!;
  const derived = derivePreparedFoodComposition(rawChicken, 100, chickenTransform);
  assert.equal(derived.status, 'derived');
  assert.ok((derived.food?.macros.proteinGPerBasis ?? 0) > rawChicken.macros.proteinGPerBasis);

  const diaasEval = evaluateMealProteinQualityDiaas(
    [
      { foodId: 'tbca:BRC0113F', foodName: 'Frango', proteinGrams: 30 },
      { foodId: 'tbca:BRC0016A', foodName: 'Arroz', proteinGrams: 5 },
      { foodId: 'tbca-unmapped-test', foodName: 'Alimento sem perfil', proteinGrams: 4 },
    ],
    'older_children_adults',
  );
  assert.equal(diaasEval.diaasResult.status, 'calculated');
  assert.ok((diaasEval.diaasResult.diaas ?? 0) > 75 && (diaasEval.diaasResult.diaas ?? 0) <= 100);
  assert.equal(diaasEval.uncoveredFoods.length, 1);
  assert.equal(diaasEval.uncoveredProteinGrams, 4);
}

// 9. Activity step/workout overlap deduplication & Adaptive TDEE calibration (P1.6 & P1.7)
{
  const dedup = deduplicateStepsAndWorkouts(
    [
      {
        id: 'step-1',
        source: 'health_connect',
        startTime: '2026-11-27T07:00:00.000Z',
        endTime: '2026-11-27T08:00:00.000Z',
        steps: 5000,
      },
      {
        id: 'step-2',
        source: 'health_connect',
        startTime: '2026-11-27T12:00:00.000Z',
        endTime: '2026-11-27T13:00:00.000Z',
        steps: 1000,
      },
    ],
    [
      {
        id: 'wo-1',
        source: 'health_connect',
        sourceRecordId: 'wo-1',
        kind: 'workout_session',
        energyKind: 'active',
        startTime: '2026-11-27T07:05:00.000Z',
        endTime: '2026-11-27T07:55:00.000Z',
        energyKcal: 420,
        quality: 'measured',
      },
    ],
    75,
  );
  assert.equal(dedup.excludedOverlappingSteps, 5000);
  assert.equal(dedup.residualSteps, 1000);
  assert.equal(dedup.workoutActiveKcal, 420);

  const samples: AdaptiveCalibrationSample[] = [
    {
      id: 'sample-1',
      subgroup: 'male_cut',
      referenceObservedTdeeKcal: 2400,
      estimate: {
        estimateKcal: 2450,
        lowerBoundKcal: 2250,
        upperBoundKcal: 2650,
        meanIntakeKcal: 2100,
        observedWeightChangeKgPerWeek: -0.35,
        energyDensityAssumptionKcalPerKg: 7000,
        coveredDays: 28,
        expectedDays: 28,
        coveragePercent: 100,
        confidence: 'higher',
        method: 'observed_intake_plus_weight_trend',
        intervalKind: 'kalman_model_based_95pct_not_externally_calibrated',
        estimator: 'robust_rolling_energy_balance_kalman_v2_hall_composition_density',
        uncertaintyKcal: 100,
        measurementWindows: 3,
        warnings: [],
      },
    },
    {
      id: 'sample-2',
      subgroup: 'female_maint',
      referenceObservedTdeeKcal: 1950,
      estimate: {
        estimateKcal: 1900,
        lowerBoundKcal: 1750,
        upperBoundKcal: 2050,
        meanIntakeKcal: 1950,
        observedWeightChangeKgPerWeek: 0,
        energyDensityAssumptionKcalPerKg: 7000,
        coveredDays: 28,
        expectedDays: 28,
        coveragePercent: 100,
        confidence: 'higher',
        method: 'observed_intake_plus_weight_trend',
        intervalKind: 'kalman_model_based_95pct_not_externally_calibrated',
        estimator: 'robust_rolling_energy_balance_kalman_v2_hall_composition_density',
        uncertaintyKcal: 75,
        measurementWindows: 3,
        warnings: [],
      },
    },
  ];
  const cal = validateAdaptiveEnergyCalibration(samples)!;
  assert.equal(cal.sampleCount, 2);
  assert.equal(cal.maeKcal, 50);
  assert.equal(cal.rmseKcal, 50);
  assert.equal(cal.meanSignedBiasKcal, 0);
  assert.equal(cal.empirical95IntervalCoveragePercent, 100);
  assert.equal(cal.isExternallyCalibrated, false);
  assert.equal(cal.subgroups.length, 2);
}

console.log('P0-P2 Nutrition Engine property & unit tests passed.');
