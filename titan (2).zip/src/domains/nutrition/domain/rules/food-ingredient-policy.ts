import type { FoodRole, FoodSourceItem } from '../entities/nutrient.ts';
import { deriveFoodRole } from './hybrid-composition-resolver.ts';

export type RecipeIngredientEligibilityReason =
  | 'eligible'
  | 'tbca_composite_preparation'
  | 'tbca_unknown_food_type'
  | 'titan_legacy_not_canonical'
  | 'non_ingredient_role_blocked';

export interface RecipeIngredientEligibility {
  eligible: boolean;
  reason: RecipeIngredientEligibilityReason;
}

function normalizeFoodType(foodType: string | undefined): string {
  return (foodType ?? '').trim().toLocaleUpperCase('pt-BR');
}

export function getRecipeIngredientFoodRole(food: FoodSourceItem | null | undefined): FoodRole {
  if (!food) return 'unknown';
  return deriveFoodRole(food);
}

/** Trust the source's typed food classification; never infer composition from its display name. */
export function isCompositeFood(food: FoodSourceItem | null | undefined): boolean {
  return normalizeFoodType(food?.food_type) === 'PREPARACAO_COMPOSTA';
}

/**
 * Recipe ingredient policy is intentionally source- and role-aware:
 * - TBCA only allows rows explicitly classified as ALIMENTO.
 * - TBCA preparations, supplements, Survey ready composite dishes, and unclassified TBCA rows fail closed.
 * - Local legacy meal snapshots are not canonical ingredient records.
 */
export function evaluateRecipeIngredientEligibility(
  food: FoodSourceItem | null | undefined,
): RecipeIngredientEligibility {
  if (!food) return { eligible: false, reason: 'titan_legacy_not_canonical' };
  if (food.source_id === 'TBCA') {
    const foodType = normalizeFoodType(food.food_type);
    if (foodType === 'ALIMENTO') return { eligible: true, reason: 'eligible' };
    if (foodType === 'PREPARACAO_COMPOSTA') {
      return { eligible: false, reason: 'tbca_composite_preparation' };
    }
    return { eligible: false, reason: 'tbca_unknown_food_type' };
  }
  if (food.source_id === 'TITAN_LEGACY') {
    return { eligible: false, reason: 'titan_legacy_not_canonical' };
  }
  const role = deriveFoodRole(food);
  if (role === 'ready_composite_dish' || role === 'supplement') {
    return { eligible: false, reason: 'non_ingredient_role_blocked' };
  }
  return { eligible: true, reason: 'eligible' };
}

export function isEligibleRecipeIngredient(food: FoodSourceItem | null | undefined): boolean {
  return evaluateRecipeIngredientEligibility(food).eligible;
}

