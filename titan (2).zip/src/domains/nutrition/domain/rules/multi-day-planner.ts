import { getLocalDateKey, isValidLocalDateKey, shiftLocalDateKey } from '../../../../shared/utils/local-date.ts';
import { RECIPE_CATALOG, findRecipeById } from '../../data/recipes/recipe-catalog.ts';
import type {
  CardapioPlan,
  ComposerDayPlan,
  ComposerMacroTotals,
  ComposerMealSlot,
  NutritionTargets,
  RecipeItem,
  TemporalDateBand,
} from '../entities/nutrient.ts';
import {
  cloneDayPlan,
  computeDayNutrition,
  createRecipeInstanceFromCatalog,
} from './cardapio-composer-engine.ts';
import { solveMacroTargetFitQP } from './macro-target-fit.ts';
import { isEligibleRecipeTemplate } from './recipe-engine.ts';
import { classifyDateTemporalBand } from './temporal-policy.ts';

export type MultiDayHorizon = 7 | 14 | 28;

export interface MultiDayPlannerRequest {
  plan: CardapioPlan;
  startDateKey: string;
  horizonDays: MultiDayHorizon;
  targets?: NutritionTargets;
  referenceTodayKey?: string;
  includeTodayConfirmed?: boolean;
  /** DateKey -> locked slot IDs that must not be replaced by rotation. */
  lockedSlotIdsByDate?: Record<string, readonly string[]>;
  /** Maximum consecutive appearances of the same recipe template in a meal category. */
  avoidConsecutiveSameRecipe?: boolean;
  /** Maximum times a recipe can be selected per 7-day window when alternatives exist. */
  maxWeeklyRepetition?: number;
}

export interface MultiDaySummaryEntry {
  dateKey: string;
  band: TemporalDateBand;
  appliedRotation: boolean;
  macros: ComposerMacroTotals;
  deviationPercent: number;
}

export interface MultiDayPlanResult {
  horizonDays: MultiDayHorizon;
  startDateKey: string;
  referenceTodayKey: string;
  plannedDays: Record<string, ComposerDayPlan>;
  frozenPastDates: string[];
  requiresTodayConfirmationDate: string | null;
  dailyMacroSummaries: MultiDaySummaryEntry[];
  recipeFrequencyById: Record<string, number>;
  warnings: string[];
}

const DEFAULT_SLOT_TEMPLATE: Array<{
  id: string;
  time: string;
  title: string;
  category: RecipeItem['category'];
}> = [
  { id: 'slot-cafe', time: '07:30', title: 'Café da manhã', category: 'cafe' },
  { id: 'slot-almoco', time: '12:30', title: 'Almoço', category: 'almoco' },
  { id: 'slot-lanche', time: '16:00', title: 'Lanche da tarde', category: 'lanche' },
  { id: 'slot-jantar', time: '20:30', title: 'Jantar', category: 'jantar' },
];

function computeTargetGapPercent(
  macros: ComposerMacroTotals,
  targets: NutritionTargets,
): number {
  const safeDiv = (num: number, den: number) => (den > 0 ? Math.abs(num - den) / den : 0);
  const weighted =
    safeDiv(macros.kcal, targets.kcal) * 0.35 +
    safeDiv(macros.proteinG, targets.proteinG) * 0.3 +
    safeDiv(macros.carbsG, targets.carbsG) * 0.2 +
    safeDiv(macros.fatG, targets.fatG) * 0.15;
  return Number((weighted * 100).toFixed(1));
}

/**
 * Deterministic multi-day cardápio planner (7/14/28 days):
 * - Freezes past history unconditionally.
 * - Requires explicit confirmation before modifying 'today'.
 * - Rotates eligible canonical recipes across categories to minimize consecutive repetition.
 * - Preserves locked meal slots and calibrates continuous portions via the QP macro-fit solver.
 */
export function planMultiDayCardapio(request: MultiDayPlannerRequest): MultiDayPlanResult {
  const referenceTodayKey =
    request.referenceTodayKey && isValidLocalDateKey(request.referenceTodayKey)
      ? request.referenceTodayKey
      : getLocalDateKey();
  const startDateKey = isValidLocalDateKey(request.startDateKey)
    ? request.startDateKey
    : referenceTodayKey;
  const targets = request.targets ?? request.plan.targets;
  const avoidConsecutive = request.avoidConsecutiveSameRecipe ?? true;
  const maxWeeklyRepetition = Math.max(1, request.maxWeeklyRepetition ?? 4);

  const eligibleByCategory: Record<RecipeItem['category'], RecipeItem[]> = {
    cafe: [],
    almoco: [],
    lanche: [],
    jantar: [],
  };
  for (const recipe of RECIPE_CATALOG) {
    if (isEligibleRecipeTemplate(recipe)) {
      eligibleByCategory[recipe.category].push(recipe);
    }
  }

  const plannedDays: Record<string, ComposerDayPlan> = {};
  const frozenPastDates: string[] = [];
  let requiresTodayConfirmationDate: string | null = null;
  const dailyMacroSummaries: MultiDaySummaryEntry[] = [];
  const recipeFrequencyById: Record<string, number> = {};
  const lastRecipeByCategory = new Map<RecipeItem['category'], string>();
  const weeklyCountsByRecipe = new Map<string, number>();
  const warnings: string[] = [];

  for (let offset = 0; offset < request.horizonDays; offset += 1) {
    if (offset > 0 && offset % 7 === 0) {
      weeklyCountsByRecipe.clear();
    }
    const shifted = shiftLocalDateKey(startDateKey, offset);
    if (!shifted) continue;
    const dateKey = shifted;
    const band = classifyDateTemporalBand(dateKey, referenceTodayKey);
    const existingDay = request.plan.days[dateKey];

    if (band === 'past') {
      frozenPastDates.push(dateKey);
      if (existingDay) {
        const preserved = cloneDayPlan(existingDay);
        plannedDays[dateKey] = preserved;
        const summary = computeDayNutrition(preserved);
        dailyMacroSummaries.push({
          dateKey,
          band,
          appliedRotation: false,
          macros: summary.macros,
          deviationPercent: computeTargetGapPercent(summary.macros, targets),
        });
      }
      continue;
    }

    if (band === 'today' && !request.includeTodayConfirmed) {
      requiresTodayConfirmationDate = dateKey;
      if (existingDay) {
        const preserved = cloneDayPlan(existingDay);
        plannedDays[dateKey] = preserved;
        const summary = computeDayNutrition(preserved);
        dailyMacroSummaries.push({
          dateKey,
          band,
          appliedRotation: false,
          macros: summary.macros,
          deviationPercent: computeTargetGapPercent(summary.macros, targets),
        });
      }
      continue;
    }

    const lockedSlots = new Set(request.lockedSlotIdsByDate?.[dateKey] ?? []);
    const baseSlots: ComposerMealSlot[] = existingDay?.slots.length
      ? existingDay.slots
      : DEFAULT_SLOT_TEMPLATE.map((tpl) => {
          const fallback = eligibleByCategory[tpl.category][0] ?? findRecipeById('rec-cafe-completo')!;
          return {
            id: tpl.id,
            time: tpl.time,
            title: tpl.title,
            recipes: [createRecipeInstanceFromCatalog(fallback, `${tpl.id}-rec-1`, 1, 'balanced')],
          };
        });

    const rotatedSlots: ComposerMealSlot[] = baseSlots.map((slot, slotIdx) => {
      if (lockedSlots.has(slot.id)) {
        return {
          ...slot,
          recipes: slot.recipes.map((r) => ({
            ...r,
            ingredients: r.ingredients.map((i) => ({ ...i })),
          })),
        };
      }

      const slotCategory: RecipeItem['category'] =
        slot.recipes[0]?.category ??
        DEFAULT_SLOT_TEMPLATE[slotIdx]?.category ??
        (slot.time < '11:00' ? 'cafe' : slot.time < '15:00' ? 'almoco' : slot.time < '19:00' ? 'lanche' : 'jantar');

      const candidates = eligibleByCategory[slotCategory];
      if (candidates.length === 0) {
        return slot;
      }

      const lastId = lastRecipeByCategory.get(slotCategory);
      const underCap = candidates.filter(
        (c) => (weeklyCountsByRecipe.get(c.id) ?? 0) < maxWeeklyRepetition,
      );
      const pool = underCap.length > 0 ? underCap : candidates;
      const nonConsecutive = avoidConsecutive
        ? pool.filter((c) => c.id !== lastId)
        : pool;
      const finalPool = nonConsecutive.length > 0 ? nonConsecutive : pool;

      // Deterministic balanced pick: lowest weekly count, breaking ties with offset rotation.
      const sorted = [...finalPool].sort((a, b) => {
        const diff = (weeklyCountsByRecipe.get(a.id) ?? 0) - (weeklyCountsByRecipe.get(b.id) ?? 0);
        if (diff !== 0) return diff;
        return ((candidates.indexOf(a) + offset) % candidates.length) -
          ((candidates.indexOf(b) + offset) % candidates.length);
      });
      const chosen = sorted[0]!;
      lastRecipeByCategory.set(slotCategory, chosen.id);
      weeklyCountsByRecipe.set(chosen.id, (weeklyCountsByRecipe.get(chosen.id) ?? 0) + 1);
      recipeFrequencyById[chosen.id] = (recipeFrequencyById[chosen.id] ?? 0) + 1;

      const baseInstanceId = slot.recipes[0]?.id ?? `${slot.id}-${dateKey}-rec-1`;
      return {
        ...slot,
        recipes: [createRecipeInstanceFromCatalog(chosen, baseInstanceId, 1, 'balanced')],
      };
    });

    const candidateDay: ComposerDayPlan = {
      dateKey,
      slots: rotatedSlots,
    };

    const fit = solveMacroTargetFitQP(candidateDay, targets, {
      scaleMode: 'preserve_recipe_ratios',
      baselineSource: 'workingBaseline',
      mealAllocations: request.plan.mealAllocations,
    });
    const calibratedDay =
      fit.status !== 'infeasible' && fit.proposal?.proposedDayPlan
        ? fit.proposal.proposedDayPlan
        : candidateDay;

    plannedDays[dateKey] = calibratedDay;
    const dayNutrition = computeDayNutrition(calibratedDay);
    dailyMacroSummaries.push({
      dateKey,
      band,
      appliedRotation: true,
      macros: dayNutrition.macros,
      deviationPercent: computeTargetGapPercent(dayNutrition.macros, targets),
    });
  }

  for (const [cat, list] of Object.entries(eligibleByCategory)) {
    if (list.length < 3 && request.horizonDays >= 7) {
      warnings.push(
        `Categoria "${cat}" possui ${list.length} receita(s) canônica(s); o limite semanal de repetição foi flexibilizado para completar ${request.horizonDays} dias.`,
      );
    }
  }
  if (frozenPastDates.length > 0) {
    warnings.push(
      `${frozenPastDates.length} dia(s) passado(s) foram mantidos congelados pela política temporal.`,
    );
  }
  if (requiresTodayConfirmationDate) {
    warnings.push(
      `O dia corrente (${requiresTodayConfirmationDate}) aguardará confirmação explícita antes de sobrescrever o cardápio.`,
    );
  }

  return {
    horizonDays: request.horizonDays,
    startDateKey,
    referenceTodayKey,
    plannedDays,
    frozenPastDates,
    requiresTodayConfirmationDate,
    dailyMacroSummaries,
    recipeFrequencyById,
    warnings,
  };
}
