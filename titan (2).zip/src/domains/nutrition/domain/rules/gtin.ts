/**
 * Strict GS1 GTIN validation and canonical string normalization.
 * GTINs are always handled as opaque digit strings so leading zeros
 * (common in UPC-A -> EAN-13 and Brazilian EAN-13/8 codes) are never lost.
 */

export type GtinFormat = 'GTIN-8' | 'UPC-A' | 'EAN-13' | 'GTIN-14';

export interface GtinValidationResult {
  valid: boolean;
  normalized: string | null;
  gtin14: string | null;
  format: GtinFormat | null;
  reason?: string;
}

const SUPPORTED_LENGTHS = new Set([8, 12, 13, 14]);

/** Computes the GS1 Mod-10 check digit for payload digits (all digits except the final check digit). */
export function computeGs1CheckDigit(payloadDigits: string): number {
  let sum = 0;
  // GS1 weights alternate 3 and 1 starting from the rightmost payload position.
  for (let offset = 0; offset < payloadDigits.length; offset += 1) {
    const idx = payloadDigits.length - 1 - offset;
    const digit = Number(payloadDigits[idx]);
    const weight = offset % 2 === 0 ? 3 : 1;
    sum += digit * weight;
  }
  return (10 - (sum % 10)) % 10;
}

export function detectGtinFormat(digits: string): GtinFormat | null {
  switch (digits.length) {
    case 8:
      return 'GTIN-8';
    case 12:
      return 'UPC-A';
    case 13:
      return 'EAN-13';
    case 14:
      return 'GTIN-14';
    default:
      return null;
  }
}

/**
 * Strips whitespace/hyphens and validates GS1 GTIN-8 / 12 (UPC-A) / 13 (EAN-13) / 14.
 * Rejects empty strings, alphabetic characters, unsupported lengths, and Mod-10 checksum failures.
 */
export function validateAndNormalizeGtin(rawInput: string | number | null | undefined): GtinValidationResult {
  if (typeof rawInput === 'number') {
    return {
      valid: false,
      normalized: null,
      gtin14: null,
      format: null,
      reason: 'GTIN deve ser tratado estritamente como string para preservar zeros à esquerda.',
    };
  }
  if (typeof rawInput !== 'string') {
    return {
      valid: false,
      normalized: null,
      gtin14: null,
      format: null,
      reason: 'Código de barras ausente.',
    };
  }

  const trimmed = rawInput.trim();
  if (!trimmed) {
    return {
      valid: false,
      normalized: null,
      gtin14: null,
      format: null,
      reason: 'Informe um código GTIN-8, UPC-A (12), EAN-13 (13) ou GTIN-14.',
    };
  }

  // Allow common human spacing/dashes only; reject letters or URL/path characters immediately.
  if (!/^[\d\s-]+$/.test(trimmed)) {
    return {
      valid: false,
      normalized: null,
      gtin14: null,
      format: null,
      reason: 'O código de barras deve conter apenas dígitos numéricos.',
    };
  }

  const digits = trimmed.replace(/[\s-]+/g, '');
  if (!SUPPORTED_LENGTHS.has(digits.length)) {
    return {
      valid: false,
      normalized: null,
      gtin14: null,
      format: null,
      reason: `Comprimento ${digits.length} inválido; use GTIN-8, UPC-A (12), EAN-13 (13) ou GTIN-14.`,
    };
  }

  if (/^0+$/.test(digits)) {
    return {
      valid: false,
      normalized: null,
      gtin14: null,
      format: null,
      reason: 'Código de barras composto apenas por zeros não identifica produto válido.',
    };
  }

  const payload = digits.slice(0, -1);
  const actualCheck = Number(digits.slice(-1));
  const expectedCheck = computeGs1CheckDigit(payload);
  if (actualCheck !== expectedCheck) {
    return {
      valid: false,
      normalized: null,
      gtin14: null,
      format: null,
      reason: `Dígito verificador GS1 inválido (esperado ${expectedCheck}, recebido ${actualCheck}).`,
    };
  }

  return {
    valid: true,
    normalized: digits,
    gtin14: digits.padStart(14, '0'),
    format: detectGtinFormat(digits),
  };
}

/**
 * Exact GTIN equivalence check (allows comparing equivalent zero-padded GTIN-12/13/14 forms
 * only when both strings validate against GS1 check-digit verification).
 */
export function matchesExactGtin(candidateGtin: string | null | undefined, requestedGtin: string): boolean {
  const req = validateAndNormalizeGtin(requestedGtin);
  const cand = validateAndNormalizeGtin(candidateGtin);
  if (!req.valid || !cand.valid || !req.gtin14 || !cand.gtin14) return false;
  return req.gtin14 === cand.gtin14;
}
