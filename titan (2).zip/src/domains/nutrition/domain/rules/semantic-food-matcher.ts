import type { FoodConcept, FoodMatchEdge, FoodSourceItem } from '../entities/nutrient.ts';
import { deriveFoodRole } from './hybrid-composition-resolver.ts';

export interface CulinaryFacets {
  species?: 'chicken' | 'beef' | 'pork' | 'fish' | 'egg' | 'dairy' | 'soy' | 'oat' | 'rice' | 'wheat' | 'potato' | 'fruit';
  cut?: string;
  thermalState: 'raw' | 'boiled' | 'grilled' | 'baked' | 'fried' | 'unknown';
  fortified: boolean;
  addedSugar: boolean;
  addedSalt: boolean;
  addedOil: boolean;
  baseUnit: 'g' | 'ml';
}

export function extractCulinaryFacets(
  food: Pick<FoodSourceItem, 'name' | 'state' | 'preparation' | 'source_group' | 'food_type' | 'source_id'>,
): CulinaryFacets {
  const text = `${food.name} ${food.state ?? ''} ${food.preparation ?? ''} ${food.source_group ?? ''}`.toLowerCase();

  let species: CulinaryFacets['species'];
  if (/\b(frango|galinha|chicken)\b/.test(text)) species = 'chicken';
  else if (/\b(bovin[oa]|carne de boi|beef|patinho|alcatra|cox[aã]o)\b/.test(text)) species = 'beef';
  else if (/\b(su[ií]n[oa]|porco|pork)\b/.test(text)) species = 'pork';
  else if (/\b(salm[aã]o|til[aá]pia|atum|peixe|salmon|fish)\b/.test(text)) species = 'fish';
  else if (/\b(ovo|ovos|egg)\b/.test(text)) species = 'egg';
  else if (/\b(leite|iogurte|queijo|whey|milk|yogurt|dairy)\b/.test(text)) species = 'dairy';
  else if (/\b(soja|soy|tofu)\b/.test(text)) species = 'soy';
  else if (/\b(aveia|oat)\b/.test(text)) species = 'oat';
  else if (/\b(arroz|rice)\b/.test(text)) species = 'rice';
  else if (/\b(trigo|p[aã]o|bread|wheat)\b/.test(text)) species = 'wheat';
  else if (/\b(batata|potato)\b/.test(text)) species = 'potato';
  else if (/\b(banana|mam[aã]o|ma[cç][aã]|fruta|papaya)\b/.test(text)) species = 'fruit';

  let cut: string | undefined;
  if (/\b(peito|breast|fil[eé])\b/.test(text)) cut = 'breast';
  else if (/\b(coxa|sobrecoxa|thigh)\b/.test(text)) cut = 'thigh';

  let thermalState: CulinaryFacets['thermalState'] = 'unknown';
  if (/\b(frit[oa]|fried)\b/.test(text)) thermalState = 'fried';
  else if (/\b(assad[oa]|baked|roasted)\b/.test(text)) thermalState = 'baked';
  else if (/\b(grelhad[oa]|grilled)\b/.test(text)) thermalState = 'grilled';
  else if (/\b(cozid[oa]|boiled|steamed)\b/.test(text)) thermalState = 'boiled';
  else if (/\b(crua?|raw|in natura|fresc[oa])\b/.test(text)) thermalState = 'raw';

  const fortified = /\b(fortificad[oa]|enriquecid[oa]|fortified)\b/.test(text);
  const addedSugar = /\b(com a[cç][uú]car|ado[cç]ad[oa]|sweetened|added sugar)\b/.test(text) && !/\b(sem a[cç][uú]car|s\/\s*a[cç][uú]car|unsweetened)\b/.test(text);
  const addedSalt = /\b(c\/\s*sal|com sal|salgad[oa]|salted)\b/.test(text) && !/\b(s\/\s*sal|sem sal|unsalted)\b/.test(text);
  const addedOil = /\b(c\/\s*[oó]leo|c\/\s*azeite|c\/\s*manteiga|in oil|fried)\b/.test(text) && !/\b(s\/\s*[oó]leo|sem [oó]leo)\b/.test(text);
  const baseUnit: 'g' | 'ml' = /\b(100\s*ml|l[ií]quido|bebida|juice|suco)\b/.test(text) ? 'ml' : 'g';

  return {
    species,
    cut,
    thermalState,
    fortified,
    addedSugar,
    addedSalt,
    addedOil,
    baseUnit,
  };
}

/**
 * Evaluates hard semantic blockers between two foods before any lexical similarity
 * can authorize copying proxy nutrients across catalogs.
 */
export function evaluateSemanticBlockers(source: FoodSourceItem, candidate: FoodSourceItem): string[] {
  const s = extractCulinaryFacets(source);
  const c = extractCulinaryFacets(candidate);
  const blockers: string[] = [];

  if (s.species && c.species && s.species !== c.species) {
    blockers.push(`species_mismatch:${s.species}!=${c.species}`);
  }
  if (s.cut && c.cut && s.cut !== c.cut) {
    blockers.push(`cut_mismatch:${s.cut}!=${c.cut}`);
  }
  if (s.thermalState !== 'unknown' && c.thermalState !== 'unknown' && s.thermalState !== c.thermalState) {
    // Allow close cooked equivalence (baked/grilled) only when neither is raw or fried.
    const rawConflict = s.thermalState === 'raw' || c.thermalState === 'raw';
    const friedConflict = s.thermalState === 'fried' || c.thermalState === 'fried';
    if (rawConflict || friedConflict) {
      blockers.push(`thermal_state_mismatch:${s.thermalState}!=${c.thermalState}`);
    }
  }
  if (s.fortified !== c.fortified) {
    blockers.push(`fortification_mismatch:${String(s.fortified)}!=${String(c.fortified)}`);
  }
  if (s.addedSugar !== c.addedSugar) {
    blockers.push(`added_sugar_mismatch:${String(s.addedSugar)}!=${String(c.addedSugar)}`);
  }
  if (s.addedOil !== c.addedOil) {
    blockers.push(`added_oil_mismatch:${String(s.addedOil)}!=${String(c.addedOil)}`);
  }
  if (s.baseUnit !== c.baseUnit) {
    blockers.push(`base_unit_mismatch:${s.baseUnit}!=${c.baseUnit}`);
  }

  return blockers;
}

function tokenJaccardSimilarity(a: string, b: string): number {
  const tokenize = (s: string) =>
    new Set(
      s
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, ' ')
        .trim()
        .split(/\s+/)
        .filter((t) => t.length >= 2),
    );
  const setA = tokenize(a);
  const setB = tokenize(b);
  if (setA.size === 0 || setB.size === 0) return 0;
  let intersection = 0;
  for (const tok of setA) {
    if (setB.has(tok)) intersection += 1;
  }
  const union = setA.size + setB.size - intersection;
  return union === 0 ? 0 : intersection / union;
}

export interface SemanticMatchCandidateResult {
  status: 'matched' | 'abstain_blocked' | 'abstain_ambiguous' | 'no_candidate';
  selectedEdge: FoodMatchEdge | null;
  topCandidates: Array<{
    food: FoodSourceItem;
    score: number;
    blockers: string[];
  }>;
  reason: string;
}

/**
 * Matches a source food observation against canonical candidate concepts using
 * culinary facets, hard semantic blockers, and margin-based abstention.
 */
export function matchFoodWithAbstention(
  source: FoodSourceItem,
  candidates: readonly FoodSourceItem[],
  options: { minConfidence?: number; minMargin?: number } = {},
): SemanticMatchCandidateResult {
  const minConfidence = options.minConfidence ?? 0.62;
  const minMargin = options.minMargin ?? 0.08;

  const evaluated = candidates
    .filter((c) => c.food_id !== source.food_id)
    .map((candidate) => {
      const blockers = evaluateSemanticBlockers(source, candidate);
      const lexical = tokenJaccardSimilarity(source.name, candidate.name);
      const sFacets = extractCulinaryFacets(source);
      const cFacets = extractCulinaryFacets(candidate);
      const facetBonus =
        (sFacets.species && sFacets.species === cFacets.species ? 0.22 : 0) +
        (sFacets.thermalState !== 'unknown' && sFacets.thermalState === cFacets.thermalState ? 0.14 : 0) +
        (sFacets.addedSalt === cFacets.addedSalt ? 0.05 : 0);
      const rawScore = Math.min(0.99, Number((lexical * 0.72 + facetBonus).toFixed(4)));
      return { food: candidate, score: rawScore, blockers };
    })
    .sort((a, b) => {
      const aClean = a.blockers.length === 0 ? 1 : 0;
      const bClean = b.blockers.length === 0 ? 1 : 0;
      return bClean - aClean || b.score - a.score;
    });

  const topCandidates = evaluated.slice(0, 5);
  if (topCandidates.length === 0) {
    return { status: 'no_candidate', selectedEdge: null, topCandidates: [], reason: 'Nenhum candidato disponível.' };
  }

  const cleanCandidates = evaluated.filter((item) => item.blockers.length === 0);
  if (cleanCandidates.length === 0) {
    return {
      status: 'abstain_blocked',
      selectedEdge: null,
      topCandidates,
      reason: `Todos os candidatos foram barrados por bloqueadores semânticos (${topCandidates[0]?.blockers.join(', ')}).`,
    };
  }

  const best = cleanCandidates[0]!;
  const second = cleanCandidates[1];
  if (best.score < minConfidence) {
    return {
      status: 'abstain_ambiguous',
      selectedEdge: null,
      topCandidates,
      reason: `Confiança insuficiente (${best.score.toFixed(2)} < ${minConfidence.toFixed(2)}); requer revisão humana.`,
    };
  }

  if (second && best.score - second.score < minMargin && second.score >= minConfidence * 0.9) {
    return {
      status: 'abstain_ambiguous',
      selectedEdge: null,
      topCandidates,
      reason: `Empate semântico ambíguo entre "${best.food.name}" e "${second.food.name}"; revisão humana necessária.`,
    };
  }

  const predicateId: FoodMatchEdge['predicate_id'] =
    best.score >= 0.85 ? 'skos:exactMatch' : best.score >= 0.7 ? 'skos:closeMatch' : 'skos:broadMatch';

  return {
    status: 'matched',
    selectedEdge: {
      edge_id: `edge:${source.food_id}->${best.food.food_id}`,
      source_food_id: source.food_id,
      target_concept_id: `concept:${best.food.food_id}`,
      target_food_id: best.food.food_id,
      predicate_id: predicateId,
      confidence: best.score,
      status: best.score >= 0.72 ? 'approved' : 'needs_review',
      blockers_triggered: [],
      justification: `Facets compatíveis (${deriveFoodRole(best.food)}) · score ${best.score.toFixed(2)}.`,
    },
    topCandidates,
    reason: `Match validado com ${best.food.name} (${best.score.toFixed(2)}).`,
  };
}

export function buildFoodConcept(food: FoodSourceItem, foodonId?: string): FoodConcept {
  const facets = extractCulinaryFacets(food);
  return {
    concept_id: `concept:${food.food_id}`,
    canonical_name: food.name,
    foodon_id: foodonId,
    food_role: deriveFoodRole(food),
    facets: {
      species: facets.species,
      cut: facets.cut,
      thermal_state: facets.thermalState === 'boiled' ? 'boiled' : facets.thermalState,
      fortified: facets.fortified,
      added_sugar: facets.addedSugar,
      added_salt: facets.addedSalt,
      added_oil: facets.addedOil,
      base_unit: facets.baseUnit,
    },
  };
}

/**
 * Exports validated semantic mapping edges in W3C SSSOM TSV format
 * (Simple Standard for Sharing Ontological Mappings).
 */
export function exportMatchesToSssomTsv(
  edges: readonly FoodMatchEdge[],
  lookupName: (foodId: string) => string,
): string {
  const header = [
    'subject_id',
    'subject_label',
    'predicate_id',
    'object_id',
    'object_label',
    'mapping_justification',
    'confidence',
    'mapping_status',
    'comment',
  ].join('\t');

  const rows = edges.map((edge) =>
    [
      edge.source_food_id,
      lookupName(edge.source_food_id).replace(/[\t\r\n]+/g, ' '),
      edge.predicate_id,
      edge.target_food_id,
      lookupName(edge.target_food_id).replace(/[\t\r\n]+/g, ' '),
      'semapv:LexicalMatching',
      edge.confidence.toFixed(3),
      edge.status,
      edge.justification.replace(/[\t\r\n]+/g, ' '),
    ].join('\t'),
  );

  return [header, ...rows].join('\n');
}
