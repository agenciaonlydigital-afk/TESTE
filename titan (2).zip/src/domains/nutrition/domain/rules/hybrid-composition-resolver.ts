import {
  MICRONUTRIENT_ORDER,
  type FoodMatchEdge,
  type FoodRole,
  type FoodSourceItem,
  type NutrientFact,
  type NutrientFactMetricKey,
  type NutrientId,
  type ProductIdentity,
  type SourceFoodObservation,
  type UserLabelCorrection,
} from '../entities/nutrient.ts';
import { getSourceUsagePolicy } from './data-governance.ts';

const ALL_METRIC_KEYS: readonly NutrientFactMetricKey[] = [
  'energy_kcal',
  'protein_g',
  'carbs_g',
  'fat_g',
  'fiber_g',
  'saturated_fat_g',
  'sodium_mg',
  ...MICRONUTRIENT_ORDER,
];

const STANDARD_UNITS: Record<NutrientFactMetricKey, string> = {
  energy_kcal: 'kcal',
  protein_g: 'g',
  carbs_g: 'g',
  fat_g: 'g',
  fiber_g: 'g',
  saturated_fat_g: 'g',
  sodium_mg: 'mg',
  vitamin_a: 'µg RAE',
  vitamin_c: 'mg',
  vitamin_d: 'µg',
  vitamin_e: 'mg',
  vitamin_k: 'µg',
  vitamin_b1: 'mg',
  vitamin_b2: 'mg',
  vitamin_b3: 'mg NE',
  vitamin_b5: 'mg',
  vitamin_b6: 'mg',
  vitamin_b7: 'µg',
  vitamin_b9: 'µg DFE',
  vitamin_b12: 'µg',
  calcium: 'mg',
  copper: 'µg',
  iron: 'mg',
  phosphorus: 'mg',
  magnesium: 'mg',
  manganese: 'mg',
  potassium: 'mg',
  selenium: 'µg',
  sodium: 'mg',
  zinc: 'mg',
  choline: 'mg',
  iodine: 'µg',
  chloride: 'mg',
  molybdenum: 'µg',
  chromium: 'µg',
  fluoride: 'mg',
};

function normalizeUpper(value: string | undefined): string {
  return (value ?? '').trim().toLocaleUpperCase('pt-BR');
}

/**
 * Explicit FoodRole taxonomy without conflating packaged foods, raw ingredients,
 * supplements, and ready composite dishes.
 */
export function deriveFoodRole(food: Pick<FoodSourceItem, 'source_id' | 'food_type' | 'name' | 'preparation' | 'source_group'>): FoodRole {
  const foodType = normalizeUpper(food.food_type);
  const nameLower = food.name.toLowerCase();
  const groupLower = (food.source_group ?? '').toLowerCase();

  if (food.source_id === 'TITAN_LEGACY' || foodType === 'PREPARACAO_COMPOSTA') {
    return 'ready_composite_dish';
  }
  if (foodType === 'SUPPLEMENT' || groupLower.includes('suplement') || /\b(suplemento|c[aá]psula|polivitam[ií]nico|creatina)\b/i.test(nameLower)) {
    return 'supplement';
  }
  if (foodType === 'FORTIFIED' || /\b(fortificad[oa]|enriquecid[oa])\b/i.test(nameLower)) {
    return 'fortified_product';
  }
  if (food.source_id === 'TBCA') {
    if (foodType === 'ALIMENTO') {
      if (/\b(in natura|crua?|fresc[oa])\b/i.test(nameLower)) {
        return 'raw_ingredient';
      }
      if (/\b(cozid[oa]|assad[oa]|grelhad[oa]|flocos|p[aã]o|iogurte|queijo|óleo|azeite)\b/i.test(nameLower) || Boolean(food.preparation)) {
        return 'simple_processed_ingredient';
      }
      return 'raw_ingredient';
    }
    return 'unknown';
  }
  if (food.source_id === 'USDA_FDC') {
    if (foodType === 'Branded') {
      return 'multi_ingredient_product';
    }
    if (foodType === 'Foundation' || foodType === 'SR Legacy' || foodType === 'Experimental') {
      return /\braw\b/i.test(nameLower) ? 'raw_ingredient' : 'simple_processed_ingredient';
    }
    if (foodType === 'Survey (FNDDS)') {
      return 'ready_composite_dish';
    }
    return 'unknown';
  }
  if (food.source_id === 'OPEN_FOOD_FACTS') {
    if (foodType === 'SINGLE_INGREDIENT') return 'single_ingredient_commercial';
    if (foodType === 'MULTI_INGREDIENT' || foodType === 'Branded') return 'multi_ingredient_product';
    return 'multi_ingredient_product';
  }
  return 'unknown';
}

function normalizePreparationState(
  state: string | undefined,
): NutrientFact['preparation_state'] {
  const s = (state ?? '').toLowerCase();
  if (s === 'as_sold') return 'as_sold';
  if (s === 'prepared' || s.includes('cozid') || s.includes('assad') || s.includes('grelhad') || s.includes('cooked')) {
    return 'prepared';
  }
  if (s.includes('cru') || s.includes('raw')) return 'as_sold';
  return 'unknown';
}

function buildMacroFact(
  food: FoodSourceItem,
  key: 'energy_kcal' | 'protein_g' | 'carbs_g' | 'fat_g' | 'fiber_g' | 'saturated_fat_g' | 'sodium_mg',
  value: number | null | undefined,
  basisUnit: 'g' | 'ml',
  sourceTier: NutrientFact['source_tier'],
): NutrientFact | undefined {
  if (value === undefined) return undefined;
  const prepState = normalizePreparationState(food.state);
  const basisQuantity = food.macros.basisQuantityG || 100;
  const valid = typeof value === 'number' && Number.isFinite(value) && value >= 0;
  return {
    nutrient_key: key,
    value: valid ? value : null,
    unit: STANDARD_UNITS[key],
    basis_type: basisUnit === 'ml' ? 'per_100ml' : 'per_100g',
    basis_quantity: basisQuantity,
    basis_unit: basisUnit,
    preparation_state: prepState,
    status: valid ? 'quantified' : value === null ? (food.source_id === 'TBCA' ? 'not_analyzed' : 'missing') : 'invalid_value',
    source_id: food.source_id,
    source_tier: sourceTier,
    source_record_id: food.source_record_id,
    source_version: food.source_version,
    confidence: food.source_id === 'TBCA' || food.source_id === 'USDA_FDC' ? 0.95 : 0.85,
    justification: `Registro direto de ${food.source_id} (${food.source_record_id}).`,
    conversion_method: 'direct',
  };
}

/** Wraps any FoodSourceItem into a provenance-rich SourceFoodObservation with per-field NutrientFacts. */
export function buildSourceObservationFromFoodItem(
  food: FoodSourceItem,
  options: {
    productIdentity?: ProductIdentity;
    basisUnit?: 'g' | 'ml';
    densityGPerMl?: number | null;
    observedAt?: string;
    sourceTierOverride?: NutrientFact['source_tier'];
    warnings?: string[];
  } = {},
): SourceFoodObservation {
  const basisUnit: 'g' | 'ml' = options.basisUnit ?? (options.productIdentity?.nutrition_data_per === '100ml' ? 'ml' : 'g');
  const sourceTier: NutrientFact['source_tier'] = options.sourceTierOverride ?? (
    food.source_id === 'OPEN_FOOD_FACTS'
      ? 'current_label'
      : food.source_id === 'USDA_FDC' && food.food_type === 'Branded'
        ? 'usda_fdc_branded_exact_gtin'
        : food.preparation_conversion
          ? 'preparation_transform'
          : 'official_reference'
  );

  const facts: Partial<Record<NutrientFactMetricKey, NutrientFact>> = {};
  const macroPairs: Array<['energy_kcal' | 'protein_g' | 'carbs_g' | 'fat_g' | 'fiber_g' | 'saturated_fat_g' | 'sodium_mg', number | null | undefined]> = [
    ['energy_kcal', food.macros.kcalPerBasis],
    ['protein_g', food.macros.proteinGPerBasis],
    ['carbs_g', food.macros.carbsGPerBasis],
    ['fat_g', food.macros.fatGPerBasis],
    ['fiber_g', food.macros.fiberGPerBasis],
    ['saturated_fat_g', food.macros.saturatedFatGPerBasis],
    ['sodium_mg', food.macros.sodiumMgPerBasis],
  ];
  for (const [key, val] of macroPairs) {
    const f = buildMacroFact(food, key, val, basisUnit, sourceTier);
    if (f) facts[key] = f;
  }

  const prepState = normalizePreparationState(food.state);
  for (const nutrientId of MICRONUTRIENT_ORDER) {
    const entry = food.micronutrients[nutrientId];
    if (!entry) continue;
    const isValidQuantified =
      entry.data_status === 'quantified' &&
      entry.normalized_value !== null &&
      Number.isFinite(entry.normalized_value) &&
      entry.normalized_value >= 0;

    facts[nutrientId] = {
      nutrient_key: nutrientId,
      value: isValidQuantified ? entry.normalized_value : null,
      unit: entry.normalized_unit || STANDARD_UNITS[nutrientId],
      basis_type: basisUnit === 'ml' ? 'per_100ml' : 'per_100g',
      basis_quantity: entry.basis_quantity || 100,
      basis_unit: basisUnit,
      preparation_state: prepState,
      status: entry.data_status === 'quantified' && !isValidQuantified ? 'invalid_value' : entry.data_status,
      source_id: food.source_id,
      source_tier: sourceTier,
      source_record_id: food.source_record_id,
      source_version: food.source_version,
      confidence: entry.data_status === 'quantified' ? (food.quality_status === 'label_partial' ? 0.82 : 0.94) : 0.9,
      justification: `${food.source_id} (${food.source_version}) · método ${entry.conversion_method}.`,
      conversion_method: entry.conversion_method,
    };
  }

  return {
    observation_id: `obs:${food.source_id}:${food.source_record_id}`,
    food_id: food.food_id,
    source_id: food.source_id,
    source_record_id: food.source_record_id,
    source_version: food.source_version,
    observed_at: options.observedAt ?? new Date().toISOString(),
    product_identity: options.productIdentity,
    food_role: deriveFoodRole(food),
    raw_name: food.name,
    state: prepState === 'as_sold' ? 'as_sold' : prepState === 'prepared' ? 'prepared' : 'unknown',
    nutrition_basis_unit: basisUnit,
    density_g_per_ml: options.densityGPerMl ?? options.productIdentity?.density_g_per_ml ?? null,
    food_item: food,
    usage_policy: getSourceUsagePolicy(food.source_id),
    facts,
    warnings: options.warnings ? [...options.warnings] : [],
  };
}

export interface HybridCompositionRequest {
  primary: SourceFoodObservation;
  officialFallback?: SourceFoodObservation | null;
  matchedConceptProxy?: {
    observation: SourceFoodObservation;
    edge: FoodMatchEdge;
  } | null;
  preparedTransformObservation?: SourceFoodObservation | null;
  userCorrection?: UserLabelCorrection | null;
  targetBasisUnit?: 'g' | 'ml';
  targetPreparationState?: 'as_sold' | 'prepared';
}

export interface ResolvedHybridComposition {
  food_id: string;
  food_role: FoodRole;
  target_basis_unit: 'g' | 'ml';
  target_preparation_state: 'as_sold' | 'prepared';
  facts: Record<NutrientFactMetricKey, NutrientFact>;
  quantifiedCount: number;
  proxyCount: number;
  indeterminateCount: number;
  warnings: string[];
}

function adaptBasisAndState(
  fact: NutrientFact,
  targetBasisUnit: 'g' | 'ml',
  targetPreparationState: 'as_sold' | 'prepared',
  densityGPerMl: number | null | undefined,
): NutrientFact {
  // Block conflating as_sold vs prepared unless the fact itself originated from preparation transform or matches state.
  if (
    fact.preparation_state !== 'unknown' &&
    fact.preparation_state !== targetPreparationState &&
    fact.source_tier !== 'preparation_transform'
  ) {
    return {
      ...fact,
      value: null,
      status: 'indeterminate',
      confidence: 0,
      justification: `Estado incompatível (${fact.preparation_state} != ${targetPreparationState}); bloqueada conversão implícita sem fator documentado.`,
      uncertainty_note: 'as_sold vs prepared não podem ser misturados sem rendimento/retenção.',
    };
  }

  if (fact.basis_unit === targetBasisUnit) {
    return fact;
  }

  // Never convert 100 ml <-> 100 g assuming density 1.0 unless explicit verified density_g_per_ml is provided!
  if (typeof densityGPerMl !== 'number' || !Number.isFinite(densityGPerMl) || densityGPerMl <= 0) {
    return {
      ...fact,
      value: null,
      status: 'unit_mismatch',
      confidence: 0,
      justification: `Unidade de base incompatível (${fact.basis_unit} -> ${targetBasisUnit}) sem densidade documentada.`,
      uncertainty_note: 'Informe densidade (g/ml) antes de converter entre volume e massa.',
    };
  }

  if (fact.status !== 'quantified' || fact.value === null) {
    return {
      ...fact,
      basis_unit: targetBasisUnit,
      basis_type: targetBasisUnit === 'ml' ? 'per_100ml' : 'per_100g',
    };
  }

  // Convert per 100 ml -> per 100 g: divide by densityGPerMl; per 100 g -> per 100 ml: multiply by densityGPerMl.
  const convertedValue =
    fact.basis_unit === 'ml' && targetBasisUnit === 'g'
      ? fact.value / densityGPerMl
      : fact.value * densityGPerMl;

  return {
    ...fact,
    value: Number(convertedValue.toFixed(6)),
    basis_unit: targetBasisUnit,
    basis_type: targetBasisUnit === 'ml' ? 'per_100ml' : 'per_100g',
    conversion_method: 'density_converted',
    justification: `${fact.justification} Convertido via densidade explícita (${densityGPerMl} g/ml).`,
  };
}

/**
 * Policy-based per-field composition resolver.
 * Precedence:
 * 1. User label correction (audit logged)
 * 2. Current label / exact GTIN observation (OFF v3 / USDA FDC Branded exact gtinUpc)
 * 3. Official source observation (TBCA / USDA Foundation/SR Legacy)
 * 4. Validated matched FoodConcept proxy (never overwrites quantified zero or valid label fact!)
 * 5. Documented preparation transform
 * 6. Preserved status (trace, not_analyzed, missing, indeterminate)
 */
export function resolveFoodComposition(request: HybridCompositionRequest): ResolvedHybridComposition {
  const targetBasisUnit: 'g' | 'ml' = request.targetBasisUnit ?? request.primary.nutrition_basis_unit;
  const targetPreparationState: 'as_sold' | 'prepared' =
    request.targetPreparationState ??
    (request.primary.state === 'prepared' ? 'prepared' : 'as_sold');
  const density =
    request.userCorrection?.density_g_per_ml ??
    request.primary.density_g_per_ml ??
    request.primary.product_identity?.density_g_per_ml ??
    null;

  const warnings: string[] = [...request.primary.warnings];
  const resolvedFacts = {} as Record<NutrientFactMetricKey, NutrientFact>;

  let quantifiedCount = 0;
  let proxyCount = 0;
  let indeterminateCount = 0;

  const isValidApprovedProxy =
    Boolean(request.matchedConceptProxy) &&
    request.matchedConceptProxy!.edge.status === 'approved' &&
    request.matchedConceptProxy!.edge.blockers_triggered.length === 0;

  if (request.matchedConceptProxy && !isValidApprovedProxy) {
    warnings.push(
      `Match semântico não aprovado (${request.matchedConceptProxy.edge.status}): proxy bloqueado para evitar transferência errada.`,
    );
  }

  for (const key of ALL_METRIC_KEYS) {
    // Tier 1: Immutable user correction override
    const userOverride = request.userCorrection?.facts[key];
    if (userOverride) {
      const candidate: NutrientFact = {
        nutrient_key: key,
        value: userOverride.status === 'quantified' ? userOverride.value : null,
        unit: userOverride.unit,
        basis_type: userOverride.basis_unit === 'ml' ? 'per_100ml' : 'per_100g',
        basis_quantity: 100,
        basis_unit: userOverride.basis_unit,
        preparation_state: targetPreparationState,
        status: userOverride.status,
        source_id: 'USER',
        source_tier: 'user_correction',
        source_record_id: request.userCorrection!.correction_id,
        source_version: request.userCorrection!.corrected_at,
        confidence: 0.99,
        justification: request.userCorrection!.reviewer_note || 'Correção manual auditável do rótulo pelo usuário.',
        conversion_method: 'user_verified',
      };
      const adapted = adaptBasisAndState(candidate, targetBasisUnit, targetPreparationState, density);
      resolvedFacts[key] = adapted;
      if (adapted.status === 'quantified') quantifiedCount += 1;
      else if (adapted.status === 'indeterminate' || adapted.status === 'unit_mismatch') indeterminateCount += 1;
      continue;
    }

    // Tier 2/3/5 primary candidate
    const primaryRaw = request.preparedTransformObservation?.facts[key] ?? request.primary.facts[key];
    if (primaryRaw) {
      const adaptedPrimary = adaptBasisAndState(primaryRaw, targetBasisUnit, targetPreparationState, density);
      // True zero (value === 0 with status === 'quantified') or explicit trace is NEVER overwritten by fallback!
      if (
        adaptedPrimary.status === 'quantified' ||
        adaptedPrimary.status === 'trace' ||
        adaptedPrimary.status === 'unit_mismatch' ||
        adaptedPrimary.status === 'invalid_value'
      ) {
        resolvedFacts[key] = adaptedPrimary;
        if (adaptedPrimary.status === 'quantified') quantifiedCount += 1;
        else if (adaptedPrimary.status === 'unit_mismatch' || adaptedPrimary.status === 'invalid_value') indeterminateCount += 1;
        continue;
      }
    }

    // Tier 3 official non-proxy fallback (e.g., USDA FDC Branded complementing OFF macro-only label)
    const officialFact = request.officialFallback?.facts[key];
    if (officialFact && (officialFact.status === 'quantified' || officialFact.status === 'trace')) {
      const adaptedOfficial = adaptBasisAndState(officialFact, targetBasisUnit, targetPreparationState, density);
      resolvedFacts[key] = adaptedOfficial;
      if (adaptedOfficial.status === 'quantified') quantifiedCount += 1;
      else if (adaptedOfficial.status === 'indeterminate' || adaptedOfficial.status === 'unit_mismatch') indeterminateCount += 1;
      continue;
    }

    // Tier 4 approved semantic FoodConcept proxy (only when primary was missing/not_analyzed, NEVER overwriting 0)
    if (isValidApprovedProxy) {
      const proxyRaw = request.matchedConceptProxy!.observation.facts[key];
      if (proxyRaw && proxyRaw.status === 'quantified' && proxyRaw.value !== null) {
        const adaptedProxy = adaptBasisAndState(
          {
            ...proxyRaw,
            status: 'proxy_estimated',
            source_tier: 'matched_concept_proxy',
            confidence: Number((proxyRaw.confidence * request.matchedConceptProxy!.edge.confidence).toFixed(3)),
            justification: `Proxy via ${request.matchedConceptProxy!.edge.predicate_id} (${request.matchedConceptProxy!.edge.target_food_id}): ${request.matchedConceptProxy!.edge.justification}`,
            uncertainty_note: 'Estimativa por alimento conceitual canônico; rótulo não declarou este nutriente.',
          },
          targetBasisUnit,
          targetPreparationState,
          density,
        );
        resolvedFacts[key] = adaptedProxy;
        if (adaptedProxy.status === 'proxy_estimated') proxyCount += 1;
        else if (adaptedProxy.status === 'indeterminate' || adaptedProxy.status === 'unit_mismatch') indeterminateCount += 1;
        continue;
      }
    }

    // Unresolved fallback preserving primary status (not_analyzed / missing / indeterminate)
    if (primaryRaw) {
      const adaptedUnresolved = adaptBasisAndState(primaryRaw, targetBasisUnit, targetPreparationState, density);
      resolvedFacts[key] = adaptedUnresolved;
      if (adaptedUnresolved.status === 'indeterminate' || adaptedUnresolved.status === 'unit_mismatch') {
        indeterminateCount += 1;
      }
    } else {
      resolvedFacts[key] = {
        nutrient_key: key,
        value: null,
        unit: STANDARD_UNITS[key],
        basis_type: targetBasisUnit === 'ml' ? 'per_100ml' : 'per_100g',
        basis_quantity: 100,
        basis_unit: targetBasisUnit,
        preparation_state: targetPreparationState,
        status: request.primary.source_id === 'TBCA' ? 'not_analyzed' : 'missing',
        source_id: request.primary.source_id,
        source_tier: 'unresolved',
        source_record_id: request.primary.source_record_id,
        source_version: request.primary.source_version,
        confidence: 0,
        justification: 'Nutriente ausente ou não analisado na fonte.',
        conversion_method: 'unavailable',
      };
    }
  }

  return {
    food_id: request.primary.food_id,
    food_role: request.primary.food_role,
    target_basis_unit: targetBasisUnit,
    target_preparation_state: targetPreparationState,
    facts: resolvedFacts,
    quantifiedCount,
    proxyCount,
    indeterminateCount,
    warnings: [...new Set(warnings)],
  };
}
