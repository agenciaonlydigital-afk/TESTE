import assert from 'node:assert/strict';
import { ensureTbcaCatalogLoaded } from '../../../data/sources/tbca-adapter.ts';
import { buildRecipeScaleModel } from '../recipe-scale-model.ts';
import { quantizeAndValidateRecipeScaleProposal } from '../recipe-scale-quantization.ts';

await ensureTbcaCatalogLoaded();

const dayPlan = {
  dateKey: '2026-11-26',
  slots: [
    {
      id: 'slot-1',
      time: '12:00',
      title: 'Almoço',
      recipes: [
        {
          id: 'rec-1',
          name: 'Ovo e Abacate',
          category: 'almoco',
          baseServings: 1,
          targetServings: 1,
          adjustmentMode: 'balanced',
          ingredients: [
            {
              id: 'i-egg',
              foodId: 'tbca-ovo-mexido',
              displayName: 'Ovo mexido',
              baseQuantityG: 140,
              currentQuantityG: 140,
              quantityStatus: 'known',
              mode: 'flexible',
              minQuantityG: 70,
              maxQuantityG: 280,
            },
            {
              id: 'i-avocado',
              foodId: 'tbca:BRC0001C',
              displayName: 'Abacate',
              baseQuantityG: 100,
              currentQuantityG: 100,
              quantityStatus: 'known',
              mode: 'flexible',
              minQuantityG: 50,
              maxQuantityG: 200,
            },
            {
              id: 'i-locked',
              foodId: 'tbca-banana-prata',
              displayName: 'Banana travada',
              baseQuantityG: 80,
              currentQuantityG: 80,
              quantityStatus: 'known',
              mode: 'locked',
              minQuantityG: 80,
              maxQuantityG: 80,
            },
            {
              id: 'i-missing',
              foodId: 'tbca-banana-prata',
              displayName: 'Sem quantidade',
              baseQuantityG: null,
              currentQuantityG: null,
              quantityStatus: 'missing',
              mode: 'flexible',
              minQuantityG: null,
              maxQuantityG: null,
            },
          ],
        },
      ],
    },
  ],
};

// 1. Half-gram rounding, non-zero enforcement, locked invariant, missingness untouched, recomputation via computeDayNutrition
const targets = { kcal: 540, proteinG: 25, carbsG: 30, fatG: 35 };
const model = buildRecipeScaleModel(dayPlan, targets);
const result = quantizeAndValidateRecipeScaleProposal(
  dayPlan,
  targets,
  model,
  [1.253], // 140 * 1.253 = 175.42 -> 175.5g; 100 * 1.253 = 125.3 -> 125.5g
  4.2,
  { solverEngine: 'Test Engine' },
);

const quantizedIngs = result.proposal.proposedDayPlan.slots[0].recipes[0].ingredients;
assert.equal(quantizedIngs[0].currentQuantityG, 175.5, 'must quantize to nearest 0.5g');
assert.equal(quantizedIngs[1].currentQuantityG, 125.5, 'must quantize to nearest 0.5g');
assert.equal(quantizedIngs[2].currentQuantityG, 80, 'locked ingredient must stay identical');
assert.equal(quantizedIngs[3].currentQuantityG, null, 'missing ingredient must remain null, never zeroed');
assert.equal(quantizedIngs[3].quantityStatus, 'missing');
// Missing data means it must be downgraded honestly instead of claiming clean optimal target_met
assert.equal(result.status, 'insufficient_data');
assert.equal(result.proposal.certificate, 'approximate');

// 2. Post-rounding UL audit catches a continuous-feasible scale that pushes UL over after 0.5g rounding,
// and repairs or flags infeasible cleanly.
const completeDay = {
  dateKey: '2026-11-26',
  slots: [
    {
      id: 'slot-1',
      time: '12:00',
      title: 'Refeição completa',
      recipes: [
        {
          id: 'rec-clean',
          name: 'Ovo simples',
          category: 'almoco',
          baseServings: 1,
          targetServings: 1,
          adjustmentMode: 'balanced',
          ingredients: [
            {
              id: 'i-egg',
              foodId: 'tbca-ovo-mexido',
              displayName: 'Ovo mexido',
              baseQuantityG: 140,
              currentQuantityG: 140,
              quantityStatus: 'known',
              mode: 'flexible',
              minQuantityG: 70,
              maxQuantityG: 280,
            },
          ],
        },
      ],
    },
  ],
};

// Egg vitamin_d is quantified; inspect tight UL right at continuous scale 1.0 (140g) vs slightly higher rounding
const strictUlTargets = [
  {
    nutrientId: 'vitamin_d',
    unit: 'µg',
    minimum: null,
    minimumKind: null,
    preferredMaximum: null,
    upperLimit: 0.0001, // impossible UL even at minQuantityG=70g if egg vitD > 0, or test exact positive micro
    upperLimitUnit: 'µg',
    upperLimitScope: 'total_intake',
  },
];
const modelUl = buildRecipeScaleModel(completeDay, targets, { micronutrientTargets: strictUlTargets });
// Force an applied tight UL below what minScale gives or right below rounded continuous solution
const customTightUlModel = {
  ...modelUl,
  micronutrientConstraints: [
    {
      nutrientId: 'iron',
      unit: 'mg',
      minimum: null,
      minimumKind: null,
      preferredMaximum: null,
      upperLimit: 1.0, // minScale (0.5 -> 70g) yields >1mg? wait egg iron ~1.8mg/100g -> 70g = ~1.26mg -> infeasible!
      fixedValue: 0,
      coefficients: [modelUl.vars[0].micronutrientsPerUnitScale.iron ?? 2.5],
      status: 'applied',
    },
  ],
};
const ulFail = quantizeAndValidateRecipeScaleProposal(
  completeDay,
  targets,
  customTightUlModel,
  [0.55],
  2.0,
  { solverEngine: 'Test Engine' },
);
assert.equal(ulFail.status, 'infeasible', 'post-rounding UL violation that cannot repair must be reported infeasible');

// 3. Multi-serving recipe (baseServings = 2, targetServings = 2) scales targetServings proportionally > 4 (up to 4 * baseServings)
const multiServingDay = {
  dateKey: '2026-11-26',
  slots: [
    {
      id: 'slot-1',
      time: '12:00',
      title: 'Almoço família',
      recipes: [
        {
          id: 'rec-multi',
          name: 'Ovos dupla porção',
          category: 'almoco',
          baseServings: 2,
          targetServings: 2,
          adjustmentMode: 'balanced',
          ingredients: [
            {
              id: 'i-egg-multi',
              foodId: 'tbca-ovo-mexido',
              displayName: 'Ovo mexido',
              baseQuantityG: 100,
              currentQuantityG: 100,
              quantityStatus: 'known',
              mode: 'flexible',
              minQuantityG: 50,
              maxQuantityG: 400,
            },
          ],
        },
      ],
    },
  ],
};
const multiModel = buildRecipeScaleModel(multiServingDay, { kcal: 400, proteinG: 30, carbsG: 5, fatG: 28 });
const multiScaled = quantizeAndValidateRecipeScaleProposal(
  multiServingDay,
  { kcal: 400, proteinG: 30, carbsG: 5, fatG: 28 },
  multiModel,
  [2.5],
  1.5,
  { solverEngine: 'Test Engine' },
);
assert.equal(
  multiScaled.proposal.proposedDayPlan.slots[0].recipes[0].targetServings,
  5,
  'targetServings with baseServings=2 and scale=2.5 must become 5, not clipped at 4',
);

console.log('recipe-scale-quantization.test.mjs: PASS');
