import assert from 'node:assert/strict';
import { LEGACY_COMPOSITE_RECIPE_ARCHIVE, RECIPE_CATALOG, findRecipeById } from '../../../data/recipes/recipe-catalog.ts';
import {
  evaluateRecipeTemplateEligibility,
  isEligibleRecipeTemplate,
  searchSubstitutionRecipes,
} from '../recipe-engine.ts';

const cafe = RECIPE_CATALOG.find((recipe) => recipe.id === 'rec-cafe-completo');
const yoghurt = RECIPE_CATALOG.find((recipe) => recipe.id === 'rec-lanche-iogurte');
const chicken = RECIPE_CATALOG.find((recipe) => recipe.id === 'rec-almoco-frango');

assert.ok(cafe && yoghurt && chicken);
for (const recipe of RECIPE_CATALOG) {
  assert.deepEqual(evaluateRecipeTemplateEligibility(recipe), {
    eligible: true,
    blockedFoodIds: [],
  }, `Canonical recipe ${recipe.id} must be 100% eligible`);
  assert.equal(isEligibleRecipeTemplate(recipe), true);
}

const selectable = RECIPE_CATALOG.filter(isEligibleRecipeTemplate).map((recipe) => recipe.id);
assert.equal(selectable.length, 8);

const substitutions = searchSubstitutionRecipes('', 'rec-sub-iogurte-leve');
assert.equal(substitutions.length, 7);
assert.ok(substitutions.every((summary) => isEligibleRecipeTemplate(summary.recipe)));

// Legacy composite meal snapshots remain preserved in archive for historical replay, never selectable in new plans.
const legacyLunch = LEGACY_COMPOSITE_RECIPE_ARCHIVE.find((recipe) => recipe.id === 'legacy-rec-almoco-frango');
assert.ok(legacyLunch);
assert.deepEqual(evaluateRecipeTemplateEligibility(legacyLunch), {
  eligible: false,
  blockedFoodIds: ['tbca-frango-arroz-legumes'],
});
assert.equal(findRecipeById('legacy-rec-almoco-frango'), undefined);
assert.ok(findRecipeById('legacy-rec-almoco-frango', { includeLegacyArchive: true }));
console.log('recipe-ingredient-eligibility: PASS');
