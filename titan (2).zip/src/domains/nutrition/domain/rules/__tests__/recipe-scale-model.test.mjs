import assert from 'node:assert/strict';
import { ensureTbcaCatalogLoaded } from '../../../data/sources/tbca-adapter.ts';
import {
  buildRecipeScaleModel,
  projectContinuousRecipeScalesToQuantities,
} from '../recipe-scale-model.ts';

await ensureTbcaCatalogLoaded();

const dayPlan = {
  dateKey: '2026-11-26',
  slots: [
    {
      id: 'slot-almoco',
      time: '12:30',
      title: 'Almoço',
      recipes: [
        {
          id: 'rec-a',
          name: 'Bowl proteico A',
          category: 'almoco',
          baseServings: 1,
          targetServings: 1,
          adjustmentMode: 'balanced',
          ingredients: [
            {
              id: 'a-frango',
              foodId: 'tbca:BRC0055B', // Peito de frango grelhado (verified TBCA) or fallback known food
              displayName: 'Peito de frango',
              baseQuantityG: 150,
              currentQuantityG: 150,
              quantityStatus: 'known',
              mode: 'flexible',
              minQuantityG: 60,
              maxQuantityG: 350,
            },
            {
              id: 'a-arroz',
              foodId: 'tbca-ovo-mexido',
              displayName: 'Ovo mexido',
              baseQuantityG: 100,
              currentQuantityG: 100,
              quantityStatus: 'known',
              mode: 'flexible',
              minQuantityG: 40,
              maxQuantityG: 250,
            },
            {
              id: 'a-azeite-locked',
              foodId: 'tbca-banana-prata',
              displayName: 'Banana (travada)',
              baseQuantityG: 80,
              currentQuantityG: 80,
              quantityStatus: 'known',
              mode: 'locked',
              minQuantityG: 80,
              maxQuantityG: 80,
            },
            {
              id: 'a-sal-to-taste',
              foodId: 'tbca:BRC0001C',
              displayName: 'Sal a gosto',
              baseQuantityG: null,
              currentQuantityG: null,
              quantityStatus: 'to_taste',
              mode: 'flexible',
              minQuantityG: null,
              maxQuantityG: null,
            },
            {
              id: 'a-pendente',
              foodId: 'tbca:BRC0001C',
              displayName: 'Pendente',
              baseQuantityG: null,
              currentQuantityG: null,
              quantityStatus: 'missing',
              mode: 'flexible',
              minQuantityG: null,
              maxQuantityG: null,
            },
          ],
        },
        {
          id: 'rec-b',
          name: 'Sobremesa energética B',
          category: 'almoco',
          baseServings: 1,
          targetServings: 1,
          adjustmentMode: 'proportional',
          ingredients: [
            {
              id: 'b-banana',
              foodId: 'tbca-banana-prata',
              displayName: 'Banana prata',
              baseQuantityG: 120,
              currentQuantityG: 120,
              quantityStatus: 'known',
              mode: 'proportional',
              minQuantityG: 50,
              maxQuantityG: 300,
            },
          ],
        },
      ],
    },
    {
      id: 'slot-locked-only',
      time: '16:00',
      title: 'Lanche travado',
      recipes: [
        {
          id: 'rec-locked',
          name: 'Lanche fixo',
          category: 'lanche',
          baseServings: 1,
          targetServings: 1,
          adjustmentMode: 'proportional',
          ingredients: [
            {
              id: 'l-banana',
              foodId: 'tbca-banana-prata',
              displayName: 'Banana travada',
              baseQuantityG: 100,
              currentQuantityG: 100,
              quantityStatus: 'known',
              mode: 'locked',
              minQuantityG: 100,
              maxQuantityG: 100,
            },
          ],
        },
      ],
    },
  ],
};

// Switch first ingredient to guaranteed food ID in TBCA_FOODS
dayPlan.slots[0].recipes[0].ingredients[0].foodId = 'tbca:BRC0001C';

const model = buildRecipeScaleModel(
  dayPlan,
  { kcal: 2000, proteinG: 120, carbsG: 220, fatG: 65 },
  { baselineSource: 'workingBaseline' },
);

// 1. Two independent recipe decision vars in the same slot; locked recipe excluded from scale vars
assert.equal(model.vars.length, 2, 'must produce one RecipeScaleDecisionVar per scalable recipe instance');
assert.equal(model.vars[0].recipeId, 'rec-a');
assert.equal(model.vars[1].recipeId, 'rec-b');
assert.equal(model.vars[0].slotId, model.vars[1].slotId);

// 2. F (fixed totals) includes locked ingredients from rec-a AND rec-locked, never missing/to_taste
assert.ok(model.fixedTotals.kcal > 150, 'locked ingredients contribute to fixed F baseline');
assert.equal(model.missingIngredientsCount, 1);
assert.equal(model.toTasteIngredientsCount, 1);
assert.equal(model.lockedIngredientsCount, 2);

// 3. Ratios strictly preserved across scalable ingredients in rec-a under arbitrary scale factor
const continuous = projectContinuousRecipeScalesToQuantities(model, [1.45, 0.75]);
const ing0 = continuous.get('slot-almoco::rec-a::a-frango');
const ing1 = continuous.get('slot-almoco::rec-a::a-arroz');
const locked = continuous.get('slot-almoco::rec-a::a-azeite-locked');
const toTaste = continuous.get('slot-almoco::rec-a::a-sal-to-taste');
const missing = continuous.get('slot-almoco::rec-a::a-pendente');
assert.ok(ing0 !== undefined && ing1 !== undefined);
assert.ok(Math.abs(ing0 / ing1 - 150 / 100) < 1e-9, 'internal ratio must stay mathematically invariant under recipe scaling');
assert.equal(locked, undefined, 'locked ingredient must never be modified by continuous projection');
assert.equal(toTaste, undefined, 'to_taste ingredient must never be modified or zeroed');
assert.equal(missing, undefined, 'missing ingredient must never be modified or zeroed');

// 4. Scale bounds intersect all scalable ingredients in rec-a: [max(60/150, 40/100), min(350/150, 250/100)] = [0.4, 2.3333]
assert.ok(Math.abs(model.vars[0].minScale - 0.4) < 1e-6);
assert.ok(Math.abs(model.vars[0].maxScale - 350 / 150) < 1e-6);
assert.equal(model.vars[0].boundsFeasible, true);

// 5. WorkingBaseline vs TemplateBaseline differences when currentQuantityG diverged
const divergedDay = structuredClone(dayPlan);
divergedDay.slots[0].recipes[0].ingredients[0].currentQuantityG = 200; // diverged from baseQuantityG = 150
const mWorking = buildRecipeScaleModel(divergedDay, { kcal: 2000, proteinG: 120, carbsG: 220, fatG: 65 }, { baselineSource: 'workingBaseline' });
const mTemplate = buildRecipeScaleModel(divergedDay, { kcal: 2000, proteinG: 120, carbsG: 220, fatG: 65 }, { baselineSource: 'templateBaseline' });
assert.notEqual(mWorking.vars[0].kcalPerUnitScale, mTemplate.vars[0].kcalPerUnitScale);

console.log('recipe-scale-model.test.mjs: PASS');
