import assert from 'node:assert/strict';
import path from 'node:path';
import { ensureTbcaCatalogLoaded } from '../../../data/sources/tbca-adapter.ts';
import { computeDayNutrition, evaluateMealAllocations } from '../cardapio-composer-engine.ts';
import { solveMacroTargetFitQP } from '../macro-target-fit.ts';
import { buildRecipeScaleModel } from '../recipe-scale-model.ts';
import { buildHighsRecipeScaleQPModelLP } from '../../../application/highs-lp-builder.ts';
import { solveMacroTargetFitWithHighsQP } from '../../../application/highs-nutrition-solver.ts';

await ensureTbcaCatalogLoaded();

const WASM_PATH = path.resolve(process.cwd(), 'public/wasm/highs.wasm');

const twoRecipeDayPlan = {
  dateKey: '2026-11-26',
  slots: [
    {
      id: 'slot-almoco',
      time: '12:30',
      title: 'Almoço',
      recipes: [
        {
          id: 'rec-prot',
          name: 'Ovos e Frango',
          category: 'almoco',
          baseServings: 1,
          targetServings: 1,
          adjustmentMode: 'balanced',
          ingredients: [
            {
              id: 'p-frango',
              foodId: 'tbca:BRC0055B',
              displayName: 'Frango',
              baseQuantityG: 120,
              currentQuantityG: 120,
              quantityStatus: 'known',
              mode: 'flexible',
              minQuantityG: 50,
              maxQuantityG: 320,
            },
            {
              id: 'p-ovo',
              foodId: 'tbca-ovo-mexido',
              displayName: 'Ovo mexido',
              baseQuantityG: 80,
              currentQuantityG: 80,
              quantityStatus: 'known',
              mode: 'flexible',
              minQuantityG: 30,
              maxQuantityG: 220,
            },
            {
              id: 'p-locked',
              foodId: 'tbca-banana-prata',
              displayName: 'Acompanhamento fixo',
              baseQuantityG: 40,
              currentQuantityG: 40,
              quantityStatus: 'known',
              mode: 'locked',
              minQuantityG: 40,
              maxQuantityG: 40,
            },
          ],
        },
        {
          id: 'rec-carb-fat',
          name: 'Banana com Abacate',
          category: 'almoco',
          baseServings: 1,
          targetServings: 1,
          adjustmentMode: 'balanced',
          ingredients: [
            {
              id: 'cf-banana',
              foodId: 'tbca-banana-prata',
              displayName: 'Banana prata',
              baseQuantityG: 100,
              currentQuantityG: 100,
              quantityStatus: 'known',
              mode: 'flexible',
              minQuantityG: 40,
              maxQuantityG: 300,
            },
            {
              id: 'cf-abacate',
              foodId: 'tbca:BRC0001C',
              displayName: 'Abacate',
              baseQuantityG: 60,
              currentQuantityG: 60,
              quantityStatus: 'known',
              mode: 'flexible',
              minQuantityG: 20,
              maxQuantityG: 200,
            },
          ],
        },
      ],
    },
  ],
};

// Known target achievable near rec-prot x 1.45, rec-carb-fat x 0.75
const scaledRefPlan = structuredClone(twoRecipeDayPlan);
scaledRefPlan.slots[0].recipes[0].ingredients[0].currentQuantityG = 174;
scaledRefPlan.slots[0].recipes[0].ingredients[1].currentQuantityG = 116;
scaledRefPlan.slots[0].recipes[1].ingredients[0].currentQuantityG = 75;
scaledRefPlan.slots[0].recipes[1].ingredients[1].currentQuantityG = 45;
const referenceSummary = computeDayNutrition(scaledRefPlan);
const achievableTargets = {
  kcal: Math.round(referenceSummary.macros.kcal),
  proteinG: Math.round(referenceSummary.macros.proteinG),
  carbsG: Math.round(referenceSummary.macros.carbsG),
  fatG: Math.round(referenceSummary.macros.fatG),
};

// 1. Default preserve_recipe_ratios mode fits both recipes independently within same slot & preserves internal ratios
const defaultFit = solveMacroTargetFitQP(twoRecipeDayPlan, achievableTargets);
assert.equal(defaultFit.proposal.scaleMode, 'preserve_recipe_ratios');
assert.equal(defaultFit.status, 'target_met');

const r0After = defaultFit.proposal.proposedDayPlan.slots[0].recipes[0].ingredients;
const r1After = defaultFit.proposal.proposedDayPlan.slots[0].recipes[1].ingredients;
assert.equal(r0After[2].currentQuantityG, 40, 'locked ingredient must stay untouched');

const ratio0Before = 120 / 80;
const ratio0After = r0After[0].currentQuantityG / r0After[1].currentQuantityG;
assert.ok(Math.abs(ratio0After - ratio0Before) < 0.05, `rec-prot ratio distorted: ${ratio0After} vs ${ratio0Before}`);

const ratio1Before = 100 / 60;
const ratio1After = r1After[0].currentQuantityG / r1After[1].currentQuantityG;
assert.ok(Math.abs(ratio1After - ratio1Before) < 0.05, `rec-carb-fat ratio distorted: ${ratio1After} vs ${ratio1Before}`);

assert.ok(defaultFit.recipeScales[0].scalePercent > 125, 'high-protein recipe should scale up');
assert.ok(defaultFit.recipeScales[1].scalePercent < 95, 'carb/fat recipe should scale down');

// 2. Single recipe with 4 conflicting targets cannot distort ratio and must never falsely report target_met
const singleRecipePlan = {
  dateKey: '2026-11-26',
  slots: [
    {
      id: 'slot-1',
      time: '08:00',
      title: 'Café',
      recipes: [structuredClone(twoRecipeDayPlan.slots[0].recipes[0])],
    },
  ],
};
const impossibleConflictingTargets = {
  kcal: 700,
  proteinG: 80,
  carbsG: 90, // chicken/egg/40g banana cannot reach 90g carbs proportionally
  fatG: 5,
};
const conflictFit = solveMacroTargetFitQP(singleRecipePlan, impossibleConflictingTargets);
const singleAfter = conflictFit.proposal.proposedDayPlan.slots[0].recipes[0].ingredients;
assert.ok(
  Math.abs(singleAfter[0].currentQuantityG / singleAfter[1].currentQuantityG - ratio0Before) < 0.05,
  'single recipe must preserve ratio under conflicting targets',
);
assert.equal(conflictFit.status, 'approximate_feasible');

// 3. Explicit opt-in ingredient_flexible diverges ingredient ratios freely
const flexFit = solveMacroTargetFitQP(
  twoRecipeDayPlan,
  { kcal: 620, proteinG: 62, carbsG: 35, fatG: 18 },
  { scaleMode: 'ingredient_flexible' },
);
assert.equal(flexFit.proposal.scaleMode, 'ingredient_flexible');
const flexR0 = flexFit.proposal.proposedDayPlan.slots[0].recipes[0].ingredients;
assert.ok(
  Math.abs(flexR0[0].currentQuantityG / flexR0[1].currentQuantityG - ratio0Before) > 0.15,
  'ingredient_flexible opt-in should independently increase chicken vs egg for high protein/low fat',
);

// 4. Meal allocations independent P/C/G + kcal and unallocatedPercent
const multiSlotPlan = {
  dateKey: '2026-11-26',
  slots: [
    { id: 'slot-1', time: '08:00', title: 'Café', recipes: [structuredClone(twoRecipeDayPlan.slots[0].recipes[1])] },
    { id: 'slot-2', time: '12:30', title: 'Almoço', recipes: [structuredClone(twoRecipeDayPlan.slots[0].recipes[0])] },
  ],
};
const balancedAlloc = evaluateMealAllocations(multiSlotPlan, achievableTargets, [
  { slotId: 'slot-1', energySharePercent: 30, proteinSharePercent: 15, carbsSharePercent: 55, fatSharePercent: 35 },
  { slotId: 'slot-2', energySharePercent: 70, proteinSharePercent: 85, carbsSharePercent: 45, fatSharePercent: 65 },
]);
assert.equal(balancedAlloc.isBalanced, true);
assert.equal(balancedAlloc.unallocatedPercent, 0);
assert.equal(balancedAlloc.totalProteinSharePercent, 100);

const unbalancedAlloc = evaluateMealAllocations(multiSlotPlan, achievableTargets, [
  { slotId: 'slot-1', energySharePercent: 40 },
  { slotId: 'slot-2', energySharePercent: 45 },
]);
assert.equal(unbalancedAlloc.isBalanced, false);
assert.equal(unbalancedAlloc.unallocatedPercent, 15);

// 5. Real HiGHS WASM solver matches deterministic TS QP on default preserve_recipe_ratios
const highsFit = await solveMacroTargetFitWithHighsQP(twoRecipeDayPlan, achievableTargets, {}, WASM_PATH);
assert.equal(highsFit.status, 'target_met');
assert.ok(highsFit.proposal.solverEngine?.includes('HiGHS'), `expected HiGHS engine, got ${highsFit.proposal.solverEngine}`);
const hR0 = highsFit.proposal.proposedDayPlan.slots[0].recipes[0].ingredients;
const hR1 = highsFit.proposal.proposedDayPlan.slots[0].recipes[1].ingredients;
assert.ok(Math.abs(hR0[0].currentQuantityG - r0After[0].currentQuantityG) <= 2.5);
assert.ok(Math.abs(hR1[0].currentQuantityG - r1After[0].currentQuantityG) <= 2.5);

// 6. LP builder never emits undeclared x0 variable in s0..s{m-1} model when micro UL has zero scalable coefficients
const zeroCoeffModel = buildRecipeScaleModel(twoRecipeDayPlan, achievableTargets);
zeroCoeffModel.micronutrientConstraints.push({
  nutrientId: 'iron',
  unit: 'mg',
  minimum: null,
  minimumKind: null,
  preferredMaximum: null,
  upperLimit: 45,
  fixedValue: 5,
  coefficients: [0, 0],
  status: 'applied',
});
const { lpText } = buildHighsRecipeScaleQPModelLP(zeroCoeffModel, achievableTargets, true);
assert.equal(/\bx0\b/.test(lpText), false, 'recipe-scale LP must never emit undeclared x0 variable');

console.log('macro-target-fit.test.mjs: PASS');
