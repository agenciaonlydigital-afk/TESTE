import assert from 'node:assert/strict';
import { FOOD_PREPARATION_RETENTION_V1, derivePreparedFoodComposition } from '../food-preparation-transform.ts';
import { calculateDietaryDIAAS, FAO_2013_DIAAS_REFERENCE_PATTERNS } from '../protein-quality.ts';
import { resolveMicronutrientResidualScales } from '../micronutrient-optimization-scales.ts';

const scales = resolveMicronutrientResidualScales({
  minimum: 30,
  preferredMaximum: 120,
  upperLimit: 300,
});
assert.deepEqual(scales, { minimum: 30, preferredMaximum: 120 }, 'soft lower and preferred upper residuals need their own normalization; a hard UL must not change either weight');
assert.deepEqual(resolveMicronutrientResidualScales({ minimum: null, preferredMaximum: 0.5, upperLimit: 5 }), {
  minimum: 1,
  preferredMaximum: 1,
});

const aminoAcids = {
  histidine: 18,
  isoleucine: 42,
  leucine: 75,
  lysine: 65,
  methionine: 25,
  cysteine: 10,
  phenylalanine: 40,
  tyrosine: 30,
  threonine: 32,
  tryptophan: 9,
  valine: 48,
};
const digestibility = Object.fromEntries(Object.keys(aminoAcids).map((aminoAcid) => [aminoAcid, {
  fraction: 0.9,
  species: 'pig',
  method: 'true_ileal',
  reference: 'synthetic validation evidence',
  sourceName: 'synthetic ileal digestibility study',
  sourceVersion: 'study-v1',
  referenceUrl: 'https://example.invalid/digestibility',
  foodId: 'test-protein',
  testedState: 'cozido',
}]));
const source = {
  foodId: 'test-protein',
  foodState: 'cozido',
  proteinGrams: 20,
  aminoAcidsMgPerGProtein: aminoAcids,
  aminoAcidEvidence: { foodId: 'test-protein', foodState: 'cozido', sourceName: 'synthetic amino acid assay', sourceVersion: 'assay-v1', reference: 'synthetic amino acid composition reference', referenceUrl: 'https://example.invalid/amino-acids', basis: 'mg_per_g_protein' },
  ilealDigestibility: digestibility,
  lysineDamageRisk: 'not_suspected',
  lysineBasis: 'total',
};
const diaas = calculateDietaryDIAAS({ proteinSources: [source], referencePattern: 'older_children_adults' });
assert.equal(diaas.status, 'calculated');
assert.ok(diaas.diaas !== null && diaas.diaas > 0);
assert.equal(diaas.limitingAminoAcid, 'histidine');
assert.equal(diaas.referencePattern, 'FAO_2013_OLDER_CHILDREN_ADULTS');
assert.equal(FAO_2013_DIAAS_REFERENCE_PATTERNS.older_children_adults.tryptophan, 6.6);
const mixedDietDiaas = calculateDietaryDIAAS({
  proteinSources: [source, { ...source, foodId: 'second-source', proteinGrams: 10, aminoAcidEvidence: { ...source.aminoAcidEvidence, foodId: 'second-source' }, ilealDigestibility: Object.fromEntries(Object.keys(aminoAcids).map((aa) => [aa, { ...digestibility[aa], foodId: 'second-source' }])) }],
  referencePattern: 'older_children_adults',
});
assert.equal(mixedDietDiaas.status, 'calculated');
assert.equal(mixedDietDiaas.untruncatedDiaas, 101.25);
assert.equal(mixedDietDiaas.diaas, 100, 'FAO mixed-diet DIAAS must be truncated at 100%, while single-food values remain untruncated');
assert.equal(mixedDietDiaas.isMixedDiet, true);

const mismatchedState = calculateDietaryDIAAS({
  proteinSources: [{ ...source, ilealDigestibility: Object.fromEntries(Object.keys(aminoAcids).map((aa) => [aa, { ...digestibility[aa], testedState: 'cru' }])) }],
  referencePattern: 'older_children_adults',
});
assert.equal(mismatchedState.status, 'insufficient_evidence');
assert.equal(mismatchedState.diaas, null, 'digestibility from a different food-preparation state must not produce a score');

const lysineRisk = calculateDietaryDIAAS({
  proteinSources: [{ ...source, lysineDamageRisk: 'suspected', lysineBasis: 'total' }],
  referencePattern: 'older_children_adults',
});
assert.equal(lysineRisk.status, 'insufficient_evidence', 'heat-damaged food requires reactive lysine evidence');

const mixedSpecies = calculateDietaryDIAAS({
  proteinSources: [source, { ...source, foodId: 'second-food', proteinGrams: 10, aminoAcidEvidence: { ...source.aminoAcidEvidence, foodId: 'second-food' }, ilealDigestibility: Object.fromEntries(Object.keys(aminoAcids).map((aa) => [aa, { ...digestibility[aa], foodId: 'second-food', species: 'human', reference: 'second source evidence' }])) }],
  referencePattern: 'older_children_adults',
});
assert.equal(mixedSpecies.status, 'insufficient_evidence', 'mixed digestibility species must not be silently harmonized');
const ratDigestibility = calculateDietaryDIAAS({
  proteinSources: [{ ...source, ilealDigestibility: Object.fromEntries(Object.keys(aminoAcids).map((aa) => [aa, { ...digestibility[aa], species: 'rat' }])) }],
  referencePattern: 'older_children_adults',
});
assert.equal(ratDigestibility.status, 'insufficient_evidence', 'rat digestibility is not accepted as a human/pig DIAAS evidence basis');
const mismatchedAminoAcidEvidence = calculateDietaryDIAAS({
  proteinSources: [{ ...source, aminoAcidEvidence: { ...source.aminoAcidEvidence, foodId: 'different-food' } }],
  referencePattern: 'older_children_adults',
});
assert.equal(mismatchedAminoAcidEvidence.status, 'insufficient_evidence', 'amino-acid composition evidence must identify the exact food and state');
const mismatchedDigestibilityEvidence = calculateDietaryDIAAS({
  proteinSources: [{ ...source, ilealDigestibility: Object.fromEntries(Object.keys(aminoAcids).map((aa) => [aa, { ...digestibility[aa], foodId: 'different-food' }])) }],
  referencePattern: 'older_children_adults',
});
assert.equal(mismatchedDigestibilityEvidence.status, 'insufficient_evidence', 'ileal digestibility evidence must identify the exact food');

const rawFood = {
  food_id: 'raw-chicken',
  name: 'Frango cru',
  source_id: 'TBCA',
  source_record_id: 'TBCA-RAW-1',
  source_version: 'TBCA-7.2',
  quality_status: 'reference_database',
  state: 'cru',
  macros: { kcalPerBasis: 120, proteinGPerBasis: 23, carbsGPerBasis: 0, fatGPerBasis: 3, basisQuantityG: 100, fiberGPerBasis: 0, sodiumMgPerBasis: 60 },
  micronutrients: {
    iron: { original_value: 1, original_unit: 'mg', normalized_value: 1, normalized_unit: 'mg', basis_quantity: 100, data_status: 'quantified', quality_status: 'reference_database', conversion_method: 'direct' },
    vitamin_c: { original_value: null, original_unit: 'mg', normalized_value: null, normalized_unit: 'mg', basis_quantity: 100, data_status: 'not_analyzed', quality_status: 'reference_database', conversion_method: 'unavailable' },
  },
};
const transform = {
  id: 'chicken-boiled-v1',
  sourceFoodId: 'raw-chicken',
  sourceState: 'cru',
  preparedFoodId: 'chicken-boiled',
  preparedFoodName: 'Frango cozido',
  preparedState: 'cozido',
  preparation: 'cozido em água, drenado',
  weightYieldFactor: 0.72,
  macroRetentionFactors: { kcal: 1, proteinG: 0.98, carbsG: 1, fatG: 0.9, fiberG: 1 },
  micronutrientRetentionFactors: { iron: 0.8 },
  macroRetentionEvidence: {
    sourceName: 'synthetic matched macro-retention measurement',
    sourceFoodId: 'raw-chicken',
    sourceState: 'cru',
    preparedState: 'cozido',
    preparation: 'cozido em água, drenado',
    sourceVersion: 'synthetic-fixture-v1',
    referenceUrl: 'https://example.invalid/macro-retention',
    retentionCode: 'TEST-MACRO-RETENTION',
    retentionMethod: 'true_retention',
  },
  micronutrientRetentionEvidence: {
    iron: {
      sourceName: 'synthetic matched micronutrient-retention measurement',
      sourceFoodId: 'raw-chicken',
      sourceState: 'cru',
      preparedState: 'cozido',
      preparation: 'cozido em água, drenado',
      sourceVersion: 'synthetic-fixture-v1',
      referenceUrl: 'https://example.invalid/iron-retention',
      retentionCode: 'TEST-IRON-RETENTION',
      retentionMethod: 'true_retention',
    },
  },
  provenance: {
    sourceName: 'synthetic transformation manifest and measured yield record',
    sourceVersion: 'synthetic-fixture-v1',
    referenceUrl: 'https://example.invalid/transformation-map',
    retentionCode: 'TEST-EXPLICIT-MAPPING',
    yieldReference: 'test-only yield',
    retentionMethod: 'true_retention',
  },
};
const prepared = derivePreparedFoodComposition(rawFood, 200, transform);
assert.equal(prepared.status, 'derived');
assert.equal(prepared.preparedWeightG, 144);
assert.equal(prepared.food.macros.basisQuantityG, 100);
assert.ok(Math.abs(prepared.food.macros.proteinGPerBasis - (200 * 23 / 100 * 0.98 * 100 / 144)) < 1e-9);
assert.equal(prepared.food.macros.sodiumMgPerBasis, null, 'optional macro-like fields need explicit retention too');
assert.ok(Math.abs(prepared.food.micronutrients.iron.normalized_value - (200 * 1 / 100 * 0.8 * 100 / 144)) < 1e-9);
assert.equal(prepared.food.micronutrients.vitamin_c.data_status, 'not_analyzed');
assert.equal(prepared.food.preparation_conversion.provenance.sourceVersion, 'synthetic-fixture-v1');
assert.equal(prepared.food.preparation_conversion.macroRetentionEvidence.sourceName, 'synthetic matched macro-retention measurement');
assert.equal(prepared.food.preparation_conversion.micronutrientRetentionEvidence.iron.sourceVersion, 'synthetic-fixture-v1');
const mismatchedMicronutrientEvidence = derivePreparedFoodComposition(rawFood, 200, {
  ...transform,
  micronutrientRetentionEvidence: {
    iron: { ...transform.micronutrientRetentionEvidence.iron, sourceFoodId: 'different-food' },
  },
});
assert.equal(mismatchedMicronutrientEvidence.food.micronutrients.iron.data_status, 'not_analyzed',
  'micronutrient retention must be tied to the exact original food and preparation state');
assert.equal(mismatchedMicronutrientEvidence.food.micronutrients.iron.normalized_value, null);
const mismatchedMacroEvidence = derivePreparedFoodComposition(rawFood, 200, {
  ...transform,
  macroRetentionEvidence: { ...transform.macroRetentionEvidence, preparation: 'grelhado' },
});
assert.equal(mismatchedMacroEvidence.status, 'invalid_input', 'macro retention evidence must match the exact preparation method');
const wrongFoodMapping = derivePreparedFoodComposition({ ...rawFood, food_id: 'another-food' }, 200, transform);
assert.equal(wrongFoodMapping.status, 'invalid_input', 'retention maps must bind to exact source food ID and state');
const excessivePreparedMacroMass = derivePreparedFoodComposition(rawFood, 200, {
  ...transform,
  weightYieldFactor: 0.1,
});
assert.equal(excessivePreparedMacroMass.status, 'invalid_input', 'derived macro mass above 105 g per 100 g must be rejected before catalog use');
const invalidRawComposition = derivePreparedFoodComposition({
  ...rawFood,
  macros: { ...rawFood.macros, proteinGPerBasis: -1 },
}, 200, transform);
assert.equal(invalidRawComposition.status, 'invalid_input', 'raw source macro data must pass the same sanity gate before preparation transforms');
assert.equal(derivePreparedFoodComposition(null, 200, transform).status, 'invalid_input', 'untrusted runtime callers must receive a controlled error result');

const withoutYieldEvidence = derivePreparedFoodComposition(rawFood, 200, { ...transform, weightYieldFactor: 0 });
assert.equal(withoutYieldEvidence.status, 'invalid_input');
assert.equal(withoutYieldEvidence.food, null);
const percentageYieldMistake = derivePreparedFoodComposition(rawFood, 200, { ...transform, weightYieldFactor: 72 });
assert.equal(percentageYieldMistake.status, 'invalid_input', 'yield must be a ratio, not a percentage');
const missingMacroRetention = derivePreparedFoodComposition(rawFood, 200, {
  ...transform,
  macroRetentionFactors: { kcal: 1, proteinG: 1, carbsG: 1 },
});
assert.equal(missingMacroRetention.status, 'invalid_input', 'no macro retention factor may be fabricated');
const missingMacroEvidence = derivePreparedFoodComposition(rawFood, 200, {
  ...transform,
  macroRetentionEvidence: undefined,
});
assert.equal(missingMacroEvidence.status, 'invalid_input', 'macro retention factors need independent source evidence; the USDA micronutrient table cannot be cited for them');
const noNutrientRetention = derivePreparedFoodComposition(rawFood, 200, {
  ...transform,
  micronutrientRetentionFactors: {},
});
assert.equal(noNutrientRetention.food.micronutrients.iron.data_status, 'not_analyzed');
assert.equal(noNutrientRetention.food.micronutrients.iron.normalized_value, null);
const missingMicronutrientEvidence = derivePreparedFoodComposition(rawFood, 200, {
  ...transform,
  micronutrientRetentionEvidence: {},
});
assert.equal(missingMicronutrientEvidence.food.micronutrients.iron.data_status, 'not_analyzed', 'a numeric retention factor without source evidence must not be applied');
const invalidRetentionFactor = derivePreparedFoodComposition(rawFood, 200, {
  ...transform,
  micronutrientRetentionFactors: { iron: -0.1 },
});
assert.equal(invalidRetentionFactor.status, 'invalid_input', 'negative nutrient retention is invalid, not a missing measurement');
const percentInsteadOfFraction = derivePreparedFoodComposition(rawFood, 200, {
  ...transform,
  micronutrientRetentionFactors: { iron: 80 },
});
assert.equal(percentInsteadOfFraction.status, 'invalid_input', 'USDA percentage values must be explicitly normalized to a fraction before applying them');
const invalidTrueRetentionOver100 = derivePreparedFoodComposition(rawFood, 200, {
  ...transform,
  micronutrientRetentionFactors: { iron: 1.05 },
});
assert.equal(invalidTrueRetentionOver100.status, 'invalid_input', 'USDA true-retention factors cannot exceed 100 percent for the mapped method');
const invalidSourceMicronutrient = derivePreparedFoodComposition({
  ...rawFood,
  micronutrients: { ...rawFood.micronutrients, iron: { ...rawFood.micronutrients.iron, normalized_value: -1 } },
}, 200, transform);
assert.equal(invalidSourceMicronutrient.food.micronutrients.iron.data_status, 'invalid_value');

assert.equal(FOOD_PREPARATION_RETENTION_V1, 'explicit-food-method-retention-v1');
console.log('protein quality and preparation transformation tests passed');
