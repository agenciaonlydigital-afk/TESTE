import { getLocalDateKey, isValidLocalDateKey } from '../../../../shared/utils/local-date.ts';
import type {
  CardapioPlan,
  ComposerDayPlan,
  MealItem,
  TemporalDateBand,
  TemporalDatePolicy,
} from '../entities/nutrient.ts';

export type TemporalMutationAction =
  | 'plan_edit'
  | 'replan_auto'
  | 'multi_day_generate'
  | 'consume_log';

export interface TemporalMutationCheck {
  allowed: boolean;
  band: TemporalDateBand;
  requiresConfirmation: boolean;
  reason?: string;
}

export function classifyDateTemporalBand(
  dateKey: string,
  referenceTodayKey: string = getLocalDateKey(),
): TemporalDateBand {
  if (!isValidLocalDateKey(dateKey) || !isValidLocalDateKey(referenceTodayKey)) {
    return 'today';
  }
  if (dateKey < referenceTodayKey) return 'past';
  if (dateKey > referenceTodayKey) return 'future';
  return 'today';
}

export function evaluateTemporalDatePolicy(
  dateKey: string,
  referenceTodayKey: string = getLocalDateKey(),
): TemporalDatePolicy {
  const band = classifyDateTemporalBand(dateKey, referenceTodayKey);
  if (band === 'past') {
    return {
      dateKey,
      referenceTodayKey,
      band,
      canMutatePlanDirectly: false,
      requiresExplicitConfirmationForToday: false,
      isFrozenHistory: true,
      bannerTitle: 'Histórico congelado',
      bannerDetail:
        'Datas anteriores preservam o snapshot registrado; replanejamentos automáticos não alteram dias passados.',
    };
  }
  if (band === 'today') {
    return {
      dateKey,
      referenceTodayKey,
      band,
      canMutatePlanDirectly: false,
      requiresExplicitConfirmationForToday: true,
      isFrozenHistory: false,
      bannerTitle: 'Dia corrente · confirmação explícita',
      bannerDetail:
        'Mudanças no cardápio de hoje geram prévia reversível e requerem confirmação explícita.',
    };
  }
  return {
    dateKey,
    referenceTodayKey,
    band,
    canMutatePlanDirectly: true,
    requiresExplicitConfirmationForToday: false,
    isFrozenHistory: false,
    bannerTitle: 'Horizonte futuro replanejável',
    bannerDetail:
      'Cardápio futuro liberado para ajustes contínuos, trocas de receitas e otimização automática.',
  };
}

export function checkTemporalPlanMutation(
  dateKey: string,
  action: TemporalMutationAction,
  options: {
    referenceTodayKey?: string;
    confirmedToday?: boolean;
  } = {},
): TemporalMutationCheck {
  const policy = evaluateTemporalDatePolicy(dateKey, options.referenceTodayKey);

  if (policy.band === 'past') {
    if (action === 'consume_log') {
      return {
        allowed: false,
        band: 'past',
        requiresConfirmation: false,
        reason: 'O diário de dias passados é histórico congelado e não deve ser reescrito automaticamente.',
      };
    }
    return {
      allowed: false,
      band: 'past',
      requiresConfirmation: false,
      reason: 'Dias passados são imutáveis para preservar o balanço histórico e TDEE adaptativo.',
    };
  }

  if (policy.band === 'today') {
    if (action === 'consume_log') {
      return { allowed: true, band: 'today', requiresConfirmation: false };
    }
    if ((action === 'replan_auto' || action === 'multi_day_generate') && !options.confirmedToday) {
      return {
        allowed: false,
        band: 'today',
        requiresConfirmation: true,
        reason: 'Replanejar o dia corrente exige prévia e confirmação explícita do usuário.',
      };
    }
    return { allowed: true, band: 'today', requiresConfirmation: true };
  }

  return { allowed: true, band: 'future', requiresConfirmation: false };
}

/** Creates an immutable deep snapshot of a meal record for historical diary audit. */
export function createImmutableMealSnapshot(meal: MealItem): Readonly<MealItem> {
  return Object.freeze({
    ...meal,
    planned_foods: Object.freeze(meal.planned_foods.map((p) => Object.freeze({ ...p }))) as MealItem['planned_foods'],
    consumed_foods: Object.freeze(meal.consumed_foods.map((p) => Object.freeze({ ...p }))) as MealItem['consumed_foods'],
  });
}

/** Collects date keys inside a plan that are safe to replan without touching frozen past days. */
export function partitionPlanDatesByTemporalBand(
  plan: CardapioPlan,
  referenceTodayKey: string = getLocalDateKey(),
): {
  past: string[];
  today: string[];
  future: string[];
} {
  const dates = Object.keys(plan.days).sort();
  const past: string[] = [];
  const today: string[] = [];
  const future: string[] = [];
  for (const dateKey of dates) {
    const band = classifyDateTemporalBand(dateKey, referenceTodayKey);
    if (band === 'past') past.push(dateKey);
    else if (band === 'today') today.push(dateKey);
    else future.push(dateKey);
  }
  return { past, today, future };
}

export function cloneFrozenDayPlan(day: ComposerDayPlan): ComposerDayPlan {
  return {
    dateKey: day.dateKey,
    slots: day.slots.map((slot) => ({
      ...slot,
      recipes: slot.recipes.map((recipe) => ({
        ...recipe,
        ingredients: recipe.ingredients.map((ing) => ({ ...ing })),
      })),
    })),
  };
}
