export const FAO_2013_DIAAS_REFERENCE_PATTERNS = {
  young_children_6m_3y: {
    id: 'FAO_2013_YOUNG_CHILDREN_6M_3Y',
    ageGroup: '6 months to 3 years',
    histidine: 20,
    isoleucine: 32,
    leucine: 66,
    lysine: 57,
    sulfur_amino_acids: 27,
    aromatic_amino_acids: 52,
    threonine: 31,
    tryptophan: 8.5,
    valine: 43,
  },
  older_children_adults: {
    id: 'FAO_2013_OLDER_CHILDREN_ADULTS',
    ageGroup: 'older children, adolescents and adults',
    histidine: 16,
    isoleucine: 30,
    leucine: 61,
    lysine: 48,
    sulfur_amino_acids: 23,
    aromatic_amino_acids: 41,
    threonine: 25,
    tryptophan: 6.6,
    valine: 40,
  },
} as const;

export type DIAASReferencePatternId = keyof typeof FAO_2013_DIAAS_REFERENCE_PATTERNS;
export type IndispensableAminoAcid =
  | 'histidine'
  | 'isoleucine'
  | 'leucine'
  | 'lysine'
  | 'methionine'
  | 'cysteine'
  | 'phenylalanine'
  | 'tyrosine'
  | 'threonine'
  | 'tryptophan'
  | 'valine';

export interface AminoAcidCompositionEvidence {
  foodId: string;
  foodState: string;
  sourceName: string;
  sourceVersion: string;
  reference: string;
  referenceUrl: string;
  basis: 'mg_per_g_protein';
}

export interface IlealDigestibilityEvidence {
  foodId: string;
  fraction: number;
  species: 'human' | 'pig';
  method: 'true_ileal' | 'standardized_ileal';
  reference: string;
  sourceName: string;
  sourceVersion: string;
  referenceUrl: string;
  testedState: string;
}

export interface ProteinQualitySourceEvidence {
  foodId: string;
  foodState: string;
  proteinGrams: number;
  aminoAcidsMgPerGProtein: Record<IndispensableAminoAcid, number>;
  aminoAcidEvidence: AminoAcidCompositionEvidence;
  ilealDigestibility: Record<IndispensableAminoAcid, IlealDigestibilityEvidence>;
  lysineDamageRisk: 'not_suspected' | 'suspected' | 'unknown';
  lysineBasis: 'reactive' | 'total';
}

export interface DietaryDIAASRequest {
  proteinSources: readonly ProteinQualitySourceEvidence[];
  referencePattern: DIAASReferencePatternId;
}

export interface DietaryDIAASResult {
  status: 'calculated' | 'insufficient_evidence' | 'invalid_input';
  referencePattern: string;
  diaas: number | null;
  untruncatedDiaas: number | null;
  isMixedDiet: boolean;
  limitingAminoAcid: string | null;
  aminoAcidScores: Record<string, number>;
  evidenceSpecies: string[];
  evidenceReferences: string[];
  reasons: string[];
}

const AMINO_ACID_GROUPS = {
  histidine: ['histidine'],
  isoleucine: ['isoleucine'],
  leucine: ['leucine'],
  lysine: ['lysine'],
  sulfur_amino_acids: ['methionine', 'cysteine'],
  aromatic_amino_acids: ['phenylalanine', 'tyrosine'],
  threonine: ['threonine'],
  tryptophan: ['tryptophan'],
  valine: ['valine'],
} as const satisfies Record<keyof (typeof FAO_2013_DIAAS_REFERENCE_PATTERNS)['older_children_adults'] extends never ? never : Exclude<keyof (typeof FAO_2013_DIAAS_REFERENCE_PATTERNS)['older_children_adults'], 'id' | 'ageGroup'>, readonly IndispensableAminoAcid[]>;

const AMINO_ACIDS = Object.keys({
  histidine: 1,
  isoleucine: 1,
  leucine: 1,
  lysine: 1,
  methionine: 1,
  cysteine: 1,
  phenylalanine: 1,
  tyrosine: 1,
  threonine: 1,
  tryptophan: 1,
  valine: 1,
}) as IndispensableAminoAcid[];

function emptyResult(
  status: DietaryDIAASResult['status'],
  pattern: DIAASReferencePatternId | undefined,
  reasons: string[],
): DietaryDIAASResult {
  return {
    status,
    referencePattern: pattern ? FAO_2013_DIAAS_REFERENCE_PATTERNS[pattern]?.id ?? 'UNKNOWN_REFERENCE_PATTERN' : 'UNKNOWN_REFERENCE_PATTERN',
    diaas: null,
    untruncatedDiaas: null,
    isMixedDiet: false,
    limitingAminoAcid: null,
    aminoAcidScores: {},
    evidenceSpecies: [],
    evidenceReferences: [],
    reasons,
  };
}

/**
 * Calculates a source-backed DIAAS-style score from amino-acid-specific ileal evidence.
 * The function never estimates amino-acid profiles or digestibility from total protein.
 */
export function calculateDietaryDIAAS(request: DietaryDIAASRequest): DietaryDIAASResult {
  const patternId = request?.referencePattern;
  const pattern = patternId ? FAO_2013_DIAAS_REFERENCE_PATTERNS[patternId] : undefined;
  if (!Array.isArray(request?.proteinSources) || request.proteinSources.length === 0 || !pattern) {
    return emptyResult('invalid_input', patternId, ['Informe ao menos uma fonte proteica e um padrão FAO válido.']);
  }

  const reasons: string[] = [];
  let totalProteinG = 0;
  const digestibleAminoAcidsMg = new Map<string, number>();
  const species = new Set<string>();
  const references = new Set<string>();

  for (const source of request.proteinSources) {
    if (!source || typeof source.foodId !== 'string' || !source.foodId.trim() ||
        typeof source.foodState !== 'string' || !source.foodState.trim() ||
        !Number.isFinite(source.proteinGrams) || source.proteinGrams <= 0 ||
        !source.aminoAcidsMgPerGProtein || !source.ilealDigestibility) {
      const sourceId = source && typeof source.foodId === 'string' && source.foodId.trim() ? source.foodId : '(sem ID)';
      return emptyResult('invalid_input', request.referencePattern, [`Fonte ${sourceId} possui identidade, estado, quantidade de proteína ou evidência inválidos.`]);
    }
    const aminoAcidEvidence = source.aminoAcidEvidence;
    if (!aminoAcidEvidence || aminoAcidEvidence.foodId !== source.foodId ||
        aminoAcidEvidence.foodState !== source.foodState ||
        aminoAcidEvidence.basis !== 'mg_per_g_protein' ||
        typeof aminoAcidEvidence.sourceName !== 'string' || !aminoAcidEvidence.sourceName.trim() ||
        typeof aminoAcidEvidence.sourceVersion !== 'string' || !aminoAcidEvidence.sourceVersion.trim() ||
        typeof aminoAcidEvidence.reference !== 'string' || !aminoAcidEvidence.reference.trim() ||
        typeof aminoAcidEvidence.referenceUrl !== 'string' || !/^https?:\/\//i.test(aminoAcidEvidence.referenceUrl)) {
      reasons.push(`${source.foodId}: composição de aminoácidos sem evidência vinculada ao alimento, estado e base mg/g de proteína.`);
    } else {
      references.add(aminoAcidEvidence.reference);
    }
    if (source.lysineDamageRisk !== 'not_suspected' && source.lysineBasis !== 'reactive') {
      reasons.push(`${source.foodId}: risco de dano térmico à lisina exige teor de lisina reativa, não apenas lisina total.`);
    }
    for (const aminoAcid of AMINO_ACIDS) {
      const amount = source.aminoAcidsMgPerGProtein[aminoAcid];
      const evidence = source.ilealDigestibility[aminoAcid];
      if (!Number.isFinite(amount) || amount < 0) {
        reasons.push(`${source.foodId}: teor ausente ou inválido para ${aminoAcid}.`);
        continue;
      }
      if (!evidence || !Number.isFinite(evidence.fraction) || evidence.fraction < 0 || evidence.fraction > 1 ||
          !['human', 'pig'].includes(evidence.species) ||
          !['true_ileal', 'standardized_ileal'].includes(evidence.method) ||
          evidence.foodId !== source.foodId ||
          typeof evidence.reference !== 'string' || !evidence.reference.trim() ||
          typeof evidence.sourceName !== 'string' || !evidence.sourceName.trim() ||
          typeof evidence.sourceVersion !== 'string' || !evidence.sourceVersion.trim() ||
          typeof evidence.referenceUrl !== 'string' || !/^https?:\/\//i.test(evidence.referenceUrl) ||
          evidence.testedState !== source.foodState) {
        reasons.push(`${source.foodId}: digestibilidade ileal de ${aminoAcid} ausente, inválida ou medida em estado diferente (${source.foodState}).`);
        continue;
      }
      const previous = digestibleAminoAcidsMg.get(aminoAcid) ?? 0;
      digestibleAminoAcidsMg.set(aminoAcid, previous + source.proteinGrams * amount * evidence.fraction);
      species.add(evidence.species);
      references.add(evidence.reference);
    }
    totalProteinG += source.proteinGrams;
  }

  const sourceMethods = new Set(request.proteinSources.flatMap((source) =>
    AMINO_ACIDS.map((aminoAcid) => source.ilealDigestibility[aminoAcid]?.method).filter(Boolean),
  ));
  const sourceSpecies = new Set(request.proteinSources.flatMap((source) =>
    AMINO_ACIDS.map((aminoAcid) => source.ilealDigestibility[aminoAcid]?.species).filter(Boolean),
  ));
  if (sourceMethods.size > 1 || sourceSpecies.size > 1) {
    reasons.push('As fontes combinam métodos ou espécies de digestibilidade ileal diferentes; não é adequado somá-los como se fossem a mesma medição.');
  }

  if (reasons.length > 0) {
    return emptyResult('insufficient_evidence', request.referencePattern, [...new Set(reasons)]);
  }
  if (!Number.isFinite(totalProteinG) || totalProteinG <= 0) {
    return emptyResult('invalid_input', request.referencePattern, ['A quantidade total de proteína deve ser maior que zero.']);
  }

  const aminoAcidScores: Record<string, number> = {};
  for (const [group, aminoAcids] of Object.entries(AMINO_ACID_GROUPS)) {
    const digestibleMgPerGProtein = aminoAcids.reduce(
      (sum, aminoAcid) => sum + (digestibleAminoAcidsMg.get(aminoAcid) ?? 0) / totalProteinG,
      0,
    );
    const referenceMgPerG = pattern[group as keyof typeof AMINO_ACID_GROUPS];
    aminoAcidScores[group] = (digestibleMgPerGProtein / referenceMgPerG) * 100;
  }

  const limitingAminoAcid = Object.entries(aminoAcidScores).sort((a, b) => a[1] - b[1])[0]?.[0] ?? null;
  const uniqueFoodStates = new Set(request.proteinSources.map((source) => `${source.foodId}::${source.foodState}`));
  const isMixedDiet = uniqueFoodStates.size > 1;
  const untruncatedDiaas = limitingAminoAcid ? Number(aminoAcidScores[limitingAminoAcid]!.toFixed(2)) : null;
  return {
    status: 'calculated',
    referencePattern: pattern.id,
    untruncatedDiaas,
    isMixedDiet,
    // FAO allows >100 for an individual food, but caps mixed-diet DIAAS at 100.
    diaas: untruncatedDiaas === null ? null : isMixedDiet ? Math.min(100, untruncatedDiaas) : untruncatedDiaas,
    limitingAminoAcid,
    aminoAcidScores: Object.fromEntries(Object.entries(aminoAcidScores).map(([key, value]) => [key, Number(value.toFixed(2))])),
    evidenceSpecies: [...species].sort(),
    evidenceReferences: [...references].sort(),
    reasons: [],
  };
}

const FAO_2013_REPORT_URL = 'https://www.fao.org/ag/humannutrition/35978-02317b979a686a57aa4593304ffc17f06.pdf';
const MULEYA_SALTER_2021_URL = 'https://data.mendeley.com/datasets/gz3cx7d5f4/1';

function buildUniformIlealDigestibility(
  foodId: string,
  testedState: string,
  fractions: Record<IndispensableAminoAcid, number>,
  reference: string,
  sourceName: string,
  sourceVersion: string,
  referenceUrl: string,
): Record<IndispensableAminoAcid, IlealDigestibilityEvidence> {
  return Object.fromEntries(
    AMINO_ACIDS.map((aa) => [
      aa,
      {
        foodId,
        fraction: fractions[aa],
        species: 'pig' as const,
        method: 'true_ileal' as const,
        reference,
        sourceName,
        sourceVersion,
        referenceUrl,
        testedState,
      },
    ]),
  ) as Record<IndispensableAminoAcid, IlealDigestibilityEvidence>;
}

/**
 * Documented FAO (2013) & Muleya/Salter (2021) amino-acid composition and true ileal digestibility
 * profiles mapped to exact canonical food IDs. Foods outside this map are never estimated from total protein.
 */
export const LITERATURE_DIAAS_PROFILES: Readonly<
  Record<string, Omit<ProteinQualitySourceEvidence, 'proteinGrams'>>
> = {
  'tbca:BRC0113F': {
    foodId: 'tbca:BRC0113F',
    foodState: 'assado',
    aminoAcidsMgPerGProtein: {
      histidine: 31,
      isoleucine: 46,
      leucine: 75,
      lysine: 85,
      methionine: 27,
      cysteine: 13,
      phenylalanine: 40,
      tyrosine: 34,
      threonine: 42,
      tryptophan: 11.2,
      valine: 49,
    },
    aminoAcidEvidence: {
      foodId: 'tbca:BRC0113F',
      foodState: 'assado',
      sourceName: 'FAO Report 92 (2013) / USDA SR Poultry Assay',
      sourceVersion: 'FAO-2013',
      reference: 'FAO Food and Nutrition Paper 92 (2013); Muleya & Salter (2021)',
      referenceUrl: FAO_2013_REPORT_URL,
      basis: 'mg_per_g_protein',
    },
    ilealDigestibility: buildUniformIlealDigestibility(
      'tbca:BRC0113F',
      'assado',
      {
        histidine: 0.94,
        isoleucine: 0.95,
        leucine: 0.95,
        lysine: 0.95,
        methionine: 0.95,
        cysteine: 0.9,
        phenylalanine: 0.94,
        tyrosine: 0.94,
        threonine: 0.93,
        tryptophan: 0.92,
        valine: 0.94,
      },
      'Muleya & Salter (2021) Ileal Digestibility Database, DOI:10.17632/gz3cx7d5f4.1',
      'Mendeley Data — Ileal Amino Acid Digestibility',
      'v1-2021',
      MULEYA_SALTER_2021_URL,
    ),
    lysineDamageRisk: 'not_suspected',
    lysineBasis: 'reactive',
  },
  'tbca-ovo-mexido': {
    foodId: 'tbca-ovo-mexido',
    foodState: 'cozido',
    aminoAcidsMgPerGProtein: {
      histidine: 24,
      isoleucine: 54,
      leucine: 86,
      lysine: 72,
      methionine: 31,
      cysteine: 23,
      phenylalanine: 54,
      tyrosine: 41,
      threonine: 47,
      tryptophan: 13.4,
      valine: 68,
    },
    aminoAcidEvidence: {
      foodId: 'tbca-ovo-mexido',
      foodState: 'cozido',
      sourceName: 'FAO Report 92 (2013) Whole Egg Protein Profile',
      sourceVersion: 'FAO-2013',
      reference: 'FAO Food and Nutrition Paper 92 (2013); Muleya & Salter (2021)',
      referenceUrl: FAO_2013_REPORT_URL,
      basis: 'mg_per_g_protein',
    },
    ilealDigestibility: buildUniformIlealDigestibility(
      'tbca-ovo-mexido',
      'cozido',
      {
        histidine: 0.94,
        isoleucine: 0.95,
        leucine: 0.96,
        lysine: 0.95,
        methionine: 0.95,
        cysteine: 0.92,
        phenylalanine: 0.95,
        tyrosine: 0.94,
        threonine: 0.93,
        tryptophan: 0.94,
        valine: 0.94,
      },
      'Muleya & Salter (2021) Ileal Digestibility Database, DOI:10.17632/gz3cx7d5f4.1',
      'Mendeley Data — Ileal Amino Acid Digestibility',
      'v1-2021',
      MULEYA_SALTER_2021_URL,
    ),
    lysineDamageRisk: 'not_suspected',
    lysineBasis: 'reactive',
  },
  'tbca:BRC0016A': {
    foodId: 'tbca:BRC0016A',
    foodState: 'cozido',
    aminoAcidsMgPerGProtein: {
      histidine: 25,
      isoleucine: 41,
      leucine: 82,
      lysine: 36,
      methionine: 24,
      cysteine: 18,
      phenylalanine: 52,
      tyrosine: 38,
      threonine: 36,
      tryptophan: 12.1,
      valine: 58,
    },
    aminoAcidEvidence: {
      foodId: 'tbca:BRC0016A',
      foodState: 'cozido',
      sourceName: 'FAO Report 92 (2013) Cooked Rice Protein Profile',
      sourceVersion: 'FAO-2013',
      reference: 'FAO Food and Nutrition Paper 92 (2013); Muleya & Salter (2021)',
      referenceUrl: FAO_2013_REPORT_URL,
      basis: 'mg_per_g_protein',
    },
    ilealDigestibility: buildUniformIlealDigestibility(
      'tbca:BRC0016A',
      'cozido',
      {
        histidine: 0.85,
        isoleucine: 0.86,
        leucine: 0.86,
        lysine: 0.82,
        methionine: 0.86,
        cysteine: 0.83,
        phenylalanine: 0.86,
        tyrosine: 0.85,
        threonine: 0.82,
        tryptophan: 0.84,
        valine: 0.86,
      },
      'Muleya & Salter (2021) Ileal Digestibility Database, DOI:10.17632/gz3cx7d5f4.1',
      'Mendeley Data — Ileal Amino Acid Digestibility',
      'v1-2021',
      MULEYA_SALTER_2021_URL,
    ),
    lysineDamageRisk: 'not_suspected',
    lysineBasis: 'reactive',
  },
  'tbca:BRC0024A': {
    foodId: 'tbca:BRC0024A',
    foodState: 'as_sold',
    aminoAcidsMgPerGProtein: {
      histidine: 22,
      isoleucine: 39,
      leucine: 74,
      lysine: 40,
      methionine: 18,
      cysteine: 28,
      phenylalanine: 52,
      tyrosine: 34,
      threonine: 34,
      tryptophan: 13.0,
      valine: 53,
    },
    aminoAcidEvidence: {
      foodId: 'tbca:BRC0024A',
      foodState: 'as_sold',
      sourceName: 'FAO Report 92 (2013) Rolled Oats Profile',
      sourceVersion: 'FAO-2013',
      reference: 'FAO Food and Nutrition Paper 92 (2013); Muleya & Salter (2021)',
      referenceUrl: FAO_2013_REPORT_URL,
      basis: 'mg_per_g_protein',
    },
    ilealDigestibility: buildUniformIlealDigestibility(
      'tbca:BRC0024A',
      'as_sold',
      {
        histidine: 0.84,
        isoleucine: 0.84,
        leucine: 0.85,
        lysine: 0.78,
        methionine: 0.85,
        cysteine: 0.82,
        phenylalanine: 0.86,
        tyrosine: 0.85,
        threonine: 0.79,
        tryptophan: 0.82,
        valine: 0.84,
      },
      'Muleya & Salter (2021) Ileal Digestibility Database, DOI:10.17632/gz3cx7d5f4.1',
      'Mendeley Data — Ileal Amino Acid Digestibility',
      'v1-2021',
      MULEYA_SALTER_2021_URL,
    ),
    lysineDamageRisk: 'not_suspected',
    lysineBasis: 'reactive',
  },
};

export interface MealProteinQualityEvaluation {
  diaasResult: DietaryDIAASResult;
  totalProteinGrams: number;
  coveredProteinGrams: number;
  uncoveredProteinGrams: number;
  proteinCoveragePercent: number;
  uncoveredFoods: Array<{ foodId: string; foodName: string; proteinGrams: number }>;
}

/**
 * Evaluates DIAAS for a list of resolved food portions without estimating missing
 * amino acid or ileal digestibility profiles for unmapped foods.
 */
export function evaluateMealProteinQualityDiaas(
  items: readonly { foodId: string; foodName: string; proteinGrams: number }[],
  referencePattern: DIAASReferencePatternId = 'older_children_adults',
): MealProteinQualityEvaluation {
  const proteinSources: ProteinQualitySourceEvidence[] = [];
  const uncoveredFoods: Array<{ foodId: string; foodName: string; proteinGrams: number }> = [];
  let totalProteinGrams = 0;
  let coveredProteinGrams = 0;

  for (const item of items) {
    if (!Number.isFinite(item.proteinGrams) || item.proteinGrams <= 0) continue;
    totalProteinGrams += item.proteinGrams;
    const profile = LITERATURE_DIAAS_PROFILES[item.foodId];
    if (!profile) {
      uncoveredFoods.push(item);
      continue;
    }
    coveredProteinGrams += item.proteinGrams;
    proteinSources.push({
      ...profile,
      proteinGrams: item.proteinGrams,
    });
  }

  const uncoveredProteinGrams = Math.max(0, totalProteinGrams - coveredProteinGrams);
  const proteinCoveragePercent =
    totalProteinGrams > 0 ? Number(((coveredProteinGrams / totalProteinGrams) * 100).toFixed(1)) : 0;

  if (proteinSources.length === 0) {
    return {
      diaasResult: emptyResult('insufficient_evidence', referencePattern, [
        'Nenhuma fonte proteica desta seleção possui perfil completo de aminoácidos e digestibilidade ileal documentado.',
      ]),
      totalProteinGrams: Number(totalProteinGrams.toFixed(2)),
      coveredProteinGrams: 0,
      uncoveredProteinGrams: Number(uncoveredProteinGrams.toFixed(2)),
      proteinCoveragePercent: 0,
      uncoveredFoods,
    };
  }

  const diaasResult = calculateDietaryDIAAS({ proteinSources, referencePattern });
  return {
    diaasResult,
    totalProteinGrams: Number(totalProteinGrams.toFixed(2)),
    coveredProteinGrams: Number(coveredProteinGrams.toFixed(2)),
    uncoveredProteinGrams: Number(uncoveredProteinGrams.toFixed(2)),
    proteinCoveragePercent,
    uncoveredFoods,
  };
}

