import type {
  FoodRole,
  FoodSourceId,
  FoodSourceItem,
  NutrientDataStatus,
  NutrientId,
} from '../entities/nutrient.ts';
import { deriveFoodRole } from './hybrid-composition-resolver.ts';

export interface NutritionCoverageTarget {
  nutrientId: NutrientId;
  unit: string;
}

export interface NutritionCoverageSourceSummary {
  totalFoodRecords: number;
  quantifiedFoodRecords: number;
  coveragePercent: number;
  statusCounts: Record<NutrientDataStatus, number>;
}

export type TbcaFoodType = 'ALIMENTO' | 'PREPARACAO_COMPOSTA' | 'UNKNOWN';

export interface NutritionDataCoverageEntry extends NutritionCoverageSourceSummary {
  nutrientId: NutrientId;
  unit: string;
  bySource: Record<FoodSourceId, NutritionCoverageSourceSummary>;
  byTbcaFoodType: Record<TbcaFoodType, NutritionCoverageSourceSummary>;
  byFoodRole: Record<FoodRole, NutritionCoverageSourceSummary>;
  baseIngredientsOnly: NutritionCoverageSourceSummary;
}

const SOURCES: readonly FoodSourceId[] = ['TBCA', 'OPEN_FOOD_FACTS', 'USDA_FDC', 'TITAN_LEGACY'];
const FOOD_ROLES: readonly FoodRole[] = [
  'raw_ingredient',
  'simple_processed_ingredient',
  'single_ingredient_commercial',
  'fortified_product',
  'multi_ingredient_product',
  'ready_composite_dish',
  'supplement',
  'unknown',
];
const STATUSES: readonly NutrientDataStatus[] = [
  'quantified', 'trace', 'not_analyzed', 'unit_mismatch', 'invalid_value', 'missing',
];

function emptyStatusCounts(): Record<NutrientDataStatus, number> {
  return Object.fromEntries(STATUSES.map((status) => [status, 0])) as Record<NutrientDataStatus, number>;
}

function emptySourceSummary(): NutritionCoverageSourceSummary {
  return {
    totalFoodRecords: 0,
    quantifiedFoodRecords: 0,
    coveragePercent: 0,
    statusCounts: emptyStatusCounts(),
  };
}

function statusFor(
  record: FoodSourceItem['micronutrients'][NutrientId] | undefined,
  expectedUnit: string,
  source: FoodSourceId,
): NutrientDataStatus {
  if (!record) return source === 'TBCA' ? 'not_analyzed' : 'missing';
  if (record.data_status === 'missing') return 'missing';
  if (record.data_status !== 'quantified') return record.data_status;
  if (record.normalized_unit !== expectedUnit) return 'unit_mismatch';
  if (!Number.isFinite(record.normalized_value) || record.normalized_value === null || record.normalized_value < 0 ||
      !Number.isFinite(record.basis_quantity) || record.basis_quantity <= 0) {
    return 'invalid_value';
  }
  return 'quantified';
}

function finalize(summary: NutritionCoverageSourceSummary): void {
  summary.coveragePercent = summary.totalFoodRecords === 0
    ? 0
    : Number(((summary.quantifiedFoodRecords / summary.totalFoodRecords) * 100).toFixed(1));
}

function recordOutcome(summary: NutritionCoverageSourceSummary, status: NutrientDataStatus): void {
  summary.totalFoodRecords += 1;
  summary.statusCounts[status] += 1;
  if (status === 'quantified') summary.quantifiedFoodRecords += 1;
}

/**
 * Audits food-catalog coverage without treating missing, trace, incompatible or invalid values as zero.
 * Breaks coverage down by source, TBCA classification, FoodRole, and base ingredients vs ready composite dishes.
 */
export function buildNutritionDataCoverage(
  foods: readonly (Pick<FoodSourceItem, 'source_id' | 'micronutrients' | 'food_type'> & Partial<Pick<FoodSourceItem, 'food_id' | 'name' | 'preparation' | 'source_group'>>)[],
  targets: readonly NutritionCoverageTarget[],
): NutritionDataCoverageEntry[] {
  return targets.map(({ nutrientId, unit }) => {
    if (!unit.trim()) throw new RangeError(`A unidade esperada de ${nutrientId} é obrigatória.`);
    const bySource = Object.fromEntries(SOURCES.map((source) => [source, emptySourceSummary()])) as Record<FoodSourceId, NutritionCoverageSourceSummary>;
    const byFoodRole = Object.fromEntries(FOOD_ROLES.map((role) => [role, emptySourceSummary()])) as Record<FoodRole, NutritionCoverageSourceSummary>;
    const total = emptySourceSummary();
    const baseIngredientsOnly = emptySourceSummary();
    const byTbcaFoodType = Object.fromEntries(
      (['ALIMENTO', 'PREPARACAO_COMPOSTA', 'UNKNOWN'] as const).map((foodType) => [foodType, emptySourceSummary()]),
    ) as Record<TbcaFoodType, NutritionCoverageSourceSummary>;

    for (const food of foods) {
      const status = statusFor(food.micronutrients?.[nutrientId], unit, food.source_id);
      const source = SOURCES.includes(food.source_id) ? food.source_id : null;
      const role = deriveFoodRole({
        source_id: food.source_id,
        food_type: food.food_type,
        name: food.name ?? food.food_id ?? '',
        preparation: food.preparation,
        source_group: food.source_group,
      });

      recordOutcome(total, status);
      recordOutcome(byFoodRole[role], status);
      if (role === 'raw_ingredient' || role === 'simple_processed_ingredient' || role === 'single_ingredient_commercial') {
        recordOutcome(baseIngredientsOnly, status);
      }
      if (source) {
        recordOutcome(bySource[source], status);
      }
      if (food.source_id === 'TBCA') {
        const foodType: TbcaFoodType = food.food_type === 'ALIMENTO' || food.food_type === 'PREPARACAO_COMPOSTA'
          ? food.food_type
          : 'UNKNOWN';
        recordOutcome(byTbcaFoodType[foodType], status);
      }
    }

    finalize(total);
    finalize(baseIngredientsOnly);
    for (const source of SOURCES) finalize(bySource[source]);
    for (const role of FOOD_ROLES) finalize(byFoodRole[role]);
    for (const foodType of ['ALIMENTO', 'PREPARACAO_COMPOSTA', 'UNKNOWN'] as const) finalize(byTbcaFoodType[foodType]);
    return { nutrientId, unit, ...total, bySource, byTbcaFoodType, byFoodRole, baseIngredientsOnly };
  });
}
