import type {
  FoodSourceId,
  FoodSourceItem,
  NutritionLicenseClass,
  UsagePolicy,
} from '../entities/nutrient.ts';

export interface SourceLicenseDescriptor {
  sourceId: FoodSourceId;
  licenseClass: NutritionLicenseClass;
  displayName: string;
  versionNote: string;
  commercialDistributionAllowed: boolean;
  requiresAttribution: boolean;
  shareAlikeRequiredForDatabase: boolean;
  userUploadedImagesRestricted: boolean;
  attributionNotice: string;
  legalNote: string;
}

export const SOURCE_LICENSE_REGISTRY: Record<FoodSourceId, SourceLicenseDescriptor> = {
  TBCA: {
    sourceId: 'TBCA',
    licenseClass: 'TBCA_RESTRICTED',
    displayName: 'TBCA (FCF/USP & FoRC)',
    versionNote: 'Snapshot local 7.2 (oficial publicada 7.3)',
    commercialDistributionAllowed: false,
    requiresAttribution: true,
    shareAlikeRequiredForDatabase: false,
    userUploadedImagesRestricted: false,
    attributionNotice: 'Tabela Brasileira de Composição de Alimentos (TBCA), Universidade de São Paulo (USP) / FoRC.',
    legalNote: 'Condições restritivas da TBCA exigem autorização expressa/escrita dos detentores antes de distribuição comercial ou redistribuição em base híbrida.',
  },
  OPEN_FOOD_FACTS: {
    sourceId: 'OPEN_FOOD_FACTS',
    licenseClass: 'OFF_ODBL_DBCL_CCBYSA',
    displayName: 'Open Food Facts (API v3)',
    versionNote: 'Base colaborativa ODbL v1.0 / DbCL v1.0',
    commercialDistributionAllowed: true,
    requiresAttribution: true,
    shareAlikeRequiredForDatabase: true,
    userUploadedImagesRestricted: true,
    attributionNotice: 'Open Food Facts contributors — base de dados sob ODbL v1.0; conteúdos individuais sob DbCL v1.0; imagens frequentemente sob CC BY-SA 3.0.',
    legalNote: 'Base derivada pública exige atribuição e Share-Alike (ODbL). Imagens de rótulos possuem licença própria (CC BY-SA) e não devem ser rehospedadas sem atribuição.',
  },
  USDA_FDC: {
    sourceId: 'USDA_FDC',
    licenseClass: 'USDA_FDC_PUBLIC_DOMAIN',
    displayName: 'USDA FoodData Central',
    versionNote: 'CC0 1.0 / Domínio Público (EUA)',
    commercialDistributionAllowed: true,
    requiresAttribution: true,
    shareAlikeRequiredForDatabase: false,
    userUploadedImagesRestricted: false,
    attributionNotice: 'U.S. Department of Agriculture, Agricultural Research Service. FoodData Central (CC0 1.0 Public Domain).',
    legalNote: 'Uso livre inclusive comercial; recomendável citar fonte e versão FDC para rastreabilidade científica.',
  },
  TITAN_LEGACY: {
    sourceId: 'TITAN_LEGACY',
    licenseClass: 'TITAN_LEGACY_UNVERIFIED',
    displayName: 'Snapshot Composto Legado Local',
    versionNote: 'Uso apenas para replay histórico de diário',
    commercialDistributionAllowed: false,
    requiresAttribution: true,
    shareAlikeRequiredForDatabase: false,
    userUploadedImagesRestricted: false,
    attributionNotice: 'Registro legado composto local — proibido em novas receitas, buscas canônicas e redistribuição.',
    legalNote: 'Bloqueado para seleção nova e exportação comercial por ausência de decomposição canônica.',
  },
};

export function getSourceUsagePolicy(sourceId: FoodSourceId): UsagePolicy {
  const desc = SOURCE_LICENSE_REGISTRY[sourceId];
  return {
    source_id: sourceId,
    license_class: desc.licenseClass,
    commercial_export_allowed: desc.commercialDistributionAllowed,
    attribution_required: desc.requiresAttribution,
    attribution_text: desc.attributionNotice,
    share_alike_database_obligation: desc.shareAlikeRequiredForDatabase,
    image_reuse_restricted: desc.userUploadedImagesRestricted,
    export_block_reason: desc.commercialDistributionAllowed ? undefined : desc.legalNote,
  };
}

export interface CommercialExportAuditResult {
  allowed: boolean;
  blockedSources: FoodSourceId[];
  requiredAttributions: string[];
  warnings: string[];
}

/**
 * Evaluates whether a set of foods/records can be bundled into a commercial hybrid export
 * without violating TBCA restrictions or omitting mandatory ODbL/CC0 attributions.
 */
export function evaluateCommercialExportGovernance(
  foods: readonly Pick<FoodSourceItem, 'food_id' | 'source_id'>[],
): CommercialExportAuditResult {
  const sourceSet = new Set<FoodSourceId>();
  for (const food of foods) {
    sourceSet.add(food.source_id);
  }

  const blockedSources: FoodSourceId[] = [];
  const requiredAttributions: string[] = [];
  const warnings: string[] = [];

  for (const sourceId of sourceSet) {
    const desc = SOURCE_LICENSE_REGISTRY[sourceId];
    if (!desc.commercialDistributionAllowed) {
      blockedSources.push(sourceId);
      warnings.push(`${desc.displayName}: ${desc.legalNote}`);
    }
    if (desc.requiresAttribution) {
      requiredAttributions.push(desc.attributionNotice);
    }
    if (desc.shareAlikeRequiredForDatabase) {
      warnings.push(`${desc.displayName}: redistribuição de base combinada aciona obrigação Share-Alike (ODbL v1.0).`);
    }
  }

  if (sourceSet.has('TBCA')) {
    warnings.push('TBCA local está na revisão 7.2 enquanto a edição pública oficial publicada é 7.3.');
  }

  return {
    allowed: blockedSources.length === 0,
    blockedSources,
    requiredAttributions,
    warnings,
  };
}
