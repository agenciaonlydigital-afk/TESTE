import fs from 'node:fs';
import path from 'node:path';

export type CompactTbcaCatalogRow = [
  string,
  string,
  string | null,
  string | null,
  string | null,
  string | null,
  string | null,
  [number, number, number, number, number, number | null, number | null, number | null, number | null],
  Array<number | null>,
];

function resolveCompactCatalogPath(): URL | string {
  const adjacent = new URL('./tbca-catalog.compact.json', import.meta.url);
  if (fs.existsSync(adjacent)) {
    return adjacent;
  }
  return path.resolve(process.cwd(), 'src/domains/nutrition/data/sources/tbca-catalog.compact.json');
}

let cachedRows: CompactTbcaCatalogRow[] | null = null;

export function readInitialCompactTbcaCatalogSync(): CompactTbcaCatalogRow[] {
  if (!cachedRows) {
    const raw = fs.readFileSync(resolveCompactCatalogPath(), 'utf8');
    cachedRows = JSON.parse(raw) as CompactTbcaCatalogRow[];
  }
  return cachedRows;
}

export function isCompactTbcaCatalogLoaded(): boolean {
  return true;
}

export async function ensureCompactTbcaCatalogAsync(): Promise<CompactTbcaCatalogRow[]> {
  return readInitialCompactTbcaCatalogSync();
}
