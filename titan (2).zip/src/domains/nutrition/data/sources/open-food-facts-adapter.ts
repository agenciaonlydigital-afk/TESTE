import type { FoodSourceItem } from '../../domain/entities/nutrient';

/**
 * Curated Open Food Facts v3 product records for branded / barcoded food search.
 * These records are local catalog data, not a live remote API client.
 * Preserve collaborative label completeness ('label_partial') without inventing missing micronutrients.
 */
export const OPEN_FOOD_FACTS_PRODUCTS: Record<string, FoodSourceItem> = {
  'off-iogurte-proteico': {
    food_id: 'off-iogurte-proteico',
    name: 'Iogurte Proteico Natural (marca comercial)',
    source_id: 'OPEN_FOOD_FACTS',
    source_record_id: '7891025118345',
    source_version: 'OFF API v3',
    quality_status: 'label_partial',
    macros: {
      kcalPerBasis: 86,
      proteinGPerBasis: 10.5,
      carbsGPerBasis: 5.2,
      fatGPerBasis: 2.1,
      basisQuantityG: 100,
    },
    micronutrients: {
      calcium: {
        original_value: 145,
        original_unit: 'mg',
        normalized_value: 145,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      sodium: {
        original_value: 52,
        original_unit: 'mg',
        normalized_value: 52,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b12: {
        original_value: 0.45,
        original_unit: 'µg',
        normalized_value: 0.45,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_d: {
        original_value: null,
        original_unit: 'µg',
        normalized_value: null,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'missing',
        conversion_method: 'unavailable',
      },
      vitamin_k: {
        original_value: null,
        original_unit: 'µg',
        normalized_value: null,
        normalized_unit: 'µg',
        basis_quantity: 100,
        data_status: 'missing',
        conversion_method: 'unavailable',
      },
    },
  },
  'off-pasta-amendoim': {
    food_id: 'off-pasta-amendoim',
    name: 'Pasta de Amendoim Integral (sem açúcar)',
    source_id: 'OPEN_FOOD_FACTS',
    source_record_id: '7898951240019',
    source_version: 'OFF API v3',
    quality_status: 'label_partial',
    macros: {
      kcalPerBasis: 598,
      proteinGPerBasis: 26.5,
      carbsGPerBasis: 14.0,
      fatGPerBasis: 48.0,
      basisQuantityG: 100,
    },
    micronutrients: {
      vitamin_e: {
        original_value: 8.9,
        original_unit: 'mg',
        normalized_value: 8.9,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      vitamin_b3: {
        original_value: 13.4,
        original_unit: 'mg',
        normalized_value: 13.4,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'preformed_niacin_only',
      },
      magnesium: {
        original_value: 168,
        original_unit: 'mg',
        normalized_value: 168,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      potassium: {
        original_value: 649,
        original_unit: 'mg',
        normalized_value: 649,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      sodium: {
        original_value: 12,
        original_unit: 'mg',
        normalized_value: 12,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
      zinc: {
        original_value: 2.9,
        original_unit: 'mg',
        normalized_value: 2.9,
        normalized_unit: 'mg',
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: 'direct',
      },
    },
  },
};

import type {
  FoodSourceItem as _FoodSourceItem,
  SourceFoodObservation,
  UserLabelCorrection,
} from '../../domain/entities/nutrient.ts';
import { matchesExactGtin, validateAndNormalizeGtin } from '../../domain/rules/gtin.ts';

const RUNTIME_OFF_OBSERVATIONS = new Map<string, SourceFoodObservation>();
const USER_LABEL_CORRECTIONS = new Map<string, UserLabelCorrection>();
const OFF_CATALOG_LISTENERS = new Set<() => void>();

export function onOpenFoodFactsCatalogUpdated(listener: () => void): () => void {
  OFF_CATALOG_LISTENERS.add(listener);
  return () => OFF_CATALOG_LISTENERS.delete(listener);
}

function notifyOffUpdated(): void {
  for (const listener of OFF_CATALOG_LISTENERS) {
    listener();
  }
}

export function registerOpenFoodFactsObservation(observation: SourceFoodObservation): void {
  RUNTIME_OFF_OBSERVATIONS.set(observation.food_id, observation);
  if (observation.product_identity?.gtin) {
    RUNTIME_OFF_OBSERVATIONS.set(observation.product_identity.gtin, observation);
  }
  notifyOffUpdated();
}

export function registerUserLabelCorrection(correction: UserLabelCorrection): void {
  USER_LABEL_CORRECTIONS.set(correction.food_id, correction);
  if (correction.gtin) {
    USER_LABEL_CORRECTIONS.set(`gtin:${correction.gtin}`, correction);
  }
  notifyOffUpdated();
}

export function getUserLabelCorrection(foodId: string, gtin?: string): UserLabelCorrection | undefined {
  return (
    USER_LABEL_CORRECTIONS.get(foodId) ??
    (gtin ? USER_LABEL_CORRECTIONS.get(`gtin:${gtin}`) : undefined)
  );
}

function applyLabelCorrectionToFoodItem(food: _FoodSourceItem): _FoodSourceItem {
  const gtin = food.source_record_id;
  const correction = getUserLabelCorrection(food.food_id, gtin);
  if (!correction) return food;

  const nextMacros = { ...food.macros };
  const e = correction.facts.energy_kcal;
  if (e && e.status === 'quantified' && typeof e.value === 'number' && Number.isFinite(e.value) && e.value >= 0) {
    nextMacros.kcalPerBasis = e.value;
  }
  const p = correction.facts.protein_g;
  if (p && p.status === 'quantified' && typeof p.value === 'number' && Number.isFinite(p.value) && p.value >= 0) {
    nextMacros.proteinGPerBasis = p.value;
  }
  const c = correction.facts.carbs_g;
  if (c && c.status === 'quantified' && typeof c.value === 'number' && Number.isFinite(c.value) && c.value >= 0) {
    nextMacros.carbsGPerBasis = c.value;
  }
  const f = correction.facts.fat_g;
  if (f && f.status === 'quantified' && typeof f.value === 'number' && Number.isFinite(f.value) && f.value >= 0) {
    nextMacros.fatGPerBasis = f.value;
  }
  const na = correction.facts.sodium_mg;
  if (na && na.status === 'quantified' && typeof na.value === 'number' && Number.isFinite(na.value) && na.value >= 0) {
    nextMacros.sodiumMgPerBasis = na.value;
  }

  return {
    ...food,
    quality_status: 'label_complete',
    source_version: `${food.source_version} · corrigido (${correction.corrected_at.slice(0, 10)})`,
    macros: nextMacros,
  };
}

export function getOpenFoodFactsFoodById(foodId: string): _FoodSourceItem | undefined {
  const curated = OPEN_FOOD_FACTS_PRODUCTS[foodId];
  if (curated) return applyLabelCorrectionToFoodItem(curated);
  const obs = RUNTIME_OFF_OBSERVATIONS.get(foodId);
  if (obs) return applyLabelCorrectionToFoodItem(obs.food_item);
  return undefined;
}

export function getOpenFoodFactsObservationByGtin(rawGtin: string): SourceFoodObservation | undefined {
  const norm = validateAndNormalizeGtin(rawGtin);
  if (!norm.valid || !norm.normalized) return undefined;
  const direct = RUNTIME_OFF_OBSERVATIONS.get(norm.normalized);
  if (direct) return direct;
  const curated = Object.values(OPEN_FOOD_FACTS_PRODUCTS).find((item) =>
    matchesExactGtin(item.source_record_id, norm.normalized!),
  );
  if (!curated) return undefined;
  return {
    observation_id: `obs:OPEN_FOOD_FACTS:${curated.source_record_id}`,
    food_id: curated.food_id,
    source_id: curated.source_id,
    source_record_id: curated.source_record_id,
    source_version: curated.source_version,
    observed_at: '2026-11-27T00:00:00.000Z',
    food_role: 'multi_ingredient_product',
    raw_name: curated.name,
    state: 'as_sold',
    nutrition_basis_unit: 'g',
    food_item: applyLabelCorrectionToFoodItem(curated),
    usage_policy: {
      source_id: 'OPEN_FOOD_FACTS',
      license_class: 'OFF_ODBL_DBCL_CCBYSA',
      commercial_export_allowed: true,
      attribution_required: true,
      attribution_text: 'Open Food Facts (ODbL v1.0 / DbCL v1.0)',
      share_alike_database_obligation: true,
      image_reuse_restricted: true,
    },
    facts: {},
    warnings: [],
    product_identity: {
      gtin: curated.source_record_id,
      gtin14: curated.source_record_id.padStart(14, '0'),
      format: 'EAN-13',
      product_name: curated.name,
      nutrition_data_per: '100g',
      preparation_state: 'as_sold',
    },
  };
}

export function getAllOpenFoodFactsFoods(): readonly _FoodSourceItem[] {
  const seen = new Set<string>();
  const out: _FoodSourceItem[] = [];
  for (const item of Object.values(OPEN_FOOD_FACTS_PRODUCTS)) {
    seen.add(item.food_id);
    out.push(applyLabelCorrectionToFoodItem(item));
  }
  for (const obs of RUNTIME_OFF_OBSERVATIONS.values()) {
    if (seen.has(obs.food_item.food_id)) continue;
    seen.add(obs.food_item.food_id);
    out.push(applyLabelCorrectionToFoodItem(obs.food_item));
  }
  return out;
}
