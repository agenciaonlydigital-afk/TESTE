import { buildFoodSearchIndex, type FoodSearchEntry } from '../../domain/rules/food-search';
import { getAllOpenFoodFactsFoods, onOpenFoodFactsCatalogUpdated } from './open-food-facts-adapter';
import { getRegisteredUsdaFdcFoods, onUsdaFdcCatalogUpdated } from './usda-fdc-adapter.ts';
import {
  TBCA_FOODS,
  ensureTbcaCatalogLoaded,
  isTbcaCatalogLoaded,
  onTbcaCatalogLoaded,
} from './tbca-adapter';

let sharedFoodSearchIndex: FoodSearchEntry[] | null = null;
let sharedFoodSearchVersion = 0;
const sharedFoodSearchListeners = new Set<() => void>();

function invalidateSharedFoodSearchIndex(): void {
  sharedFoodSearchIndex = null;
  sharedFoodSearchVersion += 1;
  for (const listener of sharedFoodSearchListeners) listener();
}

onTbcaCatalogLoaded(invalidateSharedFoodSearchIndex);
onUsdaFdcCatalogUpdated(invalidateSharedFoodSearchIndex);
onOpenFoodFactsCatalogUpdated(invalidateSharedFoodSearchIndex);

/** Lazily builds and shares one search index across Composer food drawers. */
export function getSharedFoodSearchIndex(): readonly FoodSearchEntry[] {
  if (!sharedFoodSearchIndex) {
    sharedFoodSearchIndex = buildFoodSearchIndex([
      ...Object.values(TBCA_FOODS),
      ...getAllOpenFoodFactsFoods(),
      ...getRegisteredUsdaFdcFoods(),
    ]);
  }
  return sharedFoodSearchIndex;
}

export function getSharedFoodSearchVersion(): number {
  return sharedFoodSearchVersion;
}

export function subscribeSharedFoodSearchVersion(listener: () => void): () => void {
  sharedFoodSearchListeners.add(listener);
  return () => sharedFoodSearchListeners.delete(listener);
}

export async function ensureSharedFoodSearchIndexReady(): Promise<readonly FoodSearchEntry[]> {
  if (!isTbcaCatalogLoaded()) {
    const changed = await ensureTbcaCatalogLoaded();
    if (changed) {
      sharedFoodSearchIndex = null;
    }
  }
  return getSharedFoodSearchIndex();
}
