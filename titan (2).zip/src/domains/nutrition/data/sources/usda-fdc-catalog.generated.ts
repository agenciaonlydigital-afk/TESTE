import type { FoodSourceItem } from '../../domain/entities/nutrient.ts';
import { composeUsdaCatalogs } from './usda-catalog-composition.ts';
import { USDA_FDC_FOUNDATION_CATALOG, USDA_FDC_FOUNDATION_MANIFEST } from './usda-fdc-catalog.foundation.generated.ts';
import { USDA_FDC_SR_LEGACY_CATALOG, USDA_FDC_SR_LEGACY_MANIFEST } from './usda-fdc-catalog.sr-legacy.generated.ts';
import { USDA_FDC_SURVEY_FNDDS_CATALOG, USDA_FDC_SURVEY_FNDDS_MANIFEST } from './usda-fdc-catalog.survey-fndds.generated.ts';
import { USDA_FDC_EXPERIMENTAL_CATALOG, USDA_FDC_EXPERIMENTAL_MANIFEST } from './usda-fdc-catalog.experimental.generated.ts';

/** Aggregates independent, pinned USDA releases. Reimports of one type do not erase the other types. */
const sourceCatalogs = [
  { manifest: USDA_FDC_FOUNDATION_MANIFEST, foods: USDA_FDC_FOUNDATION_CATALOG },
  { manifest: USDA_FDC_SR_LEGACY_MANIFEST, foods: USDA_FDC_SR_LEGACY_CATALOG },
  { manifest: USDA_FDC_SURVEY_FNDDS_MANIFEST, foods: USDA_FDC_SURVEY_FNDDS_CATALOG },
  { manifest: USDA_FDC_EXPERIMENTAL_MANIFEST, foods: USDA_FDC_EXPERIMENTAL_CATALOG },
] as const;

const combinedFoods = composeUsdaCatalogs(sourceCatalogs);

export const USDA_FDC_GENERATED_MANIFEST = Object.freeze({
  status: combinedFoods.length > 0 ? 'imported' : 'not_imported',
  sourceCount: sourceCatalogs.filter((source) => String(source.manifest.status) === 'imported').length,
  foodCount: combinedFoods.length,
  sources: sourceCatalogs.map((source) => source.manifest),
});
export const USDA_FDC_GENERATED_CATALOG: readonly FoodSourceItem[] = Object.freeze(combinedFoods);
