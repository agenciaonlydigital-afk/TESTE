import type { RecipeItem } from '../../domain/entities/nutrient';

/**
 * Catálogo de Receitas (Camada intermediária entre Ingredientes TBCA/OFF e o Cardápio diário).
 * Todos os modelos ativos usam exclusivamente ingredientes canônicos TBCA (ALIMENTO) ou OFF validados.
 * Modelos legados com preparações compostas são preservados para históricos no arquivo legado, mas bloqueados na seleção nova.
 */
export const RECIPE_CATALOG: readonly RecipeItem[] = [
  {
    id: 'rec-cafe-completo',
    name: 'Ovos mexidos, pão integral e mamão com aveia',
    description: 'Ovos mexidos, pão integral, mamão formosa e aveia em flocos finos',
    category: 'cafe',
    ingredients: [
      { ingredientId: 'tbca-ovo-mexido', quantityG: 140 },
      { ingredientId: 'tbca-pao-integral', quantityG: 80 },
      { ingredientId: 'tbca:BRC0045C', quantityG: 130 },
      { ingredientId: 'tbca:BRC0024A', quantityG: 30 },
    ],
  },
  {
    id: 'rec-almoco-frango',
    name: 'Peito de frango assado, arroz integral e legumes',
    description: 'Peito de frango assado, arroz integral cozido, brócolis e cenoura cozidos',
    category: 'almoco',
    imageUrl: '/src/assets/images/meal_chicken_rice_bowl_1795297143937.jpg',
    ingredients: [
      { ingredientId: 'tbca:BRC0113F', quantityG: 140 },
      { ingredientId: 'tbca:BRC0016A', quantityG: 150 },
      { ingredientId: 'tbca:BRC0150B', quantityG: 60 },
      { ingredientId: 'tbca:BRC0047B', quantityG: 50 },
    ],
  },
  {
    id: 'rec-lanche-iogurte',
    name: 'Iogurte proteico, banana e pasta de amendoim',
    description: 'Iogurte proteico, banana prata e pasta de amendoim integral',
    category: 'lanche',
    imageUrl: '/src/assets/images/meal_protein_yogurt_bowl_1795297143970.jpg',
    ingredients: [
      { ingredientId: 'off-iogurte-proteico', quantityG: 200 },
      { ingredientId: 'tbca-banana-prata', quantityG: 100 },
      { ingredientId: 'off-pasta-amendoim', quantityG: 25 },
    ],
  },
  {
    id: 'rec-jantar-salmao',
    name: 'Salmão grelhado, batata-doce assada e brócolis',
    description: 'Salmão filé grelhado, batata-doce assada e brócolis cozido',
    category: 'jantar',
    imageUrl: '/src/assets/images/meal_salmon_sweet_potato_1795297143668.jpg',
    ingredients: [
      { ingredientId: 'tbca:BRC0066E', quantityG: 140 },
      { ingredientId: 'tbca:BRC0303B', quantityG: 180 },
      { ingredientId: 'tbca:BRC0150B', quantityG: 80 },
    ],
  },
  {
    id: 'rec-sub-iogurte-leve',
    name: 'Bowl de iogurte proteico com banana',
    description: 'Iogurte proteico (220 g) e banana prata (120 g)',
    category: 'lanche',
    imageUrl: '/src/assets/images/meal_protein_yogurt_bowl_1795297143970.jpg',
    ingredients: [
      { ingredientId: 'off-iogurte-proteico', quantityG: 220 },
      { ingredientId: 'tbca-banana-prata', quantityG: 120 },
    ],
  },
  {
    id: 'rec-sub-frango-leve',
    name: 'Frango assado com arroz e legumes (porção leve)',
    description: 'Peito de frango assado (110 g), arroz integral (100 g), brócolis (60 g) e cenoura (40 g)',
    category: 'almoco',
    imageUrl: '/src/assets/images/meal_chicken_rice_bowl_1795297143937.jpg',
    ingredients: [
      { ingredientId: 'tbca:BRC0113F', quantityG: 110 },
      { ingredientId: 'tbca:BRC0016A', quantityG: 100 },
      { ingredientId: 'tbca:BRC0150B', quantityG: 60 },
      { ingredientId: 'tbca:BRC0047B', quantityG: 40 },
    ],
  },
  {
    id: 'rec-sub-salmao-power',
    name: 'Salmão grelhado com batata-doce e banana pós-treino',
    description: 'Salmão grelhado (130 g), batata-doce assada (160 g), brócolis (60 g) e banana (90 g)',
    category: 'jantar',
    imageUrl: '/src/assets/images/meal_salmon_sweet_potato_1795297143668.jpg',
    ingredients: [
      { ingredientId: 'tbca:BRC0066E', quantityG: 130 },
      { ingredientId: 'tbca:BRC0303B', quantityG: 160 },
      { ingredientId: 'tbca:BRC0150B', quantityG: 60 },
      { ingredientId: 'tbca-banana-prata', quantityG: 90 },
    ],
  },
  {
    id: 'rec-sub-sanduiche-ovos',
    name: 'Ovos mexidos com pão integral, mamão e aveia',
    description: 'Ovos mexidos (160 g), pão integral (80 g), mamão formosa (100 g) e aveia (20 g)',
    category: 'cafe',
    ingredients: [
      { ingredientId: 'tbca-ovo-mexido', quantityG: 160 },
      { ingredientId: 'tbca-pao-integral', quantityG: 80 },
      { ingredientId: 'tbca:BRC0045C', quantityG: 100 },
      { ingredientId: 'tbca:BRC0024A', quantityG: 20 },
    ],
  },
] as const;

/** Modelos históricos com preparações compostas — preservados apenas para replay auditável de diários antigos. */
export const LEGACY_COMPOSITE_RECIPE_ARCHIVE: readonly RecipeItem[] = [
  {
    id: 'legacy-rec-almoco-frango',
    name: 'Peito de frango grelhado, arroz e legumes (composto legado)',
    description: 'Snapshot composto legado não selecionável em novos planos',
    category: 'almoco',
    ingredients: [{ ingredientId: 'tbca-frango-arroz-legumes', quantityG: 400 }],
  },
  {
    id: 'legacy-rec-jantar-salmao',
    name: 'Salmão assado, batata-doce e brócolis (composto legado)',
    description: 'Snapshot composto legado não selecionável em novos planos',
    category: 'jantar',
    ingredients: [{ ingredientId: 'tbca-salmao-batata-doce', quantityG: 380 }],
  },
  {
    id: 'legacy-rec-mamao-aveia',
    name: 'Mamão com aveia (composto legado)',
    description: 'Snapshot composto legado não selecionável em novos planos',
    category: 'cafe',
    ingredients: [{ ingredientId: 'tbca-mamao-aveia', quantityG: 150 }],
  },
] as const;

export function findRecipeById(
  recipeId: string,
  options: { includeLegacyArchive?: boolean } = {},
): RecipeItem | undefined {
  const active = RECIPE_CATALOG.find((r) => r.id === recipeId);
  if (active || !options.includeLegacyArchive) return active;
  return LEGACY_COMPOSITE_RECIPE_ARCHIVE.find((r) => r.id === recipeId);
}
