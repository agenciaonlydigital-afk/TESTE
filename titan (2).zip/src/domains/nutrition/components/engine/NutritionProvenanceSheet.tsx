import { useEffect, useMemo, useState } from 'react';
import { Calendar, Check, Database, FlaskConical, ShieldCheck, X } from 'lucide-react';
import { getAllOpenFoodFactsFoods } from '../../data/sources/open-food-facts-adapter';
import { TBCA_FOODS } from '../../data/sources/tbca-adapter';
import { getRegisteredUsdaFdcFoods } from '../../data/sources/usda-fdc-adapter';
import { SOURCE_LICENSE_REGISTRY } from '../../domain/rules/data-governance';
import {
  derivePreparedFoodComposition,
  PUBLISHED_PREPARATION_TRANSFORMS,
} from '../../domain/rules/food-preparation-transform';
import {
  planMultiDayCardapio,
  type MultiDayHorizon,
  type MultiDayPlanResult,
} from '../../domain/rules/multi-day-planner';
import { resolveFoodById } from '../../domain/rules/nutrition-calculator';
import { buildNutritionDataCoverage } from '../../domain/rules/nutrition-data-coverage';
import { evaluateMealProteinQualityDiaas } from '../../domain/rules/protein-quality';
import { evaluateTemporalDatePolicy } from '../../domain/rules/temporal-policy';
import { useNutritionStore } from '../../state/nutrition.store';
import { cardapiosTokens } from '../cardapios/styles/cardapios.tokens';

interface NutritionProvenanceSheetProps {
  open: boolean;
  onClose: () => void;
}

type SheetTab = 'planner' | 'diaas' | 'retention' | 'coverage';

const HORIZON_OPTIONS: MultiDayHorizon[] = [7, 14, 28];

const COVERAGE_TARGETS = [
  { nutrientId: 'iron' as const, unit: 'mg' },
  { nutrientId: 'calcium' as const, unit: 'mg' },
  { nutrientId: 'vitamin_c' as const, unit: 'mg' },
  { nutrientId: 'vitamin_b12' as const, unit: 'µg' },
  { nutrientId: 'potassium' as const, unit: 'mg' },
  { nutrientId: 'vitamin_d' as const, unit: 'µg' },
  { nutrientId: 'iodine' as const, unit: 'µg' },
];

export function NutritionProvenanceSheet({ open, onClose }: NutritionProvenanceSheetProps) {
  const activeDateKey = useNutritionStore((s) => s.activeDateKey);
  const composerPlans = useNutritionStore((s) => s.composerPlans);
  const activeComposerPlanId = useNutritionStore((s) => s.activeComposerPlanId);
  const applyMultiDayPlan = useNutritionStore((s) => s.applyMultiDayPlan);

  const [activeTab, setActiveTab] = useState<SheetTab>('planner');
  const [horizonDays, setHorizonDays] = useState<MultiDayHorizon>(7);
  const [confirmToday, setConfirmToday] = useState(false);
  const [planPreview, setPlanPreview] = useState<MultiDayPlanResult | null>(null);
  const [applyFeedback, setApplyFeedback] = useState<{ ok: boolean; text: string } | null>(null);
  const [selectedTransformId, setSelectedTransformId] = useState<string>(
    PUBLISHED_PREPARATION_TRANSFORMS[0]?.id ?? '',
  );

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [open, onClose]);

  const activePlan = useMemo(
    () => composerPlans.find((p) => p.id === activeComposerPlanId) ?? composerPlans[0] ?? null,
    [composerPlans, activeComposerPlanId],
  );

  const temporalPolicy = useMemo(
    () => evaluateTemporalDatePolicy(activeDateKey),
    [activeDateKey],
  );

  const diaasEvaluation = useMemo(() => {
    if (!open || !activePlan) return null;
    const dayPlan = activePlan.days[activeDateKey];
    if (!dayPlan) return null;
    const proteinItems: Array<{ foodId: string; foodName: string; proteinGrams: number }> = [];
    for (const slot of dayPlan.slots) {
      for (const recipe of slot.recipes) {
        for (const ing of recipe.ingredients) {
          const grams = ing.currentQuantityG ?? 0;
          if (grams <= 0) continue;
          const food = resolveFoodById(ing.foodId);
          if (!food) continue;
          const basis = food.macros.basisQuantityG || 100;
          const proteinGrams = (food.macros.proteinGPerBasis * grams) / basis;
          if (proteinGrams > 0) {
            proteinItems.push({
              foodId: food.food_id,
              foodName: food.name,
              proteinGrams,
            });
          }
        }
      }
    }
    return evaluateMealProteinQualityDiaas(proteinItems, 'older_children_adults');
  }, [open, activePlan, activeDateKey]);

  const retentionPreview = useMemo(() => {
    const transform =
      PUBLISHED_PREPARATION_TRANSFORMS.find((t) => t.id === selectedTransformId) ??
      PUBLISHED_PREPARATION_TRANSFORMS[0];
    if (!transform) return null;
    const rawFood = resolveFoodById(transform.sourceFoodId);
    if (!rawFood) return null;
    const derived = derivePreparedFoodComposition(rawFood, 100, transform);
    return { transform, rawFood, derived };
  }, [selectedTransformId]);

  const coverageEntries = useMemo(() => {
    if (!open || activeTab !== 'coverage') return [];
    const foods = [
      ...Object.values(TBCA_FOODS),
      ...getAllOpenFoodFactsFoods(),
      ...getRegisteredUsdaFdcFoods(),
    ];
    return buildNutritionDataCoverage(foods, COVERAGE_TARGETS);
  }, [open, activeTab]);

  if (!open) return null;

  const handleGeneratePreview = () => {
    if (!activePlan) return;
    setApplyFeedback(null);
    const result = planMultiDayCardapio({
      plan: activePlan,
      startDateKey: activeDateKey,
      horizonDays,
      includeTodayConfirmed: confirmToday,
    });
    setPlanPreview(result);
  };

  const handleApplyPlan = () => {
    if (!planPreview) return;
    const outcome = applyMultiDayPlan(planPreview, { confirmedToday: confirmToday });
    if (outcome.ok) {
      setApplyFeedback({
        ok: true,
        text: `${outcome.appliedDates.length} dia(s) aplicados no plano ativo respeitando congelamento do passado.`,
      });
    } else {
      setApplyFeedback({ ok: false, text: outcome.error });
    }
  };

  const tabs: Array<{ id: SheetTab; label: string; icon: typeof Calendar }> = [
    { id: 'planner', label: 'Planejador 7–28d', icon: Calendar },
    { id: 'diaas', label: 'DIAAS Proteico', icon: ShieldCheck },
    { id: 'retention', label: 'Retenção USDA R6', icon: FlaskConical },
    { id: 'coverage', label: 'Cobertura & Licenças', icon: Database },
  ];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="titan-provenance-sheet-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/75"
    >
      <div
        className="w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-[16px] border p-5 sm:p-6 space-y-5"
        style={{
          backgroundColor: cardapiosTokens.canvasPrimary,
          borderColor: cardapiosTokens.borderSubtle,
          color: cardapiosTokens.textPrimary,
        }}
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-4 border-b pb-4" style={{ borderColor: cardapiosTokens.borderSubtle }}>
          <div>
            <p className="text-[11px] uppercase tracking-[0.14em]" style={{ color: cardapiosTokens.textMuted }}>
              Motor Nutricional Científico · Proveniência & Política Temporal
            </p>
            <h2 id="titan-provenance-sheet-title" className="text-lg font-semibold mt-1">
              Auditoria, Planejamento Multi-Dias e Qualidade
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar painel científico"
            className="min-h-[44px] min-w-[44px] inline-flex items-center justify-center rounded-md border"
            style={{
              backgroundColor: cardapiosTokens.surfaceRaised,
              borderColor: cardapiosTokens.borderSubtle,
              color: cardapiosTokens.textPrimary,
            }}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex flex-wrap gap-2 border-b pb-3" style={{ borderColor: cardapiosTokens.borderSubtle }}>
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const selected = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className="min-h-[44px] px-3.5 rounded-md border text-xs font-medium inline-flex items-center gap-2 transition-colors"
                style={{
                  backgroundColor: selected ? cardapiosTokens.accentSurface : cardapiosTokens.surfacePrimary,
                  borderColor: selected ? cardapiosTokens.accentPrimary : cardapiosTokens.borderSubtle,
                  color: selected ? cardapiosTokens.textPrimary : cardapiosTokens.textSecondary,
                }}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab 1: Multi-day Planner */}
        {activeTab === 'planner' && (
          <div className="space-y-4">
            <div
              className="rounded-lg border p-3.5 text-xs space-y-1"
              style={{
                backgroundColor: cardapiosTokens.surfacePrimary,
                borderColor: cardapiosTokens.borderSubtle,
              }}
            >
              <p className="font-semibold" style={{ color: cardapiosTokens.accentPrimary }}>
                {temporalPolicy.bannerTitle} · Data selecionada: {activeDateKey}
              </p>
              <p style={{ color: cardapiosTokens.textSecondary }}>{temporalPolicy.bannerDetail}</p>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                {HORIZON_OPTIONS.map((days) => (
                  <button
                    key={days}
                    type="button"
                    onClick={() => setHorizonDays(days)}
                    className="min-h-[44px] px-3.5 rounded-md border text-xs font-medium tabular-nums"
                    style={{
                      backgroundColor: horizonDays === days ? cardapiosTokens.accentSurface : cardapiosTokens.surfaceRaised,
                      borderColor: horizonDays === days ? cardapiosTokens.accentPrimary : cardapiosTokens.borderSubtle,
                      color: cardapiosTokens.textPrimary,
                    }}
                  >
                    {days} dias
                  </button>
                ))}
              </div>

              <label className="min-h-[44px] inline-flex items-center gap-2 text-xs cursor-pointer" style={{ color: cardapiosTokens.textSecondary }}>
                <input
                  type="checkbox"
                  checked={confirmToday}
                  onChange={(e) => setConfirmToday(e.target.checked)}
                  className="w-4 h-4"
                />
                <span>Confirmar sobrescrita explícita de hoje se incluído</span>
              </label>

              <button
                type="button"
                onClick={handleGeneratePreview}
                className="min-h-[44px] px-4 rounded-md border text-xs font-semibold"
                style={{
                  backgroundColor: cardapiosTokens.accentPrimary,
                  borderColor: cardapiosTokens.accentPrimary,
                  color: cardapiosTokens.canvasPrimary,
                }}
              >
                Gerar Prévia {horizonDays}d
              </button>
            </div>

            {planPreview && (
              <div className="space-y-3">
                {planPreview.warnings.length > 0 && (
                  <div
                    className="rounded-md border p-3 text-xs space-y-1"
                    style={{
                      backgroundColor: cardapiosTokens.surfaceRaised,
                      borderColor: cardapiosTokens.borderSubtle,
                      color: '#D7C49E',
                    }}
                  >
                    {planPreview.warnings.map((w) => (
                      <p key={w}>· {w}</p>
                    ))}
                  </div>
                )}

                <div className="overflow-x-auto rounded-lg border max-h-64" style={{ borderColor: cardapiosTokens.borderSubtle }}>
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr style={{ backgroundColor: cardapiosTokens.surfaceRaised, color: cardapiosTokens.textSecondary }}>
                        <th className="py-2 px-3">Data</th>
                        <th className="py-2 px-3">Faixa</th>
                        <th className="py-2 px-3">Ação</th>
                        <th className="py-2 px-3 text-right">kcal</th>
                        <th className="py-2 px-3 text-right">P / C / G (g)</th>
                        <th className="py-2 px-3 text-right">Desvio</th>
                      </tr>
                    </thead>
                    <tbody>
                      {planPreview.dailyMacroSummaries.map((row) => (
                        <tr key={row.dateKey} className="border-t" style={{ borderColor: cardapiosTokens.borderSubtle }}>
                          <td className="py-2 px-3 font-mono tabular-nums">{row.dateKey}</td>
                          <td className="py-2 px-3">{row.band}</td>
                          <td className="py-2 px-3" style={{ color: row.appliedRotation ? cardapiosTokens.accentPrimary : cardapiosTokens.textMuted }}>
                            {row.appliedRotation ? 'Rotacionado & calibrado' : 'Preservado'}
                          </td>
                          <td className="py-2 px-3 text-right font-mono tabular-nums">{Math.round(row.macros.kcal)}</td>
                          <td className="py-2 px-3 text-right font-mono tabular-nums">
                            {Math.round(row.macros.proteinG)} / {Math.round(row.macros.carbsG)} / {Math.round(row.macros.fatG)}
                          </td>
                          <td className="py-2 px-3 text-right font-mono tabular-nums">{row.deviationPercent.toFixed(1)}%</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3">
                  {applyFeedback ? (
                    <span className="text-xs" style={{ color: applyFeedback.ok ? cardapiosTokens.accentPrimary : '#F0B6AE' }}>
                      <Check className="w-3.5 h-3.5 inline mr-1" />
                      {applyFeedback.text}
                    </span>
                  ) : (
                    <span className="text-xs" style={{ color: cardapiosTokens.textMuted }}>
                      Passado congelado: {planPreview.frozenPastDates.length} dia(s).
                    </span>
                  )}
                  <button
                    type="button"
                    onClick={handleApplyPlan}
                    className="min-h-[44px] px-4 rounded-md border text-xs font-semibold"
                    style={{
                      backgroundColor: cardapiosTokens.accentSurface,
                      borderColor: cardapiosTokens.accentPrimary,
                      color: cardapiosTokens.textPrimary,
                    }}
                  >
                    Aplicar plano no cardápio
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Tab 2: DIAAS Protein Quality */}
        {activeTab === 'diaas' && (
          <div className="space-y-4">
            <div
              className="rounded-lg border p-4 space-y-2"
              style={{
                backgroundColor: cardapiosTokens.surfacePrimary,
                borderColor: cardapiosTokens.borderSubtle,
              }}
            >
              <p className="text-xs" style={{ color: cardapiosTokens.textSecondary }}>
                Padrão FAO (2013) para adultos e crianças maiores · Digestibilidade ileal verdadeira (Muleya & Salter 2021). Alimentos sem perfil de aminoácidos documentado não são estimados por total de proteína.
              </p>

              {diaasEvaluation ? (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                  <div className="rounded border p-3" style={{ borderColor: cardapiosTokens.borderSubtle, backgroundColor: cardapiosTokens.canvasPrimary }}>
                    <div className="text-[11px]" style={{ color: cardapiosTokens.textMuted }}>DIAAS Calculado</div>
                    <div className="text-xl font-semibold font-mono tabular-nums mt-1" style={{ color: cardapiosTokens.accentPrimary }}>
                      {diaasEvaluation.diaasResult.diaas !== null ? `${diaasEvaluation.diaasResult.diaas}%` : 'Insuficiente'}
                    </div>
                  </div>
                  <div className="rounded border p-3" style={{ borderColor: cardapiosTokens.borderSubtle, backgroundColor: cardapiosTokens.canvasPrimary }}>
                    <div className="text-[11px]" style={{ color: cardapiosTokens.textMuted }}>Aminoácido Limitante</div>
                    <div className="text-base font-medium mt-1">
                      {diaasEvaluation.diaasResult.limitingAminoAcid ?? '—'}
                    </div>
                  </div>
                  <div className="rounded border p-3" style={{ borderColor: cardapiosTokens.borderSubtle, backgroundColor: cardapiosTokens.canvasPrimary }}>
                    <div className="text-[11px]" style={{ color: cardapiosTokens.textMuted }}>Cobertura Proteica Documentada</div>
                    <div className="text-base font-semibold font-mono tabular-nums mt-1">
                      {diaasEvaluation.proteinCoveragePercent}% ({diaasEvaluation.coveredProteinGrams}g / {diaasEvaluation.totalProteinGrams}g)
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-xs" style={{ color: cardapiosTokens.textMuted }}>
                  Nenhuma refeição ativa encontrada na data {activeDateKey}.
                </p>
              )}
            </div>

            {diaasEvaluation && diaasEvaluation.uncoveredFoods.length > 0 && (
              <div
                className="rounded-lg border p-3.5 text-xs space-y-1.5"
                style={{
                  backgroundColor: cardapiosTokens.surfaceRaised,
                  borderColor: cardapiosTokens.borderSubtle,
                }}
              >
                <p className="font-semibold" style={{ color: '#D7C49E' }}>
                  Alimentos sem evidência de aminoácidos/digestibilidade ileal (excluídos sem aproximação):
                </p>
                {diaasEvaluation.uncoveredFoods.map((item) => (
                  <p key={`${item.foodId}-${item.proteinGrams}`} style={{ color: cardapiosTokens.textSecondary }}>
                    · {item.foodName} ({item.foodId}) — {item.proteinGrams.toFixed(1)} g de proteína
                  </p>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 3: USDA Retention Factors Release 6 */}
        {activeTab === 'retention' && retentionPreview && (
          <div className="space-y-4">
            <div className="flex flex-wrap gap-2">
              {PUBLISHED_PREPARATION_TRANSFORMS.map((tr) => (
                <button
                  key={tr.id}
                  type="button"
                  onClick={() => setSelectedTransformId(tr.id)}
                  className="min-h-[44px] px-3 rounded-md border text-xs font-medium"
                  style={{
                    backgroundColor:
                      retentionPreview.transform.id === tr.id
                        ? cardapiosTokens.accentSurface
                        : cardapiosTokens.surfacePrimary,
                    borderColor:
                      retentionPreview.transform.id === tr.id
                        ? cardapiosTokens.accentPrimary
                        : cardapiosTokens.borderSubtle,
                    color: cardapiosTokens.textPrimary,
                  }}
                >
                  {tr.preparedFoodName.split('(')[0]!.trim()}
                </button>
              ))}
            </div>

            <div
              className="rounded-lg border p-4 space-y-3 text-xs"
              style={{
                backgroundColor: cardapiosTokens.surfacePrimary,
                borderColor: cardapiosTokens.borderSubtle,
              }}
            >
              <div>
                <p className="font-semibold text-sm">{retentionPreview.transform.preparedFoodName}</p>
                <p className="mt-1" style={{ color: cardapiosTokens.textSecondary }}>
                  Origem: {retentionPreview.rawFood.name} ({retentionPreview.rawFood.food_id})
                  {' · '}Rendimento de massa: {retentionPreview.transform.weightYieldFactor}×
                  {' · '}Fonte: {retentionPreview.transform.provenance.sourceName} ({retentionPreview.transform.provenance.retentionCode})
                </p>
              </div>

              {retentionPreview.derived.status === 'derived' && retentionPreview.derived.food && (
                <div className="overflow-x-auto rounded border" style={{ borderColor: cardapiosTokens.borderSubtle }}>
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr style={{ backgroundColor: cardapiosTokens.surfaceRaised, color: cardapiosTokens.textSecondary }}>
                        <th className="py-2 px-3">Métrica / 100 g</th>
                        <th className="py-2 px-3 text-right">Cru (TBCA)</th>
                        <th className="py-2 px-3 text-right">Preparado (Derivado)</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-t" style={{ borderColor: cardapiosTokens.borderSubtle }}>
                        <td className="py-2 px-3">Energia (kcal)</td>
                        <td className="py-2 px-3 text-right font-mono tabular-nums">{retentionPreview.rawFood.macros.kcalPerBasis}</td>
                        <td className="py-2 px-3 text-right font-mono tabular-nums">{retentionPreview.derived.food.macros.kcalPerBasis}</td>
                      </tr>
                      <tr className="border-t" style={{ borderColor: cardapiosTokens.borderSubtle }}>
                        <td className="py-2 px-3">Proteína (g)</td>
                        <td className="py-2 px-3 text-right font-mono tabular-nums">{retentionPreview.rawFood.macros.proteinGPerBasis}</td>
                        <td className="py-2 px-3 text-right font-mono tabular-nums">{retentionPreview.derived.food.macros.proteinGPerBasis}</td>
                      </tr>
                      <tr className="border-t" style={{ borderColor: cardapiosTokens.borderSubtle }}>
                        <td className="py-2 px-3">Carboidrato (g)</td>
                        <td className="py-2 px-3 text-right font-mono tabular-nums">{retentionPreview.rawFood.macros.carbsGPerBasis}</td>
                        <td className="py-2 px-3 text-right font-mono tabular-nums">{retentionPreview.derived.food.macros.carbsGPerBasis}</td>
                      </tr>
                      <tr className="border-t" style={{ borderColor: cardapiosTokens.borderSubtle }}>
                        <td className="py-2 px-3">Lipídio (g)</td>
                        <td className="py-2 px-3 text-right font-mono tabular-nums">{retentionPreview.rawFood.macros.fatGPerBasis}</td>
                        <td className="py-2 px-3 text-right font-mono tabular-nums">{retentionPreview.derived.food.macros.fatGPerBasis}</td>
                      </tr>
                      {Object.entries(retentionPreview.transform.micronutrientRetentionFactors).map(([id, factor]) => {
                        const rawM = retentionPreview.rawFood.micronutrients[id as keyof typeof retentionPreview.rawFood.micronutrients];
                        const prepM = retentionPreview.derived.food?.micronutrients[id as keyof typeof retentionPreview.rawFood.micronutrients];
                        return (
                          <tr key={id} className="border-t" style={{ borderColor: cardapiosTokens.borderSubtle }}>
                            <td className="py-2 px-3">{id} (ret. {Math.round((factor ?? 0) * 100)}%)</td>
                            <td className="py-2 px-3 text-right font-mono tabular-nums">
                              {rawM?.data_status === 'quantified' ? `${rawM.normalized_value} ${rawM.normalized_unit}` : rawM?.data_status ?? 'não analisado'}
                            </td>
                            <td className="py-2 px-3 text-right font-mono tabular-nums">
                              {prepM?.data_status === 'quantified' ? `${prepM.normalized_value} ${prepM.normalized_unit}` : prepM?.data_status ?? 'não analisado'}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 4: Coverage & Data Governance */}
        {activeTab === 'coverage' && (
          <div className="space-y-4">
            <div className="overflow-x-auto rounded-lg border" style={{ borderColor: cardapiosTokens.borderSubtle }}>
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr style={{ backgroundColor: cardapiosTokens.surfaceRaised, color: cardapiosTokens.textSecondary }}>
                    <th className="py-2 px-3">Nutriente</th>
                    <th className="py-2 px-3 text-right">Catálogo Total</th>
                    <th className="py-2 px-3 text-right">Ingredientes Base</th>
                    <th className="py-2 px-3 text-right">TBCA ALIMENTO</th>
                    <th className="py-2 px-3 text-right">USDA FDC</th>
                  </tr>
                </thead>
                <tbody>
                  {coverageEntries.map((entry) => (
                    <tr key={entry.nutrientId} className="border-t" style={{ borderColor: cardapiosTokens.borderSubtle }}>
                      <td className="py-2 px-3 font-medium">
                        {entry.nutrientId} ({entry.unit})
                      </td>
                      <td className="py-2 px-3 text-right font-mono tabular-nums">{entry.coveragePercent}%</td>
                      <td className="py-2 px-3 text-right font-mono tabular-nums">{entry.baseIngredientsOnly.coveragePercent}%</td>
                      <td className="py-2 px-3 text-right font-mono tabular-nums">{entry.byTbcaFoodType.ALIMENTO.coveragePercent}%</td>
                      <td className="py-2 px-3 text-right font-mono tabular-nums">{entry.bySource.USDA_FDC.coveragePercent}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              {Object.values(SOURCE_LICENSE_REGISTRY).map((desc) => (
                <div
                  key={desc.sourceId}
                  className="rounded-lg border p-3.5 space-y-1"
                  style={{
                    backgroundColor: cardapiosTokens.surfacePrimary,
                    borderColor: cardapiosTokens.borderSubtle,
                  }}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold">{desc.displayName}</span>
                    <span
                      className="font-mono text-[11px]"
                      style={{ color: desc.commercialDistributionAllowed ? cardapiosTokens.accentPrimary : '#F0B6AE' }}
                    >
                      {desc.commercialDistributionAllowed ? 'Uso comercial OK (c/ atrib.)' : 'Uso comercial restrito'}
                    </span>
                  </div>
                  <p style={{ color: cardapiosTokens.textMuted }}>{desc.versionNote}</p>
                  <p style={{ color: cardapiosTokens.textSecondary }}>{desc.legalNote}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
