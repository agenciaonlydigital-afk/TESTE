import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { BarcodeDetectorPolyfill } from '@undecaf/barcode-detector-polyfill';
import { Camera, Check, Edit3, Loader2, Search, ShieldAlert, X } from 'lucide-react';
import type {
  FoodDiaryMealTitle,
} from '../../domain/rules/food-diary';
import {
  getOpenFoodFactsObservationByGtin,
  getUserLabelCorrection,
  registerOpenFoodFactsObservation,
  registerUserLabelCorrection,
} from '../../data/sources/open-food-facts-adapter';
import {
  getUsdaBrandedObservationByGtin,
  registerUsdaBrandedObservation,
} from '../../data/sources/usda-fdc-adapter';
import type {
  NutrientFactMetricKey,
  NutrientFactSourceTier,
  SourceFoodObservation,
  UserLabelCorrection,
} from '../../domain/entities/nutrient';
import { validateAndNormalizeGtin } from '../../domain/rules/gtin';
import {
  resolveFoodComposition,
  type ResolvedHybridComposition,
} from '../../domain/rules/hybrid-composition-resolver';
import { useNutritionStore } from '../../state/nutrition.store';
import { cardapiosTokens } from '../cardapios/styles/cardapios.tokens';

interface BarcodeScannerModalProps {
  open: boolean;
  onClose: () => void;
}

interface BarcodeApiResponse {
  status: 'found' | 'not_found' | 'invalid_gtin' | 'rate_limited' | 'upstream_unavailable';
  gtin?: string;
  gtin14?: string;
  observation?: SourceFoodObservation | null;
  error?: string;
}

interface FdcBrandedApiResponse {
  status: 'found' | 'not_found' | 'not_configured' | 'invalid_gtin' | 'rate_limited' | 'upstream_unavailable';
  configured: boolean;
  observations: SourceFoodObservation[];
  message?: string;
  error?: string;
}

interface BarcodeDetectorLike {
  detect(source: HTMLVideoElement): Promise<Array<{ rawValue: string; format?: string }>>;
}

const DISPLAY_FACT_KEYS: Array<{ key: NutrientFactMetricKey; label: string }> = [
  { key: 'energy_kcal', label: 'Energia' },
  { key: 'protein_g', label: 'Proteína' },
  { key: 'carbs_g', label: 'Carboidrato' },
  { key: 'fat_g', label: 'Lipídio' },
  { key: 'fiber_g', label: 'Fibra' },
  { key: 'saturated_fat_g', label: 'Gord. Sat.' },
  { key: 'sodium_mg', label: 'Sódio' },
  { key: 'calcium', label: 'Cálcio' },
  { key: 'iron', label: 'Ferro' },
  { key: 'potassium', label: 'Potássio' },
  { key: 'vitamin_c', label: 'Vitamina C' },
  { key: 'vitamin_d', label: 'Vitamina D' },
  { key: 'vitamin_b12', label: 'Vitamina B12' },
];

const SOURCE_TIER_LABELS: Record<NutrientFactSourceTier, string> = {
  user_correction: 'Correção manual',
  current_label: 'Rótulo OFF v3',
  usda_fdc_branded_exact_gtin: 'USDA FDC Branded',
  official_reference: 'Referência oficial',
  matched_concept_proxy: 'Proxy conceitual',
  preparation_transform: 'Transformação preparo',
  unresolved: 'Não declarado',
};

const MEAL_TITLE_OPTIONS: FoodDiaryMealTitle[] = [
  'Café da manhã',
  'Almoço',
  'Lanche',
  'Jantar',
];

export function BarcodeScannerModal({ open, onClose }: BarcodeScannerModalProps) {
  const bumpNutritionCatalogRevision = useNutritionStore((s) => s.bumpNutritionCatalogRevision);
  const logFoodToDiary = useNutritionStore((s) => s.logFoodToDiary);

  const [gtinInput, setGtinInput] = useState('');
  const [lookupLoading, setLookupLoading] = useState(false);
  const [lookupError, setLookupError] = useState<string | null>(null);
  const [primaryObservation, setPrimaryObservation] = useState<SourceFoodObservation | null>(null);
  const [fallbackObservation, setFallbackObservation] = useState<SourceFoodObservation | null>(null);
  const [fdcStatusNote, setFdcStatusNote] = useState<string | null>(null);

  // Camera scanner state
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraStatus, setCameraStatus] = useState<string | null>(null);
  const [lockProgress, setLockProgress] = useState<number>(0);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number | null>(null);
  const lastReadRef = useRef<{ gtin: string; streak: number }>({ gtin: '', streak: 0 });

  // Manual label correction state
  const [showCorrectionForm, setShowCorrectionForm] = useState(false);
  const [correctionRevision, setCorrectionRevision] = useState(0);
  const [corrKcal, setCorrKcal] = useState('');
  const [corrProtein, setCorrProtein] = useState('');
  const [corrCarbs, setCorrCarbs] = useState('');
  const [corrFat, setCorrFat] = useState('');
  const [corrSodium, setCorrSodium] = useState('');
  const [corrDensity, setCorrDensity] = useState('');
  const [corrNote, setCorrNote] = useState('');
  const [corrSavedMessage, setCorrSavedMessage] = useState<string | null>(null);

  // Diary log state
  const [diaryGrams, setDiaryGrams] = useState('100');
  const [diaryMealTitle, setDiaryMealTitle] = useState<FoodDiaryMealTitle>('Lanche');
  const [diaryFeedback, setDiaryFeedback] = useState<{ ok: boolean; text: string } | null>(null);

  const stopCamera = useCallback(() => {
    if (rafRef.current !== null) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
    if (streamRef.current) {
      for (const track of streamRef.current.getTracks()) {
        track.stop();
      }
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    lastReadRef.current = { gtin: '', streak: 0 };
    setLockProgress(0);
    setCameraActive(false);
  }, []);

  useEffect(() => {
    if (!open) {
      stopCamera();
      return;
    }
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        stopCamera();
        onClose();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      stopCamera();
    };
  }, [open, onClose, stopCamera]);

  const executeLookup = useCallback(
    async (rawCode: string) => {
      const check = validateAndNormalizeGtin(rawCode);
      if (!check.valid || !check.normalized) {
        setLookupError(check.reason ?? 'GTIN inválido.');
        return;
      }
      const gtin = check.normalized;
      setGtinInput(gtin);
      setLookupLoading(true);
      setLookupError(null);
      setFdcStatusNote(null);
      setDiaryFeedback(null);
      setCorrSavedMessage(null);

      try {
        // Check local curated/runtime cache first
        const localOff = getOpenFoodFactsObservationByGtin(gtin) ?? null;
        const localFdc = getUsdaBrandedObservationByGtin(gtin) ?? null;

        const [offRes, fdcRes] = await Promise.all([
          localOff
            ? Promise.resolve<BarcodeApiResponse>({ status: 'found', gtin, observation: localOff })
            : fetch(`/api/nutrition/barcode/${encodeURIComponent(gtin)}`)
                .then(async (r) => (await r.json()) as BarcodeApiResponse)
                .catch((): BarcodeApiResponse => ({
                  status: 'upstream_unavailable',
                  error: 'Falha de conexão com o proxy OFF v3.',
                })),
          localFdc
            ? Promise.resolve<FdcBrandedApiResponse>({
                status: 'found',
                configured: true,
                observations: [localFdc],
              })
            : fetch(`/api/nutrition/fdc-branded/${encodeURIComponent(gtin)}`)
                .then(async (r) => (await r.json()) as FdcBrandedApiResponse)
                .catch((): FdcBrandedApiResponse => ({
                  status: 'upstream_unavailable',
                  configured: false,
                  observations: [],
                  error: 'Proxy USDA FDC indisponível.',
                })),
        ]);

        const offObs = offRes.status === 'found' && offRes.observation ? offRes.observation : null;
        const fdcObs = fdcRes.status === 'found' && fdcRes.observations[0] ? fdcRes.observations[0] : null;

        if (offObs) {
          registerOpenFoodFactsObservation(offObs);
        }
        if (fdcObs) {
          registerUsdaBrandedObservation(fdcObs);
        }
        if (offObs || fdcObs) {
          bumpNutritionCatalogRevision();
        }

        if (fdcRes.status === 'not_configured') {
          setFdcStatusNote(fdcRes.message ?? 'USDA_FDC_API_KEY não configurada no servidor.');
        } else if (fdcObs) {
          setFdcStatusNote('Match exato de gtinUpc encontrado no USDA FDC Branded.');
        }

        const chosenPrimary = offObs ?? fdcObs;
        const chosenFallback = offObs && fdcObs ? fdcObs : null;

        if (!chosenPrimary) {
          setPrimaryObservation(null);
          setFallbackObservation(null);
          setLookupError(
            offRes.error ??
              (offRes.status === 'not_found'
                ? `Produto GTIN ${gtin} não encontrado no Open Food Facts v3 nem no USDA FDC Branded.`
                : 'Não foi possível consultar o código de barras no momento.'),
          );
          return;
        }

        setPrimaryObservation(chosenPrimary);
        setFallbackObservation(chosenFallback);

        // Pre-fill label correction inputs with observed values
        const macros = chosenPrimary.food_item.macros;
        setCorrKcal(String(macros.kcalPerBasis ?? ''));
        setCorrProtein(String(macros.proteinGPerBasis ?? ''));
        setCorrCarbs(String(macros.carbsGPerBasis ?? ''));
        setCorrFat(String(macros.fatGPerBasis ?? ''));
        setCorrSodium(
          macros.sodiumMgPerBasis !== null && macros.sodiumMgPerBasis !== undefined
            ? String(macros.sodiumMgPerBasis)
            : '',
        );
        setCorrDensity(
          chosenPrimary.density_g_per_ml ? String(chosenPrimary.density_g_per_ml) : '',
        );
        setCorrNote('');
      } finally {
        setLookupLoading(false);
      }
    },
    [bumpNutritionCatalogRevision],
  );

  const startCamera = useCallback(async () => {
    if (cameraActive) {
      stopCamera();
      return;
    }
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      setCameraStatus('Câmera não disponível neste navegador. Use a digitação manual do GTIN.');
      return;
    }

    setCameraStatus('Inicializando câmera e detector GTIN...');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
        audio: false,
      });
      streamRef.current = stream;

      const NativeDetector = (
        window as unknown as {
          BarcodeDetector?: new (opts: { formats: string[] }) => BarcodeDetectorLike;
        }
      ).BarcodeDetector;

      const detector: BarcodeDetectorLike = NativeDetector
        ? new NativeDetector({ formats: ['ean_13', 'ean_8', 'upc_a', 'upc_e'] })
        : (new BarcodeDetectorPolyfill({
            formats: ['ean_13', 'ean_8', 'upc_a', 'upc_e'],
          }) as unknown as BarcodeDetectorLike);

      setCameraActive(true);
      setCameraStatus('Aponte para o código de barras (3 leituras consecutivas estáveis).');

      // Attach stream once video element mounts
      requestAnimationFrame(() => {
        const video = videoRef.current;
        if (!video || !streamRef.current) return;
        video.srcObject = streamRef.current;
        void video.play().catch(() => {
          setCameraStatus('Não foi possível iniciar o preview de vídeo.');
        });

        const scanFrame = async () => {
          if (!streamRef.current || !videoRef.current) return;
          if (videoRef.current.readyState >= 2) {
            try {
              const detected = await detector.detect(videoRef.current);
              for (const symbol of detected) {
                const check = validateAndNormalizeGtin(symbol.rawValue);
                if (!check.valid || !check.normalized) continue;
                if (lastReadRef.current.gtin === check.normalized) {
                  lastReadRef.current.streak += 1;
                } else {
                  lastReadRef.current = { gtin: check.normalized, streak: 1 };
                }
                setLockProgress(lastReadRef.current.streak);
                if (lastReadRef.current.streak >= 3) {
                  const lockedGtin = check.normalized;
                  stopCamera();
                  setCameraStatus(`GTIN ${lockedGtin} confirmado por 3 leituras consecutivas.`);
                  void executeLookup(lockedGtin);
                  return;
                }
                break;
              }
            } catch {
              // Ignore single-frame detection glitches
            }
          }
          rafRef.current = requestAnimationFrame(() => {
            void scanFrame();
          });
        };

        rafRef.current = requestAnimationFrame(() => {
          void scanFrame();
        });
      });
    } catch {
      stopCamera();
      setCameraStatus('Permissão de câmera negada ou indisponível. Digite o GTIN manualmente.');
    }
  }, [cameraActive, executeLookup, stopCamera]);

  const resolvedComposition: ResolvedHybridComposition | null = useMemo(() => {
    if (!primaryObservation) return null;
    const gtin = primaryObservation.product_identity?.gtin ?? primaryObservation.source_record_id;
    const correction = getUserLabelCorrection(primaryObservation.food_id, gtin) ?? null;
    return resolveFoodComposition({
      primary: primaryObservation,
      officialFallback: fallbackObservation,
      userCorrection: correction,
      targetBasisUnit: primaryObservation.nutrition_basis_unit,
      targetPreparationState: primaryObservation.state === 'prepared' ? 'prepared' : 'as_sold',
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [primaryObservation, fallbackObservation, correctionRevision]);

  const handleSaveLabelCorrection = (e: React.FormEvent) => {
    e.preventDefault();
    if (!primaryObservation) return;
    const basisUnit = primaryObservation.nutrition_basis_unit;
    const parseOpt = (raw: string) => {
      const trimmed = raw.trim();
      if (!trimmed) return null;
      const n = Number(trimmed.replace(',', '.'));
      return Number.isFinite(n) && n >= 0 ? n : null;
    };

    const facts: UserLabelCorrection['facts'] = {};
    const kcal = parseOpt(corrKcal);
    if (kcal !== null) facts.energy_kcal = { value: kcal, unit: 'kcal', basis_unit: basisUnit, status: 'quantified' };
    const p = parseOpt(corrProtein);
    if (p !== null) facts.protein_g = { value: p, unit: 'g', basis_unit: basisUnit, status: 'quantified' };
    const c = parseOpt(corrCarbs);
    if (c !== null) facts.carbs_g = { value: c, unit: 'g', basis_unit: basisUnit, status: 'quantified' };
    const f = parseOpt(corrFat);
    if (f !== null) facts.fat_g = { value: f, unit: 'g', basis_unit: basisUnit, status: 'quantified' };
    const na = parseOpt(corrSodium);
    if (na !== null) facts.sodium_mg = { value: na, unit: 'mg', basis_unit: basisUnit, status: 'quantified' };

    const parsedDensity = parseOpt(corrDensity);
    const correction: UserLabelCorrection = {
      correction_id: `corr-${Date.now()}`,
      gtin: primaryObservation.product_identity?.gtin ?? primaryObservation.source_record_id,
      food_id: primaryObservation.food_id,
      corrected_at: new Date().toISOString(),
      reviewer_note: corrNote.trim() || 'Correção direta do rótulo pelo usuário.',
      density_g_per_ml: parsedDensity && parsedDensity > 0 ? parsedDensity : undefined,
      facts,
    };

    registerUserLabelCorrection(correction);
    bumpNutritionCatalogRevision();
    setCorrectionRevision((prev) => prev + 1);
    setCorrSavedMessage('Correção salva com precedência prioritária sobre o rótulo colaborativo.');
    setShowCorrectionForm(false);
  };

  const handleLogToDiary = (e: React.FormEvent) => {
    e.preventDefault();
    if (!primaryObservation) return;
    const grams = Number(diaryGrams.replace(',', '.'));
    if (!Number.isFinite(grams) || grams < 1 || grams > 2000) {
      setDiaryFeedback({ ok: false, text: 'Informe uma quantidade válida entre 1 g e 2.000 g.' });
      return;
    }
    const outcome = logFoodToDiary(primaryObservation.food_id, grams, diaryMealTitle);
    if (outcome.ok) {
      setDiaryFeedback({
        ok: true,
        text: `${grams} g de "${primaryObservation.raw_name}" registrados em ${diaryMealTitle}.`,
      });
    } else {
      setDiaryFeedback({ ok: false, text: outcome.error });
    }
  };

  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="titan-barcode-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/75"
    >
      <div
        className="w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-[16px] border p-5 sm:p-6 space-y-5"
        style={{
          backgroundColor: cardapiosTokens.canvasPrimary,
          borderColor: cardapiosTokens.borderSubtle,
          color: cardapiosTokens.textPrimary,
        }}
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-4 border-b pb-4" style={{ borderColor: cardapiosTokens.borderSubtle }}>
          <div>
            <p className="text-[11px] uppercase tracking-[0.14em]" style={{ color: cardapiosTokens.textMuted }}>
              Identificação Comercial GTIN · OFF v3 & USDA FDC Branded
            </p>
            <h2 id="titan-barcode-modal-title" className="text-lg font-semibold mt-1" style={{ color: cardapiosTokens.textPrimary }}>
              Scanner de Código de Barras e Auditoria de Rótulo
            </h2>
          </div>
          <button
            type="button"
            onClick={() => {
              stopCamera();
              onClose();
            }}
            aria-label="Fechar scanner GTIN"
            className="min-h-[44px] min-w-[44px] inline-flex items-center justify-center rounded-md border transition-colors"
            style={{
              backgroundColor: cardapiosTokens.surfaceRaised,
              borderColor: cardapiosTokens.borderSubtle,
              color: cardapiosTokens.textPrimary,
            }}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Manual lookup + Camera trigger */}
        <div className="space-y-3">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              void executeLookup(gtinInput);
            }}
            className="flex flex-col sm:flex-row gap-2.5"
          >
            <label htmlFor="titan-gtin-input" className="sr-only">
              Código GTIN-8, UPC-A, EAN-13 ou GTIN-14
            </label>
            <input
              id="titan-gtin-input"
              type="text"
              inputMode="numeric"
              value={gtinInput}
              onChange={(e) => setGtinInput(e.target.value)}
              placeholder="Digite EAN-13 / UPC-A / GTIN-8 (ex: 7891000100103)"
              className="flex-1 min-h-[44px] rounded-md border px-3.5 text-base font-mono tabular-nums outline-none"
              style={{
                backgroundColor: cardapiosTokens.surfacePrimary,
                borderColor: cardapiosTokens.borderSubtle,
                color: cardapiosTokens.textPrimary,
              }}
            />
            <button
              type="submit"
              disabled={lookupLoading}
              className="min-h-[44px] px-4 rounded-md border text-sm font-medium inline-flex items-center justify-center gap-2 transition-colors disabled:opacity-60"
              style={{
                backgroundColor: cardapiosTokens.accentSurface,
                borderColor: cardapiosTokens.accentPrimary,
                color: cardapiosTokens.textPrimary,
              }}
            >
              {lookupLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
              <span>Buscar GTIN</span>
            </button>
            <button
              type="button"
              onClick={() => void startCamera()}
              className="min-h-[44px] px-4 rounded-md border text-sm font-medium inline-flex items-center justify-center gap-2 transition-colors"
              style={{
                backgroundColor: cameraActive ? cardapiosTokens.surfaceInteractive : cardapiosTokens.surfaceRaised,
                borderColor: cardapiosTokens.borderSubtle,
                color: cardapiosTokens.textPrimary,
              }}
            >
              <Camera className="w-4 h-4" />
              <span>{cameraActive ? 'Parar câmera' : 'Ler com câmera'}</span>
            </button>
          </form>

          {/* Quick valid GTIN samples */}
          <div className="flex flex-wrap items-center gap-2 text-xs" style={{ color: cardapiosTokens.textSecondary }}>
            <span>Exemplos GTIN válidos:</span>
            <button
              type="button"
              onClick={() => void executeLookup('7891000100103')}
              className="min-h-[36px] px-2.5 py-1 rounded border font-mono tabular-nums underline-offset-2 hover:underline"
              style={{
                backgroundColor: cardapiosTokens.surfacePrimary,
                borderColor: cardapiosTokens.borderSubtle,
                color: cardapiosTokens.accentPrimary,
              }}
            >
              7891000100103 · Produto Brasil
            </button>
            <button
              type="button"
              onClick={() => void executeLookup('3017620422003')}
              className="min-h-[36px] px-2.5 py-1 rounded border font-mono tabular-nums underline-offset-2 hover:underline"
              style={{
                backgroundColor: cardapiosTokens.surfacePrimary,
                borderColor: cardapiosTokens.borderSubtle,
                color: cardapiosTokens.accentPrimary,
              }}
            >
              3017620422003 · Ferrero / OFF v3
            </button>
          </div>
        </div>

        {/* Camera viewport */}
        {(cameraActive || cameraStatus) && (
          <div
            className="rounded-lg border p-3 space-y-2.5"
            style={{
              backgroundColor: cardapiosTokens.surfacePrimary,
              borderColor: cardapiosTokens.borderSubtle,
            }}
          >
            {cameraActive && (
              <div className="relative overflow-hidden rounded border bg-black" style={{ borderColor: cardapiosTokens.borderSubtle }}>
                <video
                  ref={videoRef}
                  muted
                  playsInline
                  className="w-full max-h-56 object-cover"
                />
              </div>
            )}
            <div className="flex items-center justify-between gap-2 text-xs" style={{ color: cardapiosTokens.textSecondary }}>
              <span>{cameraStatus}</span>
              {cameraActive && (
                <span className="font-mono tabular-nums" style={{ color: cardapiosTokens.accentPrimary }}>
                  Estabilidade: {lockProgress}/3 quadros
                </span>
              )}
            </div>
          </div>
        )}

        {/* Lookup errors / notices */}
        {lookupError && (
          <div
            role="alert"
            className="rounded-md border px-3.5 py-2.5 text-sm flex items-start gap-2.5"
            style={{
              backgroundColor: cardapiosTokens.surfaceRaised,
              borderColor: '#7A4640',
              color: '#F0B6AE',
            }}
          >
            <ShieldAlert className="w-4 h-4 mt-0.5 shrink-0" />
            <span>{lookupError}</span>
          </div>
        )}

        {/* Resolved Product & Hybrid NutrientFact Matrix */}
        {primaryObservation && resolvedComposition && (
          <div className="space-y-4">
            <div
              className="rounded-lg border p-4 space-y-2"
              style={{
                backgroundColor: cardapiosTokens.surfacePrimary,
                borderColor: cardapiosTokens.borderSubtle,
              }}
            >
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h3 className="text-base font-semibold" style={{ color: cardapiosTokens.textPrimary }}>
                    {primaryObservation.raw_name}
                  </h3>
                  <p className="text-xs mt-1 tabular-nums" style={{ color: cardapiosTokens.textSecondary }}>
                    GTIN {primaryObservation.product_identity?.gtin ?? primaryObservation.source_record_id}
                    {' · '}Formato {primaryObservation.product_identity?.format ?? 'EAN-13'}
                    {' · '}Papel: {resolvedComposition.food_role}
                    {' · '}Base: 100 {resolvedComposition.target_basis_unit}
                  </p>
                  <p className="text-xs mt-0.5" style={{ color: cardapiosTokens.textMuted }}>
                    Licença: {primaryObservation.usage_policy.attribution_text}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setShowCorrectionForm((prev) => !prev)}
                  className="min-h-[44px] px-3 rounded-md border text-xs font-medium inline-flex items-center gap-1.5"
                  style={{
                    backgroundColor: cardapiosTokens.surfaceRaised,
                    borderColor: cardapiosTokens.borderSubtle,
                    color: cardapiosTokens.accentPrimary,
                  }}
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>{showCorrectionForm ? 'Ocultar correção' : 'Corrigir rótulo'}</span>
                </button>
              </div>

              {(resolvedComposition.warnings.length > 0 || fdcStatusNote) && (
                <div className="pt-2 border-t space-y-1 text-xs" style={{ borderColor: cardapiosTokens.borderSubtle, color: '#D7C49E' }}>
                  {fdcStatusNote && <p>· {fdcStatusNote}</p>}
                  {resolvedComposition.warnings.map((w) => (
                    <p key={w}>· {w}</p>
                  ))}
                </div>
              )}

              {corrSavedMessage && (
                <div className="text-xs pt-1" style={{ color: cardapiosTokens.accentPrimary }}>
                  <Check className="w-3.5 h-3.5 inline mr-1" />
                  {corrSavedMessage}
                </div>
              )}
            </div>

            {/* Inline Label Correction Form */}
            {showCorrectionForm && (
              <form
                onSubmit={handleSaveLabelCorrection}
                className="rounded-lg border p-4 space-y-3"
                style={{
                  backgroundColor: cardapiosTokens.surfaceRaised,
                  borderColor: cardapiosTokens.borderSubtle,
                }}
              >
                <div className="flex items-center justify-between gap-2">
                  <h4 className="text-sm font-semibold">
                    Correção manual do rótulo (por 100 {primaryObservation.nutrition_basis_unit})
                  </h4>
                  <span className="text-xs" style={{ color: cardapiosTokens.textMuted }}>
                    Auditada com precedência máxima
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <label className="text-xs space-y-1">
                    <span style={{ color: cardapiosTokens.textSecondary }}>Energia (kcal)</span>
                    <input
                      type="text"
                      inputMode="decimal"
                      value={corrKcal}
                      onChange={(e) => setCorrKcal(e.target.value)}
                      className="w-full min-h-[44px] rounded border px-2.5 text-base font-mono tabular-nums"
                      style={{ backgroundColor: cardapiosTokens.canvasPrimary, borderColor: cardapiosTokens.borderSubtle }}
                    />
                  </label>
                  <label className="text-xs space-y-1">
                    <span style={{ color: cardapiosTokens.textSecondary }}>Proteína (g)</span>
                    <input
                      type="text"
                      inputMode="decimal"
                      value={corrProtein}
                      onChange={(e) => setCorrProtein(e.target.value)}
                      className="w-full min-h-[44px] rounded border px-2.5 text-base font-mono tabular-nums"
                      style={{ backgroundColor: cardapiosTokens.canvasPrimary, borderColor: cardapiosTokens.borderSubtle }}
                    />
                  </label>
                  <label className="text-xs space-y-1">
                    <span style={{ color: cardapiosTokens.textSecondary }}>Carboidrato (g)</span>
                    <input
                      type="text"
                      inputMode="decimal"
                      value={corrCarbs}
                      onChange={(e) => setCorrCarbs(e.target.value)}
                      className="w-full min-h-[44px] rounded border px-2.5 text-base font-mono tabular-nums"
                      style={{ backgroundColor: cardapiosTokens.canvasPrimary, borderColor: cardapiosTokens.borderSubtle }}
                    />
                  </label>
                  <label className="text-xs space-y-1">
                    <span style={{ color: cardapiosTokens.textSecondary }}>Lipídio (g)</span>
                    <input
                      type="text"
                      inputMode="decimal"
                      value={corrFat}
                      onChange={(e) => setCorrFat(e.target.value)}
                      className="w-full min-h-[44px] rounded border px-2.5 text-base font-mono tabular-nums"
                      style={{ backgroundColor: cardapiosTokens.canvasPrimary, borderColor: cardapiosTokens.borderSubtle }}
                    />
                  </label>
                  <label className="text-xs space-y-1">
                    <span style={{ color: cardapiosTokens.textSecondary }}>Sódio (mg)</span>
                    <input
                      type="text"
                      inputMode="decimal"
                      value={corrSodium}
                      onChange={(e) => setCorrSodium(e.target.value)}
                      className="w-full min-h-[44px] rounded border px-2.5 text-base font-mono tabular-nums"
                      style={{ backgroundColor: cardapiosTokens.canvasPrimary, borderColor: cardapiosTokens.borderSubtle }}
                    />
                  </label>
                  <label className="text-xs space-y-1">
                    <span style={{ color: cardapiosTokens.textSecondary }}>Densidade (g/ml, opcional)</span>
                    <input
                      type="text"
                      inputMode="decimal"
                      value={corrDensity}
                      onChange={(e) => setCorrDensity(e.target.value)}
                      placeholder="Ex: 1.03"
                      className="w-full min-h-[44px] rounded border px-2.5 text-base font-mono tabular-nums"
                      style={{ backgroundColor: cardapiosTokens.canvasPrimary, borderColor: cardapiosTokens.borderSubtle }}
                    />
                  </label>
                </div>
                <label className="block text-xs space-y-1">
                  <span style={{ color: cardapiosTokens.textSecondary }}>Motivo / observação da revisão</span>
                  <input
                    type="text"
                    value={corrNote}
                    onChange={(e) => setCorrNote(e.target.value)}
                    placeholder="Ex: Rótulo atualizado da embalagem física"
                    className="w-full min-h-[44px] rounded border px-3 text-base"
                    style={{ backgroundColor: cardapiosTokens.canvasPrimary, borderColor: cardapiosTokens.borderSubtle }}
                  />
                </label>
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowCorrectionForm(false)}
                    className="min-h-[44px] px-4 rounded-md border text-sm"
                    style={{ borderColor: cardapiosTokens.borderSubtle, color: cardapiosTokens.textSecondary }}
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="min-h-[44px] px-4 rounded-md border text-sm font-medium"
                    style={{
                      backgroundColor: cardapiosTokens.accentPrimary,
                      borderColor: cardapiosTokens.accentPrimary,
                      color: cardapiosTokens.canvasPrimary,
                    }}
                  >
                    Salvar correção auditada
                  </button>
                </div>
              </form>
            )}

            {/* Per-field NutrientFact Matrix */}
            <div className="overflow-x-auto rounded-lg border" style={{ borderColor: cardapiosTokens.borderSubtle }}>
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr style={{ backgroundColor: cardapiosTokens.surfaceRaised, color: cardapiosTokens.textSecondary }}>
                    <th className="py-2.5 px-3 font-medium">Nutriente</th>
                    <th className="py-2.5 px-3 font-medium text-right">Valor / 100{resolvedComposition.target_basis_unit}</th>
                    <th className="py-2.5 px-3 font-medium">Estado</th>
                    <th className="py-2.5 px-3 font-medium">Camada de Origem</th>
                  </tr>
                </thead>
                <tbody>
                  {DISPLAY_FACT_KEYS.map(({ key, label }, idx) => {
                    const fact = resolvedComposition.facts[key];
                    const valueText =
                      fact.status === 'quantified' && fact.value !== null
                        ? `${fact.value} ${fact.unit}`
                        : fact.status === 'trace'
                          ? 'Traços'
                          : fact.status === 'unit_mismatch'
                            ? 'Densidade pendente'
                            : fact.status === 'not_analyzed'
                              ? 'Não analisado'
                              : 'Ausente';
                    return (
                      <tr
                        key={key}
                        className="border-t"
                        style={{
                          borderColor: cardapiosTokens.borderSubtle,
                          backgroundColor: idx % 2 === 0 ? cardapiosTokens.canvasPrimary : cardapiosTokens.surfacePrimary,
                        }}
                      >
                        <td className="py-2 px-3 font-medium" style={{ color: cardapiosTokens.textPrimary }}>
                          {label}
                        </td>
                        <td className="py-2 px-3 text-right font-mono tabular-nums" style={{ color: cardapiosTokens.textPrimary }}>
                          {valueText}
                        </td>
                        <td className="py-2 px-3" style={{ color: cardapiosTokens.textSecondary }}>
                          {fact.status}
                        </td>
                        <td className="py-2 px-3" style={{ color: cardapiosTokens.textMuted }}>
                          {SOURCE_TIER_LABELS[fact.source_tier]} · {fact.source_id}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Log into Diary */}
            <form
              onSubmit={handleLogToDiary}
              className="rounded-lg border p-4 space-y-3"
              style={{
                backgroundColor: cardapiosTokens.surfacePrimary,
                borderColor: cardapiosTokens.borderSubtle,
              }}
            >
              <div className="flex flex-col sm:flex-row sm:items-end gap-3">
                <label className="text-xs space-y-1 sm:w-36">
                  <span style={{ color: cardapiosTokens.textSecondary }}>Quantidade (g)</span>
                  <input
                    type="text"
                    inputMode="decimal"
                    value={diaryGrams}
                    onChange={(e) => setDiaryGrams(e.target.value)}
                    className="w-full min-h-[44px] rounded border px-3 text-base font-mono tabular-nums"
                    style={{
                      backgroundColor: cardapiosTokens.canvasPrimary,
                      borderColor: cardapiosTokens.borderSubtle,
                      color: cardapiosTokens.textPrimary,
                    }}
                  />
                </label>
                <label className="text-xs space-y-1 flex-1">
                  <span style={{ color: cardapiosTokens.textSecondary }}>Refeição do Diário</span>
                  <select
                    value={diaryMealTitle}
                    onChange={(e) => setDiaryMealTitle(e.target.value as FoodDiaryMealTitle)}
                    className="w-full min-h-[44px] rounded border px-3 text-base"
                    style={{
                      backgroundColor: cardapiosTokens.canvasPrimary,
                      borderColor: cardapiosTokens.borderSubtle,
                      color: cardapiosTokens.textPrimary,
                    }}
                  >
                    {MEAL_TITLE_OPTIONS.map((title) => (
                      <option key={title} value={title}>
                        {title}
                      </option>
                    ))}
                  </select>
                </label>
                <button
                  type="submit"
                  className="min-h-[44px] px-4 rounded-md border text-sm font-medium"
                  style={{
                    backgroundColor: cardapiosTokens.accentPrimary,
                    borderColor: cardapiosTokens.accentPrimary,
                    color: cardapiosTokens.canvasPrimary,
                  }}
                >
                  Registrar no Diário
                </button>
              </div>
              {diaryFeedback && (
                <p
                  className="text-xs"
                  style={{ color: diaryFeedback.ok ? cardapiosTokens.accentPrimary : '#F0B6AE' }}
                >
                  {diaryFeedback.text}
                </p>
              )}
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
