import { memo, useState } from 'react';
import { motion } from 'motion/react';
import { buildRecipeToggleA11yProps } from '../accessibility/cardapios.accessibility';
import { cardapiosMaterialSkins, cardapiosTokens } from '../styles/cardapios.tokens';
import type { RecipeCardViewModel } from '../types/cardapios.types';
import { MatrixDisclosure } from './MatrixDisclosure';
import { RecipePhoto } from './RecipePhoto';

interface RecipeHeaderProps {
  recipe: RecipeCardViewModel;
  courseNumber?: number;
  matrixId: string;
  bodyId: string;
  isCardOpen: boolean;
  onToggleCard: () => void;
  isMatrixExpanded: boolean;
  onToggleMatrix: () => void;
  surfaceTone?: 'paper' | 'dark';
}

export const RecipeHeader = memo(function RecipeHeader({
  recipe,
  courseNumber,
  matrixId,
  bodyId,
  isCardOpen,
  onToggleCard,
  isMatrixExpanded,
  onToggleMatrix,
  surfaceTone = 'paper',
}: RecipeHeaderProps) {
  const [titleHovered, setTitleHovered] = useState(false);
  const [titlePressed, setTitlePressed] = useState(false);

  const isPaper = surfaceTone === 'paper';
  const primaryInk = isPaper ? cardapiosMaterialSkins.maison.paperInk : cardapiosTokens.textPrimary;
  const mutedInk = isPaper
    ? cardapiosMaterialSkins.maison.paperInkMuted
    : cardapiosTokens.textSecondary;
  const ruleColor = isPaper ? cardapiosMaterialSkins.maison.paperRule : cardapiosTokens.borderSubtle;

  const courseTag =
    courseNumber !== undefined
      ? `${String(courseNumber).padStart(2, '0')} · ${recipe.mealSlotLabel} · ${recipe.mealTime}`
      : `${recipe.mealSlotLabel} · ${recipe.mealTime}`;

  return (
    <div
      className="flex items-start gap-4 pb-3.5 border-b"
      style={{ borderColor: ruleColor }}
    >
      {/* Foto antes do título (posição preservada) */}
      <RecipePhoto image={recipe.image} />

      <div className="min-w-0 flex-1 flex flex-col justify-between gap-2">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2 sm:gap-4">
          <div className="min-w-0">
            <p
              className="text-[10px] font-medium uppercase tracking-[0.2em] mb-1 tabular-nums"
              style={{ color: mutedInk }}
            >
              {courseTag}
            </p>
            <h3 className="min-w-0 m-0 text-[18px] sm:text-[21px] font-semibold leading-tight">
              <motion.button
                type="button"
                onClick={onToggleCard}
                onMouseEnter={() => setTitleHovered(true)}
                onMouseLeave={() => {
                  setTitleHovered(false);
                  setTitlePressed(false);
                }}
                onPointerDown={() => setTitlePressed(true)}
                onPointerUp={() => setTitlePressed(false)}
                onPointerCancel={() => setTitlePressed(false)}
                animate={{
                  backgroundColor:
                    titlePressed || titleHovered
                      ? isPaper
                        ? cardapiosMaterialSkins.maison.paperInteractive
                        : cardapiosTokens.surfaceInteractive
                      : isPaper
                        ? 'rgba(222, 214, 198, 0)'
                        : 'rgba(41, 55, 58, 0)',
                  opacity: titlePressed ? 0.9 : 1,
                }}
                transition={{ duration: 0.095, ease: [0.33, 1, 0.68, 1] }}
                {...buildRecipeToggleA11yProps(recipe.title, bodyId, isCardOpen)}
                className="font-editorial text-left min-h-[44px] -mx-2 px-2 py-1 rounded-[8px] focus-visible:outline-2 focus-visible:outline-offset-2"
                style={{
                  color: primaryInk,
                  outlineColor: primaryInk,
                }}
              >
                {recipe.title}
              </motion.button>
            </h3>
          </div>

          <div className="shrink-0 sm:pt-3">
            <MatrixDisclosure
              recipeTitle={recipe.title}
              matrixId={matrixId}
              isExpanded={isMatrixExpanded}
              onToggle={onToggleMatrix}
              surfaceTone={surfaceTone}
            />
          </div>
        </div>
      </div>
    </div>
  );
});
