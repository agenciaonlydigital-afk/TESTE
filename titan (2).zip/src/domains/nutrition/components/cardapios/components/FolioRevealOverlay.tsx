import { memo, useEffect, useState } from 'react';
import { motion, useMotionValueEvent, useTransform, type MotionValue } from 'motion/react';
import { useMaterialSurface } from '../hooks/useMaterialSurface';
import {
  computeBiFoldFrame,
  computeCrossFoldFrame,
} from '../hooks/useFolioChoreography';
import { resolveFolioMaterialMetadata } from '../materials/material-surface-procedural';
import type { FolioVariant, MaterialSkinId } from '../materials/material-surface.types';
import { cardapiosMaterialSkins, cardapiosTokens } from '../styles/cardapios.tokens';

interface FolioRevealOverlayProps {
  progress: MotionValue<number>;
  isExpanded: boolean;
  variant: FolioVariant;
  skin: MaterialSkinId;
  reduceMotion: boolean;
}

/**
 * Transient, non-interactive 3D Origami Folio Reveal layered inside the
 * existing matrix disclosure region during `0 < progress < 1`:
 * - True hierarchical `preserve-3d` with `backfaceVisibility: 'hidden'` recto/verso leaves
 * - Unfolds in 2 Euclidean stages (Right Wing Y -172->0 deg, then Bottom Pair X +172->0 deg)
 * - Zero text, digits, macros, or TBCA cells rendered inside the folio
 * - `aria-hidden="true"` + `pointer-events-none` (never blocks VoiceOver or touches)
 */
export const FolioRevealOverlay = memo(function FolioRevealOverlay({
  progress,
  isExpanded,
  variant,
  skin,
  reduceMotion,
}: FolioRevealOverlayProps) {
  const [active, setActive] = useState(() => {
    const p = progress.get();
    return p > 0.0005 && p < 0.9995;
  });

  useEffect(() => {
    if (variant !== 'flat' && !reduceMotion) {
      const p = progress.get();
      const target = isExpanded ? 1 : 0;
      if (Math.abs(p - target) > 0.0005) {
        setActive(true);
      }
    }
  }, [isExpanded, variant, reduceMotion, progress]);

  useMotionValueEvent(progress, 'change', (latest) => {
    const nextActive = latest > 0.0005 && latest < 0.9995;
    setActive((prev) => (prev === nextActive ? prev : nextActive));
  });

  const folioMeta = resolveFolioMaterialMetadata(skin);
  const frontHandle = useMaterialSurface({
    skin,
    region: 'folio-front',
    width: 320,
    height: 160,
    enabled: active && variant !== 'flat' && !reduceMotion,
  });
  const backHandle = useMaterialSurface({
    skin,
    region: 'folio-back',
    width: 320,
    height: 160,
    enabled: active && variant !== 'flat' && !reduceMotion,
  });

  const overlayOpacity = useTransform(progress, (p) =>
    variant === 'bi-fold'
      ? computeBiFoldFrame(p).overlayOpacity
      : computeCrossFoldFrame(p).overlayOpacity,
  );
  const creaseOpacity = useTransform(progress, (p) =>
    variant === 'bi-fold'
      ? computeBiFoldFrame(p).creaseOpacity
      : computeCrossFoldFrame(p).creaseOpacity,
  );

  // Cross-fold 2x2 hierarchical 3D angles & lighting
  const wingRotateY = useTransform(progress, (p) => computeCrossFoldFrame(p).wingRotateYDeg);
  const wingHighlightOpacity = useTransform(
    progress,
    (p) => computeCrossFoldFrame(p).wingHighlightOpacity,
  );
  const q1ShadowOpacity = useTransform(
    progress,
    (p) => computeCrossFoldFrame(p).q1ShadowOpacity,
  );
  const bottomRotateX = useTransform(progress, (p) => computeCrossFoldFrame(p).bottomRotateXDeg);
  const bottomHighlightOpacity = useTransform(
    progress,
    (p) => computeCrossFoldFrame(p).bottomHighlightOpacity,
  );
  const topStripShadowOpacity = useTransform(
    progress,
    (p) => computeCrossFoldFrame(p).topStripShadowOpacity,
  );

  // Bi-fold 3D transforms
  const biBottomRotateX = useTransform(progress, (p) => computeBiFoldFrame(p).bottomRotateXDeg);
  const biBottomHighlight = useTransform(
    progress,
    (p) => computeBiFoldFrame(p).bottomHighlightOpacity,
  );
  const biTopShadow = useTransform(progress, (p) => computeBiFoldFrame(p).topShadowOpacity);

  if (variant === 'flat' || reduceMotion || !active) {
    return null;
  }

  const frontStyle = {
    backgroundColor: folioMeta.frontFallbackColor,
    backgroundImage: frontHandle.uri ? `url(${frontHandle.uri})` : undefined,
    backgroundSize: '100% 100%',
  } as const;

  const backStyle = {
    backgroundColor: folioMeta.backFallbackColor,
    backgroundImage: backHandle.uri ? `url(${backHandle.uri})` : undefined,
    backgroundSize: '100% 100%',
  } as const;

  if (variant === 'bi-fold') {
    return (
      <motion.div
        aria-hidden="true"
        className="pointer-events-none select-none absolute inset-0 z-20"
        style={{
          opacity: overlayOpacity,
          perspective: 1100,
          perspectiveOrigin: '50% 45%',
          transformStyle: 'preserve-3d',
        }}
      >
        <div
          className="absolute inset-x-0 top-0 h-1/2 rounded-t-[10px] border-t border-x"
          style={{
            ...frontStyle,
            borderColor: cardapiosTokens.borderSubtle,
            zIndex: 1,
          }}
        >
          <motion.div
            className="absolute inset-0 rounded-t-[10px]"
            style={{ opacity: biTopShadow, backgroundColor: '#070B0D' }}
          />
        </div>

        <motion.div
          className="absolute inset-x-0 top-1/2 h-1/2"
          style={{
            transformOrigin: 'top center',
            transformStyle: 'preserve-3d',
            rotateX: biBottomRotateX,
            z: 2,
          }}
        >
          <div
            className="absolute inset-0 rounded-b-[10px] border-b border-x"
            style={{
              ...frontStyle,
              borderColor: cardapiosTokens.borderSubtle,
              transform: 'translateZ(0.6px)',
              backfaceVisibility: 'hidden',
              WebkitBackfaceVisibility: 'hidden',
              boxShadow: '0 10px 24px rgba(0, 0, 0, 0.34)',
            }}
          >
            <motion.div
              className="absolute inset-0 rounded-b-[10px]"
              style={{ opacity: biBottomHighlight, backgroundColor: '#F2F0E8' }}
            />
          </div>
          <div
            className="absolute inset-0 rounded-[10px] border"
            style={{
              ...backStyle,
              borderColor: cardapiosMaterialSkins.maison.goldTooling,
              transform: 'rotateX(180deg) translateZ(0.6px)',
              backfaceVisibility: 'hidden',
              WebkitBackfaceVisibility: 'hidden',
              boxShadow: '0 10px 24px rgba(0, 0, 0, 0.38)',
            }}
          />
        </motion.div>

        <motion.div
          className="absolute inset-x-0 top-1/2 h-[1px]"
          style={{
            opacity: creaseOpacity,
            backgroundColor: cardapiosTokens.accentPrimary,
            z: 4,
          }}
        />
      </motion.div>
    );
  }

  // Hero Variant C: True Euclidean 2-Stage 3D Cross-Fold 2x2
  return (
    <motion.div
      aria-hidden="true"
      className="pointer-events-none select-none absolute inset-0 z-20"
      style={{
        opacity: overlayOpacity,
        perspective: 1150,
        perspectiveOrigin: '50% 42%',
        transformStyle: 'preserve-3d',
      }}
    >
      {/* Q1: Top-Left anchor quadrant */}
      <div
        className="absolute left-0 top-0 w-1/2 h-1/2 rounded-tl-[10px] border-t border-l"
        style={{
          ...frontStyle,
          borderColor: cardapiosTokens.borderSubtle,
          transform: 'translateZ(0px)',
        }}
      >
        <motion.div
          className="absolute inset-0 rounded-tl-[10px]"
          style={{ opacity: q1ShadowOpacity, backgroundColor: '#070B0D' }}
        />
        <motion.div
          className="absolute inset-0 rounded-tl-[10px]"
          style={{ opacity: topStripShadowOpacity, backgroundColor: '#070B0D' }}
        />
      </div>

      {/* Q3: Bottom-Left quadrant hinged along horizontal center crease (+172 -> 0 deg) */}
      <motion.div
        className="absolute left-0 top-1/2 w-1/2 h-1/2"
        style={{
          transformOrigin: 'top center',
          transformStyle: 'preserve-3d',
          rotateX: bottomRotateX,
          z: 1.5,
        }}
      >
        <div
          className="absolute inset-0 rounded-bl-[10px] border-b border-l"
          style={{
            ...frontStyle,
            borderColor: cardapiosTokens.borderSubtle,
            transform: 'translateZ(0.6px)',
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden',
            boxShadow: '0 10px 24px rgba(0, 0, 0, 0.3)',
          }}
        >
          <motion.div
            className="absolute inset-0 rounded-bl-[10px]"
            style={{ opacity: bottomHighlightOpacity, backgroundColor: '#F2F0E8' }}
          />
        </div>
        <div
          className="absolute inset-0 rounded-tl-[10px] border"
          style={{
            ...backStyle,
            borderColor: cardapiosMaterialSkins.maison.goldTooling,
            transform: 'rotateX(180deg) translateZ(0.6px)',
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden',
            boxShadow: '0 10px 24px rgba(0, 0, 0, 0.36)',
          }}
        />
      </motion.div>

      {/* Hierarchical Right Wing (Q2 + nested Q4) hinged along vertical center spine (-172 -> 0 deg) */}
      <motion.div
        className="absolute left-1/2 top-0 w-1/2 h-1/2"
        style={{
          transformOrigin: 'left center',
          transformStyle: 'preserve-3d',
          rotateY: wingRotateY,
          z: 3,
        }}
      >
        {/* Q2: Top-Right Recto */}
        <div
          className="absolute inset-0 rounded-tr-[10px] border-t border-r"
          style={{
            ...frontStyle,
            borderColor: cardapiosTokens.borderSubtle,
            transform: 'translateZ(0.6px)',
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden',
            boxShadow: '0 8px 20px rgba(0, 0, 0, 0.28)',
          }}
        >
          <motion.div
            className="absolute inset-0 rounded-tr-[10px]"
            style={{ opacity: wingHighlightOpacity, backgroundColor: '#F2F0E8' }}
          />
          <motion.div
            className="absolute inset-0 rounded-tr-[10px]"
            style={{ opacity: topStripShadowOpacity, backgroundColor: '#070B0D' }}
          />
        </div>

        {/* Q2: Top-Right Verso (Maison dark cover with champagne rule) */}
        <div
          className="absolute inset-0 rounded-tl-[10px] border"
          style={{
            ...backStyle,
            borderColor: cardapiosMaterialSkins.maison.goldTooling,
            transform: 'rotateY(180deg) translateZ(0.6px)',
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden',
            boxShadow: '0 12px 28px rgba(0, 0, 0, 0.42)',
          }}
        />

        {/* Q4: Bottom-Right nested inside Right Wing, unfolding downward synchronously (+172 -> 0 deg) */}
        <motion.div
          className="absolute left-0 top-full w-full h-full"
          style={{
            transformOrigin: 'top center',
            transformStyle: 'preserve-3d',
            rotateX: bottomRotateX,
            z: 1.5,
          }}
        >
          <div
            className="absolute inset-0 rounded-br-[10px] border-b border-r"
            style={{
              ...frontStyle,
              borderColor: cardapiosTokens.borderSubtle,
              transform: 'translateZ(0.6px)',
              backfaceVisibility: 'hidden',
              WebkitBackfaceVisibility: 'hidden',
              boxShadow: '0 10px 24px rgba(0, 0, 0, 0.3)',
            }}
          >
            <motion.div
              className="absolute inset-0 rounded-br-[10px]"
              style={{ opacity: bottomHighlightOpacity, backgroundColor: '#F2F0E8' }}
            />
          </div>
          <div
            className="absolute inset-0 rounded-tr-[10px] border"
            style={{
              ...backStyle,
              borderColor: cardapiosMaterialSkins.maison.goldTooling,
              transform: 'rotateX(180deg) translateZ(0.6px)',
              backfaceVisibility: 'hidden',
              WebkitBackfaceVisibility: 'hidden',
              boxShadow: '0 10px 24px rgba(0, 0, 0, 0.36)',
            }}
          />
        </motion.div>
      </motion.div>

      {/* Luminous orthogonal fold ridge lines catching overhead light while unfolding */}
      <motion.div
        className="absolute inset-x-0 top-1/2 h-[1px]"
        style={{
          opacity: creaseOpacity,
          backgroundColor: cardapiosTokens.accentPrimary,
          z: 6,
        }}
      />
      <motion.div
        className="absolute inset-y-0 left-1/2 w-[1px]"
        style={{
          opacity: creaseOpacity,
          backgroundColor: cardapiosTokens.accentPrimary,
          z: 6,
        }}
      />
    </motion.div>
  );
});
