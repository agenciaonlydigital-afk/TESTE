import { memo } from 'react';
import type { NutritionMatrixViewModel } from '../types/cardapios.types';
import { NutritionMatrix } from './NutritionMatrix';

interface NutritionMatrixDisclosureProps {
  matrixId: string;
  recipeTitle: string;
  matrix: NutritionMatrixViewModel;
  isExpanded: boolean;
  surfaceTone?: 'paper' | 'dark';
}

/**
 * Mantém a tabela editorial única sempre visível na receita aberta (sem duplicação com lista separada)
 * e alterna a exibição das colunas detalhadas de lipídios, vitaminas e minerais.
 */
export const NutritionMatrixDisclosure = memo(function NutritionMatrixDisclosure({
  matrixId,
  recipeTitle,
  matrix,
  isExpanded,
  surfaceTone = 'paper',
}: NutritionMatrixDisclosureProps) {
  return (
    <NutritionMatrix
      matrixId={matrixId}
      recipeTitle={recipeTitle}
      matrix={matrix}
      showExtendedColumns={isExpanded}
      surfaceTone={surfaceTone}
    />
  );
});
