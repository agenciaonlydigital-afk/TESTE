import { memo, useEffect, useState } from 'react';
import { motion, useMotionValueEvent, useTransform, type MotionValue } from 'motion/react';
import { computeGatefoldFrame } from '../hooks/useFolioChoreography';
import { useMaterialSurfaceLayers } from '../hooks/useMaterialSurface';
import type { MaterialSkinId } from '../materials/material-surface.types';
import { cardapiosMaterials, cardapiosMaterialSkins } from '../styles/cardapios.tokens';

interface RecipeFolio3DRevealProps {
  progress: MotionValue<number>;
  isCardOpen: boolean;
  skin: MaterialSkinId;
  reduceMotion: boolean;
}

/**
 * Michelin 3-Star Double-Gatefold Tasting Folio 3D Choreography (`0 < progress < 1`):
 * - Closed: Twin full-height Morocco goatskin doors meet at a central champagne gold seam.
 * - Unfolding: Left door swings outward left (`0 -> -156 deg`) around its outer left hinge and
 *   right door swings outward right (`0 -> +156 deg`) around its outer right hinge—parting
 *   symmetrically along the vertical axis with zero collision and unveiling the full dish
 *   cotton-rag carte cleanly without slicing through the header or table.
 */
export const RecipeFolio3DReveal = memo(function RecipeFolio3DReveal({
  progress,
  isCardOpen,
  skin,
  reduceMotion,
}: RecipeFolio3DRevealProps) {
  const [active, setActive] = useState(() => {
    const p = progress.get();
    return p > 0.001 && p < 0.999;
  });

  useEffect(() => {
    if (!reduceMotion) {
      const p = progress.get();
      const target = isCardOpen ? 1 : 0;
      if (Math.abs(p - target) > 0.001) {
        setActive(true);
      }
    }
  }, [isCardOpen, reduceMotion, progress]);

  useMotionValueEvent(progress, 'change', (latest) => {
    const nextActive = latest > 0.001 && latest < 0.999;
    setActive((prev) => (prev === nextActive ? prev : nextActive));
  });

  const leatherAssets = useMaterialSurfaceLayers(skin, 'folio-back', !reduceMotion);
  const paperAssets = useMaterialSurfaceLayers(skin, 'folio-front', !reduceMotion);

  const overlayOpacity = useTransform(progress, (p) => computeGatefoldFrame(p).overlayOpacity);
  const doorsOpacity = useTransform(progress, (p) => computeGatefoldFrame(p).doorsOpacity);
  const leftDoorY = useTransform(progress, (p) => computeGatefoldFrame(p).leftDoorRotateYDeg);
  const rightDoorY = useTransform(progress, (p) => computeGatefoldFrame(p).rightDoorRotateYDeg);
  const doorSpecular = useTransform(progress, (p) => computeGatefoldFrame(p).doorSpecularOpacity);
  const innerShadow = useTransform(progress, (p) => computeGatefoldFrame(p).innerShadowOpacity);
  const seamGlow = useTransform(progress, (p) => computeGatefoldFrame(p).seamGlowOpacity);

  const pendingTransition =
    !reduceMotion && Math.abs(progress.get() - (isCardOpen ? 1 : 0)) > 0.001;

  if (reduceMotion || (!active && !pendingTransition)) {
    return null;
  }

  const paperTileStyle = {
    backgroundColor: cardapiosMaterialSkins.maison.paperNatural,
    backgroundImage: paperAssets ? `url(${paperAssets.tileUri})` : undefined,
    backgroundRepeat: 'repeat' as const,
    backgroundSize: paperAssets ? `${paperAssets.tileSizeCss}px ${paperAssets.tileSizeCss}px` : undefined,
  };

  const leatherTileStyle = {
    backgroundColor: cardapiosMaterialSkins.maison.leatherLowlight,
    backgroundImage: leatherAssets ? `url(${leatherAssets.tileUri})` : undefined,
    backgroundRepeat: 'repeat' as const,
    backgroundSize: leatherAssets ? `${leatherAssets.tileSizeCss}px ${leatherAssets.tileSizeCss}px` : undefined,
  };

  const leatherFrameStyle = leatherAssets?.frameUri
    ? {
        boxSizing: 'border-box' as const,
        borderStyle: 'solid' as const,
        borderColor: 'transparent',
        borderWidth: 24,
        borderImageSource: `url(${leatherAssets.frameUri})`,
        borderImageSlice: leatherAssets.frameSlicePx,
        borderImageWidth: '24px',
        borderImageRepeat: 'round' as const,
      }
    : null;

  const leatherEdgeColor = cardapiosMaterials.recipeClosedCover.borderColor;
  const paperEdgeColor = cardapiosMaterialSkins.maison.paperRule;

  return (
    <motion.div
      aria-hidden="true"
      className="pointer-events-none select-none absolute inset-0 z-30 rounded-[14px] overflow-visible"
      style={{
        opacity: overlayOpacity,
        perspective: 1600,
        perspectiveOrigin: '50% 42%',
        transformStyle: 'preserve-3d',
      }}
    >
      {/* Cast occlusion shadow over the revealed cotton-rag sheet as twin doors part */}
      <motion.div
        className="absolute inset-0 rounded-[14px]"
        style={{
          opacity: innerShadow,
          backgroundColor: '#0A100E',
          transform: 'translateZ(1px)',
        }}
      />

      {/* Left Gatefold Door hinged along outer-left edge (0 -> -156 deg) */}
      <motion.div
        className="absolute left-0 inset-y-0 w-1/2"
        style={{
          transformOrigin: 'left center',
          transformStyle: 'preserve-3d',
          rotateY: leftDoorY,
          opacity: doorsOpacity,
          z: 8,
        }}
      >
        {/* Outer Morocco goatskin door face (visible closed -> swinging open) */}
        <div
          className="absolute inset-0 rounded-l-[14px] border-y border-l overflow-hidden"
          style={{
            ...leatherTileStyle,
            borderColor: leatherEdgeColor,
            transform: 'translateZ(0.8px)',
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden',
            boxShadow: '6px 14px 28px rgba(0, 0, 0, 0.48)',
          }}
        >
          {leatherFrameStyle ? <div className="absolute inset-0" style={leatherFrameStyle} /> : null}
          <div
            className="absolute inset-y-3 right-0 w-[1px]"
            style={{ backgroundColor: cardapiosMaterialSkins.maison.goldHairline }}
          />
          <motion.div
            className="absolute inset-0 rounded-l-[14px]"
            style={{ opacity: doorSpecular, backgroundColor: '#FFE8BA' }}
          />
        </div>

        {/* Inner cotton-vellum endpaper (revealed once door swings past 90 deg) */}
        <div
          className="absolute inset-0 rounded-r-[14px] border overflow-hidden"
          style={{
            ...paperTileStyle,
            borderColor: paperEdgeColor,
            transform: 'rotateY(180deg) translateZ(0.8px)',
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden',
            boxShadow: '0 12px 28px rgba(0, 0, 0, 0.36)',
          }}
        >
          <div
            className="absolute inset-3 rounded-[8px] border"
            style={{ borderColor: paperEdgeColor }}
          />
          <motion.div
            className="absolute inset-0 rounded-r-[14px]"
            style={{ opacity: doorSpecular, backgroundColor: '#FFF5DF' }}
          />
        </div>
      </motion.div>

      {/* Right Gatefold Door hinged along outer-right edge (0 -> +156 deg) */}
      <motion.div
        className="absolute right-0 inset-y-0 w-1/2"
        style={{
          transformOrigin: 'right center',
          transformStyle: 'preserve-3d',
          rotateY: rightDoorY,
          opacity: doorsOpacity,
          z: 8.5,
        }}
      >
        {/* Outer Morocco goatskin door face */}
        <div
          className="absolute inset-0 rounded-r-[14px] border-y border-r overflow-hidden"
          style={{
            ...leatherTileStyle,
            borderColor: leatherEdgeColor,
            transform: 'translateZ(0.8px)',
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden',
            boxShadow: '-6px 14px 28px rgba(0, 0, 0, 0.48)',
          }}
        >
          {leatherFrameStyle ? <div className="absolute inset-0" style={leatherFrameStyle} /> : null}
          <div
            className="absolute inset-y-3 left-0 w-[1px]"
            style={{ backgroundColor: cardapiosMaterialSkins.maison.goldHairline }}
          />
          <motion.div
            className="absolute inset-0 rounded-r-[14px]"
            style={{ opacity: doorSpecular, backgroundColor: '#FFE8BA' }}
          />
        </div>

        {/* Inner cotton-vellum endpaper */}
        <div
          className="absolute inset-0 rounded-l-[14px] border overflow-hidden"
          style={{
            ...paperTileStyle,
            borderColor: paperEdgeColor,
            transform: 'rotateY(180deg) translateZ(0.8px)',
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden',
            boxShadow: '0 12px 28px rgba(0, 0, 0, 0.36)',
          }}
        >
          <div
            className="absolute inset-3 rounded-[8px] border"
            style={{ borderColor: paperEdgeColor }}
          />
          <motion.div
            className="absolute inset-0 rounded-l-[14px]"
            style={{ opacity: doorSpecular, backgroundColor: '#FFF5DF' }}
          />
        </div>
      </motion.div>

      {/* Subtle Champagne Gold Meeting Seam catching light as gatefold unlatches */}
      <motion.div
        className="absolute inset-y-2 left-1/2 w-[1px]"
        style={{
          opacity: seamGlow,
          backgroundColor: cardapiosMaterialSkins.maison.goldTooling,
          z: 14,
        }}
      />
    </motion.div>
  );
});
