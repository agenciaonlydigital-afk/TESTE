import { memo, useRef } from 'react';
import {
  ACTIVE_CARDAPIOS_MATERIAL_SKIN,
  cardapiosMaterials,
  cardapiosMaterialSkins,
} from '../styles/cardapios.tokens';
import type { MenuGroupViewModel } from '../types/cardapios.types';
import { MaterialSurfaceLayer } from './MaterialSurfaceLayer';
import { RecipeCard } from './RecipeCard';

interface MenuGroupProps {
  menu: MenuGroupViewModel;
  isCardExpanded: (recipeId: string, defaultExpanded: boolean) => boolean;
  onToggleCard: (recipeId: string, defaultExpanded: boolean) => void;
  isRecipeExpanded: (recipeId: string, defaultExpanded?: boolean) => boolean;
  onToggleMatrix: (recipeId: string, defaultExpanded?: boolean) => void;
}

const MENU_SHELL_SAFE_INSETS = { top: 14, right: 14, bottom: 14, left: 14 } as const;

export const MenuGroup = memo(function MenuGroup({
  menu,
  isCardExpanded,
  onToggleCard,
  isRecipeExpanded,
  onToggleMatrix,
}: MenuGroupProps) {
  const shellRef = useRef<HTMLElement | null>(null);

  return (
    <section
      ref={shellRef}
      aria-label={menu.code}
      className="relative overflow-visible rounded-[18px] border p-4 sm:p-6 space-y-4"
      style={{
        backgroundColor: cardapiosMaterials.cardapioShell.backgroundColor,
        borderColor: cardapiosMaterials.cardapioShell.borderColor,
        boxShadow: cardapiosMaterials.cardapioShell.boxShadow,
      }}
    >
      <MaterialSurfaceLayer
        containerRef={shellRef}
        skin={ACTIVE_CARDAPIOS_MATERIAL_SKIN}
        region="menu-shell"
        contentSafeInsets={MENU_SHELL_SAFE_INSETS}
      />

      {/* Título prensado a quente no couro com filetes champagne laterais (estilo Maison 3 estrelas) */}
      <header className="relative z-10 flex items-center justify-center gap-4 pb-1">
        <span
          className="h-[1px] flex-1"
          style={{ backgroundColor: cardapiosMaterialSkins.maison.goldHairline }}
          aria-hidden="true"
        />
        <div
          className="inline-flex items-center justify-center rounded-[8px] border px-4 py-1.5"
          style={{
            backgroundColor: cardapiosMaterials.debossPlate.backgroundColor,
            borderColor: cardapiosMaterials.debossPlate.borderColor,
            boxShadow: cardapiosMaterials.debossPlate.boxShadow,
          }}
        >
          <h2
            className="font-editorial text-[16px] sm:text-[18px] font-semibold tracking-[0.22em] uppercase leading-none m-0"
            style={{
              color: cardapiosMaterialSkins.maison.leatherDebossInk,
              textShadow: cardapiosMaterials.debossPlate.textShadow,
            }}
          >
            {menu.code}
          </h2>
        </div>
        <span
          className="h-[1px] flex-1"
          style={{ backgroundColor: cardapiosMaterialSkins.maison.goldHairline }}
          aria-hidden="true"
        />
      </header>

      <div className="relative z-10 space-y-3.5">
        {menu.recipes.map((recipe, index) => {
          const cardOpen = isCardExpanded(recipe.recipeId, recipe.isNextToConsume);
          return (
            <RecipeCard
              key={recipe.recipeId}
              recipe={recipe}
              courseNumber={index + 1}
              isCardOpen={cardOpen}
              isMatrixExpanded={isRecipeExpanded(recipe.recipeId, cardOpen)}
              onToggleCard={onToggleCard}
              onToggleMatrix={onToggleMatrix}
            />
          );
        })}
      </div>
    </section>
  );
});
