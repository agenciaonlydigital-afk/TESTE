import { memo, useCallback, useMemo, useRef, type PointerEvent } from 'react';
import { buildMatrixCellA11yLabel } from '../accessibility/cardapios.accessibility';
import {
  ACTIVE_CARDAPIOS_MATERIAL_SKIN,
  cardapiosMaterials,
  cardapiosMaterialSkins,
  cardapiosTokens,
  formatMatrixCellDisplay,
  formatNutrientNumberPtBr,
} from '../styles/cardapios.tokens';
import type { NutritionGroupId, NutritionMatrixViewModel } from '../types/cardapios.types';
import { MaterialSurfaceLayer } from './MaterialSurfaceLayer';

interface NutritionMatrixProps {
  matrixId: string;
  recipeTitle: string;
  matrix: NutritionMatrixViewModel;
  showExtendedColumns?: boolean;
  surfaceTone?: 'paper' | 'dark';
}

interface ColumnGroupSpan {
  groupId: NutritionGroupId;
  groupLabel: string;
  colSpan: number;
  widthPx: number;
}

const CORE_COLUMN_IDS = new Set(['food', 'quantity', 'kcal', 'protein', 'carbs', 'fat']);
const MATRIX_SAFE_INSETS = { top: 6, right: 6, bottom: 6, left: 6 } as const;

function parseGramsFromDisplay(display: string): number | null {
  const match = display.match(/^\s*([\d.,]+)\s*g\s*$/i);
  if (!match) return null;
  const normalized = match[1]!.replace(/\./g, '').replace(',', '.');
  const num = Number(normalized);
  return Number.isFinite(num) ? num : null;
}

export const NutritionMatrix = memo(function NutritionMatrix({
  matrixId,
  recipeTitle,
  matrix,
  showExtendedColumns = true,
  surfaceTone = 'paper',
}: NutritionMatrixProps) {
  const matrixRef = useRef<HTMLDivElement | null>(null);
  const scrollerRef = useRef<HTMLDivElement | null>(null);
  const dragStateRef = useRef<{ active: boolean; startX: number; scrollLeft: number }>({
    active: false,
    startX: 0,
    scrollLeft: 0,
  });

  const visibleColumns = useMemo(
    () =>
      showExtendedColumns
        ? matrix.columns
        : matrix.columns.filter((col) => CORE_COLUMN_IDS.has(col.nutrientId)),
    [matrix.columns, showExtendedColumns],
  );

  const { rows } = matrix;
  const hasExtended = showExtendedColumns && visibleColumns.length > 6;

  const isPaper = surfaceTone === 'paper';
  const inkPrimary = isPaper ? cardapiosMaterialSkins.maison.paperInk : cardapiosTokens.textPrimary;
  const inkSecondary = isPaper
    ? cardapiosMaterialSkins.maison.paperInkSecondary
    : cardapiosTokens.textSecondary;
  const inkMuted = isPaper ? cardapiosMaterialSkins.maison.paperInkMuted : cardapiosTokens.textMuted;
  const ruleColor = isPaper ? cardapiosMaterialSkins.maison.paperRule : cardapiosTokens.borderSubtle;
  const strongRuleColor = isPaper
    ? cardapiosMaterialSkins.maison.goldHairline
    : cardapiosTokens.borderSubtle;
  const bodyBg = isPaper
    ? cardapiosMaterials.nutritionMatrix.backgroundColor
    : cardapiosTokens.surfaceRaised;
  const altRowBg = isPaper
    ? cardapiosMaterials.nutritionMatrix.altRowBackgroundColor
    : cardapiosTokens.surfacePrimary;
  const totalRowBg = isPaper
    ? cardapiosMaterials.nutritionMatrix.totalRowBackgroundColor
    : cardapiosTokens.surfacePrimary;
  const headerBg = isPaper
    ? cardapiosMaterials.nutritionMatrix.headerBackgroundColor
    : cardapiosTokens.surfacePrimary;

  const groupSpans = useMemo<ColumnGroupSpan[]>(() => {
    const spans: ColumnGroupSpan[] = [];
    for (const col of visibleColumns) {
      const last = spans[spans.length - 1];
      if (last && last.groupId === col.groupId) {
        last.colSpan += 1;
        last.widthPx += col.widthPx;
      } else {
        spans.push({
          groupId: col.groupId,
          groupLabel: col.groupLabel,
          colSpan: 1,
          widthPx: col.widthPx,
        });
      }
    }
    return spans;
  }, [visibleColumns]);

  const totalTableWidth = useMemo(
    () => visibleColumns.reduce((sum, col) => sum + col.widthPx, 0),
    [visibleColumns],
  );

  const columnTotals = useMemo(() => {
    let totalGrams = 0;
    let hasAnyGrams = false;
    const sums: Record<string, { total: number; hasValue: boolean; unit: string | null }> = {};

    for (const col of visibleColumns) {
      if (col.nutrientId === 'food' || col.nutrientId === 'quantity') continue;
      sums[col.nutrientId] = { total: 0, hasValue: false, unit: col.unit };
    }

    for (const row of rows) {
      const parsedG = parseGramsFromDisplay(row.quantityDisplay);
      if (parsedG !== null) {
        totalGrams += parsedG;
        hasAnyGrams = true;
      }
      for (const col of visibleColumns) {
        if (col.nutrientId === 'food' || col.nutrientId === 'quantity') continue;
        const cell = row.cells[col.nutrientId];
        if (
          cell &&
          (cell.status === 'measured' || cell.status === 'true-zero') &&
          cell.value !== null &&
          Number.isFinite(cell.value)
        ) {
          const entry = sums[col.nutrientId]!;
          entry.total += cell.value;
          entry.hasValue = true;
        }
      }
    }

    return {
      quantityText: hasAnyGrams ? `${formatNutrientNumberPtBr(totalGrams, 'g')} g` : '—',
      sums,
    };
  }, [rows, visibleColumns]);

  const handlePointerDown = useCallback((event: PointerEvent<HTMLDivElement>) => {
    if (event.pointerType === 'touch') return;
    const el = scrollerRef.current;
    if (!el || el.scrollWidth <= el.clientWidth) return;
    dragStateRef.current = {
      active: true,
      startX: event.clientX,
      scrollLeft: el.scrollLeft,
    };
  }, []);

  const handlePointerMove = useCallback((event: PointerEvent<HTMLDivElement>) => {
    const state = dragStateRef.current;
    const el = scrollerRef.current;
    if (!state.active || !el) return;
    el.scrollLeft = state.scrollLeft - (event.clientX - state.startX);
  }, []);

  const handlePointerEnd = useCallback(() => {
    dragStateRef.current.active = false;
  }, []);

  return (
    <div
      ref={matrixRef}
      id={matrixId}
      className="relative rounded-[10px] border overflow-hidden"
      style={{
        backgroundColor: bodyBg,
        borderColor: ruleColor,
      }}
    >
      <MaterialSurfaceLayer
        containerRef={matrixRef}
        skin={ACTIVE_CARDAPIOS_MATERIAL_SKIN}
        region="nutrition-matrix"
        contentSafeInsets={MATRIX_SAFE_INSETS}
      />
      <div
        ref={scrollerRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerEnd}
        onPointerCancel={handlePointerEnd}
        onPointerLeave={handlePointerEnd}
        className={`relative z-10 overflow-x-auto titan-no-scrollbar ${
          hasExtended ? 'cursor-grab active:cursor-grabbing' : ''
        }`}
      >
        <table
          className="w-full border-collapse text-left"
          style={{
            minWidth: `${totalTableWidth}px`,
            width: hasExtended ? `${totalTableWidth}px` : '100%',
            tableLayout: hasExtended ? 'fixed' : 'auto',
          }}
        >
          <caption className="sr-only">
            Composição nutricional de {recipeTitle}
          </caption>
          <colgroup>
            {visibleColumns.map((col) => (
              <col
                key={col.nutrientId}
                style={{
                  width: hasExtended
                    ? `${col.widthPx}px`
                    : col.nutrientId === 'food'
                      ? '34%'
                      : undefined,
                }}
              />
            ))}
          </colgroup>
          <thead>
            {hasExtended ? (
              <tr
                className="border-b"
                style={{
                  backgroundColor: headerBg,
                  borderColor: ruleColor,
                }}
              >
                {groupSpans.map((group) => (
                  <th
                    key={group.groupId}
                    colSpan={group.colSpan}
                    scope="colgroup"
                    className={`px-3.5 py-2 text-[10px] font-semibold uppercase tracking-[0.14em] border-r last:border-r-0 ${
                      group.groupId === 'base' ? 'sticky left-0 z-20' : ''
                    }`}
                    style={{
                      color: inkMuted,
                      borderColor: ruleColor,
                      backgroundColor: headerBg,
                    }}
                  >
                    {group.groupLabel}
                  </th>
                ))}
              </tr>
            ) : null}
            <tr
              className="border-b"
              style={{
                backgroundColor: headerBg,
                borderColor: strongRuleColor,
              }}
            >
              {visibleColumns.map((col, idx) => {
                const isFood = col.nutrientId === 'food';
                const isNumeric = idx >= 1;
                const displayLabel =
                  col.nutrientId === 'quantity'
                    ? 'Porção'
                    : col.nutrientId === 'kcal'
                      ? 'Energia'
                      : col.label;
                return (
                  <th
                    key={col.nutrientId}
                    scope="col"
                    className={`px-3.5 py-2.5 text-[11px] font-semibold uppercase tracking-[0.08em] align-bottom border-r last:border-r-0 ${
                      isFood ? 'sticky left-0 z-20 text-left' : isNumeric ? 'text-right' : 'text-left'
                    }`}
                    style={{
                      color: inkPrimary,
                      borderColor: ruleColor,
                      backgroundColor: headerBg,
                    }}
                  >
                    <span className="block leading-tight">{displayLabel}</span>
                    {col.unit ? (
                      <span
                        className="block text-[10px] font-normal lowercase tracking-normal mt-0.5"
                        style={{ color: inkMuted }}
                      >
                        ({col.unit})
                      </span>
                    ) : null}
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {rows.map((row, rowIdx) => {
              const rowBg = rowIdx % 2 === 1 ? altRowBg : bodyBg;
              return (
                <tr
                  key={row.ingredientId}
                  className="border-b last:border-b-0"
                  style={{
                    borderColor: ruleColor,
                    backgroundColor: rowBg,
                  }}
                >
                  {visibleColumns.map((col) => {
                    if (col.nutrientId === 'food') {
                      return (
                        <th
                          key={col.nutrientId}
                          scope="row"
                          className="sticky left-0 z-10 px-3.5 py-2.5 text-[13px] font-medium leading-snug text-left align-middle border-r"
                          style={{
                            color: inkPrimary,
                            borderColor: ruleColor,
                            backgroundColor: rowBg,
                          }}
                        >
                          {row.foodName}
                        </th>
                      );
                    }
                    if (col.nutrientId === 'quantity') {
                      return (
                        <td
                          key={col.nutrientId}
                          className="px-3.5 py-2.5 text-[12px] font-mono-metric tabular-nums text-right align-middle whitespace-nowrap border-r"
                          style={{
                            color: inkSecondary,
                            borderColor: ruleColor,
                          }}
                        >
                          {row.quantityDisplay}
                        </td>
                      );
                    }

                    const cell = row.cells[col.nutrientId];
                    const formatted = cell
                      ? formatMatrixCellDisplay(cell.value, cell.status, cell.unit)
                      : { text: '—', title: 'Não fornecido pela fonte' };
                    const isUnquantified =
                      !cell || (cell.status !== 'measured' && cell.status !== 'true-zero');
                    const cellA11yLabel = buildMatrixCellA11yLabel(
                      col.label,
                      col.unit,
                      formatted.text,
                      cell?.status,
                      formatted.title,
                    );

                    return (
                      <td
                        key={col.nutrientId}
                        title={formatted.title}
                        aria-label={cellA11yLabel}
                        className="px-3.5 py-2.5 text-[12px] font-mono-metric tabular-nums text-right align-middle whitespace-nowrap border-r last:border-r-0"
                        style={{
                          color: isUnquantified ? inkMuted : inkPrimary,
                          borderColor: ruleColor,
                        }}
                      >
                        {formatted.text}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
          <tfoot>
            <tr
              className="border-t-2"
              style={{
                backgroundColor: totalRowBg,
                borderColor: strongRuleColor,
              }}
            >
              {visibleColumns.map((col) => {
                if (col.nutrientId === 'food') {
                  return (
                    <th
                      key={col.nutrientId}
                      scope="row"
                      className="sticky left-0 z-10 px-3.5 py-2.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-left border-r"
                      style={{
                        color: inkPrimary,
                        borderColor: ruleColor,
                        backgroundColor: totalRowBg,
                      }}
                    >
                      Total do prato
                    </th>
                  );
                }
                if (col.nutrientId === 'quantity') {
                  return (
                    <td
                      key={col.nutrientId}
                      className="px-3.5 py-2.5 text-[12px] font-semibold font-mono-metric tabular-nums text-right whitespace-nowrap border-r"
                      style={{
                        color: inkPrimary,
                        borderColor: ruleColor,
                      }}
                    >
                      {columnTotals.quantityText}
                    </td>
                  );
                }
                const sumEntry = columnTotals.sums[col.nutrientId];
                const totalText =
                  sumEntry && sumEntry.hasValue
                    ? formatNutrientNumberPtBr(sumEntry.total, sumEntry.unit)
                    : '—';

                return (
                  <td
                    key={col.nutrientId}
                    className="px-3.5 py-2.5 text-[12px] font-semibold font-mono-metric tabular-nums text-right whitespace-nowrap border-r last:border-r-0"
                    style={{
                      color: sumEntry?.hasValue ? inkPrimary : inkMuted,
                      borderColor: ruleColor,
                    }}
                  >
                    {totalText}
                  </td>
                );
              })}
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
});
