import { memo, type RefObject } from 'react';
import { useMaterialSurfaceLayers } from '../hooks/useMaterialSurface';
import type {
  ContentSafeInsets,
  MaterialRegion,
  MaterialSkinId,
} from '../materials/material-surface.types';

interface MaterialSurfaceLayerProps {
  containerRef: RefObject<HTMLElement | null>;
  skin: MaterialSkinId;
  region: MaterialRegion;
  contentSafeInsets?: ContentSafeInsets;
}

/**
 * Pure background PBR surface layer mounted strictly inside existing containers:
 * - Zero layout participation (`pointer-events-none`, `aria-hidden="true"`)
 * - Seamless 512px WebGL2 PBR tile (`repeat`, zero squash/stretch at any height or width)
 * - Phase-locked Retina 2x 9-slice frame (`border-image-repeat: round`) so corners,
 *   3D Couture Sellier saddle stitches & metallic gold foil never distort
 * - Vertical seamless French-joint spine hinge strip on bound recipe covers
 * - Falls back silently to opaque solid CSS container fill on SSR or non-WebGL
 */
export const MaterialSurfaceLayer = memo(function MaterialSurfaceLayer({
  skin,
  region,
}: MaterialSurfaceLayerProps) {
  const assets = useMaterialSurfaceLayers(skin, region, true);

  if (!assets) {
    return null;
  }

  return (
    <div
      aria-hidden="true"
      className="pointer-events-none select-none absolute inset-0 overflow-hidden rounded-[inherit]"
      style={{ zIndex: 0 }}
    >
      {/* Layer A: Seamless 1:1 WebGL2 PBR leather or cotton rag tile (never stretches) */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: `url(${assets.tileUri})`,
          backgroundRepeat: 'repeat',
          backgroundSize: `${assets.tileSizeCss}px ${assets.tileSizeCss}px`,
        }}
      />

      {/* Layer B: Phase-locked Retina 2x 9-slice PBR frame (bevel, 3D stitching, gold fillet) */}
      {assets.frameUri ? (
        <div
          className="absolute inset-0"
          style={{
            boxSizing: 'border-box',
            borderStyle: 'solid',
            borderColor: 'transparent',
            borderWidth: assets.frameWidthCss,
            borderImageSource: `url(${assets.frameUri})`,
            borderImageSlice: assets.frameSlicePx,
            borderImageWidth: `${assets.frameWidthCss}px`,
            borderImageRepeat: 'round',
          }}
        />
      ) : null}

      {/* Layer C: Optional French-joint bound spine hinge strip along left edge (repeat-y) */}
      {assets.spineUri ? (
        <div
          className="absolute inset-y-0 left-0"
          style={{
            width: assets.spineWidthCss,
            backgroundImage: `url(${assets.spineUri})`,
            backgroundRepeat: 'repeat-y',
            backgroundSize: `${assets.spineWidthCss}px ${assets.spineHeightCss}px`,
          }}
        />
      ) : null}
    </div>
  );
});
