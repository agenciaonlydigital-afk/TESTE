import { memo, useId, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { TITAN_MOTION_VARIANTS } from '../../../../../shared/motion/titan-motion';
import { buildPreparationActionA11yProps } from '../accessibility/cardapios.accessibility';
import {
  cardapiosMaterials,
  cardapiosMaterialSkins,
  cardapiosTokens,
} from '../styles/cardapios.tokens';
import type { PreparationViewModel } from '../types/cardapios.types';

interface RecipePreparationActionProps {
  recipeTitle: string;
  preparation: PreparationViewModel | null;
  surfaceTone?: 'paper' | 'dark';
}

export const RecipePreparationAction = memo(function RecipePreparationAction({
  recipeTitle,
  preparation,
  surfaceTone = 'paper',
}: RecipePreparationActionProps) {
  const [open, setOpen] = useState(false);
  const [hovered, setHovered] = useState(false);
  const [pressed, setPressed] = useState(false);
  const panelId = useId();
  const a11yProps = buildPreparationActionA11yProps(recipeTitle, panelId, open);

  const isPaper = surfaceTone === 'paper';
  const primaryInk = isPaper ? cardapiosMaterialSkins.maison.paperInk : cardapiosTokens.textPrimary;
  const secondaryInk = isPaper
    ? cardapiosMaterialSkins.maison.paperInkSecondary
    : cardapiosTokens.textSecondary;
  const ruleColor = isPaper ? cardapiosMaterialSkins.maison.paperRule : cardapiosTokens.borderSubtle;

  return (
    <div className="pt-3 border-t" style={{ borderColor: ruleColor }}>
      <motion.button
        type="button"
        onClick={() => setOpen((prev) => !prev)}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => {
          setHovered(false);
          setPressed(false);
        }}
        onPointerDown={() => setPressed(true)}
        onPointerUp={() => setPressed(false)}
        onPointerCancel={() => setPressed(false)}
        animate={{ opacity: pressed ? 0.86 : hovered ? 0.93 : 1 }}
        transition={{ duration: 0.095, ease: [0.33, 1, 0.68, 1] }}
        {...a11yProps}
        className="w-full sm:w-auto min-h-[44px] px-5 py-2.5 rounded-[10px] border text-[13px] font-semibold tracking-tight inline-flex items-center justify-center focus-visible:outline-2 focus-visible:outline-offset-2"
        style={{
          backgroundColor: cardapiosMaterials.primaryAction.backgroundColor,
          color: cardapiosMaterials.primaryAction.color,
          borderColor: cardapiosMaterials.primaryAction.borderColor,
          boxShadow: cardapiosMaterials.primaryAction.boxShadow,
          outlineColor: primaryInk,
        }}
      >
        Receita e Preparo
      </motion.button>

      <AnimatePresence initial={false}>
        {open ? (
          <motion.div
            key="recipe-preparation-panel"
            id={panelId}
            initial={TITAN_MOTION_VARIANTS.panel.initial}
            animate={TITAN_MOTION_VARIANTS.panel.animate}
            exit={TITAN_MOTION_VARIANTS.panel.exit}
            className="overflow-hidden"
          >
            <div
              className="mt-3 pt-3 border-t text-[13px] leading-relaxed"
              style={{
                borderColor: ruleColor,
                color: secondaryInk,
              }}
            >
              {preparation && preparation.steps.length > 0 ? (
                <ol className="list-decimal list-inside space-y-1.5">
                  {preparation.steps.map((step) => (
                    <li key={step.stepNumber} style={{ color: primaryInk }}>
                      {step.instruction}
                    </li>
                  ))}
                </ol>
              ) : (
                <p style={{ color: secondaryInk }}>
                  Modo de preparo não cadastrado na ficha técnica desta receita.
                  {preparation?.totalPortionDisplay
                    ? ` Porção total composta: ${preparation.totalPortionDisplay}.`
                    : ''}
                </p>
              )}
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </div>
  );
});
