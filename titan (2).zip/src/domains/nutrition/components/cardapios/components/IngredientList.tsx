import { memo } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { cardapiosMaterialSkins, cardapiosTokens } from '../styles/cardapios.tokens';
import type { IngredientRowViewModel } from '../types/cardapios.types';

interface IngredientListProps {
  ingredients: readonly IngredientRowViewModel[];
  surfaceTone?: 'paper' | 'dark';
}

export const IngredientList = memo(function IngredientList({
  ingredients,
  surfaceTone = 'paper',
}: IngredientListProps) {
  const isPaper = surfaceTone === 'paper';
  const primaryInk = isPaper ? cardapiosMaterialSkins.maison.paperInk : cardapiosTokens.textPrimary;
  const secondaryInk = isPaper
    ? cardapiosMaterialSkins.maison.paperInkSecondary
    : cardapiosTokens.textSecondary;
  const mutedInk = isPaper ? cardapiosMaterialSkins.maison.paperInkMuted : cardapiosTokens.textMuted;
  const ruleColor = isPaper ? cardapiosMaterialSkins.maison.paperRule : cardapiosTokens.borderSubtle;

  return (
    <ul
      aria-label="Ingredientes da receita"
      className="divide-y"
      style={{ borderColor: ruleColor }}
    >
      {ingredients.map((ingredient) => (
        <li
          key={ingredient.ingredientId}
          className="flex items-baseline justify-between gap-4 py-2 first:pt-1 last:pb-1"
          style={{ borderColor: ruleColor }}
        >
          <span
            className="text-[13px] font-medium leading-snug min-w-0"
            style={{ color: primaryInk }}
          >
            {ingredient.foodDisplayName}
          </span>
          <AnimatePresence initial={false} mode="popLayout">
            <motion.span
              key={`${ingredient.ingredientId}:${ingredient.quantity.display}`}
              initial={{ opacity: 0.4 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.125, ease: [0.33, 1, 0.68, 1] }}
              className="text-[13px] font-mono-metric tabular-nums shrink-0 whitespace-nowrap"
              style={{
                color: ingredient.quantity.value === null ? mutedInk : secondaryInk,
              }}
            >
              {ingredient.quantity.display}
            </motion.span>
          </AnimatePresence>
        </li>
      ))}
    </ul>
  );
});
