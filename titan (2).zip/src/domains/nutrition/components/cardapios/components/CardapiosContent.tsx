import { memo, useEffect, useMemo, useRef } from 'react';
import { AnimatePresence, MotionConfig } from 'motion/react';
import type { MacroFitProposalSnapshot } from '../../../application/macro-target-fit-service';
import { useRecipeCardExpansion } from '../hooks/useRecipeCardExpansion';
import { useRecipeMatrixExpansion } from '../hooks/useRecipeMatrixExpansion';
import { materialSurfaceRenderer2D } from '../materials/material-surface-renderer';
import {
  ACTIVE_CARDAPIOS_MATERIAL_SKIN,
  cardapiosMaterials,
  cardapiosMaterialSkins,
  cardapiosTokens,
} from '../styles/cardapios.tokens';
import type { CardapiosViewModel } from '../types/cardapios.types';
import { prefetchVisibleRecipePhotos } from '../utils/recipe-image-prefetch';
import { MacroFitProposalBanner } from './MacroFitProposalBanner';
import { MaterialSurfaceLayer } from './MaterialSurfaceLayer';
import { MealHistory } from './MealHistory';
import { MenuGroup } from './MenuGroup';

interface MacroFitControlProps {
  snapshot: MacroFitProposalSnapshot;
  canUndo: boolean;
  justApplied: boolean;
  errorFeedback?: string | null;
  onApply: () => void;
  onDismiss: () => void;
  onUndo: () => void;
}

interface CardapiosContentProps {
  viewModel: CardapiosViewModel;
  macroFitControl?: MacroFitControlProps | null;
}

export const CardapiosContent = memo(function CardapiosContent({
  viewModel,
  macroFitControl,
}: CardapiosContentProps) {
  const mastheadRef = useRef<HTMLElement | null>(null);
  const { isCardExpanded, toggleCardExpansion, pruneRemovedCards } = useRecipeCardExpansion();
  const { isRecipeExpanded, toggleRecipeMatrix, pruneRemovedMatrices } = useRecipeMatrixExpansion();

  const activeRecipeIds = useMemo(
    () => viewModel.menus.flatMap((menu) => menu.recipes.map((recipe) => recipe.recipeId)),
    [viewModel.menus],
  );

  const visiblePhotoUris = useMemo(
    () => viewModel.menus.flatMap((menu) => menu.recipes.map((recipe) => recipe.image.uri)),
    [viewModel.menus],
  );

  useEffect(() => {
    pruneRemovedCards(activeRecipeIds);
    pruneRemovedMatrices(activeRecipeIds);
  }, [activeRecipeIds, pruneRemovedCards, pruneRemovedMatrices]);

  useEffect(() => {
    prefetchVisibleRecipePhotos(visiblePhotoUris);
  }, [visiblePhotoUris]);

  useEffect(() => {
    return () => {
      materialSurfaceRenderer2D.clearUnusedCache();
    };
  }, []);

  return (
    <MotionConfig reducedMotion="user">
      <div
        className="-mx-[14px] -mt-[14px] px-[14px] pt-[14px] pb-24 md:-mx-[28px] md:-mt-[24px] md:px-[28px] md:pt-[24px] md:pb-12 min-h-full space-y-6"
        style={{ backgroundColor: cardapiosTokens.canvasPrimary }}
      >
        {/* Capa Haute Reliure com palavra "Cardápios" prensada a quente (blind deboss) */}
        <header
          ref={mastheadRef}
          className="relative overflow-hidden rounded-[18px] border px-5 py-6 sm:py-7 text-center"
          style={{
            backgroundColor: cardapiosMaterials.cardapioShell.backgroundColor,
            borderColor: cardapiosMaterials.cardapioShell.borderColor,
            boxShadow: cardapiosMaterials.cardapioShell.boxShadow,
          }}
        >
          <MaterialSurfaceLayer
            containerRef={mastheadRef}
            skin={ACTIVE_CARDAPIOS_MATERIAL_SKIN}
            region="menu-shell"
          />

          <div className="relative z-10 flex flex-col items-center justify-center gap-3">
            <div className="flex items-center justify-center gap-3 w-full max-w-[320px]">
              <span
                className="h-[1px] flex-1"
                style={{ backgroundColor: cardapiosMaterialSkins.maison.goldHairline }}
                aria-hidden="true"
              />
              <span
                className="text-[10px] font-medium uppercase tracking-[0.26em]"
                style={{ color: cardapiosTokens.textMuted }}
              >
                Carte Dégustation
              </span>
              <span
                className="h-[1px] flex-1"
                style={{ backgroundColor: cardapiosMaterialSkins.maison.goldHairline }}
                aria-hidden="true"
              />
            </div>

            <div
              className="inline-flex items-center justify-center rounded-[10px] border px-7 py-2.5 sm:px-9 sm:py-3"
              style={{
                backgroundColor: cardapiosMaterials.debossPlate.backgroundColor,
                borderColor: cardapiosMaterials.debossPlate.borderColor,
                boxShadow: cardapiosMaterials.debossPlate.boxShadow,
              }}
            >
              <h1
                className="font-editorial text-[28px] sm:text-[34px] font-semibold tracking-[0.24em] uppercase leading-none m-0"
                style={{
                  color: cardapiosMaterialSkins.maison.leatherDebossInk,
                  textShadow: cardapiosMaterials.debossPlate.textShadow,
                }}
              >
                Cardápios
              </h1>
            </div>
          </div>
        </header>

        <AnimatePresence initial={false}>
          {macroFitControl ? (
            <MacroFitProposalBanner
              key="macro-fit-proposal-banner"
              snapshot={macroFitControl.snapshot}
              canUndo={macroFitControl.canUndo}
              justApplied={macroFitControl.justApplied}
              errorFeedback={macroFitControl.errorFeedback}
              onApply={macroFitControl.onApply}
              onDismiss={macroFitControl.onDismiss}
              onUndo={macroFitControl.onUndo}
            />
          ) : null}
        </AnimatePresence>

        <div className="space-y-7">
          {viewModel.menus.map((menu) => (
            <MenuGroup
              key={menu.menuId}
              menu={menu}
              isCardExpanded={isCardExpanded}
              onToggleCard={toggleCardExpansion}
              isRecipeExpanded={isRecipeExpanded}
              onToggleMatrix={toggleRecipeMatrix}
            />
          ))}
        </div>

        <MealHistory rows={viewModel.history} />
      </div>
    </MotionConfig>
  );
});
