import { memo, useCallback, useEffect, useId, useRef, useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { motion, useMotionValueEvent, useTransform } from 'motion/react';
import {
  TITAN_MOTION_VARIANTS,
  useTitanReducedMotion,
} from '../../../../../shared/motion/titan-motion';
import { buildRecipeToggleA11yProps } from '../accessibility/cardapios.accessibility';
import {
  computeGatefoldFrame,
  useFolioChoreography,
} from '../hooks/useFolioChoreography';
import {
  ACTIVE_CARDAPIOS_MATERIAL_SKIN,
  cardapiosMaterials,
  cardapiosMaterialSkins,
  cardapiosTokens,
} from '../styles/cardapios.tokens';
import type { RecipeCardViewModel } from '../types/cardapios.types';
import { MacroSummary } from './MacroSummary';
import { MaterialSurfaceLayer } from './MaterialSurfaceLayer';
import { NutritionMatrixDisclosure } from './NutritionMatrixDisclosure';
import { RecipeFolio3DReveal } from './RecipeFolio3DReveal';
import { RecipeHeader } from './RecipeHeader';
import { RecipePhoto } from './RecipePhoto';
import { RecipePreparationAction } from './RecipePreparationAction';

interface RecipeCardProps {
  recipe: RecipeCardViewModel;
  courseNumber?: number;
  isCardOpen: boolean;
  isMatrixExpanded: boolean;
  onToggleCard: (recipeId: string, defaultOpen: boolean) => void;
  onToggleMatrix: (recipeId: string, defaultExpanded?: boolean) => void;
}

export const RecipeCard = memo(function RecipeCard({
  recipe,
  courseNumber,
  isCardOpen,
  isMatrixExpanded,
  onToggleCard,
  onToggleMatrix,
}: RecipeCardProps) {
  const cardRef = useRef<HTMLElement | null>(null);
  const matrixId = useId();
  const bodyId = useId();
  const [closedHovered, setClosedHovered] = useState(false);
  const [closedPressed, setClosedPressed] = useState(false);
  const [showOpenBody, setShowOpenBody] = useState(isCardOpen);

  const reduceMotion = useTitanReducedMotion();
  const { progress } = useFolioChoreography({
    isExpanded: isCardOpen,
    variant: reduceMotion ? 'flat' : 'gatefold',
    reduceMotion,
  });

  useEffect(() => {
    if (isCardOpen) {
      setShowOpenBody(true);
    } else if (reduceMotion) {
      setShowOpenBody(false);
    }
  }, [isCardOpen, reduceMotion]);

  useMotionValueEvent(progress, 'change', (latest) => {
    if (!isCardOpen && latest <= 0.02) {
      setShowOpenBody(false);
    }
  });

  const contentOpacity = useTransform(progress, (p) =>
    reduceMotion ? 1 : computeGatefoldFrame(p).contentOpacity,
  );
  const contentScale = useTransform(progress, (p) =>
    reduceMotion ? 1 : computeGatefoldFrame(p).contentScale,
  );
  const contentPitchX = useTransform(progress, (p) =>
    reduceMotion ? 0 : computeGatefoldFrame(p).contentPitchXDeg,
  );

  const handleToggleCard = useCallback(() => {
    onToggleCard(recipe.recipeId, recipe.isNextToConsume);
  }, [onToggleCard, recipe.recipeId, recipe.isNextToConsume]);

  const handleToggleMatrix = useCallback(() => {
    onToggleMatrix(recipe.recipeId, isCardOpen);
  }, [onToggleMatrix, recipe.recipeId, isCardOpen]);

  const containerBg = showOpenBody
    ? cardapiosMaterials.recipeOpenPaper.backgroundColor
    : closedPressed || closedHovered
      ? cardapiosMaterials.recipeClosedCover.hoverBackgroundColor
      : cardapiosMaterials.recipeClosedCover.backgroundColor;

  const containerBorder = showOpenBody
    ? cardapiosMaterials.recipeOpenPaper.borderColor
    : cardapiosMaterials.recipeClosedCover.borderColor;

  const containerShadow = showOpenBody
    ? cardapiosMaterials.recipeOpenPaper.boxShadow
    : cardapiosMaterials.recipeClosedCover.boxShadow;

  const courseTag =
    courseNumber !== undefined
      ? `${String(courseNumber).padStart(2, '0')} · ${recipe.mealSlotLabel} · ${recipe.mealTime}`
      : `${recipe.mealSlotLabel} · ${recipe.mealTime}`;

  return (
    <motion.article
      ref={cardRef}
      layout="position"
      transition={TITAN_MOTION_VARIANTS.layout.transition}
      className={
        showOpenBody
          ? 'relative overflow-visible rounded-[14px] border p-5 sm:p-6 space-y-4'
          : 'relative overflow-visible rounded-[14px] border p-3.5 sm:p-4'
      }
      style={{
        backgroundColor: containerBg,
        borderColor: containerBorder,
        boxShadow: containerShadow,
        perspective: 1500,
      }}
      aria-label={recipe.title}
    >
      <MaterialSurfaceLayer
        key={showOpenBody ? 'open-paper' : 'closed-cover'}
        containerRef={cardRef}
        skin={ACTIVE_CARDAPIOS_MATERIAL_SKIN}
        region={showOpenBody ? 'recipe-open-paper' : 'recipe-cover-closed'}
      />

      {!showOpenBody ? (
        <div className="relative z-10 flex items-center gap-3.5 sm:gap-4 pl-2">
          <RecipePhoto image={recipe.image} sizePx={56} />

          <div className="min-w-0 flex-1 flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 sm:gap-4">
            <div className="min-w-0">
              <p
                className="text-[10px] font-medium uppercase tracking-[0.18em] mb-0.5 tabular-nums"
                style={{ color: cardapiosMaterialSkins.maison.goldTooling }}
              >
                {courseTag}
              </p>
              <h3 className="min-w-0 m-0 text-[15px] sm:text-[17px] font-semibold leading-snug">
                <button
                  type="button"
                  onClick={handleToggleCard}
                  onMouseEnter={() => setClosedHovered(true)}
                  onMouseLeave={() => {
                    setClosedHovered(false);
                    setClosedPressed(false);
                  }}
                  onPointerDown={() => setClosedPressed(true)}
                  onPointerUp={() => setClosedPressed(false)}
                  onPointerCancel={() => setClosedPressed(false)}
                  {...buildRecipeToggleA11yProps(recipe.title, bodyId, false)}
                  className="font-editorial w-full text-left min-h-[44px] -mx-2 px-2 py-1 rounded-[8px] inline-flex items-center justify-between gap-2 focus-visible:outline-2 focus-visible:outline-offset-2"
                  style={{
                    color: cardapiosTokens.textPrimary,
                    outlineColor: cardapiosTokens.textPrimary,
                  }}
                >
                  <span>{recipe.title}</span>
                  <ChevronDown
                    className="w-4 h-4 shrink-0 sm:hidden"
                    style={{ color: cardapiosTokens.accentPrimary }}
                    aria-hidden="true"
                  />
                </button>
              </h3>
            </div>

            <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0">
              <MacroSummary macros={recipe.macros} surfaceTone="dark" />
              <ChevronDown
                className="hidden sm:block w-4 h-4 shrink-0"
                style={{ color: cardapiosTokens.accentPrimary }}
                aria-hidden="true"
              />
            </div>
          </div>
        </div>
      ) : (
        <motion.div
          key="recipe-open-sheet"
          initial={reduceMotion ? false : { height: 84 }}
          animate={{
            height: isCardOpen ? 'auto' : 84,
            transition: reduceMotion
              ? { duration: 0 }
              : {
                  height: {
                    duration: isCardOpen ? 0.56 : 0.4,
                    delay: isCardOpen ? 0.06 : 0.14,
                    ease: [0.22, 1, 0.36, 1],
                  },
                },
          }}
          className="relative z-10 overflow-hidden"
        >
          <motion.div
            className="space-y-4"
            style={
              reduceMotion
                ? undefined
                : {
                    opacity: contentOpacity,
                    scale: contentScale,
                    rotateX: contentPitchX,
                    transformOrigin: 'center top',
                  }
            }
          >
            <RecipeHeader
              recipe={recipe}
              courseNumber={courseNumber}
              matrixId={matrixId}
              bodyId={bodyId}
              isCardOpen={isCardOpen}
              onToggleCard={handleToggleCard}
              isMatrixExpanded={isMatrixExpanded}
              onToggleMatrix={handleToggleMatrix}
              surfaceTone="paper"
            />

            <div id={bodyId} className="space-y-4">
              {/* Somente a tabela nutricional editorial unificada (sem lista duplicada de ingredientes) */}
              <NutritionMatrixDisclosure
                matrixId={matrixId}
                recipeTitle={recipe.title}
                matrix={recipe.nutritionMatrix}
                isExpanded={isMatrixExpanded}
                surfaceTone="paper"
              />

              <RecipePreparationAction
                recipeTitle={recipe.title}
                preparation={recipe.preparation}
                surfaceTone="paper"
              />
            </div>
          </motion.div>
        </motion.div>
      )}

      <RecipeFolio3DReveal
        progress={progress}
        isCardOpen={isCardOpen}
        skin={ACTIVE_CARDAPIOS_MATERIAL_SKIN}
        reduceMotion={reduceMotion}
      />
    </motion.article>
  );
});
