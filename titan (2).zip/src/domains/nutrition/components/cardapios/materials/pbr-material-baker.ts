import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import type { MaterialRegion, MaterialSkinId } from './material-surface.types.ts';

export interface PbrBakeResult {
  uri: string;
  widthPx: number;
  heightPx: number;
}

export type PbrTileKind = 'leather' | 'paper';
export type PbrFrameVariant =
  | 'leather-stitched'
  | 'leather-spine-stitched'
  | 'paper-folio'
  | 'paper-matrix';

export interface PbrLayerAssets {
  tileUri: string;
  tileSizeCss: number;
  frameUri: string | null;
  frameSlicePx: number;
  frameWidthCss: number;
  spineUri: string | null;
  spineWidthCss: number;
  spineHeightCss: number;
}

interface RawTileData {
  size: number;
  heights: Float32Array;
  albedo: Uint8Array;
  roughness: Uint8Array;
  ao: Uint8Array;
  clearcoatRoughness?: Uint8Array;
}

interface BakerResources {
  renderer: THREE.WebGLRenderer;
  pmremGenerator: THREE.PMREMGenerator;
  envTarget: THREE.WebGLRenderTarget;
  scene: THREE.Scene;
  camera: THREE.OrthographicCamera;
  keyLight: THREE.DirectionalLight;
  rimLight: THREE.DirectionalLight;
  fillLight: THREE.DirectionalLight;
  hemiLight: THREE.HemisphereLight;
  isSoftwareGl: boolean;
  maxAnisotropy: number;
  contextLost: boolean;
  leatherTile: RawTileData | null;
  paperTile: RawTileData | null;
  tileUriCache: Map<PbrTileKind, string>;
  frameUriCache: Map<PbrFrameVariant, string>;
  spineUriCache: string | null;
}

let sharedBaker: BakerResources | null = null;

function clamp01(v: number): number {
  return v < 0 ? 0 : v > 1 ? 1 : v;
}

function clampByte(v: number): number {
  return v < 0 ? 0 : v > 255 ? 255 : Math.round(v);
}

function smoothstep(edge0: number, edge1: number, x: number): number {
  const t = clamp01((x - edge0) / (edge1 - edge0));
  return t * t * (3 - 2 * t);
}

function hash2Periodic(ix: number, iy: number, period: number, seed: number): number {
  const wx = ((ix % period) + period) % period;
  const wy = ((iy % period) + period) % period;
  let h = (wx * 374761393 + wy * 668265263 + seed * 1442695041) | 0;
  h = (h ^ (h >>> 13)) * 1274126177;
  h = h ^ (h >>> 16);
  return (h >>> 0) / 4294967295;
}

function hash1D(i: number, seed: number): number {
  let h = (i * 374761393 + seed * 1442695041) | 0;
  h = (h ^ (h >>> 13)) * 1274126177;
  h = h ^ (h >>> 16);
  return (h >>> 0) / 4294967295;
}

function smoothPeriodicNoise(u: number, v: number, freq: number, seed: number): number {
  const sx = u * freq;
  const sy = v * freq;
  const x0 = Math.floor(sx);
  const y0 = Math.floor(sy);
  const fx = sx - x0;
  const fy = sy - y0;
  const ux = fx * fx * (3 - 2 * fx);
  const uy = fy * fy * (3 - 2 * fy);
  const n00 = hash2Periodic(x0, y0, freq, seed);
  const n10 = hash2Periodic(x0 + 1, y0, freq, seed);
  const n01 = hash2Periodic(x0, y0 + 1, freq, seed);
  const n11 = hash2Periodic(x0 + 1, y0 + 1, freq, seed);
  return (n00 + (n10 - n00) * ux) * (1 - uy) + (n01 + (n11 - n01) * ux) * uy;
}

function fbmPeriodic(u: number, v: number, seed: number): number {
  return (
    smoothPeriodicNoise(u, v, 6, seed) * 0.48 +
    smoothPeriodicNoise(u, v, 14, seed + 19) * 0.29 +
    smoothPeriodicNoise(u, v, 32, seed + 47) * 0.15 +
    smoothPeriodicNoise(u, v, 72, seed + 83) * 0.08
  );
}

function voronoiPebble(
  u: number,
  v: number,
  cells: number,
  anisotropyX: number,
  anisotropyY: number,
  seed: number,
): { dome: number; crease: number; ridge: number; cellId: number } {
  const sx = u * cells;
  const sy = v * cells;
  const gx = Math.floor(sx);
  const gy = Math.floor(sy);
  let minD1 = 10;
  let minD2 = 10;
  let cellId = 0;

  for (let dy = -1; dy <= 1; dy += 1) {
    for (let dx = -1; dx <= 1; dx += 1) {
      const cx = gx + dx;
      const cy = gy + dy;
      const px = cx + 0.14 + 0.72 * hash2Periodic(cx, cy, cells, seed);
      const py = cy + 0.14 + 0.72 * hash2Periodic(cx, cy, cells, seed + 97);
      const dist = Math.hypot((sx - px) * anisotropyX, (sy - py) * anisotropyY);
      if (dist < minD1) {
        minD2 = minD1;
        minD1 = dist;
        cellId = hash2Periodic(cx, cy, cells, seed + 211);
      } else if (dist < minD2) {
        minD2 = dist;
      }
    }
  }

  const valleyDist = Math.max(0, minD2 - minD1);
  const crease = smoothstep(0.01, 0.21, valleyDist);
  const ridge = 1 - smoothstep(0.0, 0.14, valleyDist);
  const dome = Math.pow(clamp01(1 - minD1 * 1.06), 0.64);
  return { dome, crease, ridge, cellId };
}

/**
 * Seamless high-definition Morocco Goatskin (Chèvre Sully) tile (1024px GPU / 512px software GL):
 * - Domain-warped 2-scale anisotropic Voronoi grain (18x18 macro + 42x42 micro pebbles)
 * - Directional boarding crease network characteristic of hand-boarded goatskin
 * - Hair-follicle pinholes with subtle annular raised rims & crevice AO occlusion
 * - Burnished carnauba wax domes (roughness ~0.22–0.30) vs matte pore valleys (~0.88–0.94)
 */
function createMoroccoLeatherTile(size: number): RawTileData {
  const n = size * size;
  const heights = new Float32Array(n);
  const albedo = new Uint8Array(n * 3);
  const roughness = new Uint8Array(n);
  const ao = new Uint8Array(n);
  const clearcoatRoughness = new Uint8Array(n);

  for (let y = 0; y < size; y += 1) {
    const v = y / size;
    for (let x = 0; x < size; x += 1) {
      const u = x / size;
      const idx = y * size + x;
      const aIdx = idx * 3;

      const warpU = u + (smoothPeriodicNoise(u, v, 8, 11) - 0.5) * 0.026;
      const warpV = v + (smoothPeriodicNoise(u, v, 8, 29) - 0.5) * 0.026;

      const primary = voronoiPebble(warpU, warpV, 18, 0.84, 1.26, 101);
      const secondary = voronoiPebble(warpU + 0.013, warpV - 0.017, 42, 1.05, 0.91, 307);

      // Characteristic Chèvre directional boarding stretch lines intersecting grain valleys
      const boardPhaseA = smoothPeriodicNoise(u * 1.0 + v * 0.35, v * 0.7 - u * 0.25, 28, 419);
      const boardCrease = Math.exp(-Math.pow((boardPhaseA - 0.5) * 11, 2)) * (0.35 + 0.65 * primary.ridge);

      const pullUp = fbmPeriodic(u, v, 503);
      const microTooth = smoothPeriodicNoise(u, v, 148, 613);
      const poreNoise = smoothPeriodicNoise(u, v, 96, 709);

      // Genuine hair-follicle pinhole with tiny raised collar ring
      const porePit = poreNoise < 0.145 ? Math.pow((0.145 - poreNoise) / 0.145, 1.35) * 0.32 : 0;
      const poreCollar =
        poreNoise >= 0.145 && poreNoise < 0.21
          ? Math.sin(((poreNoise - 0.145) / 0.065) * Math.PI) * 0.075
          : 0;

      const pebbleBody =
        primary.crease * (0.44 + 0.56 * primary.dome) * 0.72 +
        secondary.crease * (0.32 + 0.68 * secondary.dome) * 0.28;

      const h = clamp01(
        pebbleBody * 0.86 +
          0.11 * pullUp +
          (microTooth - 0.5) * 0.045 +
          poreCollar -
          boardCrease * 0.14 -
          porePit,
      );
      heights[idx] = h;

      const crown = smoothstep(0.24, 0.88, h);
      const individualTone = (primary.cellId - 0.5) * 9;
      const pullUpBoost = (pullUp - 0.5) * 11;
      const valleyShade = primary.ridge * 7 + boardCrease * 6 + porePit * 16;

      // Deep pine-emerald Morocco leather (#0B1412 pore -> #2B4237 wax-burnished crown)
      albedo[aIdx] = clampByte(11 + crown * 32 + pullUpBoost * 0.55 + individualTone * 0.6 - valleyShade * 0.45);
      albedo[aIdx + 1] = clampByte(20 + crown * 44 + pullUpBoost * 0.85 + individualTone * 0.8 - valleyShade * 0.6);
      albedo[aIdx + 2] = clampByte(17 + crown * 35 + pullUpBoost * 0.65 + individualTone * 0.7 - valleyShade * 0.5);

      // Matte creased valleys & dry pores (~0.88–0.95) vs wax-burnished dome crowns (~0.23)
      roughness[idx] = clampByte(
        238 - crown * 176 + primary.ridge * 24 + boardCrease * 20 + porePit * 28,
      );

      // Ambient occlusion attenuates inside deep Voronoi valleys, boarding creases & follicle pits
      const aoVal = 1 - primary.ridge * 0.36 - boardCrease * 0.22 - porePit * 0.48;
      ao[idx] = clampByte(clamp01(aoVal) * 255);

      // Carnauba wax sits smoothly on pebble domes and thins out in creases
      clearcoatRoughness[idx] = clampByte(56 + (1 - crown) * 124 + primary.ridge * 40);
    }
  }

  return { size, heights, albedo, roughness, ao, clearcoatRoughness };
}

/**
 * Seamless Mould-Made Cotton Rag Paper (Arches / Fabriano 300-600g, #EEE9DE):
 * - Multi-octave cellulose pulp clouding + felt-press surface tooth
 * - Subtle European mould-made laid wires & spaced chain marks (barely-there tactile authenticity)
 * - Dense wrapped curved cotton/flax fibers + sparse warm flax botanical micro-flecks
 * - Zero plastic gloss: velvet matte cellulose roughness (0.85–0.97) + soft inter-fiber AO
 */
function createCottonPaperTile(size: number): RawTileData {
  const n = size * size;
  const heights = new Float32Array(n);
  const albedo = new Uint8Array(n * 3);
  const roughness = new Uint8Array(n);
  const ao = new Uint8Array(n);

  for (let y = 0; y < size; y += 1) {
    const v = y / size;
    for (let x = 0; x < size; x += 1) {
      const u = x / size;
      const idx = y * size + x;
      const aIdx = idx * 3;

      const pulpCloud = fbmPeriodic(u, v, 811);
      const feltDimple = smoothPeriodicNoise(u, v, 56, 919);
      const microTooth = smoothPeriodicNoise(u, v, 152, 1021);
      const ultraFine = smoothPeriodicNoise(u, v, 280, 1151);

      // Ultra-subtle handmade mould-made laid wire & chain stitch impression (broken by pulp cloud)
      const wireBreakup = 0.45 + 0.55 * pulpCloud;
      const laidWire =
        (Math.cos(v * Math.PI * 2 * 44 + (pulpCloud - 0.5) * 0.9) * 0.5 + 0.5) * 0.032 * wireBreakup;
      const chainShadow =
        Math.exp(-Math.pow((Math.sin(u * Math.PI * 6) + 0.0) * 14, 2)) * 0.028 * wireBreakup;

      const h = clamp01(
        0.48 +
          (pulpCloud - 0.5) * 0.22 +
          (feltDimple - 0.5) * 0.16 +
          (microTooth - 0.5) * 0.11 +
          (ultraFine - 0.5) * 0.05 +
          laidWire -
          chainShadow,
      );
      heights[idx] = h;

      const warmShift = (pulpCloud - 0.5) * 6.5;
      const microShade = (h - 0.5) * 11;
      albedo[aIdx] = clampByte(238 + warmShift + microShade);
      albedo[aIdx + 1] = clampByte(233 + warmShift * 0.85 + microShade);
      albedo[aIdx + 2] = clampByte(222 + warmShift * 0.55 + microShade * 0.9);

      roughness[idx] = clampByte(218 + (1 - h) * 32);
      ao[idx] = clampByte(230 + h * 25);
    }
  }

  const fiberCount = Math.round((size * size) / 72);
  for (let i = 0; i < fiberCount; i += 1) {
    const x0 = hash1D(i, 41) * size;
    const y0 = hash1D(i, 73) * size;
    const angle = hash1D(i, 109) * Math.PI * 2;
    const scale = size / 512;
    const len = (7 + hash1D(i, 149) * 19) * scale;
    const curve = (hash1D(i, 193) - 0.5) * 5 * scale;
    const isFlaxSpeck = hash1D(i, 311) > 0.985;
    const isLightFiber = !isFlaxSpeck && hash1D(i, 233) > 0.42;
    const strength = 0.34 + hash1D(i, 277) * 0.66;
    const steps = Math.max(8, Math.ceil(len * 1.4));

    const cosA = Math.cos(angle);
    const sinA = Math.sin(angle);
    const perpX = -sinA;
    const perpY = cosA;

    const effLen = isFlaxSpeck ? len * 0.35 : len;
    for (let s = 0; s <= steps; s += 1) {
      const t = s / steps;
      const bend = Math.sin(t * Math.PI) * curve;
      const fx = x0 + cosA * effLen * t + perpX * bend;
      const fy = y0 + sinA * effLen * t + perpY * bend;
      const px = ((Math.round(fx) % size) + size) % size;
      const py = ((Math.round(fy) % size) + size) % size;
      const idx = py * size + px;
      const aIdx = idx * 3;
      const taper = Math.sin(t * Math.PI) * strength;

      if (isFlaxSpeck) {
        heights[idx] = clamp01(heights[idx]! + 0.06 * taper);
        albedo[aIdx] = clampByte(albedo[aIdx]! - 14 * taper);
        albedo[aIdx + 1] = clampByte(albedo[aIdx + 1]! - 17 * taper);
        albedo[aIdx + 2] = clampByte(albedo[aIdx + 2]! - 24 * taper);
        ao[idx] = clampByte(ao[idx]! - 12 * taper);
      } else if (isLightFiber) {
        heights[idx] = clamp01(heights[idx]! + 0.08 * taper);
        albedo[aIdx] = clampByte(albedo[aIdx]! + 5 * taper);
        albedo[aIdx + 1] = clampByte(albedo[aIdx + 1]! + 4.5 * taper);
        albedo[aIdx + 2] = clampByte(albedo[aIdx + 2]! + 3.5 * taper);
        roughness[idx] = clampByte(roughness[idx]! - 6 * taper);
      } else {
        heights[idx] = clamp01(heights[idx]! - 0.052 * taper);
        albedo[aIdx] = clampByte(albedo[aIdx]! - 6.5 * taper);
        albedo[aIdx + 1] = clampByte(albedo[aIdx + 1]! - 7.5 * taper);
        albedo[aIdx + 2] = clampByte(albedo[aIdx + 2]! - 9.5 * taper);
        ao[idx] = clampByte(ao[idx]! - 8 * taper);
      }
    }
  }

  return { size, heights, albedo, roughness, ao };
}

function roundedBoxSdf(
  px: number,
  py: number,
  cx: number,
  cy: number,
  halfW: number,
  halfH: number,
  radius: number,
): number {
  const qx = Math.abs(px - cx) - Math.max(0, halfW - radius);
  const qy = Math.abs(py - cy) - Math.max(0, halfH - radius);
  const outDist = Math.hypot(Math.max(qx, 0), Math.max(qy, 0));
  const inDist = Math.min(Math.max(qx, qy), 0);
  return outDist + inDist - radius;
}

function distToSegment(
  px: number,
  py: number,
  ax: number,
  ay: number,
  bx: number,
  by: number,
): { dist: number; t: number } {
  const dx = bx - ax;
  const dy = by - ay;
  const lenSq = dx * dx + dy * dy;
  if (lenSq < 1e-6) return { dist: Math.hypot(px - ax, py - ay), t: 0 };
  const t = clamp01(((px - ax) * dx + (py - ay) * dy) / lenSq);
  return { dist: Math.hypot(px - (ax + t * dx), py - (ay + t * dy)), t };
}

interface StitchPoint {
  x: number;
  y: number;
  tx: number;
  ty: number;
  nx: number;
  ny: number;
}

/**
 * Generates exact phase-locked stitches for a 512x512 9-slice atlas (`slice = 112`, middle = `288`):
 * - Straight middle segments [112..400] receive 9 stitches at exact 32-texel pitch (128, 160, ..., 384)
 *   so CSS `border-image-repeat: round` repeats cleanly with zero stitch splitting or jump.
 * - Each corner [0..112] connects smoothly around the rounded arc at ~32 texel pitch.
 */
function buildNineSliceStitchPoints(inset: number, cornerRadius: number): StitchPoint[] {
  const size = 512;
  const slice = 112;
  const pitch = 32;
  const halfPitch = 16;
  const pts: StitchPoint[] = [];

  for (let pos = slice + halfPitch; pos <= size - slice - halfPitch; pos += pitch) {
    pts.push({ x: pos, y: inset, tx: 1, ty: 0, nx: 0, ny: -1 });
    pts.push({ x: size - inset, y: pos, tx: 0, ty: 1, nx: 1, ny: 0 });
    pts.push({ x: size - pos, y: size - inset, tx: -1, ty: 0, nx: 0, ny: 1 });
    pts.push({ x: inset, y: size - pos, tx: 0, ty: -1, nx: -1, ny: 0 });
  }

  const r = Math.min(cornerRadius, slice - inset - halfPitch);
  const straightStub = slice - halfPitch - (inset + r);
  const arcLen = 0.5 * Math.PI * r;
  const cornerLen = 2 * straightStub + arcLen;
  const intervals = Math.max(2, Math.round(cornerLen / pitch));

  const sampleCornerPoint = (s: number): StitchPoint => {
    if (s <= straightStub) {
      return { x: inset, y: slice - halfPitch - s, tx: 0, ty: -1, nx: -1, ny: 0 };
    }
    const rem = s - straightStub;
    if (rem <= arcLen) {
      const a = Math.PI + (rem / Math.max(0.001, arcLen)) * (Math.PI / 2);
      return {
        x: inset + r + Math.cos(a) * r,
        y: inset + r + Math.sin(a) * r,
        tx: -Math.sin(a),
        ty: Math.cos(a),
        nx: Math.cos(a),
        ny: Math.sin(a),
      };
    }
    const rem2 = rem - arcLen;
    return { x: inset + r + rem2, y: inset, tx: 1, ty: 0, nx: 0, ny: -1 };
  };

  for (let k = 1; k < intervals; k += 1) {
    const tl = sampleCornerPoint((k / intervals) * cornerLen);
    pts.push(tl);
    pts.push({
      x: size - tl.y,
      y: tl.x,
      tx: -tl.ty,
      ty: tl.tx,
      nx: -tl.ny,
      ny: tl.nx,
    });
    pts.push({
      x: size - tl.x,
      y: size - tl.y,
      tx: -tl.tx,
      ty: -tl.ty,
      nx: -tl.nx,
      ny: -tl.ny,
    });
    pts.push({
      x: tl.y,
      y: size - tl.x,
      tx: tl.ty,
      ty: -tl.tx,
      nx: tl.ny,
      ny: -tl.nx,
    });
  }

  return pts;
}

function buildNormalDataFromHeights(
  width: number,
  height: number,
  heights: Float32Array,
  strength: number,
  periodic: boolean,
): Uint8Array {
  const normalData = new Uint8Array(width * height * 4);
  for (let y = 0; y < height; y += 1) {
    const ym = periodic ? (y - 1 + height) % height : Math.max(0, y - 1);
    const yp = periodic ? (y + 1) % height : Math.min(height - 1, y + 1);
    for (let x = 0; x < width; x += 1) {
      const xm = periodic ? (x - 1 + width) % width : Math.max(0, x - 1);
      const xp = periodic ? (x + 1) % width : Math.min(width - 1, x + 1);

      const tl = heights[ym * width + xm] ?? 0;
      const tc = heights[ym * width + x] ?? 0;
      const tr = heights[ym * width + xp] ?? 0;
      const ml = heights[y * width + xm] ?? 0;
      const mr = heights[y * width + xp] ?? 0;
      const bl = heights[yp * width + xm] ?? 0;
      const bc = heights[yp * width + x] ?? 0;
      const br = heights[yp * width + xp] ?? 0;

      const gx = (tr + 2 * mr + br - (tl + 2 * ml + bl)) * 0.25 * strength;
      const gy = (bl + 2 * bc + br - (tl + 2 * tc + tr)) * 0.25 * strength;
      const invLen = 1 / Math.hypot(-gx, -gy, 1);

      const pIdx = (y * width + x) * 4;
      normalData[pIdx] = clampByte((-gx * invLen * 0.5 + 0.5) * 255);
      normalData[pIdx + 1] = clampByte((gy * invLen * 0.5 + 0.5) * 255);
      normalData[pIdx + 2] = clampByte((invLen * 0.5 + 0.5) * 255);
      normalData[pIdx + 3] = 255;
    }
  }
  return normalData;
}

function getOrCreateSharedBaker(): BakerResources | null {
  if (typeof document === 'undefined' || typeof WebGLRenderingContext === 'undefined') {
    return null;
  }
  if (sharedBaker && !sharedBaker.contextLost) {
    return sharedBaker;
  }

  try {
    const canvas = document.createElement('canvas');
    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: true,
      premultipliedAlpha: false,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: true,
    });

    const gl = renderer.getContext();
    const dbgInfo = gl.getExtension('WEBGL_debug_renderer_info');
    const glRenderer = dbgInfo ? String(gl.getParameter(dbgInfo.UNMASKED_RENDERER_WEBGL)) : '';
    const isSoftwareGl = /swiftshader|llvmpipe|softpipe/i.test(glRenderer);
    const maxAnisotropy = Math.min(8, Math.max(1, renderer.capabilities.getMaxAnisotropy()));

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.24;
    renderer.setClearColor(0x000000, 0);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    pmremGenerator.compileEquirectangularShader();
    const roomEnv = new RoomEnvironment();
    const envTarget = pmremGenerator.fromScene(roomEnv, 0.04);
    roomEnv.dispose();

    const scene = new THREE.Scene();
    scene.environment = envTarget.texture;
    scene.environmentIntensity = 1.18;

    const camera = new THREE.OrthographicCamera(-0.5, 0.5, 0.5, -0.5, 0.1, 10);
    camera.position.set(0, 0, 2);
    camera.lookAt(0, 0, 0);

    // Grazing studio key light from top-left to carve deep 3D pebble, fiber & stitch catchlights
    const keyLight = new THREE.DirectionalLight('#FFF0D4', 3.45);
    keyLight.position.set(-2.3, 2.45, 1.32);
    scene.add(keyLight);

    // Cool sage-slate rim light from bottom-right to catch gold foil fillets and stitch twists
    const rimLight = new THREE.DirectionalLight('#B8D6CC', 1.48);
    rimLight.position.set(2.2, -1.75, 1.15);
    scene.add(rimLight);

    const fillLight = new THREE.DirectionalLight('#FAF5EA', 0.54);
    fillLight.position.set(0.15, 0.6, 2.6);
    scene.add(fillLight);

    const hemiLight = new THREE.HemisphereLight('#F4EFE4', '#0A100E', 0.58);
    scene.add(hemiLight);

    const baker: BakerResources = {
      renderer,
      pmremGenerator,
      envTarget,
      scene,
      camera,
      keyLight,
      rimLight,
      fillLight,
      hemiLight,
      isSoftwareGl,
      maxAnisotropy,
      contextLost: false,
      leatherTile: null,
      paperTile: null,
      tileUriCache: new Map(),
      frameUriCache: new Map(),
      spineUriCache: null,
    };

    canvas.addEventListener('webglcontextlost', (e) => {
      e.preventDefault();
      baker.contextLost = true;
    });
    canvas.addEventListener('webglcontextrestored', () => {
      baker.contextLost = false;
    });

    sharedBaker = baker;
    return baker;
  } catch {
    return null;
  }
}

export function canBakePbrInBrowser(): boolean {
  return typeof document !== 'undefined' && typeof WebGLRenderingContext !== 'undefined';
}

function makeDataTexture(
  data: Uint8Array,
  w: number,
  h: number,
  srgb: boolean,
  repeat: boolean,
  anisotropy = 4,
): THREE.DataTexture {
  const tex = new THREE.DataTexture(data, w, h, THREE.RGBAFormat);
  tex.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  tex.flipY = true;
  tex.wrapS = repeat ? THREE.RepeatWrapping : THREE.ClampToEdgeWrapping;
  tex.wrapT = repeat ? THREE.RepeatWrapping : THREE.ClampToEdgeWrapping;
  tex.magFilter = THREE.LinearFilter;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.generateMipmaps = true;
  tex.anisotropy = Math.max(1, anisotropy);
  tex.needsUpdate = true;
  return tex;
}

/**
 * Bakes a 100% seamless ultra-high-density Three.js PBR-lit Morocco goatskin or cotton rag tile ONCE.
 * Renders a 3x3 tiled PlaneGeometry(3, 3) captured on the center [-0.5..0.5] so border pixels
 * wrap with zero seam and zero distortion at any CSS box size.
 */
export function bakePbrTileUri(kind: PbrTileKind): string | null {
  const baker = getOrCreateSharedBaker();
  if (!baker) return null;
  const cached = baker.tileUriCache.get(kind);
  if (cached) return cached;

  const isPaper = kind === 'paper';
  const tileSize = baker.isSoftwareGl ? 512 : 1024;
  if (isPaper && !baker.paperTile) baker.paperTile = createCottonPaperTile(tileSize);
  if (!isPaper && !baker.leatherTile) baker.leatherTile = createMoroccoLeatherTile(tileSize);

  const tile = isPaper ? baker.paperTile! : baker.leatherTile!;
  const size = tile.size;
  const n = size * size;

  const albedoData = new Uint8Array(n * 4);
  const roughData = new Uint8Array(n * 4);
  const aoData = new Uint8Array(n * 4);
  const clearcoatRoughData = tile.clearcoatRoughness ? new Uint8Array(n * 4) : null;

  for (let i = 0; i < n; i += 1) {
    const pIdx = i * 4;
    const aIdx = i * 3;
    albedoData[pIdx] = tile.albedo[aIdx]!;
    albedoData[pIdx + 1] = tile.albedo[aIdx + 1]!;
    albedoData[pIdx + 2] = tile.albedo[aIdx + 2]!;
    albedoData[pIdx + 3] = 255;

    const r = tile.roughness[i]!;
    roughData[pIdx] = r;
    roughData[pIdx + 1] = r;
    roughData[pIdx + 2] = r;
    roughData[pIdx + 3] = 255;

    const ao = tile.ao[i]!;
    aoData[pIdx] = ao;
    aoData[pIdx + 1] = ao;
    aoData[pIdx + 2] = ao;
    aoData[pIdx + 3] = 255;

    if (clearcoatRoughData && tile.clearcoatRoughness) {
      const cr = tile.clearcoatRoughness[i]!;
      clearcoatRoughData[pIdx] = cr;
      clearcoatRoughData[pIdx + 1] = cr;
      clearcoatRoughData[pIdx + 2] = cr;
      clearcoatRoughData[pIdx + 3] = 255;
    }
  }

  const normalData = buildNormalDataFromHeights(
    size,
    size,
    tile.heights,
    isPaper ? 2.75 : 6.1,
    true,
  );

  const aniso = baker.maxAnisotropy;
  const map = makeDataTexture(albedoData, size, size, true, true, aniso);
  map.repeat.set(3, 3);
  const normalMap = makeDataTexture(normalData, size, size, false, true, aniso);
  normalMap.repeat.set(3, 3);
  const roughnessMap = makeDataTexture(roughData, size, size, false, true, aniso);
  roughnessMap.repeat.set(3, 3);
  const aoMap = makeDataTexture(aoData, size, size, false, true, aniso);
  aoMap.repeat.set(3, 3);
  const clearcoatRoughnessMap = clearcoatRoughData
    ? makeDataTexture(clearcoatRoughData, size, size, false, true, aniso)
    : null;
  if (clearcoatRoughnessMap) clearcoatRoughnessMap.repeat.set(3, 3);

  const geometry = new THREE.PlaneGeometry(3, 3);
  const uvAttr = geometry.getAttribute('uv');
  if (uvAttr) geometry.setAttribute('uv1', uvAttr);
  const material = new THREE.MeshPhysicalMaterial({
    map,
    normalMap,
    normalScale: new THREE.Vector2(isPaper ? 1.55 : 2.85, isPaper ? 1.55 : 2.85),
    roughnessMap,
    roughness: isPaper ? 0.96 : 0.76,
    metalness: isPaper ? 0.0 : 0.02,
    aoMap,
    aoMapIntensity: isPaper ? 0.55 : 0.96,
    sheen: isPaper ? 0.22 : 0.65,
    sheenRoughness: isPaper ? 0.88 : 0.4,
    sheenColor: new THREE.Color(isPaper ? '#FAF6EC' : '#5B7668'),
    clearcoat: isPaper ? 0 : 0.34,
    clearcoatRoughness: 0.24,
    clearcoatRoughnessMap: clearcoatRoughnessMap ?? undefined,
    specularIntensity: isPaper ? 0.25 : 0.92,
  });

  const mesh = new THREE.Mesh(geometry, material);
  baker.scene.add(mesh);
  baker.renderer.setPixelRatio(1);
  baker.renderer.setSize(size, size, false);
  baker.renderer.setClearColor(0x000000, 1);
  baker.renderer.render(baker.scene, baker.camera);
  const uri = baker.renderer.domElement.toDataURL('image/png');

  baker.scene.remove(mesh);
  geometry.dispose();
  material.dispose();
  map.dispose();
  normalMap.dispose();
  roughnessMap.dispose();
  aoMap.dispose();
  clearcoatRoughnessMap?.dispose();

  baker.tileUriCache.set(kind, uri);
  return uri;
}

/**
 * Bakes a 512x512 Retina 4x 9-slice Three.js PBR Frame Atlas (`slice = 112` -> `28px` CSS border):
 * - 3D vertex-displaced padded edge cushion bevel
 * - Rounded-corner SDF debossed stitch groove + 3D slanted 3-ply Couture Sellier waxed-linen stitches + awl dimples + collar lip
 * - Blind-tooled channel + micro-broken hot-stamped champagne gold leaf fillet (`metalness: 0.95`, conforms to underlying grain)
 * - Transparent center beyond 27px CSS so Layer A's crisp tiled interior shows with ZERO stretch
 */
export function bakePbrFrameAtlasUri(variant: PbrFrameVariant): string | null {
  const baker = getOrCreateSharedBaker();
  if (!baker) return null;
  const cached = baker.frameUriCache.get(variant);
  if (cached) return cached;

  const isPaper = variant === 'paper-folio' || variant === 'paper-matrix';
  const tileRes = baker.isSoftwareGl ? 512 : 1024;
  if (isPaper && !baker.paperTile) baker.paperTile = createCottonPaperTile(tileRes);
  if (!isPaper && !baker.leatherTile) baker.leatherTile = createMoroccoLeatherTile(tileRes);

  const tile = isPaper ? baker.paperTile! : baker.leatherTile!;
  const size = 512;
  const n = size * size;
  const tileSize = tile.size;
  const tileStep = Math.max(1, Math.round(tileSize / 256));

  const heights = new Float32Array(n);
  const albedoData = new Uint8Array(n * 4);
  const roughData = new Uint8Array(n * 4);
  const metalData = new Uint8Array(n * 4);
  const aoData = new Uint8Array(n * 4);

  const cornerRadius = variant === 'paper-matrix' ? 40 : variant === 'leather-stitched' ? 72 : 56;
  const half = size * 0.5;
  const hasStitching = !isPaper;
  const hasGold = variant !== 'paper-matrix';

  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      const idx = y * size + x;
      const pIdx = idx * 4;
      const tx = (x * tileStep) % tileSize;
      const ty = (y * tileStep) % tileSize;
      const tIdx = ty * tileSize + tx;
      const aIdx = tIdx * 3;

      const baseH = tile.heights[tIdx]!;
      heights[idx] = baseH;
      albedoData[pIdx] = tile.albedo[aIdx]!;
      albedoData[pIdx + 1] = tile.albedo[aIdx + 1]!;
      albedoData[pIdx + 2] = tile.albedo[aIdx + 2]!;

      const rb = tile.roughness[tIdx]!;
      roughData[pIdx] = rb;
      roughData[pIdx + 1] = rb;
      roughData[pIdx + 2] = rb;
      roughData[pIdx + 3] = 255;

      metalData[pIdx] = 6;
      metalData[pIdx + 1] = 6;
      metalData[pIdx + 2] = 6;
      metalData[pIdx + 3] = 255;

      const baseAo = tile.ao[tIdx]!;
      aoData[pIdx] = baseAo;
      aoData[pIdx + 1] = baseAo;
      aoData[pIdx + 2] = baseAo;
      aoData[pIdx + 3] = 255;

      const sdf = roundedBoxSdf(x + 0.5, y + 0.5, half, half, half, half, cornerRadius);

      // Alpha feather: solid around border ring [0..-72], fades cleanly to 0 across [-72..-108]
      const alphaWeight = sdf <= -108 ? 0 : sdf >= -72 ? 1 : 1 - smoothstep(-72, -108, sdf);
      albedoData[pIdx + 3] = clampByte(alphaWeight * 255);

      if (alphaWeight <= 0.005) continue;

      if (isPaper) {
        if (sdf > -20) {
          const edgeBevel = smoothstep(-20, 0, sdf);
          heights[idx] = clamp01(heights[idx]! - edgeBevel * 0.22);
          const aoVal = clampByte(aoData[pIdx]! * (1 - edgeBevel * 0.24));
          aoData[pIdx] = aoVal;
          aoData[pIdx + 1] = aoVal;
          aoData[pIdx + 2] = aoVal;
        }
        if (hasGold) {
          const ruleDist = Math.abs(sdf + 44);
          if (ruleDist < 8) {
            const groove = 1 - smoothstep(0, 6.4, ruleDist);
            heights[idx] = clamp01(heights[idx]! - groove * 0.22);
            const gAo = clampByte(aoData[pIdx]! * (1 - groove * 0.16));
            aoData[pIdx] = gAo;
            aoData[pIdx + 1] = gAo;
            aoData[pIdx + 2] = gAo;
            if (ruleDist < 3.0) {
              const foil = 0.42 * (1 - ruleDist / 3.0) * (0.8 + 0.2 * baseH);
              albedoData[pIdx] = clampByte(albedoData[pIdx]! * (1 - foil) + 190 * foil);
              albedoData[pIdx + 1] = clampByte(albedoData[pIdx + 1]! * (1 - foil) + 164 * foil);
              albedoData[pIdx + 2] = clampByte(albedoData[pIdx + 2]! * (1 - foil) + 110 * foil);
              const fm = clampByte(185 * foil + 6 * (1 - foil));
              metalData[pIdx] = fm;
              metalData[pIdx + 1] = fm;
              metalData[pIdx + 2] = fm;
            }
          }
        }
      } else {
        // Outer padded leather bevel & edge burnish
        if (sdf > -22) {
          const bevelT = smoothstep(-22, 0, sdf);
          heights[idx] = clamp01(heights[idx]! - bevelT * 0.3);
          const eAo = clampByte(aoData[pIdx]! * (1 - bevelT * 0.42));
          aoData[pIdx] = eAo;
          aoData[pIdx + 1] = eAo;
          aoData[pIdx + 2] = eAo;
          const eRough = clampByte(roughData[pIdx]! * (1 - bevelT * 0.35));
          roughData[pIdx] = eRough;
          roughData[pIdx + 1] = eRough;
          roughData[pIdx + 2] = eRough;
        }

        // Stitch channel groove at inset = 36 texels
        if (hasStitching) {
          const sDist = Math.abs(sdf + 36);
          if (sDist < 8.8) {
            const groove = Math.cos((sDist / 8.8) * (Math.PI * 0.5));
            const gSq = groove * groove;
            heights[idx] = clamp01(heights[idx]! - gSq * 0.28);
            const gAo = clampByte(aoData[pIdx]! * (1 - gSq * 0.35));
            aoData[pIdx] = gAo;
            aoData[pIdx + 1] = gAo;
            aoData[pIdx + 2] = gAo;
          }
        }

        // Blind-tooled inner channel & micro-broken champagne gold leaf fillet at inset = 62 texels
        if (hasGold) {
          const tDist = Math.abs(sdf + 62);
          if (tDist < 9.0) {
            const deboss = Math.cos((tDist / 9.0) * (Math.PI * 0.5));
            heights[idx] = clamp01(heights[idx]! - deboss * deboss * 0.38);
            const tAo = clampByte(aoData[pIdx]! * (1 - deboss * deboss * 0.28));
            aoData[pIdx] = tAo;
            aoData[pIdx + 1] = tAo;
            aoData[pIdx + 2] = tAo;

            if (tDist < 3.4) {
              // Real hot-stamped gold leaf sits thicker on pebble crowns and slightly breaks into deep grain pores
              const grainConform = smoothstep(0.18, 0.72, baseH);
              const foilMask = smoothstep(3.4, 0.9, tDist) * (0.68 + 0.32 * grainConform);
              albedoData[pIdx] = clampByte(albedoData[pIdx]! * (1 - foilMask) + 216 * foilMask);
              albedoData[pIdx + 1] = clampByte(albedoData[pIdx + 1]! * (1 - foilMask) + 184 * foilMask);
              albedoData[pIdx + 2] = clampByte(albedoData[pIdx + 2]! * (1 - foilMask) + 122 * foilMask);

              const rVal = clampByte(roughData[pIdx]! * (1 - foilMask) + 42 * foilMask);
              roughData[pIdx] = rVal;
              roughData[pIdx + 1] = rVal;
              roughData[pIdx + 2] = rVal;

              const mVal = clampByte(244 * foilMask + 6 * (1 - foilMask));
              metalData[pIdx] = mVal;
              metalData[pIdx + 1] = mVal;
              metalData[pIdx + 2] = mVal;
            }
          }
        }
      }
    }
  }

  // Stamp crisp 3D 3-ply Couture Sellier saddle stitches around the phase-locked 9-slice perimeter
  if (hasStitching) {
    const pts = buildNineSliceStitchPoints(36, Math.max(16, cornerRadius - 36));
    const halfLen = 11.2;
    const threadRadius = 3.45;
    const holeRadius = 4.3;
    const slantCos = Math.cos(0.28);
    const slantSin = Math.sin(0.28);

    for (let i = 0; i < pts.length; i += 1) {
      const pt = pts[i]!;
      const sx = pt.tx * slantCos - pt.nx * slantSin;
      const sy = pt.ty * slantCos - pt.ny * slantSin;
      const ax = pt.x - sx * halfLen;
      const ay = pt.y - sy * halfLen;
      const bx = pt.x + sx * halfLen;
      const by = pt.y + sy * halfLen;

      const minX = Math.max(0, Math.floor(Math.min(ax, bx) - holeRadius * 2.2));
      const maxX = Math.min(size - 1, Math.ceil(Math.max(ax, bx) + holeRadius * 2.2));
      const minY = Math.max(0, Math.floor(Math.min(ay, by) - holeRadius * 2.2));
      const maxY = Math.min(size - 1, Math.ceil(Math.max(ay, by) + holeRadius * 2.2));

      for (let py = minY; py <= maxY; py += 1) {
        for (let px = minX; px <= maxX; px += 1) {
          const idx = py * size + px;
          const pIdx = idx * 4;

          const dHole = Math.min(
            Math.hypot(px + 0.5 - ax, py + 0.5 - ay),
            Math.hypot(px + 0.5 - bx, py + 0.5 - by),
          );
          if (dHole < holeRadius * 1.4) {
            if (dHole < holeRadius) {
              const hMask = 1 - smoothstep(0, holeRadius, dHole);
              heights[idx] = clamp01(heights[idx]! - hMask * 0.65);
              const hAo = clampByte(aoData[pIdx]! * (1 - hMask * 0.78));
              aoData[pIdx] = hAo;
              aoData[pIdx + 1] = hAo;
              aoData[pIdx + 2] = hAo;
            } else {
              // Subtle displaced leather collar raised around awl puncture
              const lip = Math.sin(((dHole - holeRadius) / (holeRadius * 0.4)) * Math.PI);
              heights[idx] = clamp01(heights[idx]! + lip * 0.08);
            }
          }

          const seg = distToSegment(px + 0.5, py + 0.5, ax, ay, bx, by);
          if (seg.dist < threadRadius * 1.48) {
            if (seg.dist < threadRadius) {
              const profile = Math.sqrt(Math.max(0, 1 - (seg.dist / threadRadius) ** 2));
              // 3-ply diagonal waxed linen cord twist
              const crossAngle = (seg.dist / threadRadius) * 1.2;
              const plyTwist = 0.85 + 0.15 * Math.sin(seg.t * Math.PI * 7 + crossAngle * 2.1);
              const cov = smoothstep(threadRadius, threadRadius * 0.36, seg.dist);
              const crown = 0.66 + 0.34 * profile * plyTwist;
              heights[idx] = clamp01(heights[idx]! * (1 - cov) + crown * cov);

              const shade = (0.76 + 0.34 * profile) * plyTwist;
              albedoData[pIdx] = clampByte(albedoData[pIdx]! * (1 - cov) + 198 * shade * cov);
              albedoData[pIdx + 1] = clampByte(albedoData[pIdx + 1]! * (1 - cov) + 174 * shade * cov);
              albedoData[pIdx + 2] = clampByte(albedoData[pIdx + 2]! * (1 - cov) + 128 * shade * cov);

              const tr = clampByte(roughData[pIdx]! * (1 - cov) + 68 * cov);
              roughData[pIdx] = tr;
              roughData[pIdx + 1] = tr;
              roughData[pIdx + 2] = tr;

              const ta = clampByte(aoData[pIdx]! * (1 - cov) + 252 * cov);
              aoData[pIdx] = ta;
              aoData[pIdx + 1] = ta;
              aoData[pIdx + 2] = ta;
            } else {
              const contact = 1 - smoothstep(threadRadius, threadRadius * 1.48, seg.dist);
              const sAo = clampByte(aoData[pIdx]! * (1 - contact * 0.36));
              aoData[pIdx] = sAo;
              aoData[pIdx + 1] = sAo;
              aoData[pIdx + 2] = sAo;
            }
          }
        }
      }
    }
  }

  const normalData = buildNormalDataFromHeights(size, size, heights, isPaper ? 2.5 : 5.4, false);

  const aniso = baker.maxAnisotropy;
  const map = makeDataTexture(albedoData, size, size, true, false, aniso);
  const normalMap = makeDataTexture(normalData, size, size, false, false, aniso);
  const roughnessMap = makeDataTexture(roughData, size, size, false, false, aniso);
  const metalnessMap = makeDataTexture(metalData, size, size, false, false, aniso);
  const aoMap = makeDataTexture(aoData, size, size, false, false, aniso);

  const geometry = new THREE.PlaneGeometry(1, 1, 72, 72);
  const posAttr = geometry.attributes.position as THREE.BufferAttribute;
  const uvAttr = geometry.attributes.uv as THREE.BufferAttribute;
  geometry.setAttribute('uv1', uvAttr);

  for (let i = 0; i < posAttr.count; i += 1) {
    const u = uvAttr.getX(i);
    const v = uvAttr.getY(i);
    const edgeDist = Math.min(u, 1 - u, v, 1 - v);
    const cushionZ = -0.018 * (1 - smoothstep(0, 0.075, edgeDist));
    posAttr.setZ(i, cushionZ);
  }
  posAttr.needsUpdate = true;
  geometry.computeVertexNormals();

  const material = new THREE.MeshPhysicalMaterial({
    map,
    normalMap,
    normalScale: new THREE.Vector2(isPaper ? 1.55 : 2.75, isPaper ? 1.55 : 2.75),
    roughnessMap,
    roughness: isPaper ? 0.96 : 0.76,
    metalnessMap,
    metalness: 1.0,
    aoMap,
    aoMapIntensity: isPaper ? 0.52 : 0.96,
    sheen: isPaper ? 0.2 : 0.62,
    sheenRoughness: isPaper ? 0.86 : 0.42,
    sheenColor: new THREE.Color(isPaper ? '#FAF6EC' : '#5B7668'),
    clearcoat: isPaper ? 0 : 0.3,
    clearcoatRoughness: 0.26,
    transparent: true,
  });

  const mesh = new THREE.Mesh(geometry, material);
  baker.scene.add(mesh);
  baker.renderer.setPixelRatio(1);
  baker.renderer.setSize(size, size, false);
  baker.renderer.setClearColor(0x000000, 0);
  baker.renderer.render(baker.scene, baker.camera);
  const uri = baker.renderer.domElement.toDataURL('image/png');

  baker.scene.remove(mesh);
  geometry.dispose();
  material.dispose();
  map.dispose();
  normalMap.dispose();
  roughnessMap.dispose();
  metalnessMap.dispose();
  aoMap.dispose();

  baker.frameUriCache.set(variant, uri);
  return uri;
}

/**
 * Bakes a 64x512 vertical seamless French-joint spine hinge strip (`lombada + mors`) ONCE.
 * Renders a convex cylindrical leather spine shoulder + deep recessed French hinge crease
 * with horizontal seamless tiling (`repeat-y`), zero distortion at any height.
 */
export function bakePbrSpineStripUri(): string | null {
  const baker = getOrCreateSharedBaker();
  if (!baker) return null;
  if (baker.spineUriCache) return baker.spineUriCache;
  const tileRes = baker.isSoftwareGl ? 512 : 1024;
  if (!baker.leatherTile) baker.leatherTile = createMoroccoLeatherTile(tileRes);

  const tile = baker.leatherTile;
  const tileSize = tile.size;
  const tileStep = Math.max(1, Math.round(tileSize / 256));
  const outW = 64;
  const outH = 512;
  const n = outW * outH;

  const heights = new Float32Array(n);
  const albedoData = new Uint8Array(n * 4);
  const roughData = new Uint8Array(n * 4);
  const aoData = new Uint8Array(n * 4);

  for (let y = 0; y < outH; y += 1) {
    for (let x = 0; x < outW; x += 1) {
      const idx = y * outW + x;
      const pIdx = idx * 4;
      const tx = (x * tileStep) % tileSize;
      const ty = (y * tileStep) % tileSize;
      const tIdx = ty * tileSize + tx;
      const aIdx = tIdx * 3;

      let h = tile.heights[tIdx]!;
      let r = tile.albedo[aIdx]!;
      let g = tile.albedo[aIdx + 1]!;
      let b = tile.albedo[aIdx + 2]!;
      let rough = tile.roughness[tIdx]!;
      let aoVal = tile.ao[tIdx]!;

      const u = (x + 0.5) / outW;
      let alpha = 1;
      if (u < 0.44) {
        const bump = Math.sin((u / 0.44) * Math.PI);
        h = clamp01(h + bump * 0.28);
        rough = clampByte(rough - bump * 54);
      } else {
        const jointT = (u - 0.58) / 0.14;
        const crease = Math.exp(-jointT * jointT);
        h = clamp01(h - crease * 0.5);
        aoVal = clampByte(aoVal * (1 - crease * 0.66));
        if (u > 0.74) {
          alpha = 1 - smoothstep(0.74, 1.0, u);
        }
      }

      if (Math.abs(u - 0.74) < 0.03) {
        r = clampByte(r + 18);
        g = clampByte(g + 15);
        b = clampByte(b + 10);
      }

      heights[idx] = h;
      albedoData[pIdx] = r;
      albedoData[pIdx + 1] = g;
      albedoData[pIdx + 2] = b;
      albedoData[pIdx + 3] = clampByte(alpha * 255);

      roughData[pIdx] = rough;
      roughData[pIdx + 1] = rough;
      roughData[pIdx + 2] = rough;
      roughData[pIdx + 3] = 255;

      aoData[pIdx] = aoVal;
      aoData[pIdx + 1] = aoVal;
      aoData[pIdx + 2] = aoVal;
      aoData[pIdx + 3] = 255;
    }
  }

  const normalData = buildNormalDataFromHeights(outW, outH, heights, 5.2, true);

  const aniso = baker.maxAnisotropy;
  const map = makeDataTexture(albedoData, outW, outH, true, false, aniso);
  const normalMap = makeDataTexture(normalData, outW, outH, false, false, aniso);
  const roughnessMap = makeDataTexture(roughData, outW, outH, false, false, aniso);
  const aoMap = makeDataTexture(aoData, outW, outH, false, false, aniso);

  const geometry = new THREE.PlaneGeometry(1, 1, 28, 16);
  const posAttr = geometry.attributes.position as THREE.BufferAttribute;
  const uvAttr = geometry.attributes.uv as THREE.BufferAttribute;
  geometry.setAttribute('uv1', uvAttr);

  for (let i = 0; i < posAttr.count; i += 1) {
    const u = uvAttr.getX(i);
    let spineZ = 0;
    if (u < 0.44) {
      spineZ = 0.022 * Math.sin((u / 0.44) * Math.PI);
    } else {
      const jt = (u - 0.58) / 0.14;
      spineZ = -0.028 * Math.exp(-jt * jt);
    }
    posAttr.setZ(i, spineZ);
  }
  posAttr.needsUpdate = true;
  geometry.computeVertexNormals();

  const material = new THREE.MeshPhysicalMaterial({
    map,
    normalMap,
    normalScale: new THREE.Vector2(2.75, 2.75),
    roughnessMap,
    roughness: 0.74,
    metalness: 0.03,
    aoMap,
    aoMapIntensity: 0.96,
    sheen: 0.62,
    sheenRoughness: 0.4,
    sheenColor: new THREE.Color('#5B7668'),
    clearcoat: 0.3,
    clearcoatRoughness: 0.26,
    transparent: true,
  });

  const mesh = new THREE.Mesh(geometry, material);
  baker.scene.add(mesh);
  baker.renderer.setPixelRatio(1);
  baker.renderer.setSize(outW, outH, false);
  baker.renderer.setClearColor(0x000000, 0);
  baker.renderer.render(baker.scene, baker.camera);
  const uri = baker.renderer.domElement.toDataURL('image/png');

  baker.scene.remove(mesh);
  geometry.dispose();
  material.dispose();
  map.dispose();
  normalMap.dispose();
  roughnessMap.dispose();
  aoMap.dispose();

  baker.spineUriCache = uri;
  return uri;
}

/**
 * Resolves cached non-distorting Three.js PBR layer URIs (tiled base + 9-slice frame + optional spine)
 * instantaneously after the initial one-time session bake.
 */
export function resolvePbrLayerAssets(
  skin: MaterialSkinId,
  region: MaterialRegion,
): PbrLayerAssets | null {
  if (skin === 'solid-fallback' || region === 'existing-divider') return null;

  const isPaper =
    region === 'recipe-open-paper' ||
    region === 'nutrition-matrix' ||
    region === 'folio-front';
  const tileUri = bakePbrTileUri(isPaper ? 'paper' : 'leather');
  if (!tileUri) return null;

  const hasSpine = region === 'recipe-cover-closed' || region === 'folio-back';
  const frameVariant: PbrFrameVariant | null =
    region === 'menu-shell'
      ? 'leather-stitched'
      : hasSpine
        ? 'leather-spine-stitched'
        : region === 'recipe-open-paper' || region === 'folio-front'
          ? 'paper-folio'
          : region === 'nutrition-matrix'
            ? 'paper-matrix'
            : null;

  const frameUri = frameVariant ? bakePbrFrameAtlasUri(frameVariant) : null;
  const spineUri = hasSpine ? bakePbrSpineStripUri() : null;

  return {
    tileUri,
    tileSizeCss: 256,
    frameUri,
    frameSlicePx: 112,
    frameWidthCss: 28,
    spineUri,
    spineWidthCss: 14,
    spineHeightCss: 128,
  };
}

/** Legacy single-surface bake entry retained for compatibility. */
export function bakePbrSurfaceUri(
  skin: MaterialSkinId,
  region: MaterialRegion,
  requestedWidth: number,
  requestedHeight: number,
  dpr = 1,
): PbrBakeResult | null {
  if (skin === 'solid-fallback') return null;
  const isPaper =
    region === 'recipe-open-paper' ||
    region === 'nutrition-matrix' ||
    region === 'folio-front';
  const uri = bakePbrTileUri(isPaper ? 'paper' : 'leather');
  if (!uri) return null;
  return {
    uri,
    widthPx: Math.max(48, Math.round(requestedWidth * Math.min(2, dpr))),
    heightPx: Math.max(48, Math.round(requestedHeight * Math.min(2, dpr))),
  };
}

export function disposeSharedPbrBaker(): void {
  if (!sharedBaker) return;
  sharedBaker.leatherTile = null;
  sharedBaker.paperTile = null;
  sharedBaker.tileUriCache.clear();
  sharedBaker.frameUriCache.clear();
  sharedBaker.spineUriCache = null;
  sharedBaker.envTarget.dispose();
  sharedBaker.pmremGenerator.dispose();
  sharedBaker.renderer.dispose();
  sharedBaker = null;
}
