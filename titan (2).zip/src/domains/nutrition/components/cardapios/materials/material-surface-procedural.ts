import { cardapiosMaterialSkins, cardapiosTokens } from '../styles/cardapios.tokens.ts';
import type {
  ContentSafeInsets,
  FolioMaterial,
  MaterialRegion,
  MaterialSkinId,
  MaterialSurfaceRequest,
} from './material-surface.types.ts';

export const MATERIAL_ASSET_VERSION = 'v9.4.0-maison';

interface RgbColor {
  r: number;
  g: number;
  b: number;
}

function parseHexRgb(hex: string): RgbColor {
  const clean = hex.replace('#', '');
  const r = Number.parseInt(clean.slice(0, 2), 16);
  const g = Number.parseInt(clean.slice(2, 4), 16);
  const b = Number.parseInt(clean.slice(4, 6), 16);
  return {
    r: Number.isFinite(r) ? r : 23,
    g: Number.isFinite(g) ? g : 31,
    b: Number.isFinite(b) ? b : 34,
  };
}

/** Deterministic integer hash (Mulberry32 / splitmix-style) — zero Math.random(). */
function hash2D(ix: number, iy: number, seed: number): number {
  let h = (ix * 374761393 + iy * 668265263 + seed * 1442695041) | 0;
  h = (h ^ (h >>> 13)) * 1274126177;
  h = h ^ (h >>> 16);
  return (h >>> 0) / 4294967295;
}

function smoothNoise2D(x: number, y: number, seed: number): number {
  const x0 = Math.floor(x);
  const y0 = Math.floor(y);
  const fx = x - x0;
  const fy = y - y0;
  const ux = fx * fx * (3 - 2 * fx);
  const uy = fy * fy * (3 - 2 * fy);

  const n00 = hash2D(x0, y0, seed);
  const n10 = hash2D(x0 + 1, y0, seed);
  const n01 = hash2D(x0, y0 + 1, seed);
  const n11 = hash2D(x0 + 1, y0 + 1, seed);

  const nx0 = n00 + (n10 - n00) * ux;
  const nx1 = n01 + (n11 - n01) * ux;
  return nx0 + (nx1 - nx0) * uy;
}

function getSkinSeed(skin: MaterialSkinId, region: MaterialRegion): number {
  const str = `${MATERIAL_ASSET_VERSION}:${skin}:${region}`;
  let acc = 2166136261;
  for (let i = 0; i < str.length; i += 1) {
    acc ^= str.charCodeAt(i);
    acc = Math.imul(acc, 16777619);
  }
  return acc >>> 0;
}

export function resolveFallbackColor(skin: MaterialSkinId, region: MaterialRegion): string {
  if (region === 'folio-front' || region === 'recipe-open-paper' || region === 'nutrition-matrix') {
    return skin === 'solid-fallback'
      ? cardapiosTokens.surfaceRaised
      : cardapiosMaterialSkins.maison.paperNatural;
  }
  if (region === 'folio-back' || region === 'recipe-cover-closed') {
    return skin === 'solid-fallback'
      ? cardapiosTokens.surfacePrimary
      : cardapiosMaterialSkins.maison.leatherLowlight;
  }
  if (skin === 'solid-fallback') {
    return region === 'menu-shell' ? cardapiosTokens.surfacePrimary : cardapiosTokens.surfaceRaised;
  }
  if (skin === 'maison-a1-leather-led' || skin === 'maison-a2-bound-menu') {
    if (region === 'menu-shell') return cardapiosMaterialSkins.maison.leatherBase;
    if (region === 'existing-divider') return cardapiosMaterialSkins.maison.goldTooling;
    return cardapiosTokens.surfaceRaised;
  }
  if (skin === 'grand-service' || skin === 'shikki-roiro' || skin === 'shikki-nuritate') {
    return region === 'menu-shell' ? cardapiosTokens.surfacePrimary : cardapiosTokens.surfaceRaised;
  }
  return cardapiosTokens.surfacePrimary;
}

export function resolveFolioMaterialMetadata(skin: MaterialSkinId): FolioMaterial {
  return {
    frontFallbackColor: resolveFallbackColor(skin, 'folio-front'),
    backFallbackColor: resolveFallbackColor(skin, 'folio-back'),
    assetVersion: MATERIAL_ASSET_VERSION,
  };
}

export function buildMaterialCacheKey(request: MaterialSurfaceRequest): string {
  const qW = Math.max(16, Math.round(request.width / 8) * 8);
  const qH = Math.max(16, Math.round(request.height / 8) * 8);
  const dpr = Math.max(1, Math.min(3, Math.round(request.pixelRatio * 2) / 2));
  const insets = request.contentSafeInsets;
  const insetsKey = insets
    ? `${Math.round(insets.top)}-${Math.round(insets.right)}-${Math.round(insets.bottom)}-${Math.round(insets.left)}`
    : 'none';
  return `${MATERIAL_ASSET_VERSION}:${request.skin}:${request.region}:${qW}x${qH}@${dpr}:${request.colorScheme}:${insetsKey}`;
}

/**
 * Computes normalized [0..1] exclusion weight for `contentSafeInsets`:
 * Returns 0 inside the content-safe region (guaranteeing zero texture behind
 * photos, titles, macros, ingredients, or TBCA digits), feathering smoothly
 * only in the outer perimeter frame.
 */
function computePerimeterMask(
  px: number,
  py: number,
  widthPx: number,
  heightPx: number,
  dpr: number,
  insets?: ContentSafeInsets,
): number {
  if (!insets) return 1;
  const left = Math.max(0, insets.left * dpr);
  const right = Math.max(0, widthPx - insets.right * dpr);
  const top = Math.max(0, insets.top * dpr);
  const bottom = Math.max(0, heightPx - insets.bottom * dpr);

  if (px >= left && px <= right && py >= top && py <= bottom) {
    return 0;
  }

  const feather = Math.max(2, 4 * dpr);
  const distOutside = Math.max(left - px, px - right, top - py, py - bottom, 0);
  return Math.min(1, distOutside / feather);
}

export interface ProceduralPixelSurface {
  widthPx: number;
  heightPx: number;
  data: Uint8ClampedArray;
  fallbackColor: string;
}

/**
 * Renders deterministic, low-amplitude V9/V4 procedural surface pixels:
 * - Morocco goatskin (`menu-shell`): anisotropic organic grain (<= 1.6%) + 1px blind tooling + subtle champagne rule
 * - Smooth/wove editorial surface (`recipe-surface`): subtle outer-perimeter warmth only (0% behind photo/macros)
 * - Rag/cotton smooth/wove (`nutrition-matrix`): ultra-fine cross-wove edge fiber strictly outside glyphs
 * - Transient Folio (`folio-front` / `folio-back`): coherent Maison paper face pair for Origami Folio Reveal
 */
export function generateProceduralSurfacePixels(
  request: MaterialSurfaceRequest,
): ProceduralPixelSurface {
  const dpr = Math.max(1, Math.min(3, request.pixelRatio || 1));
  const widthPx = Math.max(16, Math.min(1440, Math.round(request.width * dpr)));
  const heightPx = Math.max(16, Math.min(1440, Math.round(request.height * dpr)));
  const fallbackColor = resolveFallbackColor(request.skin, request.region);
  const baseRgb = parseHexRgb(fallbackColor);
  const data = new Uint8ClampedArray(widthPx * heightPx * 4);
  const seed = getSkinSeed(request.skin, request.region);

  if (request.skin === 'solid-fallback') {
    for (let i = 0; i < data.length; i += 4) {
      data[i] = baseRgb.r;
      data[i + 1] = baseRgb.g;
      data[i + 2] = baseRgb.b;
      data[i + 3] = 255;
    }
    return { widthPx, heightPx, data, fallbackColor };
  }

  const warmRgb = parseHexRgb(cardapiosMaterialSkins.maison.leatherWarmReflection);
  const goldRgb = parseHexRgb(cardapiosMaterialSkins.maison.goldTooling);
  const blindToolingLight = parseHexRgb('#2D3B3F');
  const blindToolingDark = parseHexRgb('#0D1416');
  const insetPx = Math.max(4, Math.round(5 * dpr));
  const strokePx = Math.max(1, Math.round(dpr));

  for (let py = 0; py < heightPx; py += 1) {
    for (let px = 0; px < widthPx; px += 1) {
      const idx = (py * widthPx + px) * 4;
      const lx = px / dpr;
      const ly = py / dpr;

      let r = baseRgb.r;
      let g = baseRgb.g;
      let b = baseRgb.b;

      const mask = computePerimeterMask(
        px,
        py,
        widthPx,
        heightPx,
        dpr,
        request.contentSafeInsets,
      );

      if (mask > 0) {
        if (request.region === 'folio-front' || request.region === 'folio-back') {
          const warp = smoothNoise2D(lx * 0.65, ly * 0.08, seed + 31) - 0.5;
          const weft = smoothNoise2D(lx * 0.08, ly * 0.65, seed + 71) - 0.5;
          if (request.region === 'folio-front') {
            const sheen = (1 - Math.abs(lx / Math.max(16, request.width) - 0.5) * 1.4) * 2.4;
            const delta = ((warp + weft) * 1.5 + sheen) * mask;
            r += delta;
            g += delta;
            b += delta;
          } else {
            const grain = (smoothNoise2D(lx * 0.25, ly * 0.3, seed + 17) - 0.5) * 2.2;
            const onOuterGoldEdge =
              px === insetPx ||
              px === widthPx - insetPx - 1 ||
              py === insetPx ||
              py === heightPx - insetPx - 1;
            if (onOuterGoldEdge) {
              r = r * 0.78 + goldRgb.r * 0.22;
              g = g * 0.78 + goldRgb.g * 0.22;
              b = b * 0.78 + goldRgb.b * 0.22;
            } else {
              r += grain;
              g += grain;
              b += grain;
            }
          }
        } else if (
          request.skin === 'maison-a1-leather-led' ||
          request.skin === 'maison-a2-bound-menu'
        ) {
          if (request.region === 'menu-shell') {
            // Anisotropic Morocco goatskin micrograin: subtle, non-periodic, <= 1.6% luminance swing
            const grainCoarse = smoothNoise2D(lx * 0.24, ly * 0.31, seed) - 0.5;
            const grainFine = hash2D(Math.floor(lx * 0.9), Math.floor(ly * 0.9), seed + 17) - 0.5;
            const delta = (grainCoarse * 3.1 + grainFine * 1.6) * mask;
            const warmMix = Math.max(0, 1 - ly / Math.max(32, request.height)) * 0.035 * mask;

            r = r + (warmRgb.r - r) * warmMix + delta;
            g = g + (warmRgb.g - g) * warmMix + delta;
            b = b + (warmRgb.b - b) * warmMix + delta;

            // Blind tooling (1px debossed framing inside outer container perimeter only)
            const onTopTooling =
              py >= insetPx && py < insetPx + strokePx && px >= insetPx && px < widthPx - insetPx;
            const onTopShadow =
              py >= insetPx + strokePx &&
              py < insetPx + strokePx * 2 &&
              px >= insetPx &&
              px < widthPx - insetPx;
            // Subtle champagne gold tooling only on A2 top spine inner rule (never bright yellow)
            const onTopGoldRule =
              request.skin === 'maison-a2-bound-menu' &&
              py === insetPx &&
              px >= insetPx * 2 &&
              px < widthPx - insetPx * 2;

            if (onTopGoldRule) {
              r = r * 0.94 + goldRgb.r * 0.06;
              g = g * 0.94 + goldRgb.g * 0.06;
              b = b * 0.94 + goldRgb.b * 0.06;
            } else if (onTopTooling) {
              r = r * 0.65 + blindToolingDark.r * 0.35;
              g = g * 0.65 + blindToolingDark.g * 0.35;
              b = b * 0.65 + blindToolingDark.b * 0.35;
            } else if (onTopShadow) {
              r = r * 0.72 + blindToolingLight.r * 0.28;
              g = g * 0.72 + blindToolingLight.g * 0.28;
              b = b * 0.72 + blindToolingLight.b * 0.28;
            }
          } else if (request.region === 'recipe-surface') {
            if (request.skin === 'maison-a1-leather-led') {
              const grain = (smoothNoise2D(lx * 0.22, ly * 0.28, seed + 19) - 0.5) * 2.2 * mask;
              r += grain;
              g += grain;
              b += grain;
            } else {
              // A2 Bound Menu inner leaf: ultra-quiet smooth/wove editorial edge warmth
              const wove = (smoothNoise2D(lx * 0.5, ly * 0.5, seed + 29) - 0.5) * 1.4 * mask;
              const edgeTone = Math.max(0, 1 - ly / Math.max(28, request.height)) * 1.2 * mask;
              r += wove + edgeTone;
              g += wove + edgeTone;
              b += wove + edgeTone;
            }
          } else if (request.region === 'nutrition-matrix') {
            // Rag/cotton smooth-wove subtle peripheral edge fiber only (never under numbers)
            const crossWove =
              (smoothNoise2D(lx * 0.75, ly * 0.14, seed + 41) +
                smoothNoise2D(lx * 0.14, ly * 0.75, seed + 53) -
                1) *
              1.1 *
              mask;
            r += crossWove;
            g += crossWove;
            b += crossWove;
          }
        } else if (request.skin === 'grand-service') {
          const edgeGlow =
            Math.max(0, 1 - Math.hypot(lx / request.width - 0.2, ly / request.height - 0.1) * 1.8) *
            3.5 *
            mask;
          r += edgeGlow;
          g += edgeGlow;
          b += edgeGlow;
        } else if (request.skin === 'shikki-roiro' || request.skin === 'shikki-nuritate') {
          const spread = request.skin === 'shikki-roiro' ? 2.4 : 1.3;
          const sheen = Math.max(0, 1 - (ly / Math.max(24, request.height)) * spread) * 3.2 * mask;
          r += sheen;
          g += sheen;
          b += sheen;
        }
      }

      data[idx] = Math.max(0, Math.min(255, Math.round(r)));
      data[idx + 1] = Math.max(0, Math.min(255, Math.round(g)));
      data[idx + 2] = Math.max(0, Math.min(255, Math.round(b)));
      data[idx + 3] = 255;
    }
  }

  return { widthPx, heightPx, data, fallbackColor };
}
