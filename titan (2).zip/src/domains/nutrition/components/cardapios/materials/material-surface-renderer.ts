import {
  buildMaterialCacheKey,
  generateProceduralSurfacePixels,
  resolveFallbackColor,
} from './material-surface-procedural.ts';
import {
  bakePbrSurfaceUri,
  canBakePbrInBrowser,
  disposeSharedPbrBaker,
} from './pbr-material-baker.ts';
import type {
  MaterialSurfaceHandle,
  MaterialSurfaceRenderer,
  MaterialSurfaceRequest,
} from './material-surface.types.ts';

interface CacheEntry {
  handle: MaterialSurfaceHandle;
  refCount: number;
  lastUsedAt: number;
}

const MAX_CACHE_ENTRIES = 48;

function canRenderInBrowserCanvas(): boolean {
  return typeof document !== 'undefined' && typeof document.createElement === 'function';
}

function pixelsToDataOrBlobUri(
  widthPx: number,
  heightPx: number,
  data: Uint8ClampedArray,
): string | undefined {
  if (!canRenderInBrowserCanvas()) return undefined;
  try {
    const canvas = document.createElement('canvas');
    canvas.width = widthPx;
    canvas.height = heightPx;
    const ctx = canvas.getContext('2d');
    if (!ctx) return undefined;
    const imageData = ctx.createImageData(widthPx, heightPx);
    imageData.data.set(data);
    ctx.putImageData(imageData, 0, 0);
    return canvas.toDataURL('image/png');
  } catch {
    return undefined;
  }
}

export class MaterialSurfaceRenderer2D implements MaterialSurfaceRenderer {
  private initialized = false;
  private disposed = false;
  private readonly cache = new Map<string, CacheEntry>();

  async initialize(): Promise<void> {
    this.disposed = false;
    this.initialized = true;
  }

  async renderStatic(request: MaterialSurfaceRequest): Promise<MaterialSurfaceHandle> {
    if (this.disposed) {
      await this.initialize();
    }
    if (!this.initialized) {
      await this.initialize();
    }

    const cacheKey = buildMaterialCacheKey(request);
    const existing = this.cache.get(cacheKey);
    if (existing) {
      existing.refCount += 1;
      existing.lastUsedAt = Date.now();
      return existing.handle;
    }

    const fallbackColor = resolveFallbackColor(request.skin, request.region);
    const safeWidth = Math.max(16, Math.round(request.width));
    const safeHeight = Math.max(16, Math.round(request.height));
    const dpr = Math.max(1, Math.min(3, request.pixelRatio || 1));

    if (request.skin === 'solid-fallback' || !canRenderInBrowserCanvas()) {
      const handle: MaterialSurfaceHandle = {
        widthPx: Math.round(safeWidth * dpr),
        heightPx: Math.round(safeHeight * dpr),
        cacheKey,
        fallbackColor,
        isFallback: true,
      };
      this.insertEntry(cacheKey, handle);
      return handle;
    }

    try {
      if (canBakePbrInBrowser() && request.region !== 'existing-divider') {
        const pbr = bakePbrSurfaceUri(request.skin, request.region, safeWidth, safeHeight, dpr);
        if (pbr) {
          const handle: MaterialSurfaceHandle = {
            uri: pbr.uri,
            widthPx: pbr.widthPx,
            heightPx: pbr.heightPx,
            cacheKey,
            fallbackColor,
            isFallback: false,
          };
          this.insertEntry(cacheKey, handle);
          return handle;
        }
      }

      const pixels = generateProceduralSurfacePixels(request);
      const uri = pixelsToDataOrBlobUri(pixels.widthPx, pixels.heightPx, pixels.data);
      const handle: MaterialSurfaceHandle = {
        uri,
        widthPx: pixels.widthPx,
        heightPx: pixels.heightPx,
        cacheKey,
        fallbackColor: pixels.fallbackColor,
        isFallback: !uri,
      };
      this.insertEntry(cacheKey, handle);
      return handle;
    } catch {
      const fallbackHandle: MaterialSurfaceHandle = {
        widthPx: Math.round(safeWidth * dpr),
        heightPx: Math.round(safeHeight * dpr),
        cacheKey,
        fallbackColor,
        isFallback: true,
      };
      this.insertEntry(cacheKey, fallbackHandle);
      return fallbackHandle;
    }
  }

  release(handle: MaterialSurfaceHandle): void {
    const entry = this.cache.get(handle.cacheKey);
    if (!entry) return;
    entry.refCount = Math.max(0, entry.refCount - 1);
  }

  clearUnusedCache(): void {
    for (const [key, entry] of this.cache.entries()) {
      if (entry.refCount <= 0) {
        this.revokeHandleUri(entry.handle);
        this.cache.delete(key);
      }
    }
  }

  async dispose(): Promise<void> {
    for (const entry of this.cache.values()) {
      this.revokeHandleUri(entry.handle);
    }
    this.cache.clear();
    disposeSharedPbrBaker();
    this.initialized = false;
    this.disposed = true;
  }

  getCacheSize(): number {
    return this.cache.size;
  }

  private insertEntry(cacheKey: string, handle: MaterialSurfaceHandle): void {
    if (this.cache.size >= MAX_CACHE_ENTRIES) {
      let oldestUnusedKey: string | null = null;
      let oldestTime = Number.POSITIVE_INFINITY;
      for (const [key, entry] of this.cache.entries()) {
        if (entry.refCount <= 0 && entry.lastUsedAt < oldestTime) {
          oldestTime = entry.lastUsedAt;
          oldestUnusedKey = key;
        }
      }
      if (oldestUnusedKey) {
        const evicted = this.cache.get(oldestUnusedKey);
        if (evicted) this.revokeHandleUri(evicted.handle);
        this.cache.delete(oldestUnusedKey);
      }
    }
    this.cache.set(cacheKey, {
      handle,
      refCount: 1,
      lastUsedAt: Date.now(),
    });
  }

  private revokeHandleUri(handle: MaterialSurfaceHandle): void {
    if (
      handle.uri &&
      handle.uri.startsWith('blob:') &&
      typeof URL !== 'undefined' &&
      typeof URL.revokeObjectURL === 'function'
    ) {
      URL.revokeObjectURL(handle.uri);
    }
  }
}

export const materialSurfaceRenderer2D = new MaterialSurfaceRenderer2D();
