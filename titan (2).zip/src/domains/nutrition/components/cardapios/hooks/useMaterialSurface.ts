import { useEffect, useMemo, useState } from 'react';
import {
  buildMaterialCacheKey,
  resolveFallbackColor,
} from '../materials/material-surface-procedural';
import { materialSurfaceRenderer2D } from '../materials/material-surface-renderer';
import {
  resolvePbrLayerAssets,
  type PbrLayerAssets,
} from '../materials/pbr-material-baker';
import type {
  ContentSafeInsets,
  MaterialRegion,
  MaterialSkinId,
  MaterialSurfaceHandle,
} from '../materials/material-surface.types';

interface UseMaterialSurfaceOptions {
  skin: MaterialSkinId;
  region: MaterialRegion;
  width: number;
  height: number;
  contentSafeInsets?: ContentSafeInsets;
  enabled?: boolean;
}

/**
 * Resolves cached non-distorting Three.js PBR layer assets (tiled surface + 9-slice frame + optional spine)
 * synchronously in the browser so cards and 3D origami leaves never flash blank on Frame 0.
 */
export function useMaterialSurfaceLayers(
  skin: MaterialSkinId,
  region: MaterialRegion,
  enabled = true,
): PbrLayerAssets | null {
  return useMemo(() => {
    if (!enabled) return null;
    return resolvePbrLayerAssets(skin, region);
  }, [enabled, skin, region]);
}

export function useMaterialSurface({
  skin,
  region,
  width,
  height,
  contentSafeInsets,
  enabled = true,
}: UseMaterialSurfaceOptions): MaterialSurfaceHandle {
  const dpr =
    typeof window !== 'undefined' && Number.isFinite(window.devicePixelRatio)
      ? Math.max(1, Math.min(3, window.devicePixelRatio))
      : 1;

  const fallbackColor = resolveFallbackColor(skin, region);
  const safeW = Math.max(16, Math.round(width));
  const safeH = Math.max(16, Math.round(height));

  const [handle, setHandle] = useState<MaterialSurfaceHandle>(() => ({
    widthPx: Math.round(safeW * dpr),
    heightPx: Math.round(safeH * dpr),
    cacheKey: buildMaterialCacheKey({
      skin,
      region,
      width: safeW,
      height: safeH,
      pixelRatio: dpr,
      colorScheme: 'dark',
      contentSafeInsets,
    }),
    fallbackColor,
    isFallback: true,
  }));

  const insetTop = contentSafeInsets?.top ?? 0;
  const insetRight = contentSafeInsets?.right ?? 0;
  const insetBottom = contentSafeInsets?.bottom ?? 0;
  const insetLeft = contentSafeInsets?.left ?? 0;

  useEffect(() => {
    if (!enabled) return;
    let active = true;
    let acquiredHandle: MaterialSurfaceHandle | null = null;

    void materialSurfaceRenderer2D
      .renderStatic({
        skin,
        region,
        width: safeW,
        height: safeH,
        pixelRatio: dpr,
        colorScheme: 'dark',
        contentSafeInsets:
          insetTop || insetRight || insetBottom || insetLeft
            ? { top: insetTop, right: insetRight, bottom: insetBottom, left: insetLeft }
            : undefined,
      })
      .then((nextHandle) => {
        if (!active) {
          materialSurfaceRenderer2D.release(nextHandle);
          return;
        }
        acquiredHandle = nextHandle;
        setHandle(nextHandle);
      });

    return () => {
      active = false;
      if (acquiredHandle) {
        materialSurfaceRenderer2D.release(acquiredHandle);
      }
    };
  }, [
    enabled,
    skin,
    region,
    safeW,
    safeH,
    dpr,
    insetTop,
    insetRight,
    insetBottom,
    insetLeft,
  ]);

  return handle;
}
