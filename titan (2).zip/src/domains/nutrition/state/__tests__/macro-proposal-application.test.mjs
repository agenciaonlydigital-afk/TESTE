import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import esbuild from 'esbuild';
import { ensureTbcaCatalogLoaded } from '../../data/sources/tbca-adapter.ts';

await ensureTbcaCatalogLoaded();

const tmpRoot = path.resolve('node_modules');
await fs.mkdir(tmpRoot, { recursive: true });
const tmpDir = await fs.mkdtemp(path.join(tmpRoot, '.tmp-macro-store-'));

try {
  await esbuild.build({
    entryPoints: [
      path.resolve('src/domains/nutrition/state/nutrition.store.ts'),
      path.resolve('src/domains/nutrition/domain/rules/macro-target-fit.ts'),
      path.resolve('src/domains/nutrition/domain/rules/cardapio-composer-engine.ts'),
    ],
    outdir: tmpDir,
    bundle: true,
    format: 'esm',
    platform: 'node',
    outExtension: { '.js': '.mjs' },
  });

  const { useNutritionStore } = await import(
    pathToFileURL(path.join(tmpDir, 'state/nutrition.store.mjs')).href
  );
  const { solveMacroTargetFitQP } = await import(
    pathToFileURL(path.join(tmpDir, 'domain/rules/macro-target-fit.mjs')).href
  );
  const { cloneDayPlan } = await import(
    pathToFileURL(path.join(tmpDir, 'domain/rules/cardapio-composer-engine.mjs')).href
  );

  const initialState = useNutritionStore.getState();
  const activePlan = initialState.composerPlans.find((p) => p.id === initialState.activeComposerPlanId);
  assert.ok(activePlan, 'initial active plan must exist');
  const dateKey = initialState.activeDateKey;
  const dayBefore = cloneDayPlan(activePlan.days[dateKey]);
  const revBefore = activePlan.revision;
  const inputsRevBefore = initialState.nutritionInputsRevision;
  assert.ok(typeof inputsRevBefore === 'number' && inputsRevBefore >= 1);

  // 1. UI selection does NOT increment nutritionInputsRevision
  initialState.setActiveComposerSlotId('slot-2');
  assert.equal(
    useNutritionStore.getState().nutritionInputsRevision,
    inputsRevBefore,
    'UI slot selection must not bump nutritionInputsRevision',
  );

  // 2. Generating a proposal never mutates store silently
  const customTargets = { kcal: 2100, proteinG: 150, carbsG: 220, fatG: 65 };
  const result = solveMacroTargetFitQP(dayBefore, customTargets);
  assert.deepEqual(
    useNutritionStore.getState().composerPlans.find((p) => p.id === activePlan.id)?.days[dateKey],
    dayBefore,
    'generating optimization proposal must never mutate plan silently',
  );

  // 3. Stale revision rejection: mismatching expectedPlanRevision must reject safely
  const staleRes = useNutritionStore.getState().applyMacroTargetFitProposal(
    dateKey,
    result,
    revBefore + 999,
  );
  assert.equal(staleRes.ok, false);
  assert.equal(staleRes.reason, 'stale_revision');

  // 4. Blocked / infeasible proposal rejection
  const infeasibleResult = {
    ...result,
    status: 'infeasible',
    blockReason: 'UL ultrapassado',
  };
  const blockedRes = useNutritionStore.getState().applyMacroTargetFitProposal(
    dateKey,
    infeasibleResult,
    revBefore,
  );
  assert.equal(blockedRes.ok, false);
  assert.equal(blockedRes.reason, 'infeasible_or_blocked');

  // 5. Target mutation bumps nutritionInputsRevision and plan.revision
  useNutritionStore.getState().updateComposerPlanTargets(activePlan.id, customTargets);
  const afterTargetState = useNutritionStore.getState();
  const revAfterTarget = afterTargetState.composerPlans.find((p) => p.id === activePlan.id).revision;
  assert.ok(revAfterTarget > revBefore, 'updating targets must bump plan.revision');
  assert.ok(afterTargetState.nutritionInputsRevision > inputsRevBefore, 'updating targets must bump nutritionInputsRevision');

  const mealsBeforeApply = structuredClone(afterTargetState.meals);
  const dayPreApply = cloneDayPlan(
    afterTargetState.composerPlans.find((p) => p.id === activePlan.id).days[dateKey],
  );

  // 6. Valid apply commits proposal atomically and records Undo snapshot
  const applyRes = useNutritionStore.getState().applyMacroTargetFitProposal(
    dateKey,
    result,
    revAfterTarget,
  );
  assert.equal(applyRes.ok, true);
  const afterApplyState = useNutritionStore.getState();
  assert.ok(afterApplyState.lastAppliedMacroProposalUndo !== null);
  assert.deepEqual(
    afterApplyState.composerPlans.find((p) => p.id === activePlan.id).days[dateKey],
    result.proposal.proposedDayPlan,
  );

  // 7. Undo atomically restores day plan and synced meals
  const undone = useNutritionStore.getState().undoLastMacroProposal();
  assert.equal(undone, true);
  const afterUndoState = useNutritionStore.getState();
  assert.equal(afterUndoState.lastAppliedMacroProposalUndo, null);
  assert.deepEqual(
    afterUndoState.composerPlans.find((p) => p.id === activePlan.id).days[dateKey],
    dayPreApply,
  );
  assert.deepEqual(afterUndoState.meals, mealsBeforeApply);

  console.log('macro-proposal-application.test.mjs: PASS');
} finally {
  await fs.rm(tmpDir, { recursive: true, force: true });
}
