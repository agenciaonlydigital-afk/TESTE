import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { safeStorageAdapter } from '@/src/infrastructure/storage/local-storage';
import { APP_DAY_KEY } from '@/src/shared/constants/app';
import { getLocalDateKey, isValidLocalDateKey } from '@/src/shared/utils/local-date';
import { mergeNutritionPersistedState, type PersistedNutritionState } from './nutrition-persistence';
import { findRecipeById } from '../data/recipes/recipe-catalog';
import { ensureTbcaCatalogLoaded } from '../data/sources/tbca-adapter';
import type {
  CardapioMealSlot,
  CardapioPlan,
  ComposerAdjustmentMode,
  ComposerDayPlan,
  ComposerMealSlot,
  ComposerPlanStatus,
  CompositionVariant,
  DiscreteCombinationProposal,
  IngredientAdjustment,
  MealFoodPortion,
  MealItem,
  MealTargetAllocation,
  NutritionTargets,
  OptimizationProposal,
  ReferenceProfileId,
} from '../domain/entities/nutrient';
import {
  aggregateDailyMacros,
  resolveFoodById,
  aggregateDailyMicronutrients,
  computeMealDisplayMacros,
  computePortionsMacrosWithQuality,
  getEffectiveConsumedPortions,
  resolveNutrientDisplay,
  resolveReferenceProfile,
  type ResolvedNutrientDisplay,
} from '../domain/rules/nutrition-calculator';
import { validateFoodMacroComposition } from '../domain/rules/food-data-quality';
import { isEligibleRecipeIngredient } from '../domain/rules/food-ingredient-policy';
import {
  buildMealFromCardapioSlot,
  computeRecipeSummary,
  isEligibleRecipeTemplate,
} from '../domain/rules/recipe-engine';
import {
  applyYieldScaleToRecipe,
  buildComposerDayFromMeals,
  buildDefaultMealAllocations,
  buildInitialComposerPlans,
  buildPlanDateRange,
  cloneCardapioPlan,
  cloneDayPlan,
  computeDayNutrition,
  computeDayWeightedDeviationPercent,
  createRecipeInstanceFromCatalog,
  extractMealPortionsFromSlot,
  getEffectiveIngredientBounds,
  getRecipeScaleFactor,
  getScaledReferenceGrams,
  getOptimizationProposalBlockReason,
  isCompositeFoodId,
  roundGramsHalf,
} from '../domain/rules/cardapio-composer-engine';
import { MICRONUTRIENT_ORDER } from '../domain/entities/nutrient';
import { createFoodDiaryMeal, type FoodDiaryMealTitle } from '../domain/rules/food-diary';
import type { RecipeScaleQuantizationResult } from '../domain/rules/recipe-scale-quantization';
import { isValidSupplementMicronutrientIntake, type SupplementMicronutrientIntake } from '../domain/rules/supplement-intake';
import { checkTemporalPlanMutation } from '../domain/rules/temporal-policy';
import type { MultiDayPlanResult } from '../domain/rules/multi-day-planner';

export type { MealItem } from '../domain/entities/nutrient';

export interface DailyMacroGoals {
  kcal: number;
  proteinG: number;
  carbsG: number;
  fatG: number;
}

export interface MacroProposalUndoSnapshot {
  dateKey: string;
  planId: string;
  expectedPlanRevisionAfterApply: number;
  previousDayPlan: ComposerDayPlan;
  previousMeals: MealItem[];
}

interface NutritionState {
  activeDateKey: string;
  referenceProfileId: ReferenceProfileId;
  dailyGoals: DailyMacroGoals;
  meals: MealItem[];
  supplementMicronutrientIntakes: SupplementMicronutrientIntake[];
  addSupplementMicronutrientIntake: (entry: SupplementMicronutrientIntake) => boolean;
  removeSupplementMicronutrientIntake: (id: string) => void;
  intakeDayConfirmations: string[];
  composerPlans: CardapioPlan[];
  activeComposerPlanId: string;
  nutritionInputsRevision: number;
  lastAppliedMacroProposalUndo: MacroProposalUndoSnapshot | null;
  confirmIntakeDay: (dateKey: string) => { ok: true } | { ok: false; error: string };
  setActiveDateKey: (dateKey: string) => void;
  setReferenceProfileId: (profileId: ReferenceProfileId) => void;
  updateDailyGoals: (goals: Partial<DailyMacroGoals>) => void;
  confirmMealConsumed: (mealId: string) => void;
  setMealPartial: (mealId: string, portionFactor: number) => void;
  skipMeal: (mealId: string) => void;
  substituteMeal: (
    mealId: string,
    substitutedFoods: MealFoodPortion[],
    note: string,
    recipeId?: string,
    imageUrl?: string,
  ) => void;
  substituteMealWithRecipe: (mealId: string, recipeId: string) => void;
  restoreMealPlanned: (mealId: string) => void;
  toggleMealCompleted: (mealId: string) => void;
  logFoodToDiary: (foodId: string, quantityG: number, mealTitle: FoodDiaryMealTitle) => { ok: true; mealId: string } | { ok: false; error: string };
  createPlannedMeal: (title: string, time: string) => string | null;
  updatePlannedMeal: (mealId: string, values: { title?: string; time?: string }) => void;
  addFoodToPlannedMeal: (mealId: string, foodId: string, quantityG: number) => boolean;
  updatePlannedMealFood: (mealId: string, foodId: string, quantityG: number) => void;
  removeFoodFromPlannedMeal: (mealId: string, foodId: string) => void;
  deletePlannedMeal: (mealId: string) => void;

  // CardapioComposer actions (plan-scoped & strictly isolated)
  activeComposerSlotId: string | null;
  setActiveComposerSlotId: (slotId: string | null) => void;
  selectComposerPlan: (planId: string) => void;
  createComposerPlan: (input: {
    name: string;
    startDateKey?: string;
    endDateKey?: string;
    duplicateFromPlanId?: string;
    status?: ComposerPlanStatus;
  }) => string | null;
  deleteComposerPlan: (planId: string) => boolean;
  updateComposerPlanMeta: (
    planId: string,
    patch: { name?: string; status?: ComposerPlanStatus; startDateKey?: string; endDateKey?: string },
  ) => void;
  updateComposerPlanTargets: (planId: string, patch: Partial<NutritionTargets>) => void;
  updateComposerMealAllocations: (planId: string, allocations: MealTargetAllocation[]) => void;
  setComposerSlotRecipeYield: (
    dateKey: string,
    slotId: string,
    recipeId: string,
    targetServings: number,
  ) => void;
  setComposerRecipeAdjustmentMode: (
    dateKey: string,
    slotId: string,
    recipeId: string,
    mode: ComposerAdjustmentMode,
    resetToScaled?: boolean,
  ) => void;
  updateComposerIngredient: (
    dateKey: string,
    slotId: string,
    recipeId: string,
    ingredientId: string,
    patch: Partial<Pick<IngredientAdjustment, 'currentQuantityG' | 'mode' | 'minQuantityG' | 'maxQuantityG' | 'quantityStatus'>>,
  ) => void;
  addIngredientToComposerRecipe: (
    dateKey: string,
    slotId: string,
    recipeId: string,
    foodId: string,
    quantityG: number,
  ) => boolean;
  removeIngredientFromComposerRecipe: (
    dateKey: string,
    slotId: string,
    recipeId: string,
    ingredientId: string,
  ) => void;
  replaceCompositeWithSeparateFoods: (
    dateKey: string,
    slotId: string,
    recipeId: string,
    ingredientId: string,
    replacements: Array<{ foodId: string; quantityG: number }>,
  ) => boolean;
  addRecipeToComposerSlot: (
    dateKey: string,
    slotId: string,
    catalogRecipeId: string,
  ) => string | null;
  removeRecipeFromComposerSlot: (
    dateKey: string,
    slotId: string,
    recipeId: string,
  ) => void;
  swapComposerSlotRecipe: (
    dateKey: string,
    slotId: string,
    recipeId: string,
    newCatalogRecipeId: string,
  ) => void;
  addComposerMealSlot: (
    dateKey: string,
    title: string,
    time: string,
    recipeId?: string,
  ) => string | null;
  removeComposerMealSlot: (dateKey: string, slotId: string) => void;
  applyOptimizationProposal: (dateKey: string, proposal: OptimizationProposal) => void;
  applyMacroTargetFitProposal: (
    dateKey: string,
    result: RecipeScaleQuantizationResult,
    expectedPlanRevision: number,
  ) =>
    | { ok: true; appliedPlanRevision: number }
    | { ok: false; reason: 'stale_revision' | 'infeasible_or_blocked' | 'plan_not_found'; error: string };
  undoLastMacroProposal: () => boolean;
  replaceComposerDayPlan: (dateKey: string, dayPlan: ComposerDayPlan) => void;
  applyDiscreteCombinationProposal: (dateKey: string, combination: DiscreteCombinationProposal) => void;
  restoreComposerDayBaseline: (dateKey: string) => void;
  restoreComposerDaySnapshot: (dateKey: string, snapshot: ComposerDayPlan) => void;
  saveCompositionVariant: (
    dateKey: string,
    name: string,
    dayOverride?: ComposerDayPlan,
    description?: string,
  ) => string | null;
  activateCompositionVariant: (dateKey: string, variantId: string) => void;
  deleteCompositionVariant: (variantId: string) => void;
  applyMultiDayPlan: (
    result: MultiDayPlanResult,
    options?: { confirmedToday?: boolean },
  ) => { ok: true; appliedDates: string[] } | { ok: false; error: string };
  bumpNutritionCatalogRevision: () => void;
}

const INITIAL_CARDAPIO_SLOTS: CardapioMealSlot[] = [
  {
    id: 'meal-1',
    dateKey: APP_DAY_KEY,
    time: '07:30',
    title: 'Café da manhã',
    recipeId: 'rec-cafe-completo',
    status: 'planned',
  },
  {
    id: 'meal-2',
    dateKey: APP_DAY_KEY,
    time: '12:30',
    title: 'Almoço',
    recipeId: 'rec-almoco-frango',
    status: 'consumed',
  },
  {
    id: 'meal-3',
    dateKey: APP_DAY_KEY,
    time: '16:00',
    title: 'Lanche da tarde',
    recipeId: 'rec-lanche-iogurte',
    status: 'consumed',
  },
  {
    id: 'meal-4',
    dateKey: APP_DAY_KEY,
    time: '20:30',
    title: 'Jantar',
    recipeId: 'rec-jantar-salmao',
    status: 'planned',
  },
];

const INITIAL_MEALS: MealItem[] = INITIAL_CARDAPIO_SLOTS.map(buildMealFromCardapioSlot);

const INITIAL_DAILY_GOALS: DailyMacroGoals = {
  kcal: 2550,
  proteinG: 170,
  carbsG: 285,
  fatG: 76,
};

const INITIAL_COMPOSER_PLANS: CardapioPlan[] = buildInitialComposerPlans(
  APP_DAY_KEY,
  INITIAL_DAILY_GOALS,
  INITIAL_MEALS,
);

function withoutConfirmedMealDay(state: Pick<NutritionState, 'meals' | 'intakeDayConfirmations'>, mealId: string): string[] {
  const dateKey = state.meals.find((meal) => meal.id === mealId)?.dateKey;
  return dateKey ? state.intakeDayConfirmations.filter((confirmedDate) => confirmedDate !== dateKey) : state.intakeDayConfirmations;
}

function getOrBuildDayInPlan(
  plan: CardapioPlan,
  dateKey: string,
  allMeals: readonly MealItem[],
): ComposerDayPlan {
  const existing = plan.days[dateKey];
  if (existing) return existing;
  return buildComposerDayFromMeals(
    dateKey,
    allMeals.filter((meal) => meal.dateKey === dateKey),
  );
}

function syncComposerSlotToMeals(
  meals: MealItem[],
  dateKey: string,
  slot: ComposerMealSlot,
): MealItem[] {
  const targetId = slot.linkedMealId ?? slot.id;
  const portions = extractMealPortionsFromSlot(slot);
  const totalGrams = portions.reduce((sum, p) => sum + p.quantityG, 0);
  const firstRecipe = slot.recipes[0];
  const exists = meals.some((meal) => meal.id === targetId && meal.dateKey === dateKey);

  if (!exists) {
    return [
      ...meals,
      {
        id: targetId,
        dateKey,
        time: slot.time,
        title: slot.title,
        description: firstRecipe?.name ?? 'Refeição composta no estúdio',
        recipeId: firstRecipe?.sourceRecipeId,
        imageUrl: firstRecipe?.imageUrl,
        planned_quantity: totalGrams,
        consumed_quantity: 0,
        planned_foods: portions,
        consumed_foods: [],
        status: 'planned',
      },
    ];
  }

  return meals.map((meal) => {
    if (meal.id !== targetId || meal.dateKey !== dateKey) return meal;
    return {
      ...meal,
      time: slot.time,
      title: slot.title,
      recipeId: firstRecipe?.sourceRecipeId ?? meal.recipeId,
      imageUrl: firstRecipe?.imageUrl ?? meal.imageUrl,
      description: firstRecipe?.name ?? meal.description,
      planned_quantity: totalGrams,
      planned_foods: portions,
      consumed_foods:
        meal.status === 'consumed'
          ? portions.map((p) => ({ ...p }))
          : meal.consumed_foods,
      consumed_quantity:
        meal.status === 'consumed' ? totalGrams : meal.consumed_quantity,
    };
  });
}

function updateActivePlanDay(
  state: NutritionState,
  dateKey: string,
  updater: (day: ComposerDayPlan, plan: CardapioPlan) => { day: ComposerDayPlan; syncSlotIds?: string[] },
): Partial<NutritionState> {
  const activePlanIndex = state.composerPlans.findIndex(
    (plan) => plan.id === state.activeComposerPlanId,
  );
  if (activePlanIndex === -1) return {};
  const activePlan = state.composerPlans[activePlanIndex]!;
  const currentDay = getOrBuildDayInPlan(activePlan, dateKey, state.meals);
  const { day: nextDay, syncSlotIds } = updater(currentDay, activePlan);

  const nextPlan: CardapioPlan = {
    ...activePlan,
    revision: activePlan.revision + 1,
    activeVariantId: null,
    days: {
      ...activePlan.days,
      [dateKey]: nextDay,
    },
  };

  const nextPlans = state.composerPlans.map((plan, index) =>
    index === activePlanIndex ? nextPlan : plan,
  );

  let nextMeals = state.meals;
  if (activePlan.status === 'active') {
    const idsToSync = syncSlotIds ?? nextDay.slots.map((s) => s.id);
    for (const slot of nextDay.slots) {
      if (idsToSync.includes(slot.id)) {
        nextMeals = syncComposerSlotToMeals(nextMeals, dateKey, slot);
      }
    }
  }

  return {
    composerPlans: nextPlans,
    meals: nextMeals,
    nutritionInputsRevision: state.nutritionInputsRevision + 1,
  };
}

export const useNutritionStore = create<NutritionState>()(persist<NutritionState, [], [], PersistedNutritionState>((set, get) => ({
  activeDateKey: APP_DAY_KEY,
  referenceProfileId: 'adult_male_19_50',
  dailyGoals: INITIAL_DAILY_GOALS,
  meals: INITIAL_MEALS,
  supplementMicronutrientIntakes: [],
  intakeDayConfirmations: [],
  composerPlans: INITIAL_COMPOSER_PLANS,
  activeComposerPlanId: INITIAL_COMPOSER_PLANS[0]?.id ?? 'plan-principal',
  nutritionInputsRevision: 1,
  lastAppliedMacroProposalUndo: null,
  activeComposerSlotId: null,

  addSupplementMicronutrientIntake: (entry) => {
    if (!isValidSupplementMicronutrientIntake(entry)) return false;
    let added = false;
    set((state) => {
      if (state.supplementMicronutrientIntakes.some((item) => item.id === entry.id) ||
          state.supplementMicronutrientIntakes.filter((item) => item.dateKey === entry.dateKey).length >= 100 ||
          state.supplementMicronutrientIntakes.length >= 2000) return state;
      added = true;
      return { supplementMicronutrientIntakes: [...state.supplementMicronutrientIntakes, entry] };
    });
    return added;
  },
  removeSupplementMicronutrientIntake: (id) => set((state) => ({
    supplementMicronutrientIntakes: state.supplementMicronutrientIntakes.filter((item) => item.id !== id),
  })),

  confirmIntakeDay: (dateKey) => {
    const dayMeals = useNutritionStore.getState().meals.filter((meal) => meal.dateKey === dateKey);
    if (dayMeals.length === 0 || dayMeals.some((meal) => meal.status === 'planned')) {
      return { ok: false, error: 'Registre ou pule todas as refeições do dia antes de confirmar.' };
    }
    const portions = dayMeals.flatMap(getEffectiveConsumedPortions);
    const quality = computePortionsMacrosWithQuality(portions);
    if (quality.macros.kcal < 500 || quality.unresolvedFoodIds.length > 0 || quality.lowConfidenceFoodIds.length > 0) {
      return { ok: false, error: 'O dia precisa ter ingestão registrada e alimentos com composição nutricional confiável.' };
    }
    set((state) => ({ intakeDayConfirmations: [...new Set([...state.intakeDayConfirmations, dateKey])] }));
    return { ok: true };
  },

  setActiveDateKey: (dateKey) => set((state) => {
    if (!isValidLocalDateKey(dateKey)) return state;
    const activePlan = state.composerPlans.find((p) => p.id === state.activeComposerPlanId);
    if (!activePlan || activePlan.days[dateKey]) {
      return { activeDateKey: dateKey };
    }
    const hydratedDay = buildComposerDayFromMeals(
      dateKey,
      state.meals.filter((meal) => meal.dateKey === dateKey),
    );
    return {
      activeDateKey: dateKey,
      composerPlans: state.composerPlans.map((plan) =>
        plan.id !== activePlan.id
          ? plan
          : { ...plan, days: { ...plan.days, [dateKey]: hydratedDay } },
      ),
    };
  }),

  setReferenceProfileId: (profileId) => set({ referenceProfileId: profileId }),

  updateDailyGoals: (goals) =>
    set((state) => {
      const nextDailyGoals = {
        ...state.dailyGoals,
        ...goals,
      };
      return {
        dailyGoals: nextDailyGoals,
        nutritionInputsRevision: state.nutritionInputsRevision + 1,
        composerPlans: state.composerPlans.map((plan) =>
          plan.id === state.activeComposerPlanId && plan.targets.sourceLabel === 'Metas diárias TITAN'
            ? {
                ...plan,
                revision: plan.revision + 1,
                targets: {
                  ...plan.targets,
                  kcal: nextDailyGoals.kcal,
                  proteinG: nextDailyGoals.proteinG,
                  carbsG: nextDailyGoals.carbsG,
                  fatG: nextDailyGoals.fatG,
                },
              }
            : plan,
        ),
      };
    }),

  confirmMealConsumed: (mealId) =>
    set((state) => ({
      intakeDayConfirmations: withoutConfirmedMealDay(state, mealId),
      meals: state.meals.map((meal) => {
        if (meal.id !== mealId) return meal;
        if (meal.status === 'substituted' && meal.consumed_foods.length > 0) {
          return {
            ...meal,
            status: 'consumed',
          };
        }
        return {
          ...meal,
          status: 'consumed',
          consumed_quantity: meal.planned_quantity,
          consumed_foods: meal.planned_foods.map((p) => ({ ...p })),
          substitutionNote: undefined,
        };
      }),
    })),

  setMealPartial: (mealId, portionFactor) =>
    set((state) => ({
      intakeDayConfirmations: withoutConfirmedMealDay(state, mealId),
      meals: state.meals.map((meal) => {
        if (meal.id !== mealId) return meal;
        const safeFactor = Number.isFinite(portionFactor) ? Math.max(0.1, Math.min(2, portionFactor)) : 0.5;
        return {
          ...meal,
          status: safeFactor === 1 ? 'consumed' : 'partial',
          consumed_quantity: meal.planned_quantity * safeFactor,
          consumed_foods: meal.planned_foods.map((p) => ({
            foodId: p.foodId,
            quantityG: p.quantityG * safeFactor,
          })),
        };
      }),
    })),

  skipMeal: (mealId) =>
    set((state) => ({
      intakeDayConfirmations: withoutConfirmedMealDay(state, mealId),
      meals: state.meals.map((meal) =>
        meal.id === mealId
          ? {
              ...meal,
              status: 'skipped',
              consumed_quantity: 0,
              consumed_foods: [],
            }
          : meal,
      ),
    })),

  substituteMeal: (mealId, substitutedFoods, note, recipeId, imageUrl) =>
    set((state) => {
      const validFoods = substitutedFoods.filter((food) => {
        const source = resolveFoodById(food.foodId);
        return Number.isFinite(food.quantityG) && food.quantityG > 0 && Boolean(source && validateFoodMacroComposition(source).valid);
      });
      if (validFoods.length === 0) return state;
      return ({
      intakeDayConfirmations: withoutConfirmedMealDay(state, mealId),
      meals: state.meals.map((meal) => {
        if (meal.id !== mealId) return meal;
        const totalG = validFoods.reduce((sum, f) => sum + f.quantityG, 0);
        return {
          ...meal,
          status: 'substituted',
          recipeId: recipeId ?? meal.recipeId,
          imageUrl: imageUrl ?? meal.imageUrl,
          consumed_quantity: Math.round(totalG),
          consumed_foods: validFoods,
          substitutionNote: note,
        };
      }),
    });
    }),

  substituteMealWithRecipe: (mealId, recipeId) =>
    set((state) => {
      const recipe = findRecipeById(recipeId);
      if (!recipe || !isEligibleRecipeTemplate(recipe)) return state;
      const summary = computeRecipeSummary(recipe, 1);
      if (summary.dataCoveragePercent < 100 || summary.unresolvedFoodIds.length > 0) return state;
      return {
        intakeDayConfirmations: withoutConfirmedMealDay(state, mealId),
        meals: state.meals.map((meal) =>
          meal.id !== mealId
            ? meal
            : {
                ...meal,
                status: 'substituted',
                recipeId: recipe.id,
                imageUrl: recipe.imageUrl ?? meal.imageUrl,
                consumed_quantity: summary.totalGrams,
                consumed_foods: summary.portions,
                substitutionNote: recipe.name,
              },
        ),
      };
    }),

  restoreMealPlanned: (mealId) =>
    set((state) => ({
      intakeDayConfirmations: withoutConfirmedMealDay(state, mealId),
      meals: state.meals.map((meal) => {
        if (meal.id !== mealId) return meal;
        const originalSlot = INITIAL_CARDAPIO_SLOTS.find((s) => s.id === meal.id);
        if (originalSlot) {
          return {
            ...buildMealFromCardapioSlot({ ...originalSlot, status: 'planned' }),
            substitutionNote: undefined,
          };
        }
        return {
          ...meal,
          status: 'planned',
          consumed_quantity: 0,
          consumed_foods: [],
          substitutionNote: undefined,
        };
      }),
    })),

  toggleMealCompleted: (mealId) =>
    set((state) => ({
      intakeDayConfirmations: withoutConfirmedMealDay(state, mealId),
      meals: state.meals.map((meal) => {
        if (meal.id !== mealId) return meal;
        const isDone =
          meal.status === 'consumed' ||
          meal.status === 'partial' ||
          meal.status === 'substituted';
        if (isDone) {
          const originalSlot = INITIAL_CARDAPIO_SLOTS.find((s) => s.id === meal.id);
          if (originalSlot) {
            return {
              ...buildMealFromCardapioSlot({ ...originalSlot, status: 'planned' }),
              substitutionNote: undefined,
            };
          }
          return {
            ...meal,
            status: 'planned',
            consumed_quantity: 0,
            consumed_foods: [],
            substitutionNote: undefined,
          };
        }
        return {
          ...meal,
          status: 'consumed',
          consumed_quantity: meal.planned_quantity,
          consumed_foods: meal.planned_foods.map((p) => ({ ...p })),
        };
      }),
    })),

  logFoodToDiary: (foodId, quantityG, mealTitle) => {
    const state = useNutritionStore.getState();
    const food = resolveFoodById(foodId);
    if (!food) return { ok: false, error: 'Alimento não encontrado no catálogo.' };
    if (!validateFoodMacroComposition(food).valid) return { ok: false, error: 'Composição nutricional inconsistente; o alimento foi bloqueado até correção na fonte.' };
    const nowMs = Date.now();
    const meal = createFoodDiaryMeal({
      food,
      quantityG,
      dateKey: state.activeDateKey,
      mealTitle,
      id: `food-log-${nowMs}-${state.meals.length}`,
      nowMs,
    });
    if (!meal) return { ok: false, error: 'Quantidade inválida. Registre entre 1 e 2.000 g.' };
    if (state.meals.length >= 2000) return { ok: false, error: 'Limite local de 2.000 refeições atingido. Exporte seu backup antes de remover registros antigos.' };
    set((current) => ({
      meals: [...current.meals, meal],
      intakeDayConfirmations: current.intakeDayConfirmations.filter((dateKey) => dateKey !== meal.dateKey),
    }));
    return { ok: true, mealId: meal.id };
  },

  createPlannedMeal: (title, time) => {
    const normalizedTitle = title.trim().slice(0, 80);
    if (!normalizedTitle || !/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) return null;
    const state = useNutritionStore.getState();
    if (state.meals.length >= 2000 || state.meals.filter((meal) => meal.dateKey === state.activeDateKey).length >= 30) return null;
    const id = `custom-meal-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
    set((current) => ({ meals: [...current.meals, { id, dateKey: current.activeDateKey, time, title: normalizedTitle,
      description: 'Refeição personalizada', planned_quantity: 0, consumed_quantity: 0, planned_foods: [], consumed_foods: [], status: 'planned' }],
      intakeDayConfirmations: current.intakeDayConfirmations.filter((dateKey) => dateKey !== current.activeDateKey) }));
    return id;
  },

  updatePlannedMeal: (mealId, values) => set((state) => ({
    meals: state.meals.map((meal) => meal.id !== mealId || !meal.id.startsWith('custom-meal-') ? meal : {
      ...meal,
      title: values.title === undefined ? meal.title : values.title.trim().slice(0, 80) || meal.title,
      time: values.time === undefined || !/^([01]\d|2[0-3]):[0-5]\d$/.test(values.time) ? meal.time : values.time,
    }),
    intakeDayConfirmations: withoutConfirmedMealDay(state, mealId),
  })),

  addFoodToPlannedMeal: (mealId, foodId, quantityG) => {
    const food = resolveFoodById(foodId);
    if (!Number.isFinite(quantityG) || quantityG < 1 || quantityG > 2000 || !food || !validateFoodMacroComposition(food).valid) return false;
    const state = useNutritionStore.getState();
    const meal = state.meals.find((item) => item.id === mealId);
    if (!meal || !meal.id.startsWith('custom-meal-') || meal.planned_foods.length >= 40) return false;
    const existingQuantity = meal.planned_foods.find((portion) => portion.foodId === foodId)?.quantityG ?? 0;
    if (existingQuantity + quantityG > 2000) return false;
    set((current) => ({ meals: current.meals.map((item) => item.id !== mealId ? item : {
      ...item,
      planned_foods: [...item.planned_foods.filter((portion) => portion.foodId !== foodId), {
        foodId, quantityG: (item.planned_foods.find((portion) => portion.foodId === foodId)?.quantityG ?? 0) + quantityG,
      }],
      planned_quantity: item.planned_quantity + quantityG,
    }), intakeDayConfirmations: withoutConfirmedMealDay(current, mealId) }));
    return true;
  },

  updatePlannedMealFood: (mealId, foodId, quantityG) => {
    if (!Number.isFinite(quantityG) || quantityG < 1 || quantityG > 2000) return;
    set((state) => ({ meals: state.meals.map((meal) => {
      if (meal.id !== mealId || !meal.id.startsWith('custom-meal-')) return meal;
      const planned_foods = meal.planned_foods.map((portion) => portion.foodId === foodId ? { ...portion, quantityG } : portion);
      return { ...meal, planned_foods, planned_quantity: planned_foods.reduce((sum, portion) => sum + portion.quantityG, 0) };
    }), intakeDayConfirmations: withoutConfirmedMealDay(state, mealId) }));
  },

  removeFoodFromPlannedMeal: (mealId, foodId) => set((state) => ({ meals: state.meals.map((meal) => {
    if (meal.id !== mealId || !meal.id.startsWith('custom-meal-')) return meal;
    const planned_foods = meal.planned_foods.filter((portion) => portion.foodId !== foodId);
    return { ...meal, planned_foods, planned_quantity: planned_foods.reduce((sum, portion) => sum + portion.quantityG, 0) };
  }), intakeDayConfirmations: withoutConfirmedMealDay(state, mealId) })),

  deletePlannedMeal: (mealId) => set((state) => ({
    meals: state.meals.filter((meal) => meal.id !== mealId || !meal.id.startsWith('custom-meal-')),
    intakeDayConfirmations: withoutConfirmedMealDay(state, mealId),
  })),

  // ==========================================
  // CardapioComposer Actions
  // ==========================================

  setActiveComposerSlotId: (slotId) => set({ activeComposerSlotId: slotId }),

  selectComposerPlan: (planId) => set((state) => {
    const exists = state.composerPlans.find((plan) => plan.id === planId);
    if (!exists) return state;
    return { activeComposerPlanId: planId };
  }),

  createComposerPlan: ({ name, startDateKey, endDateKey, duplicateFromPlanId, status }) => {
    const cleanName = name.trim().slice(0, 100);
    if (!cleanName) return null;
    const state = useNutritionStore.getState();
    if (state.composerPlans.length >= 20) return null;

    const newId = `plan-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
    let nextPlan: CardapioPlan;

    if (duplicateFromPlanId) {
      const source = state.composerPlans.find((p) => p.id === duplicateFromPlanId);
      if (!source) return null;
      const cloned = cloneCardapioPlan(source);
      nextPlan = {
        ...cloned,
        id: newId,
        name: cleanName,
        revision: 1,
        status: status ?? 'draft',
        startDateKey: startDateKey && isValidLocalDateKey(startDateKey) ? startDateKey : cloned.startDateKey,
        endDateKey: endDateKey && isValidLocalDateKey(endDateKey) ? endDateKey : cloned.endDateKey,
        variants: cloned.variants.map((v, idx) => ({ ...v, id: `${newId}-var-${idx + 1}` })),
      };
    } else {
      const range = buildPlanDateRange(state.activeDateKey, 7);
      const sKey = startDateKey && isValidLocalDateKey(startDateKey) ? startDateKey : (range[0] ?? state.activeDateKey);
      const eKey = endDateKey && isValidLocalDateKey(endDateKey) ? endDateKey : (range[range.length - 1] ?? state.activeDateKey);
      const days: Record<string, ComposerDayPlan> = {};
      for (const dateKey of range) {
        days[dateKey] = buildComposerDayFromMeals(dateKey, []);
      }
      const firstSlots = days[state.activeDateKey]?.slots ?? [];
      nextPlan = {
        id: newId,
        name: cleanName,
        revision: 1,
        status: status ?? 'draft',
        startDateKey: sKey,
        endDateKey: eKey,
        targets: {
          ...state.dailyGoals,
          sourceLabel: 'Meta independente do plano',
        },
        mealAllocations: buildDefaultMealAllocations(firstSlots),
        days,
        variants: [],
        activeVariantId: null,
      };
    }

    set((current) => ({
      composerPlans: [...current.composerPlans, nextPlan],
      activeComposerPlanId: newId,
    }));
    return newId;
  },

  deleteComposerPlan: (planId) => {
    const state = useNutritionStore.getState();
    if (state.composerPlans.length <= 1) return false;
    const remaining = state.composerPlans.filter((p) => p.id !== planId);
    if (remaining.length === state.composerPlans.length) return false;

    const nextActive =
      state.activeComposerPlanId === planId
        ? remaining.find((p) => p.status === 'active')?.id ?? remaining[0]!.id
        : state.activeComposerPlanId;

    set({
      composerPlans: remaining,
      activeComposerPlanId: nextActive,
    });
    return true;
  },

  updateComposerPlanMeta: (planId, patch) => set((state) => ({
    composerPlans: state.composerPlans.map((plan) => {
      if (plan.id === planId) {
        return {
          ...plan,
          name: patch.name !== undefined && patch.name.trim() ? patch.name.trim().slice(0, 100) : plan.name,
          status: patch.status ?? plan.status,
          startDateKey:
            patch.startDateKey && isValidLocalDateKey(patch.startDateKey)
              ? patch.startDateKey
              : plan.startDateKey,
          endDateKey:
            patch.endDateKey && isValidLocalDateKey(patch.endDateKey)
              ? patch.endDateKey
              : plan.endDateKey,
        };
      }
      // If promoting planId to active, archive/demote other active plans cleanly
      if (patch.status === 'active' && plan.status === 'active') {
        return { ...plan, status: 'draft' };
      }
      return plan;
    }),
  })),

  updateComposerPlanTargets: (planId, patch) => set((state) => ({
    nutritionInputsRevision: state.nutritionInputsRevision + 1,
    composerPlans: state.composerPlans.map((plan) => {
      if (plan.id !== planId) return plan;
      return {
        ...plan,
        revision: plan.revision + 1,
        targets: {
          ...plan.targets,
          ...patch,
        },
      };
    }),
  })),

  updateComposerMealAllocations: (planId, allocations) => set((state) => {
    const normalizeShare = (val: number | null | undefined) =>
      val === undefined || val === null || !Number.isFinite(val)
        ? null
        : Math.max(0, Math.min(100, Number(val.toFixed(1))));
    return {
      nutritionInputsRevision: state.nutritionInputsRevision + 1,
      composerPlans: state.composerPlans.map((plan) => {
        if (plan.id !== planId) return plan;
        return {
          ...plan,
          revision: plan.revision + 1,
          mealAllocations: allocations.map((a) => ({
            slotId: a.slotId,
            energySharePercent: Math.max(0, Math.min(100, Number(a.energySharePercent.toFixed(1)))),
            proteinSharePercent: normalizeShare(a.proteinSharePercent),
            carbsSharePercent: normalizeShare(a.carbsSharePercent),
            fatSharePercent: normalizeShare(a.fatSharePercent),
          })),
        };
      }),
    };
  }),

  setComposerSlotRecipeYield: (dateKey, slotId, recipeId, targetServings) =>
    set((state) =>
      updateActivePlanDay(state, dateKey, (day) => ({
        syncSlotIds: [slotId],
        day: {
          ...day,
          slots: day.slots.map((slot) =>
            slot.id !== slotId
              ? slot
              : {
                  ...slot,
                  recipes: slot.recipes.map((recipe) =>
                    recipe.id !== recipeId
                      ? recipe
                      : applyYieldScaleToRecipe(recipe, targetServings),
                  ),
                },
          ),
        },
      })),
    ),

  setComposerRecipeAdjustmentMode: (dateKey, slotId, recipeId, mode, resetToScaled = false) =>
    set((state) =>
      updateActivePlanDay(state, dateKey, (day) => ({
        syncSlotIds: [slotId],
        day: {
          ...day,
          slots: day.slots.map((slot) =>
            slot.id !== slotId
              ? slot
              : {
                  ...slot,
                  recipes: slot.recipes.map((recipe) => {
                    if (recipe.id !== recipeId) return recipe;
                    const scale = getRecipeScaleFactor(recipe);
                    return {
                      ...recipe,
                      adjustmentMode: mode,
                      ingredients: recipe.ingredients.map((ing) => {
                        if (mode === 'proportional') {
                          const refG = getScaledReferenceGrams(ing, scale);
                          return {
                            ...ing,
                            mode: ing.mode === 'locked' && !resetToScaled ? 'locked' : 'proportional',
                            currentQuantityG:
                              resetToScaled && refG !== null
                                ? refG
                                : ing.mode !== 'locked' && refG !== null
                                  ? refG
                                  : ing.currentQuantityG,
                          };
                        }
                        if (ing.mode === 'proportional' && mode === 'balanced') {
                          return { ...ing, mode: 'flexible' };
                        }
                        return ing;
                      }),
                    };
                  }),
                },
          ),
        },
      })),
    ),

  updateComposerIngredient: (dateKey, slotId, recipeId, ingredientId, patch) =>
    set((state) =>
      updateActivePlanDay(state, dateKey, (day) => ({
        syncSlotIds: [slotId],
        day: {
          ...day,
          slots: day.slots.map((slot) =>
            slot.id !== slotId
              ? slot
              : {
                  ...slot,
                  recipes: slot.recipes.map((recipe) => {
                    if (recipe.id !== recipeId) return recipe;
                    const scale = getRecipeScaleFactor(recipe);
                    return {
                      ...recipe,
                      ingredients: recipe.ingredients.map((ing) => {
                        if (ing.id !== ingredientId) return ing;
                        const updated: IngredientAdjustment = {
                          ...ing,
                          ...patch,
                        };
                        if (patch.mode === 'proportional') {
                          const refG = getScaledReferenceGrams(updated, scale);
                          if (refG !== null) updated.currentQuantityG = refG;
                        } else if (
                          patch.currentQuantityG !== undefined &&
                          patch.currentQuantityG !== null &&
                          Number.isFinite(patch.currentQuantityG)
                        ) {
                          const bounds = getEffectiveIngredientBounds(updated, scale);
                          updated.currentQuantityG = Math.max(
                            bounds.minG,
                            Math.min(bounds.maxG, roundGramsHalf(patch.currentQuantityG)),
                          );
                          updated.quantityStatus = 'known';
                        }
                        return updated;
                      }),
                    };
                  }),
                },
          ),
        },
      })),
    ),

  addIngredientToComposerRecipe: (dateKey, slotId, recipeId, foodId, quantityG) => {
    if (!Number.isFinite(quantityG) || quantityG < 1 || quantityG > 2000) return false;
    const food = resolveFoodById(foodId);
    if (!food || !validateFoodMacroComposition(food).valid || !isEligibleRecipeIngredient(food)) return false;
    let added = false;
    set((state) =>
      updateActivePlanDay(state, dateKey, (day) => ({
        syncSlotIds: [slotId],
        day: {
          ...day,
          slots: day.slots.map((slot) => {
            if (slot.id !== slotId) return slot;
            return {
              ...slot,
              recipes: slot.recipes.map((recipe) => {
                if (recipe.id !== recipeId || recipe.ingredients.length >= 40) return recipe;
                const cleanG = roundGramsHalf(quantityG);
                const existing = recipe.ingredients.find((ing) => ing.foodId === foodId);
                added = true;
                if (existing) {
                  return {
                    ...recipe,
                    ingredients: recipe.ingredients.map((ing) =>
                      ing.id === existing.id
                        ? {
                            ...ing,
                            currentQuantityG: Math.min(2000, (ing.currentQuantityG ?? 0) + cleanG),
                            quantityStatus: 'known',
                          }
                        : ing,
                    ),
                  };
                }
                const newIng: IngredientAdjustment = {
                  id: `${recipeId}-ing-${Date.now().toString(36)}`,
                  foodId,
                  displayName: food.name,
                  baseQuantityG: cleanG,
                  currentQuantityG: cleanG,
                  quantityStatus: 'known',
                  mode: 'flexible',
                  minQuantityG: Math.max(5, roundGramsHalf(cleanG * 0.45)),
                  maxQuantityG: Math.min(2000, Math.max(20, roundGramsHalf(cleanG * 1.85))),
                  isCompositeDish: isCompositeFoodId(foodId),
                };
                return {
                  ...recipe,
                  ingredients: [...recipe.ingredients, newIng],
                };
              }),
            };
          }),
        },
      })),
    );
    return added;
  },

  removeIngredientFromComposerRecipe: (dateKey, slotId, recipeId, ingredientId) =>
    set((state) =>
      updateActivePlanDay(state, dateKey, (day) => ({
        syncSlotIds: [slotId],
        day: {
          ...day,
          slots: day.slots.map((slot) =>
            slot.id !== slotId
              ? slot
              : {
                  ...slot,
                  recipes: slot.recipes.map((recipe) =>
                    recipe.id !== recipeId
                      ? recipe
                      : {
                          ...recipe,
                          ingredients: recipe.ingredients.filter((ing) => ing.id !== ingredientId),
                        },
                  ),
                },
          ),
        },
      })),
    ),

  replaceCompositeWithSeparateFoods: (dateKey, slotId, recipeId, ingredientId, replacements) => {
    const valid = replacements
      .filter((r) => {
        const food = resolveFoodById(r.foodId);
        return Number.isFinite(r.quantityG) && r.quantityG >= 1 && r.quantityG <= 2000 && Boolean(food && validateFoodMacroComposition(food).valid && isEligibleRecipeIngredient(food));
      })
      .slice(0, 12);
    if (valid.length === 0) return false;
    let applied = false;
    set((state) =>
      updateActivePlanDay(state, dateKey, (day) => ({
        syncSlotIds: [slotId],
        day: {
          ...day,
          slots: day.slots.map((slot) => {
            if (slot.id !== slotId) return slot;
            return {
              ...slot,
              recipes: slot.recipes.map((recipe) => {
                if (recipe.id !== recipeId) return recipe;
                const idx = recipe.ingredients.findIndex((ing) => ing.id === ingredientId);
                if (idx === -1) return recipe;
                applied = true;
                const newItems: IngredientAdjustment[] = valid.map((rep, repIdx) => {
                  const food = resolveFoodById(rep.foodId)!;
                  const cleanG = roundGramsHalf(rep.quantityG);
                  return {
                    id: `${recipeId}-split-${Date.now().toString(36)}-${repIdx}`,
                    foodId: rep.foodId,
                    displayName: food.name,
                    baseQuantityG: cleanG,
                    currentQuantityG: cleanG,
                    quantityStatus: 'known',
                    mode: 'flexible',
                    minQuantityG: Math.max(5, roundGramsHalf(cleanG * 0.45)),
                    maxQuantityG: Math.min(2000, Math.max(20, roundGramsHalf(cleanG * 1.85))),
                    isCompositeDish: isCompositeFoodId(rep.foodId),
                  };
                });
                const nextIngredients = [...recipe.ingredients];
                nextIngredients.splice(idx, 1, ...newItems);
                return {
                  ...recipe,
                  ingredients: nextIngredients.slice(0, 40),
                };
              }),
            };
          }),
        },
      })),
    );
    return applied;
  },

  addRecipeToComposerSlot: (dateKey, slotId, catalogRecipeId) => {
    const catalogRecipe = findRecipeById(catalogRecipeId);
    if (!catalogRecipe || !isEligibleRecipeTemplate(catalogRecipe)) return null;
    const newRecipeId = `${slotId}-rec-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 5)}`;
    set((state) =>
      updateActivePlanDay(state, dateKey, (day) => ({
        syncSlotIds: [slotId],
        day: {
          ...day,
          slots: day.slots.map((slot) => {
            if (slot.id !== slotId || slot.recipes.length >= 12) return slot;
            return {
              ...slot,
              recipes: [
                ...slot.recipes,
                createRecipeInstanceFromCatalog(catalogRecipe, newRecipeId, 1, 'balanced'),
              ],
            };
          }),
        },
      })),
    );
    return newRecipeId;
  },

  removeRecipeFromComposerSlot: (dateKey, slotId, recipeId) =>
    set((state) =>
      updateActivePlanDay(state, dateKey, (day) => ({
        syncSlotIds: [slotId],
        day: {
          ...day,
          slots: day.slots.map((slot) => {
            if (slot.id !== slotId || slot.recipes.length <= 1) return slot;
            return {
              ...slot,
              recipes: slot.recipes.filter((r) => r.id !== recipeId),
            };
          }),
        },
      })),
    ),

  swapComposerSlotRecipe: (dateKey, slotId, recipeId, newCatalogRecipeId) =>
    set((state) => {
      const catalogRecipe = findRecipeById(newCatalogRecipeId);
      if (!catalogRecipe || !isEligibleRecipeTemplate(catalogRecipe)) return state;
      return updateActivePlanDay(state, dateKey, (day) => ({
        syncSlotIds: [slotId],
        day: {
          ...day,
          slots: day.slots.map((slot) =>
            slot.id !== slotId
              ? slot
              : {
                  ...slot,
                  recipes: slot.recipes.map((recipe) =>
                    recipe.id !== recipeId
                      ? recipe
                      : createRecipeInstanceFromCatalog(
                          catalogRecipe,
                          recipe.id,
                          recipe.targetServings,
                          recipe.adjustmentMode,
                        ),
                  ),
                },
          ),
        },
      }));
    }),

  addComposerMealSlot: (dateKey, title, time, recipeId) => {
    const cleanTitle = title.trim().slice(0, 80);
    if (!cleanTitle || !/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) return null;
    const slotId = `slot-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
    const catalogRecipe = recipeId ? findRecipeById(recipeId) : undefined;
    if (recipeId && (!catalogRecipe || !isEligibleRecipeTemplate(catalogRecipe))) return null;
    const category =
      catalogRecipe?.category ??
      (time < '11:00' ? 'cafe' : time < '15:00' ? 'almoco' : time < '19:00' ? 'lanche' : 'jantar');

    set((state) => {
      const result = updateActivePlanDay(state, dateKey, (day) => {
        const nextSlot: ComposerMealSlot = {
          id: slotId,
          time,
          title: cleanTitle,
          linkedMealId: `custom-meal-${slotId}`,
          recipes: [
            catalogRecipe
              ? createRecipeInstanceFromCatalog(catalogRecipe, `${slotId}-rec-1`, 1, 'balanced')
              : {
                  id: `${slotId}-rec-1`,
                  name: cleanTitle,
                  description: 'Composição personalizada',
                  category,
                  baseServings: 1,
                  targetServings: 1,
                  adjustmentMode: 'balanced',
                  ingredients: [
                    {
                      id: `${slotId}-ing-1`,
                      foodId: 'tbca-banana-prata',
                      displayName: resolveFoodById('tbca-banana-prata')?.name ?? 'Banana prata',
                      baseQuantityG: 100,
                      currentQuantityG: 100,
                      quantityStatus: 'known',
                      mode: 'flexible',
                      minQuantityG: 45,
                      maxQuantityG: 200,
                    },
                  ],
                },
          ],
        };
        const slots = [...day.slots, nextSlot].sort((a, b) => a.time.localeCompare(b.time));
        return {
          syncSlotIds: [slotId],
          day: {
            ...day,
            slots,
          },
        };
      });

      if (!result.composerPlans) return state;
      const updatedPlans = result.composerPlans.map((plan) => {
        if (plan.id !== state.activeComposerPlanId) return plan;
        const alreadyHasAlloc = plan.mealAllocations.some((a) => a.slotId === slotId);
        if (alreadyHasAlloc) return plan;
        return {
          ...plan,
          mealAllocations: [...plan.mealAllocations, { slotId, energySharePercent: 0 }],
        };
      });
      return {
        ...result,
        composerPlans: updatedPlans,
      };
    });

    return slotId;
  },

  removeComposerMealSlot: (dateKey, slotId) =>
    set((state) => {
      const result = updateActivePlanDay(state, dateKey, (day) => ({
        day: {
          ...day,
          slots: day.slots.filter((slot) => slot.id !== slotId),
        },
      }));
      if (!result.composerPlans) return state;
      return {
        ...result,
        composerPlans: result.composerPlans.map((plan) =>
          plan.id !== state.activeComposerPlanId
            ? plan
            : {
                ...plan,
                mealAllocations: plan.mealAllocations.filter((a) => a.slotId !== slotId),
              },
        ),
      };
    }),

  applyOptimizationProposal: (dateKey, proposal) => {
    if (getOptimizationProposalBlockReason(proposal)) return;
    set((state) =>
      updateActivePlanDay(state, dateKey, () => ({
        day: cloneDayPlan(proposal.proposedDayPlan),
      })),
    );
  },

  applyMacroTargetFitProposal: (dateKey, result, expectedPlanRevision) => {
    const blockReason = result.blockReason ?? getOptimizationProposalBlockReason(result.proposal);
    if (result.status === 'infeasible' || blockReason !== null) {
      return {
        ok: false,
        reason: 'infeasible_or_blocked',
        error: blockReason ?? 'Proposta inviável para os limites atuais e não pode ser aplicada.',
      };
    }

    const current = get();
    const activePlan = current.composerPlans.find((p) => p.id === current.activeComposerPlanId);
    if (!activePlan) {
      return {
        ok: false,
        reason: 'plan_not_found',
        error: 'Plano ativo não encontrado para aplicação da proposta.',
      };
    }
    if (activePlan.revision !== expectedPlanRevision) {
      return {
        ok: false,
        reason: 'stale_revision',
        error: 'O cardápio foi alterado após o cálculo desta proposta. Recalcule antes de aplicar.',
      };
    }

    let appliedPlanRevision = activePlan.revision;
    set((state) => {
      const targetPlan = state.composerPlans.find((p) => p.id === state.activeComposerPlanId);
      if (!targetPlan || targetPlan.revision !== expectedPlanRevision) return state;
      const previousDayPlan = cloneDayPlan(getOrBuildDayInPlan(targetPlan, dateKey, state.meals));
      const previousMeals = state.meals.map((m) => ({
        ...m,
        planned_foods: m.planned_foods.map((p) => ({ ...p })),
        consumed_foods: m.consumed_foods.map((p) => ({ ...p })),
      }));
      const next = updateActivePlanDay(state, dateKey, () => ({
        day: cloneDayPlan(result.proposal.proposedDayPlan),
      }));
      const nextPlan = next.composerPlans?.find((p) => p.id === targetPlan.id);
      if (!nextPlan) return state;
      appliedPlanRevision = nextPlan.revision;
      return {
        ...next,
        lastAppliedMacroProposalUndo: {
          dateKey,
          planId: targetPlan.id,
          expectedPlanRevisionAfterApply: appliedPlanRevision,
          previousDayPlan,
          previousMeals,
        },
      };
    });

    if (appliedPlanRevision === activePlan.revision) {
      return {
        ok: false,
        reason: 'stale_revision',
        error: 'A revisão do plano mudou concorrentemente antes da confirmação.',
      };
    }
    return { ok: true, appliedPlanRevision };
  },

  undoLastMacroProposal: () => {
    const state = get();
    const undo = state.lastAppliedMacroProposalUndo;
    if (!undo) return false;
    set((current) => {
      const undoSnapshot = current.lastAppliedMacroProposalUndo;
      if (!undoSnapshot) return current;
      const planIdx = current.composerPlans.findIndex((p) => p.id === undoSnapshot.planId);
      if (planIdx === -1) {
        return { lastAppliedMacroProposalUndo: null };
      }
      const targetPlan = current.composerPlans[planIdx]!;
      const restoredPlan: CardapioPlan = {
        ...targetPlan,
        revision: targetPlan.revision + 1,
        days: {
          ...targetPlan.days,
          [undoSnapshot.dateKey]: cloneDayPlan(undoSnapshot.previousDayPlan),
        },
      };
      return {
        composerPlans: current.composerPlans.map((p, idx) => (idx === planIdx ? restoredPlan : p)),
        meals: undoSnapshot.previousMeals.map((m) => ({
          ...m,
          planned_foods: m.planned_foods.map((p) => ({ ...p })),
          consumed_foods: m.consumed_foods.map((p) => ({ ...p })),
        })),
        nutritionInputsRevision: current.nutritionInputsRevision + 1,
        lastAppliedMacroProposalUndo: null,
      };
    });
    return true;
  },

  replaceComposerDayPlan: (dateKey, dayPlan) =>
    set((state) => {
      if (dayPlan.dateKey !== dateKey) return state;
      return updateActivePlanDay(state, dateKey, () => ({
        day: cloneDayPlan(dayPlan),
      }));
    }),

  applyDiscreteCombinationProposal: (dateKey, combination) =>
    set((state) =>
      updateActivePlanDay(state, dateKey, (day) => {
        const swapBySlot = new Map(combination.swaps.map((sw) => [sw.slotId, sw]));
        return {
          syncSlotIds: combination.swaps.map((sw) => sw.slotId),
          day: {
            ...day,
            slots: day.slots.map((slot) => {
              const sw = swapBySlot.get(slot.id);
              if (!sw) return slot;
              const catalogRecipe = findRecipeById(sw.candidateRecipeId);
              if (!catalogRecipe || !isEligibleRecipeTemplate(catalogRecipe)) return slot;
              return {
                ...slot,
                recipes: slot.recipes.map((recipe) =>
                  recipe.id !== sw.currentRecipeId
                    ? recipe
                    : createRecipeInstanceFromCatalog(
                        catalogRecipe,
                        recipe.id,
                        recipe.targetServings,
                        recipe.adjustmentMode,
                      ),
                ),
              };
            }),
          },
        };
      }),
    ),

  restoreComposerDayBaseline: (dateKey) =>
    set((state) =>
      updateActivePlanDay(state, dateKey, (day) => ({
        day: {
          ...day,
          slots: day.slots.map((slot) => ({
            ...slot,
            recipes: slot.recipes.map((recipe) => {
              const scale = getRecipeScaleFactor(recipe);
              return {
                ...recipe,
                adjustmentMode: 'proportional',
                ingredients: recipe.ingredients.map((ing) => {
                  const refG = getScaledReferenceGrams(ing, scale);
                  if (ing.quantityStatus !== 'known' || refG === null) return ing;
                  return {
                    ...ing,
                    mode: 'proportional',
                    currentQuantityG: refG,
                  };
                }),
              };
            }),
          })),
        },
      })),
    ),

  restoreComposerDaySnapshot: (dateKey, snapshot) =>
    set((state) =>
      updateActivePlanDay(state, dateKey, () => ({
        day: cloneDayPlan({ ...snapshot, dateKey }),
      })),
    ),

  saveCompositionVariant: (dateKey, name, dayOverride, description) => {
    const cleanName = name.trim().slice(0, 80);
    if (!cleanName) return null;
    const state = useNutritionStore.getState();
    const activePlan = state.composerPlans.find((p) => p.id === state.activeComposerPlanId);
    if (!activePlan || activePlan.variants.length >= 24) return null;

    const targetDay = cloneDayPlan(
      dayOverride ?? getOrBuildDayInPlan(activePlan, dateKey, state.meals),
    );
    const summary = computeDayNutrition(targetDay);
    const variantId = `var-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 5)}`;

    const variant: CompositionVariant = {
      id: variantId,
      name: cleanName,
      createdAt: new Date().toISOString(),
      description,
      dayPlan: targetDay,
      weightedDeviationPercent: computeDayWeightedDeviationPercent(targetDay),
      macros: summary.macros,
    };

    set((current) => ({
      composerPlans: current.composerPlans.map((plan) =>
        plan.id !== current.activeComposerPlanId
          ? plan
          : {
              ...plan,
              variants: [...plan.variants, variant],
              activeVariantId: variantId,
            },
      ),
    }));
    return variantId;
  },

  activateCompositionVariant: (dateKey, variantId) =>
    set((state) => {
      const activePlan = state.composerPlans.find((p) => p.id === state.activeComposerPlanId);
      const variant = activePlan?.variants.find((v) => v.id === variantId);
      if (!activePlan || !variant) return state;

      const nextDay = cloneDayPlan({ ...variant.dayPlan, dateKey });
      const result = updateActivePlanDay(state, dateKey, () => ({ day: nextDay }));
      if (!result.composerPlans) return state;

      return {
        ...result,
        composerPlans: result.composerPlans.map((plan) =>
          plan.id !== activePlan.id ? plan : { ...plan, activeVariantId: variantId },
        ),
      };
    }),

  deleteCompositionVariant: (variantId) =>
    set((state) => ({
      composerPlans: state.composerPlans.map((plan) =>
        plan.id !== state.activeComposerPlanId
          ? plan
          : {
              ...plan,
              variants: plan.variants.filter((v) => v.id !== variantId),
              activeVariantId:
                plan.activeVariantId === variantId ? null : plan.activeVariantId,
            },
      ),
    })),

  applyMultiDayPlan: (result, options = {}) => {
    const state = get();
    const activePlan = state.composerPlans.find((p) => p.id === state.activeComposerPlanId);
    if (!activePlan) {
      return { ok: false, error: 'Plano ativo não encontrado.' };
    }
    const appliedDates: string[] = [];
    const nextDays = { ...activePlan.days };
    for (const [dateKey, dayPlan] of Object.entries(result.plannedDays)) {
      const guard = checkTemporalPlanMutation(dateKey, 'multi_day_generate', {
        referenceTodayKey: result.referenceTodayKey,
        confirmedToday: options.confirmedToday,
      });
      if (!guard.allowed) continue;
      nextDays[dateKey] = cloneDayPlan(dayPlan);
      appliedDates.push(dateKey);
    }
    if (appliedDates.length === 0) {
      return {
        ok: false,
        error: 'Nenhuma data elegível para aplicação segundo a política temporal.',
      };
    }
    set((current) => ({
      composerPlans: current.composerPlans.map((plan) =>
        plan.id !== activePlan.id
          ? plan
          : {
              ...plan,
              revision: plan.revision + 1,
              activeVariantId: null,
              days: nextDays,
            },
      ),
      nutritionInputsRevision: current.nutritionInputsRevision + 1,
    }));
    return { ok: true, appliedDates };
  },

  bumpNutritionCatalogRevision: () =>
    set((state) => ({
      nutritionInputsRevision: state.nutritionInputsRevision + 1,
      meals: [...state.meals],
    })),
}), {
  name: 'titan:nutrition:v1',
  version: 3,
  storage: createJSONStorage(() => safeStorageAdapter),
  partialize: (state) => ({
    activeDateKey: state.activeDateKey,
    referenceProfileId: state.referenceProfileId,
    dailyGoals: state.dailyGoals,
    meals: state.meals,
    supplementMicronutrientIntakes: state.supplementMicronutrientIntakes,
    intakeDayConfirmations: state.intakeDayConfirmations,
    composerPlans: state.composerPlans,
    activeComposerPlanId: state.activeComposerPlanId,
  }),
  migrate: (persisted) => mergeNutritionPersistedState(persisted, {
    activeDateKey: getLocalDateKey(),
    referenceProfileId: 'adult_male_19_50',
    dailyGoals: INITIAL_DAILY_GOALS,
    meals: INITIAL_MEALS,
    supplementMicronutrientIntakes: [],
    intakeDayConfirmations: [],
    composerPlans: INITIAL_COMPOSER_PLANS,
    activeComposerPlanId: INITIAL_COMPOSER_PLANS[0]?.id ?? 'plan-principal',
  }),
  merge: (persisted, current) => ({
    ...current,
    ...mergeNutritionPersistedState(persisted, current),
  }),
  onRehydrateStorage: () => (state) => {
    if (!state) return;
    const hasUnresolvedCompactTbca =
      state.meals.some((meal) =>
        [...meal.planned_foods, ...meal.consumed_foods].some(
          (portion) => portion.foodId.startsWith('tbca:') && !resolveFoodById(portion.foodId),
        ),
      ) ||
      state.composerPlans.some((plan) =>
        Object.values(plan.days).some((day) =>
          day.slots.some((slot) =>
            slot.recipes.some((recipe) =>
              recipe.ingredients.some(
                (ingredient) =>
                  ingredient.foodId.startsWith('tbca:') && !resolveFoodById(ingredient.foodId),
              ),
            ),
          ),
        ),
      );
    if (hasUnresolvedCompactTbca) {
      void ensureTbcaCatalogLoaded().then((changed) => {
        if (changed) {
          useNutritionStore.setState((prev) => ({
            meals: [...prev.meals],
            composerPlans: [...prev.composerPlans],
          }));
        }
      });
    }
  },
}));

export function computeNutritionTotals(
  meals: MealItem[],
  dateKey: string = getLocalDateKey(),
) {
  const totals = aggregateDailyMacros(meals, dateKey);
  const consumedMeals = meals.filter((meal) => meal.dateKey === dateKey && ['consumed', 'partial', 'substituted'].includes(meal.status));
  const consumedPortions = consumedMeals.flatMap(getEffectiveConsumedPortions);
  const quality = computePortionsMacrosWithQuality(consumedPortions);
  return {
    kcal: Math.round(totals.kcal),
    proteinG: Math.round(totals.proteinG),
    carbsG: Math.round(totals.carbsG),
    fatG: Math.round(totals.fatG),
    dataCoveragePercent: consumedMeals.length > 0 ? quality.coveragePercent : null,
    unresolvedFoodCount: quality.unresolvedFoodIds.length,
    lowConfidenceFoodCount: quality.lowConfidenceFoodIds.length,
  };
}

export function getMealMacros(meal: MealItem) {
  const macros = computeMealDisplayMacros(meal);
  return {
    kcal: Math.round(macros.kcal),
    proteinG: Math.round(macros.proteinG),
    carbsG: Math.round(macros.carbsG),
    fatG: Math.round(macros.fatG),
  };
}

export function getDailyMicronutrientDisplays(
  meals: MealItem[],
  dateKey: string,
  profileId: ReferenceProfileId,
): ResolvedNutrientDisplay[] {
  const profile = resolveReferenceProfile(profileId);
  const aggregated = aggregateDailyMicronutrients(meals, dateKey, profileId);
  return MICRONUTRIENT_ORDER.map((id) =>
    resolveNutrientDisplay(aggregated[id], profile.entries[id], profile),
  );
}


export interface DailyEnergyIntakeRecord {
  dateKey: string;
  consumedKcal: number;
  completeness: 'complete';
}

/** Only days explicitly confirmed by the user and still fully quantified are eligible for adaptive TDEE. */
export function getDailyEnergyIntakeHistory(): DailyEnergyIntakeRecord[] {
  const state = useNutritionStore.getState();
  return state.intakeDayConfirmations.flatMap((dateKey) => {
    const dayMeals = state.meals.filter((meal) => meal.dateKey === dateKey);
    if (dayMeals.length === 0 || dayMeals.some((meal) => meal.status === 'planned')) return [];
    const quality = computePortionsMacrosWithQuality(dayMeals.flatMap(getEffectiveConsumedPortions));
    if (quality.macros.kcal < 500 || quality.coveragePercent < 99.99 || quality.unresolvedFoodIds.length > 0 || quality.lowConfidenceFoodIds.length > 0) return [];
    return [{ dateKey, consumedKcal: quality.macros.kcal, completeness: 'complete' as const }];
  }).sort((a, b) => a.dateKey.localeCompare(b.dateKey));
}
