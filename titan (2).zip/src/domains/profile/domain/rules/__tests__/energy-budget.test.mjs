import assert from 'node:assert/strict';
import { resolveDailyEnergyBudget } from '../energy-budget.ts';

const totalDay = resolveDailyEnergyBudget({
  restingMetabolicRateKcal: 1600,
  baseExpenditureKcal: 2600,
  basis: 'total_includes_exercise',
  exerciseNetKcal: 400,
  goalAdjustmentKcal: -500,
});
assert.equal(totalDay.totalDailyExpenditureKcal, 2600, 'exercise already included in TDEE must not be added again');
assert.equal(totalDay.exerciseNetKcal, 400);
assert.equal(totalDay.exerciseAdditionalKcal, 0);
assert.equal(totalDay.nonRestingResidualKcal, 1000);
assert.equal(totalDay.targetIntakeKcal, 2100);
assert.equal(totalDay.exerciseAccounting, 'already_included');

const withoutWorkoutRecord = resolveDailyEnergyBudget({
  restingMetabolicRateKcal: 1500,
  baseExpenditureKcal: 2300,
  basis: 'total_includes_exercise',
  goalAdjustmentKcal: 0,
});
assert.equal(withoutWorkoutRecord.totalDailyExpenditureKcal, 2300);
assert.equal(withoutWorkoutRecord.exerciseNetKcal, null, 'missing exercise data must not be invented');
assert.equal(withoutWorkoutRecord.exerciseAccounting, 'not_reported');

const componentBudget = resolveDailyEnergyBudget({
  restingMetabolicRateKcal: 1500,
  baseExpenditureKcal: 2300,
  basis: 'base_excludes_exercise',
  exerciseNetKcal: 400,
  goalAdjustmentKcal: 250,
});
assert.equal(componentBudget.totalDailyExpenditureKcal, 2700, 'only an explicitly exercise-excluding base may add net exercise kcal');
assert.equal(componentBudget.exerciseAdditionalKcal, 400);
assert.equal(componentBudget.targetIntakeKcal, 2950);
assert.equal(componentBudget.exerciseAccounting, 'added_once');

assert.throws(() => resolveDailyEnergyBudget({
  restingMetabolicRateKcal: 1500,
  baseExpenditureKcal: 2300,
  basis: 'base_excludes_exercise',
  goalAdjustmentKcal: 0,
}), /exerciseNetKcal/);
assert.throws(() => resolveDailyEnergyBudget({
  restingMetabolicRateKcal: 1600,
  baseExpenditureKcal: 1500,
  basis: 'total_includes_exercise',
  goalAdjustmentKcal: 0,
}), /menor que o RMR/);
assert.throws(() => resolveDailyEnergyBudget({
  restingMetabolicRateKcal: 1600,
  baseExpenditureKcal: 2600,
  basis: 'total_includes_exercise',
  exerciseNetKcal: -10,
  goalAdjustmentKcal: 0,
}), /exerciseNetKcal/);
assert.throws(() => resolveDailyEnergyBudget({
  restingMetabolicRateKcal: 1600,
  baseExpenditureKcal: 2600,
  basis: 'total_includes_exercise',
  goalAdjustmentKcal: -3000,
}), /meta de ingestão/);

console.log('energy-budget.test.mjs PASS');

assert.throws(() => resolveDailyEnergyBudget({
  restingMetabolicRateKcal: 1500,
  baseExpenditureKcal: 1200,
  basis: 'base_excludes_exercise',
  exerciseNetKcal: 400,
  goalAdjustmentKcal: 0,
}), /base energética.*RMR/i, 'adding exercise must not disguise a non-exercise base below resting metabolism');
