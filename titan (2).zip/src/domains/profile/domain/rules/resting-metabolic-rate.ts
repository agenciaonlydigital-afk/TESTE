import type { BiologicalSex } from '../contracts/user-profile';

export type RestingMetabolicRateMethod =
  | 'mifflin_st_jeor'
  | 'pavlidou_2023'
  | 'cunningham_1980'
  | 'katch_mcardle'
  | 'ten_haaf_2014';

export type FatFreeMassSource =
  | 'dexa'
  | 'bod_pod'
  | 'isotope_dilution'
  | 'validated_bioimpedance'
  | 'other';

export interface RestingMetabolicRateInput {
  sex: BiologicalSex;
  age: number;
  heightCm: number;
  weightKg: number;
  /** Optional FFM in kg. Do not derive this from BMI. */
  fatFreeMassKg?: number;
  /** Optional body-fat percentage; FFM is derived as weight × (1 − body-fat fraction). */
  bodyFatPercent?: number;
  /** Provenance for FFM/body-fat input; estimates from waist formulas are not measurement-grade. */
  fatFreeMassSource?: FatFreeMassSource;
  /** Optional measured RMR from indirect calorimetry, kcal/day. */
  measuredRmrKcal?: number;
}

export interface RestingMetabolicRateEstimate {
  kcalPerDay: number;
  method: RestingMetabolicRateMethod | 'indirect_calorimetry';
  methodLabel: string;
  population: string;
  evidenceNote: string;
  fatFreeMassSource?: FatFreeMassSource;
  isMeasured: boolean;
  warnings: string[];
}

function validate(input: RestingMetabolicRateInput): void {
  if (input.sex !== 'male' && input.sex !== 'female') throw new RangeError('Sexo de referência inválido.');
  if (![input.age, input.heightCm, input.weightKg].every(Number.isFinite) ||
      input.age < 18 || input.age > 105 || input.heightCm < 110 || input.heightCm > 245 ||
      input.weightKg < 30 || input.weightKg > 300) {
    throw new RangeError('RMR exige idade, altura e peso em faixas adultas plausíveis.');
  }
  if (input.fatFreeMassKg !== undefined &&
      (!Number.isFinite(input.fatFreeMassKg) || input.fatFreeMassKg <= 0 || input.fatFreeMassKg > input.weightKg)) {
    throw new RangeError('Massa livre de gordura deve ser positiva e não pode superar o peso corporal.');
  }
  if (input.bodyFatPercent !== undefined && (!Number.isFinite(input.bodyFatPercent) || input.bodyFatPercent < 2 || input.bodyFatPercent > 70)) {
    throw new RangeError('Percentual de gordura deve estar entre 2% e 70%.');
  }
  if (input.fatFreeMassKg !== undefined && input.bodyFatPercent !== undefined) {
    const derivedFfm = input.weightKg * (1 - input.bodyFatPercent / 100);
    if (Math.abs(derivedFfm - input.fatFreeMassKg) > 3) throw new RangeError('Massa livre de gordura e percentual de gordura informados são inconsistentes.');
  }
  if (input.measuredRmrKcal !== undefined &&
      (!Number.isFinite(input.measuredRmrKcal) || input.measuredRmrKcal < 300 || input.measuredRmrKcal > 5000)) {
    throw new RangeError('RMR medido fora da faixa plausível; confira unidade e laudo.');
  }
}

export interface AutomaticRmrSelection {
  method: RestingMetabolicRateMethod;
  effectiveMethod: RestingMetabolicRateMethod | 'indirect_calorimetry';
  label: string;
  reason: string;
}

/**
 * Selects the most appropriate RMR method automatically from the information provided:
 * 1. Measured RMR (indirect calorimetry) takes precedence whenever supplied.
 * 2. Without an individual measurement, general adults use Mifflin–St Jeor (1990).
 * 3. Katch–McArdle, Cunningham, Pavlidou and Ten Haaf remain explicit alternatives;
 *    activity labels or FFM provenance alone do not establish their study populations.
 */
export function resolveAutomaticRmrMethod(input: {
  age?: number;
  activityLevel?: 'sedentary' | 'light' | 'moderate' | 'high' | 'very_high';
  bodyFatPercent?: number;
  fatFreeMassKg?: number;
  fatFreeMassSource?: FatFreeMassSource;
  measuredRmrKcal?: number;
}): AutomaticRmrSelection {
  if (input.measuredRmrKcal !== undefined && Number.isFinite(input.measuredRmrKcal) && input.measuredRmrKcal >= 300) {
    return {
      method: 'mifflin_st_jeor',
      effectiveMethod: 'indirect_calorimetry',
      label: 'Calorimetria indireta (laudo)',
      reason: 'Usa diretamente o valor medido informado.',
    };
  }
  return {
    method: 'mifflin_st_jeor',
    effectiveMethod: 'mifflin_st_jeor',
    label: 'Mifflin–St Jeor (1990)',
    reason: 'Estimativa geral adulta. Equações específicas exigem seleção explícita porque atividade e origem da FFM, isoladamente, não comprovam compatibilidade com a população de desenvolvimento.',
  };
}

/**
 * Resting metabolic rate (RMR/REE) prediction. This is not a strict laboratory
 * basal metabolic rate (BMR) measurement. Mifflin is the default general-adult
 * estimator; Pavlidou is an alternative, while FFM equations require a supplied
 * body-composition result with provenance. Athlete-specific Ten Haaf is opt-in.
 */
export function estimateRestingMetabolicRate(
  input: RestingMetabolicRateInput,
  method: RestingMetabolicRateMethod = 'mifflin_st_jeor',
): RestingMetabolicRateEstimate {
  validate(input);
  if (input.measuredRmrKcal !== undefined) {
    return {
      kcalPerDay: Math.round(input.measuredRmrKcal),
      method: 'indirect_calorimetry',
      methodLabel: 'Calorimetria indireta informada',
      population: 'Medição individual; depende do protocolo e equipamento do laudo',
      evidenceNote: 'Medição fornecida pelo usuário; não recalculada pelo aplicativo.',
      isMeasured: true,
      warnings: ['Confirme data, protocolo, jejum, repouso prévio e unidade do laudo.'],
    };
  }

  let kcalPerDay: number;
  let methodLabel: string;
  let population: string;
  let evidenceNote: string;
  const warnings: string[] = ['Equação populacional: não substitui calorimetria indireta nem mede metabolismo basal em condições laboratoriais.'];
  const fatFreeMassKg = input.fatFreeMassKg ?? (input.bodyFatPercent === undefined ? undefined : input.weightKg * (1 - input.bodyFatPercent / 100));

  switch (method) {
    case 'mifflin_st_jeor': {
      const sexOffset = input.sex === 'male' ? 5 : -161;
      kcalPerDay = 10 * input.weightKg + 6.25 * input.heightCm - 5 * input.age + sexOffset;
      methodLabel = 'Mifflin–St Jeor (1990)';
      population = 'Adultos; equação geral sem composição corporal';
      evidenceNote = 'Estimativa de referência geral amplamente utilizada; erro individual permanece relevante.';
      break;
    }
    case 'pavlidou_2023': {
      const heightM = input.heightCm / 100;
      kcalPerDay = input.sex === 'male'
        ? 9.65 * input.weightKg + 573 * heightM - 5.08 * input.age + 260
        : 7.38 * input.weightKg + 607 * heightM - 2.31 * input.age + 43;
      methodLabel = 'Pavlidou et al. (2023)';
      population = '722 adultos caucasianos (173 homens, 549 mulheres), 18–78 anos; gestação/lactação excluídas';
      evidenceNote = 'O estudo reportou R² 0,95 em homens e 0,86 em mulheres. R² não equivale a acurácia individual nem garante validade externa em brasileiros.';
      warnings.push('Aplicabilidade externa à população brasileira e a diferentes grupos étnicos não está estabelecida pelo estudo original.');
      break;
    }
    case 'cunningham_1980': {
      if (fatFreeMassKg === undefined) throw new RangeError('Cunningham exige massa livre de gordura ou percentual de gordura informado.');
      if (!input.fatFreeMassSource) throw new RangeError('Cunningham exige a origem da composição corporal.');
      kcalPerDay = 500 + 22 * fatFreeMassKg;
      methodLabel = 'Cunningham (1980)';
      population = 'Equação baseada em massa livre de gordura; evidência especialmente relevante em atletas';
      evidenceNote = 'A qualidade depende da FFM de entrada. Não usar percentual de gordura estimado por cintura como se fosse DXA/BodPod.';
      if (input.fatFreeMassSource === 'other') warnings.push('A origem da massa livre de gordura não foi identificada como método de composição corporal validado.');
      break;
    }
    case 'katch_mcardle': {
      if (fatFreeMassKg === undefined) throw new RangeError('Katch–McArdle exige massa livre de gordura ou percentual de gordura informado.');
      if (!input.fatFreeMassSource) throw new RangeError('Katch–McArdle exige a origem da composição corporal.');
      kcalPerDay = 370 + 21.6 * fatFreeMassKg;
      methodLabel = 'Katch–McArdle';
      population = 'Equação baseada em massa livre de gordura';
      evidenceNote = 'A precisão depende diretamente da qualidade da medição de FFM.';
      if (input.fatFreeMassSource === 'other') warnings.push('A origem da massa livre de gordura não foi identificada como método de composição corporal validado.');
      break;
    }
    case 'ten_haaf_2014': {
      const sexIndicator = input.sex === 'male' ? 1 : 0;
      kcalPerDay = 11.936 * input.weightKg + 587.728 * (input.heightCm / 100) -
        8.129 * input.age + 191.027 * sexIndicator + 29.279;
      methodLabel = 'Ten Haaf & Weijs (2014)';
      population = 'Adultos recreacionalmente ativos de 18–35 anos, treinando em média ~9 h/semana';
      evidenceNote = 'Opção específica para atletas recreacionais; não generalizar para sedentários, atletas masters ou outros perfis.';
      if (input.age < 18 || input.age > 35) warnings.push('Idade fora da população original de desenvolvimento (18–35 anos).');
      break;
    }
  }

  if (!Number.isFinite(kcalPerDay) || kcalPerDay < 300 || kcalPerDay > 5000) {
    throw new RangeError('A equação de RMR produziu valor fora da faixa plausível.');
  }
  return {
    kcalPerDay: Math.round(kcalPerDay),
    method,
    methodLabel,
    population,
    evidenceNote,
    ...(input.fatFreeMassSource ? { fatFreeMassSource: input.fatFreeMassSource } : {}),
    isMeasured: false,
    warnings,
  };
}
