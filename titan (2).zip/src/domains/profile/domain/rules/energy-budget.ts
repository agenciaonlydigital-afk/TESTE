export type EnergyExpenditureBasis = 'total_includes_exercise' | 'base_excludes_exercise';
export type ExerciseEnergyAccounting = 'already_included' | 'added_once' | 'not_reported';

export interface DailyEnergyBudgetInput {
  restingMetabolicRateKcal: number;
  baseExpenditureKcal: number;
  basis: EnergyExpenditureBasis;
  /** NET active energy only. Gross exercise calories must never be passed here. */
  exerciseNetKcal?: number | null;
  goalAdjustmentKcal: number;
}

export interface DailyEnergyBudget {
  restingMetabolicRateKcal: number;
  baseExpenditureKcal: number;
  totalDailyExpenditureKcal: number;
  nonRestingResidualKcal: number;
  exerciseNetKcal: number | null;
  exerciseAdditionalKcal: number;
  exerciseAccounting: ExerciseEnergyAccounting;
  goalAdjustmentKcal: number;
  targetIntakeKcal: number;
}

function assertFinite(value: number, field: string): void {
  if (!Number.isFinite(value)) throw new RangeError(`${field} precisa ser um número finito.`);
}

/**
 * Source-aware daily energy accounting.
 * A total-day TDEE already contains activity/exercise; only a baseline explicitly
 * marked as excluding exercise may add a measured NET exercise value.
 */
export function resolveDailyEnergyBudget(input: DailyEnergyBudgetInput): DailyEnergyBudget {
  assertFinite(input.restingMetabolicRateKcal, 'RMR');
  assertFinite(input.baseExpenditureKcal, 'TDEE base');
  assertFinite(input.goalAdjustmentKcal, 'Ajuste do objetivo');
  if (input.restingMetabolicRateKcal <= 0 || input.baseExpenditureKcal <= 0) {
    throw new RangeError('RMR e TDEE base precisam ser positivos.');
  }
  if (input.exerciseNetKcal !== undefined && input.exerciseNetKcal !== null) {
    assertFinite(input.exerciseNetKcal, 'exerciseNetKcal');
    if (input.exerciseNetKcal < 0) throw new RangeError('exerciseNetKcal precisa ser positivo ou zero.');
  }
  if (input.basis !== 'total_includes_exercise' && input.basis !== 'base_excludes_exercise') {
    throw new RangeError('Base energética inválida.');
  }
  if (input.basis === 'base_excludes_exercise' && input.exerciseNetKcal == null) {
    throw new RangeError('exerciseNetKcal é obrigatório quando a base exclui o exercício.');
  }
  if (input.basis === 'base_excludes_exercise' && input.baseExpenditureKcal + 0.5 < input.restingMetabolicRateKcal) {
    throw new RangeError('A base energética sem exercício não pode ser menor que o RMR.');
  }

  const exerciseAdditionalKcal = input.basis === 'base_excludes_exercise'
    ? input.exerciseNetKcal!
    : 0;
  const totalDailyExpenditureKcal = Math.round(input.baseExpenditureKcal + exerciseAdditionalKcal);
  if (totalDailyExpenditureKcal + 0.5 < input.restingMetabolicRateKcal) {
    throw new RangeError('O TDEE total não pode ser menor que o RMR.');
  }
  const targetIntakeKcal = Math.round(totalDailyExpenditureKcal + input.goalAdjustmentKcal);
  if (targetIntakeKcal <= 0) throw new RangeError('A meta de ingestão precisa ser positiva.');

  const exerciseAccounting: ExerciseEnergyAccounting = input.exerciseNetKcal == null
    ? 'not_reported'
    : input.basis === 'total_includes_exercise'
      ? 'already_included'
      : 'added_once';

  return {
    restingMetabolicRateKcal: Math.round(input.restingMetabolicRateKcal),
    baseExpenditureKcal: Math.round(input.baseExpenditureKcal),
    totalDailyExpenditureKcal,
    nonRestingResidualKcal: Math.max(0, Math.round(totalDailyExpenditureKcal - input.restingMetabolicRateKcal)),
    exerciseNetKcal: input.exerciseNetKcal ?? null,
    exerciseAdditionalKcal,
    exerciseAccounting,
    goalAdjustmentKcal: Math.round(input.goalAdjustmentKcal),
    targetIntakeKcal,
  };
}
