import { isValidLocalDateKey } from '@/src/shared/utils/local-date';
import { z } from 'zod';

export const profileGoalsSchema = z.object({
  sex: z.enum(['male', 'female']),
  goal: z.enum(['gain_muscle', 'lose_weight', 'recomposition', 'maintain']),
  currentWeightKg: z
    .number()
    .finite('Informe um peso atual válido.')
    .min(30, 'Peso atual deve ser maior que 30 kg.')
    .max(300, 'Peso atual deve ser menor que 300 kg.'),
  targetWeightKg: z
    .number()
    .finite('Informe um peso desejado válido.')
    .min(30, 'Peso desejado deve ser maior que 30 kg.')
    .max(300, 'Peso desejado deve ser menor que 300 kg.'),
  activityLevel: z.enum(['sedentary', 'light', 'moderate', 'high', 'very_high']),
  deadlineDateKey: z
    .string()
    .refine(isValidLocalDateKey, 'Selecione uma data válida para o prazo.'),
  heightCm: z
    .number()
    .finite('Informe uma altura válida.')
    .min(110, 'Altura mínima de 110 cm.')
    .max(245, 'Altura máxima de 245 cm.'),
  rmrMethod: z.enum(['mifflin_st_jeor', 'pavlidou_2023', 'cunningham_1980', 'katch_mcardle', 'ten_haaf_2014']).optional(),
  measuredRmrKcal: z.number().finite().min(300).max(5000).optional(),
  bodyFatPercent: z.number().finite().min(2).max(70).optional(),
  fatFreeMassSource: z.enum(['dexa', 'bod_pod', 'isotope_dilution', 'validated_bioimpedance', 'other']).optional(),
  age: z
    .number()
    .finite('Informe uma idade válida.')
    .int('Informe a idade em anos completos.')
    .min(19, 'O cálculo atual de metas está validado para adultos a partir de 19 anos.')
    .max(105, 'Idade máxima de 105 anos.'),
});
