import assert from 'node:assert/strict';
import {
  calculatePhysiologicalGoalTargets,
  estimateNASEM2023Eer,
  resolveDriProfileId,
  daysBetweenDateKeys,
  isValidDateKey,
} from '../domain/rules/goal-calculator.ts';
import { estimateAdaptiveTdee } from '../domain/rules/adaptive-energy.ts';
import { DRI_REFERENCE_PROFILES } from '../../nutrition/data/references/dri-profiles.ts';
import {
  calculateBmi,
  calculateBodyComposition,
  calculateWaistToHeightRatio,
  estimateBodyFatNavy,
  estimateRelativeFatMass,
} from '../domain/rules/body-composition.ts';

const baseProfile = {
  sex: 'male', goal: 'gain_muscle', currentWeightKg: 79.1, targetWeightKg: 82,
  activityLevel: 'moderate', deadlineDateKey: '2027-02-20', heightCm: 179, age: 29,
};

// Date key parsing is calendar-strict (including leap-year boundaries).
assert.equal(resolveDriProfileId('female', 25), 'adult_female_19_30');
assert.equal(resolveDriProfileId('male', 30), 'adult_male_19_30');
assert.equal(resolveDriProfileId('male', 31), 'adult_male_19_50');
assert.equal(resolveDriProfileId('female', 55), 'adult_female_51_70');
assert.equal(resolveDriProfileId('male', 55), 'adult_male_51_70');
assert.equal(resolveDriProfileId('female', 75), 'adult_female_71_plus');
assert.equal(resolveDriProfileId('male', 75), 'adult_male_71_plus');
assert.equal(DRI_REFERENCE_PROFILES.adult_male_51_70.entries.calcium.referenceValue, 1000);
assert.equal(DRI_REFERENCE_PROFILES.adult_male_19_30.entries.magnesium.referenceValue, 400);
assert.equal(DRI_REFERENCE_PROFILES.adult_male_19_50.entries.magnesium.referenceValue, 420);
assert.equal(DRI_REFERENCE_PROFILES.adult_female_19_30.entries.magnesium.referenceValue, 310);
assert.equal(DRI_REFERENCE_PROFILES.adult_female_19_50.entries.magnesium.referenceValue, 320);
assert.equal(DRI_REFERENCE_PROFILES.adult_female_51_70.entries.calcium.referenceValue, 1200);
assert.equal(DRI_REFERENCE_PROFILES.adult_male_71_plus.entries.vitamin_d.referenceValue, 20);
assert.equal(DRI_REFERENCE_PROFILES.adult_female_71_plus.entries.iron.referenceValue, 8);
assert.equal(DRI_REFERENCE_PROFILES.adult_male_19_50.entries.sodium.kind, 'AI');
assert.equal(DRI_REFERENCE_PROFILES.adult_male_19_50.entries.sodium.referenceValue, 1500);
assert.equal(DRI_REFERENCE_PROFILES.adult_male_19_50.entries.sodium.cdrrValue, 2300);
assert.equal(DRI_REFERENCE_PROFILES.adult_male_19_50.entries.sodium.upperLimit, undefined, 'CDRR is not a tolerable upper intake level');
assert.equal(isValidDateKey('2024-02-29'), true);
assert.equal(isValidDateKey('2025-02-29'), false);
assert.equal(isValidDateKey('2026-13-01'), false);
assert.equal(daysBetweenDateKeys('2026-11-23', '2026-11-30'), 7);
assert.equal(daysBetweenDateKeys('2026-11-30', '2026-11-23'), -7);
assert.equal(daysBetweenDateKeys('2026-11-31', '2026-12-01'), null);

// NASEM 2023 Table S-3: adult EER formulas in years, centimetres and kilograms.
assert.equal(estimateNASEM2023Eer({ sex: 'female', age: 22, heightCm: 165, weightKg: 63, activityCategory: 'low_active' }), 2275);
assert.equal(estimateNASEM2023Eer({ sex: 'male', age: 30, heightCm: 180, weightKg: 80, activityCategory: 'active' }), 3126);
assert.deepEqual(
  ['inactive', 'low_active', 'active', 'very_active'].map((activityCategory) => estimateNASEM2023Eer({ sex: 'male', age: 30, heightCm: 180, weightKg: 80, activityCategory })),
  [2726, 2946, 3126, 3496],
);
assert.deepEqual(
  ['inactive', 'low_active', 'active', 'very_active'].map((activityCategory) => estimateNASEM2023Eer({ sex: 'female', age: 30, heightCm: 180, weightKg: 80, activityCategory })),
  [2341, 2525, 2664, 2939],
);
assert.throws(() => estimateNASEM2023Eer({ sex: 'male', age: 18, heightCm: 180, weightKg: 80, activityCategory: 'active' }), /19 anos/);
assert.throws(() => estimateNASEM2023Eer({ sex: 'unknown', age: 30, heightCm: 180, weightKg: 80, activityCategory: 'active' }), /Sexo de referência inválido/);
assert.throws(() => estimateNASEM2023Eer({ sex: 'male', age: 30, heightCm: 180, weightKg: 80, activityCategory: 'unknown' }), /Categoria de atividade inválida/);
assert.throws(() => calculatePhysiologicalGoalTargets({ ...baseProfile, sex: 'unknown' }, '2026-11-23'), /Sexo biológico/);
assert.throws(() => calculatePhysiologicalGoalTargets({ ...baseProfile, goal: 'crash_diet' }, '2026-11-23'), /Objetivo físico/);
assert.throws(() => calculatePhysiologicalGoalTargets({ ...baseProfile, bodyFatPercent: 18 }, '2026-11-23'), /origem declarada/);

// Energy target: BMR/TDEE are internally consistent and rate-limited.
const gain = calculatePhysiologicalGoalTargets(baseProfile, '2026-11-23');
assert.ok(gain.bmr > 0 && gain.tdee > gain.bmr);
assert.ok(gain.kcal > gain.tdee);
assert.ok(gain.proteinG >= gain.proteinMinG && gain.proteinG <= gain.proteinMaxG);
assert.ok(gain.warnings.length >= 1); // Model uncertainty is explicit.
assert.equal(gain.tdeeSource, 'equation_nasem_2023');
assert.equal(gain.restingMetabolicRateKcal, gain.bmr, 'the explicit RMR field must preserve the legacy bmr alias');
assert.equal(gain.energyBudget.totalDailyExpenditureKcal, gain.tdee);
assert.equal(gain.energyBudget.nonRestingResidualKcal, gain.tdee - gain.bmr);
assert.equal(gain.energyBudget.targetIntakeKcal, gain.kcal);
assert.equal(gain.calorieAdjustmentKcal, gain.kcal - gain.tdee, 'effective adjustment must reconcile with the final kcal target');
assert.equal(gain.boundedCalorieAdjustmentKcal, gain.calorieAdjustmentKcal);
const workoutContextGoal = calculatePhysiologicalGoalTargets(baseProfile, '2026-11-23', null, { exerciseNetKcal: 420 });
assert.equal(workoutContextGoal.tdee, gain.tdee, 'workout calories are already included in the NASEM activity-category total');
assert.equal(workoutContextGoal.energyBudget.exerciseNetKcal, 420);
assert.equal(workoutContextGoal.energyBudget.exerciseAdditionalKcal, 0, 'exercise must not be added a second time');
assert.equal(workoutContextGoal.energyBudget.targetIntakeKcal, workoutContextGoal.kcal);
assert.equal(gain.energyEquationVersion, 'HALL_2011_DYNAMIC_CORE_V1');
assert.ok(gain.bodyWeightModel);
assert.equal(gain.bodyWeightModel.version, 'hall_2011_adult_energy_balance_core_v1');
assert.ok(gain.bodyWeightModel.predictedWeightKg > 0);
assert.equal(gain.tdeeActivityCategory, 'active');
assert.ok(gain.warnings.some((warning) => warning.includes('NASEM 2023')));
assert.ok(gain.warnings.some((warning) => warning.includes('RMR automático')));
const compositionModerate = calculatePhysiologicalGoalTargets({
  ...baseProfile, bodyFatPercent: 18, fatFreeMassSource: 'dexa', activityLevel: 'moderate',
}, '2026-11-23');
assert.equal(compositionModerate.bmr, 1770, 'moderate activity must not auto-select Katch solely because body fat was entered');
const compositionHigh = calculatePhysiologicalGoalTargets({
  ...baseProfile, bodyFatPercent: 18, fatFreeMassSource: 'dexa', activityLevel: 'high',
}, '2026-11-23');
assert.equal(compositionHigh.bmr, 1770, 'high activity plus FFM alone must not auto-select an athlete-specific equation');
assert.ok(gain.energyDensityAssumptions.central > 4000 && gain.energyDensityAssumptions.central < 8000);
assert.ok(gain.energyDensityAssumptions.low < gain.energyDensityAssumptions.central);
assert.ok(gain.energyDensityAssumptions.high > gain.energyDensityAssumptions.central);
const gainWeeklyLimit = baseProfile.currentWeightKg * 0.0025;
assert.ok((gain.calorieAdjustmentKcal * 7 / gain.energyDensityAssumptions.central) <= gainWeeklyLimit + 0.01);

const maintenanceGoal = calculatePhysiologicalGoalTargets({
  ...baseProfile, goal: 'maintain', targetWeightKg: baseProfile.currentWeightKg,
}, '2026-11-23');
assert.equal(maintenanceGoal.calorieAdjustmentKcal, 0);
assert.equal(maintenanceGoal.kcal, maintenanceGoal.tdee);
const recompositionGoal = calculatePhysiologicalGoalTargets({
  ...baseProfile, goal: 'recomposition', targetWeightKg: baseProfile.currentWeightKg,
}, '2026-11-23');
assert.equal(recompositionGoal.calorieAdjustmentKcal, 0);
assert.ok(recompositionGoal.proteinG >= recompositionGoal.proteinMinG);
const lossGoal = calculatePhysiologicalGoalTargets({
  ...baseProfile, goal: 'lose_weight', targetWeightKg: baseProfile.currentWeightKg - 3,
}, '2026-11-23');
assert.ok(lossGoal.calorieAdjustmentKcal < 0);

const wrongGainDirection = calculatePhysiologicalGoalTargets(
  { ...baseProfile, targetWeightKg: 76 }, '2026-11-23',
);
assert.equal(wrongGainDirection.calorieAdjustmentKcal, 0);
assert.ok(wrongGainDirection.warnings.some((warning) => warning.includes('abaixo')));

const wrongLossDirection = calculatePhysiologicalGoalTargets(
  { ...baseProfile, goal: 'lose_weight', targetWeightKg: 82 }, '2026-11-23',
);
assert.equal(wrongLossDirection.calorieAdjustmentKcal, 0);
assert.ok(wrongLossDirection.warnings.some((warning) => warning.includes('acima')));

const expired = calculatePhysiologicalGoalTargets(
  { ...baseProfile, deadlineDateKey: '2026-11-20' }, '2026-11-23',
);
assert.equal(expired.calorieAdjustmentKcal, 0);
assert.ok(expired.warnings.some((warning) => warning.includes('vencido')));

const tooAggressive = calculatePhysiologicalGoalTargets(
  { ...baseProfile, targetWeightKg: 95, deadlineDateKey: '2026-12-01' }, '2026-11-23',
);
assert.ok(tooAggressive.calorieAdjustmentKcal <= 300);
assert.ok(tooAggressive.warnings.some((warning) => warning.includes('limitada')));

// Adversarial macro floor: reduce the preferred protein target to its configured minimum before relaxing a safe deficit.
const macroFloorGoal = calculatePhysiologicalGoalTargets({
  sex: 'female', goal: 'lose_weight', currentWeightKg: 300, targetWeightKg: 290,
  activityLevel: 'sedentary', deadlineDateKey: '2026-12-10', heightCm: 110, age: 105,
}, '2026-11-23');
assert.equal(macroFloorGoal.proteinG, macroFloorGoal.proteinMinG);
assert.ok(macroFloorGoal.kcal < macroFloorGoal.tdee, 'macro feasibility must not silently turn a weight-loss plan into a surplus');
assert.equal(macroFloorGoal.calorieAdjustmentKcal, macroFloorGoal.kcal - macroFloorGoal.tdee);
assert.ok(macroFloorGoal.calorieAdjustmentKcal > macroFloorGoal.boundedCalorieAdjustmentKcal, 'the effective deficit is smaller only when the minimum macro floor requires it');
assert.ok(macroFloorGoal.warnings.some((warning) => warning.includes('mínimos de proteína e gordura')));

const beyondHallHorizon = calculatePhysiologicalGoalTargets(
  { ...baseProfile, deadlineDateKey: '2038-11-23' }, '2026-11-23',
);
assert.equal(beyondHallHorizon.bodyWeightModel, undefined, 'the dynamic model must not be silently extrapolated beyond its 10-year horizon');
assert.ok(beyondHallHorizon.warnings.some((warning) => warning.includes('ultrapassa os 10 anos')));

// Anthropometric functions: adult screening, not clinical diagnosis.
assert.equal(calculateBmi(75, 180), 23.1);
assert.equal(calculateWaistToHeightRatio(80, 180), 0.444);
const maleBodyFat = estimateBodyFatNavy({ sex: 'male', heightCm: 180, waistCm: 90, neckCm: 38 });
assert.ok(maleBodyFat > 5 && maleBodyFat < 35);
const femaleBodyFat = estimateBodyFatNavy({ sex: 'female', heightCm: 165, waistCm: 75, neckCm: 32, hipCm: 98 });
assert.ok(femaleBodyFat > 10 && femaleBodyFat < 45);
assert.equal(estimateRelativeFatMass({ sex: 'male', heightCm: 180, waistCm: 90 }), 24);
assert.equal(estimateRelativeFatMass({ sex: 'female', heightCm: 165, waistCm: 75 }), 32);
assert.throws(() => estimateRelativeFatMass({ sex: 'male', heightCm: 180, waistCm: 0 }), /positivo e finito/);
assert.throws(() => estimateRelativeFatMass({ sex: 'unknown', heightCm: 180, waistCm: 80 }), /Sexo de referência inválido/);
assert.throws(() => estimateRelativeFatMass({ sex: 'male', heightCm: 180, waistCm: 80, age: 19 }), /20 anos/);
assert.throws(() => estimateBodyFatNavy({ sex: 'female', heightCm: 165, waistCm: 75, neckCm: 32 }), /quadril/i);
const composition = calculateBodyComposition({
  weightKg: 75, heightCm: 180, age: 25, waistCm: 80, neckCm: 38, sex: 'male',
});
assert.equal(composition.bmi, 23.1);
assert.ok(composition.fatMassKg > 0 && composition.leanMassKg > 0 && composition.ffmi > 0);
assert.equal(composition.relativeFatMassPercent, 19);
assert.ok(composition.bodyFatMethodDifferencePercent >= 0);
assert.equal(calculateBodyComposition({ weightKg: 60, heightCm: 170, age: 18 }).bmiCategory, 'not_classified_for_age');
assert.throws(() => calculateBmi(Number.NaN, 180), /positivo e finito/i);

console.log('PASS calculation engine profile: goals, limits, date validation and body composition');

// Adaptive expenditure requires sufficiently complete intake and weight history.
const intake = Array.from({ length: 28 }, (_, index) => {
  const date = new Date(Date.UTC(2026, 9, 27 + index));
  return { dateKey: date.toISOString().slice(0, 10), consumedKcal: 2400 + (index % 3) * 20, completeness: 'complete' };
});
const weightHistory = Array.from({ length: 5 }, (_, index) => {
  const date = new Date(Date.UTC(2026, 9, 27 + index * 7));
  return { id: `adaptive-${index}`, dateKey: date.toISOString().slice(0, 10), dateLabel: '', weightKg: 79 - index * 0.15, waistCm: 80, armCm: 38, thighCm: 59 };
});
const adaptive = estimateAdaptiveTdee(intake, weightHistory, 28);
assert.ok(adaptive);
assert.ok(adaptive.lowerBoundKcal <= adaptive.estimateKcal);
assert.ok(adaptive.estimateKcal <= adaptive.upperBoundKcal);
assert.equal(adaptive.method, 'observed_intake_plus_weight_trend');
assert.ok(adaptive.coveragePercent >= 90);
assert.equal(adaptive.meanIntakeKcal, Math.round(intake.reduce((sum, item) => sum + item.consumedKcal, 0) / intake.length));
const alignedWeights = [...weightHistory.slice(0, 4), { ...weightHistory[3], id: 'aligned-anchor', dateKey: '2026-11-23', weightKg: 78.55 }];
const futureOutlierWeights = [...alignedWeights, { ...weightHistory[4], id: 'future-outlier', dateKey: '2026-11-24', weightKg: 60 }];
const alignedAdaptive = estimateAdaptiveTdee(intake, alignedWeights, 28);
const futureOutlierAdaptive = estimateAdaptiveTdee(intake, futureOutlierWeights, 28);
assert.ok(alignedAdaptive && futureOutlierAdaptive);
assert.equal(futureOutlierAdaptive.estimateKcal, alignedAdaptive.estimateKcal, 'weight observations after the last complete intake day must not enter the calibration window');
assert.equal(adaptive.intervalKind, 'kalman_model_based_95pct_not_externally_calibrated');
assert.equal(adaptive.estimator, 'robust_rolling_energy_balance_kalman_v2_hall_composition_density');
const withFastedDay = intake.map((entry, index) => index === 0 ? { ...entry, consumedKcal: 0, completeness: 'fasted' } : entry);
assert.ok(estimateAdaptiveTdee(withFastedDay, alignedWeights));
assert.ok(adaptive.uncertaintyKcal > 0);
assert.ok(adaptive.measurementWindows >= 1);
const duplicatedDay = estimateAdaptiveTdee([...intake, { ...intake[0], consumedKcal: 7000 }, { dateKey: '2026-02-30', consumedKcal: 7000, completeness: 'complete' }], weightHistory, 28);
assert.ok(duplicatedDay);
assert.ok(duplicatedDay.warnings.some((warning) => warning.includes('duplicadas')));
const calibratedGoal = calculatePhysiologicalGoalTargets(baseProfile, '2026-11-23', adaptive);
assert.equal(calibratedGoal.tdeeSource, 'observed_adaptive');
assert.equal(calibratedGoal.energyEquationVersion, 'HALL_2011_DYNAMIC_CORE_V1');
assert.equal(calibratedGoal.tdee, adaptive.estimateKcal);
assert.equal(calibratedGoal.energyBudget.exerciseAccounting, 'not_reported');
const adaptiveWorkoutGoal = calculatePhysiologicalGoalTargets(baseProfile, '2026-11-23', adaptive, { exerciseNetKcal: 300 });
assert.equal(adaptiveWorkoutGoal.tdee, adaptive.estimateKcal, 'observed TDEE already includes exercise energy');
assert.equal(adaptiveWorkoutGoal.energyBudget.exerciseAdditionalKcal, 0);
const belowRmrAdaptive = calculatePhysiologicalGoalTargets(baseProfile, '2026-11-23', {
  ...adaptive, estimateKcal: 1500, lowerBoundKcal: 1400, upperBoundKcal: 1600,
});
assert.equal(belowRmrAdaptive.tdeeSource, 'equation_nasem_2023');
assert.ok(belowRmrAdaptive.warnings.some((warning) => warning.includes('abaixo do RMR')));
const lowConfidenceGoal = calculatePhysiologicalGoalTargets(baseProfile, '2026-11-23', { ...adaptive, confidence: 'low' });
assert.equal(lowConfidenceGoal.tdeeSource, 'equation_nasem_2023');
assert.equal(estimateAdaptiveTdee(intake.slice(0, 10), weightHistory, 28), null);
const implausibleWeights = weightHistory.map((record, index) => ({ ...record, weightKg: 79 - index * 8 }));
assert.equal(estimateAdaptiveTdee(intake, implausibleWeights, 28), null, 'implausible inferred expenditure must be rejected instead of clamped');
const invalidAdaptive = calculatePhysiologicalGoalTargets(baseProfile, '2026-11-23', { ...adaptive, lowerBoundKcal: 9000 });
assert.equal(invalidAdaptive.tdeeSource, 'equation_nasem_2023');
assert.ok(invalidAdaptive.warnings.some((warning) => warning.includes('limites inválidos')));
console.log('PASS adaptive TDEE interval, coverage gating and insufficient-data handling');
