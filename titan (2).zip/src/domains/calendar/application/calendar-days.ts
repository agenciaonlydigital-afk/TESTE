import { buildRecentLocalDayDescriptors } from '@/src/shared/utils/local-date';
import { getFirstRecordDateKey } from './calendar-boundary';
import { MonthlyCalendar } from '../components/MonthlyCalendar';
import {
  formatCalendarLabels,
  formatNumericDateBR,
  type CalendarDayDescriptor,
} from '../domain/entities/calendar-day';
import {
  INITIAL_FIRST_RECORD_DATE_KEY,
  useCalendarStore,
} from '../state/calendar.store';

export { getFirstRecordDateKey };

export function getSelectableCalendarDays(): readonly CalendarDayDescriptor[] {
  return buildRecentLocalDayDescriptors();
}

export function resolveCalendarDay(dateKey: string): CalendarDayDescriptor {
  const preset = buildRecentLocalDayDescriptors().find((day) => day.key === dateKey);
  if (preset) return preset;
  return formatCalendarLabels(dateKey);
}

export {
  formatNumericDateBR,
  INITIAL_FIRST_RECORD_DATE_KEY,
  MonthlyCalendar,
  useCalendarStore,
};
