import { useEffect, useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { getLocalDateKey } from '@/src/shared/utils/local-date';
import {
  buildMonthMatrix,
  formatNumericDateBR,
  MONTHS_FULL,
  parseDateKeyParts,
} from '../domain/entities/calendar-day';

interface MonthlyCalendarProps {
  selectedDateKey: string;
  onSelectDate: (dateKey: string) => void;
  minDateKey?: string;
  maxDateKey?: string;
  markedDateKeys?: ReadonlySet<string>;
  anchorLabel?: string;
}

const WEEKDAY_HEADERS = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'] as const;

export function MonthlyCalendar({
  selectedDateKey,
  onSelectDate,
  minDateKey,
  maxDateKey,
  markedDateKeys,
  anchorLabel,
}: MonthlyCalendarProps) {
  const todayKey = getLocalDateKey();
  const todayParts = parseDateKeyParts(todayKey);
  const initialParts = parseDateKeyParts(selectedDateKey);
  const [viewYear, setViewYear] = useState(initialParts.year);
  const [viewMonth, setViewMonth] = useState(initialParts.month);

  useEffect(() => {
    const nextParts = parseDateKeyParts(selectedDateKey);
    setViewYear(nextParts.year);
    setViewMonth(nextParts.month);
  }, [selectedDateKey]);

  const cells = useMemo(
    () => buildMonthMatrix(viewYear, viewMonth),
    [viewYear, viewMonth],
  );

  const yearOptions = useMemo(() => {
    const minYear = minDateKey ? Math.min(parseDateKeyParts(minDateKey).year, todayParts.year - 2) : todayParts.year - 3;
    const maxYear = maxDateKey ? Math.max(parseDateKeyParts(maxDateKey).year, todayParts.year + 5) : todayParts.year + 5;
    const years: number[] = [];
    for (let y = minYear; y <= maxYear; y += 1) years.push(y);
    if (!years.includes(viewYear)) years.push(viewYear);
    return years.sort((a, b) => a - b);
  }, [minDateKey, maxDateKey, todayParts.year, viewYear]);

  const handlePrevMonth = () => {
    if (viewMonth === 1) {
      setViewYear((y) => y - 1);
      setViewMonth(12);
    } else {
      setViewMonth((m) => m - 1);
    }
  };

  const handleNextMonth = () => {
    if (viewMonth === 12) {
      setViewYear((y) => y + 1);
      setViewMonth(1);
    } else {
      setViewMonth((m) => m + 1);
    }
  };

  const canJumpToday =
    (minDateKey === undefined || todayKey >= minDateKey) &&
    (maxDateKey === undefined || todayKey <= maxDateKey);
  const isViewingCurrentMonth =
    viewYear === todayParts.year && viewMonth === todayParts.month;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-2">
        <button
          type="button"
          onClick={handlePrevMonth}
          aria-label="Mês anterior"
          className="min-h-[44px] min-w-[44px] rounded-xl bg-[var(--titan-surface-inset)] border border-[var(--titan-border-subtle)] text-[var(--titan-text-secondary)] flex items-center justify-center transition-colors hover:border-[var(--titan-accent)]/45 hover:text-[var(--titan-text-primary)]"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-1.5 min-w-0">
          <select
            aria-label="Selecionar mês"
            value={viewMonth}
            onChange={(event) => setViewMonth(Number(event.target.value))}
            className="min-h-[44px] rounded-xl border border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)] px-2.5 text-xs font-semibold capitalize text-[var(--titan-text-primary)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-focus)]/70"
          >
            {MONTHS_FULL.map((label, idx) => (
              <option key={label} value={idx + 1}>
                {label}
              </option>
            ))}
          </select>

          <select
            aria-label="Selecionar ano"
            value={viewYear}
            onChange={(event) => setViewYear(Number(event.target.value))}
            className="min-h-[44px] rounded-xl border border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)] px-2.5 text-xs font-mono-metric font-semibold text-[var(--titan-text-primary)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-focus)]/70"
          >
            {yearOptions.map((year) => (
              <option key={year} value={year}>
                {year}
              </option>
            ))}
          </select>

          {canJumpToday && (!isViewingCurrentMonth || selectedDateKey !== todayKey) && (
            <button
              type="button"
              onClick={() => {
                setViewYear(todayParts.year);
                setViewMonth(todayParts.month);
                onSelectDate(todayKey);
              }}
              className="min-h-[44px] rounded-xl border border-[var(--titan-champagne)]/35 bg-[var(--titan-surface-raised)] px-2.5 text-xs font-semibold text-[var(--titan-champagne)] transition-colors hover:border-[var(--titan-champagne)]"
            >
              Hoje
            </button>
          )}
        </div>

        <button
          type="button"
          onClick={handleNextMonth}
          aria-label="Próximo mês"
          className="min-h-[44px] min-w-[44px] rounded-xl bg-[var(--titan-surface-inset)] border border-[var(--titan-border-subtle)] text-[var(--titan-text-secondary)] flex items-center justify-center transition-colors hover:border-[var(--titan-accent)]/45 hover:text-[var(--titan-text-primary)]"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      <div className="rounded-2xl border border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)]/90 p-2.5 sm:p-3">
        <div className="grid grid-cols-7 gap-1 text-center mb-1.5">
          {WEEKDAY_HEADERS.map((wd) => (
            <div
              key={wd}
              className="py-1 text-[10px] font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-muted)]"
            >
              {wd}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-1 text-center">
          {cells.map((cell) => {
            const isSelected = cell.dateKey === selectedDateKey;
            const isToday = cell.dateKey === todayKey;
            const isDisabled =
              (minDateKey !== undefined && cell.dateKey < minDateKey) ||
              (maxDateKey !== undefined && cell.dateKey > maxDateKey);
            const hasRecord = markedDateKeys?.has(cell.dateKey) ?? false;

            return (
              <button
                key={cell.dateKey}
                type="button"
                disabled={isDisabled}
                onClick={() => onSelectDate(cell.dateKey)}
                aria-pressed={isSelected}
                aria-current={isToday ? 'date' : undefined}
                aria-label={`Selecionar dia ${formatNumericDateBR(cell.dateKey)}`}
                className={`relative min-h-[44px] rounded-xl text-xs font-mono-metric flex flex-col items-center justify-center transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-focus)] focus-visible:ring-offset-2 focus-visible:ring-offset-[var(--titan-surface)] ${
                  isSelected
                    ? 'bg-[var(--titan-accent)] text-[var(--titan-text-on-accent)] font-semibold shadow-[inset_0_1px_0_rgba(255,255,255,0.3)]'
                    : isDisabled
                    ? 'text-[var(--titan-text-disabled)]/45 cursor-not-allowed'
                    : isToday
                    ? 'border border-[var(--titan-champagne)]/60 bg-[var(--titan-surface-raised)] text-[var(--titan-text-primary)] font-semibold hover:border-[var(--titan-champagne)]'
                    : cell.inCurrentMonth
                    ? 'text-[var(--titan-text-primary)] hover:bg-[var(--titan-surface-raised)]'
                    : 'text-[var(--titan-text-muted)]/45 hover:bg-[var(--titan-surface)]/70'
                }`}
              >
                <span className="tabular-nums">{cell.dayNumber}</span>
                {hasRecord && (
                  <span
                    className={`absolute bottom-1.5 h-[2px] w-3 rounded-full ${
                      isSelected ? 'bg-[var(--titan-text-on-accent)]/75' : 'bg-[var(--titan-champagne)]'
                    }`}
                    aria-hidden="true"
                  />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {(minDateKey || markedDateKeys) && (
        <div className="pt-1 flex flex-wrap items-center justify-between gap-2 text-[11px] text-[var(--titan-text-muted)]">
          {minDateKey && (
            <span>
              {anchorLabel ?? 'Primeiro registro'}:{' '}
              <span className="font-mono-metric text-[var(--titan-text-secondary)]">
                {formatNumericDateBR(minDateKey)}
              </span>
            </span>
          )}
          {markedDateKeys && markedDateKeys.size > 0 && (
            <span className="inline-flex items-center gap-1.5">
              <span className="inline-block h-[2px] w-3 rounded-full bg-[var(--titan-champagne)]" aria-hidden="true" />
              <span>Com registros</span>
            </span>
          )}
        </div>
      )}
    </div>
  );
}
