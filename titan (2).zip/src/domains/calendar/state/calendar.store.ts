import { isValidLocalDateKey } from '@/src/shared/utils/local-date';
import { create } from 'zustand';

/**
 * Armazena a data do primeiro registro como ponto de partida oficial do usuário.
 */
export const INITIAL_FIRST_RECORD_DATE_KEY = '2026-11-07';

interface CalendarState {
  firstRecordDateKey: string;
  registerRecordDate: (dateKey: string) => void;
}

export const useCalendarStore = create<CalendarState>((set) => ({
  firstRecordDateKey: INITIAL_FIRST_RECORD_DATE_KEY,
  registerRecordDate: (dateKey) =>
    set((state) => {
      if (!isValidLocalDateKey(dateKey)) return state;
      if (dateKey < state.firstRecordDateKey) {
        return { firstRecordDateKey: dateKey };
      }
      return state;
    }),
}));
