import assert from 'node:assert/strict';
import { mergeHydrationPersistedState } from '../hydration-persistence.ts';

const fallback = {
  dailyGoalMl: 2500,
  entries: [{ id: 'seed', dateKey: '2026-11-23', amountMl: 350, timeLabel: '08:00' }],
  lastEventSeq: 0,
};
const restored = mergeHydrationPersistedState({
  dailyGoalMl: 3000,
  lastEventSeq: 8,
  entries: [
    { id: 'ok', dateKey: '2026-11-22', amountMl: 500, timeLabel: '10:30' },
    { id: 'hyd-1', dateKey: '2026-11-23', amountMl: 350, timeLabel: '07:20' },
    { id: 'bad-volume', dateKey: '2026-11-22', amountMl: Number.NaN, timeLabel: '10:30' },
    { id: 'bad-date', dateKey: '2026-02-30', amountMl: 100, timeLabel: '10:30' },
  ],
}, fallback);
assert.equal(restored.dailyGoalMl, 3000);
assert.equal(restored.lastEventSeq, 8);
assert.deepEqual(restored.entries.map((entry) => entry.id), ['ok'], 'legacy hard-coded sample hydration events must not be represented as user logs');
const legacySeedOnly = mergeHydrationPersistedState({ entries: [{ id: 'hyd-prev-1', dateKey: '2026-11-20', amountMl: 600, timeLabel: '09:00' }] }, fallback);
assert.deepEqual(legacySeedOnly.entries, [], 'legacy seeded events are removed during rehydration');
const corrupt = mergeHydrationPersistedState({ dailyGoalMl: -1, entries: 'broken' }, fallback);
assert.equal(corrupt.dailyGoalMl, fallback.dailyGoalMl);
assert.deepEqual(corrupt.entries, fallback.entries);
console.log('Hydration persistence tests passed.');
