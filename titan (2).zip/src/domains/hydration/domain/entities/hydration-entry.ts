export interface HydrationLogEntry {
  id: string;
  dateKey: string;
  amountMl: number;
  timeLabel: string;
}

export interface HydrationSummarySnapshot {
  currentMl: number;
  goalMl: number;
  percent: number;
  barPercent: number;
  hasRecords: boolean;
  dayEntries: HydrationLogEntry[];
}
