import { isValidLocalDateKey } from '@/src/shared/utils/local-date';
import { parseLocaleNumber } from '@/src/shared/utils/formatters';
import { getHydrationSummary } from '../domain/rules/hydration-summary';
import {
  waterAmountSchema,
  waterCorrectionSchema,
  waterGoalSchema,
} from '../schemas/hydration.schema';
import { useHydrationStore } from '../state/hydration.store';

export type HydrationActionResult = { ok: true } | { ok: false; error: string };

export function logValidatedWater(
  rawValue: string | number,
  dateKey?: string,
): HydrationActionResult {
  if (typeof rawValue === 'string' && rawValue.trim() === '') {
    return { ok: false, error: 'Informe um volume em ml.' };
  }
  if (dateKey !== undefined && !isValidLocalDateKey(dateKey)) {
    return { ok: false, error: 'Data do registro inválida.' };
  }
  const numeric = parseLocaleNumber(rawValue);
  const parsed = waterAmountSchema.safeParse(numeric);
  if (!parsed.success) {
    return { ok: false, error: parsed.error.issues[0]?.message ?? 'Volume inválido.' };
  }
  useHydrationStore.getState().logWater(parsed.data, dateKey);
  return { ok: true };
}

export function correctValidatedLastWater(
  rawValue: string | number,
  dateKey?: string,
): HydrationActionResult {
  if (typeof rawValue === 'string' && rawValue.trim() === '') {
    return { ok: false, error: 'Informe um volume válido para correção.' };
  }
  if (dateKey !== undefined && !isValidLocalDateKey(dateKey)) {
    return { ok: false, error: 'Data do registro inválida.' };
  }
  const numeric = parseLocaleNumber(rawValue);
  const parsed = waterCorrectionSchema.safeParse(numeric);
  if (!parsed.success) {
    return { ok: false, error: parsed.error.issues[0]?.message ?? 'Valor inválido.' };
  }
  useHydrationStore.getState().correctLastEntry(parsed.data, dateKey);
  return { ok: true };
}

export function validateWaterGoal(rawValue: string | number): {
  ok: true;
  value: number;
} | {
  ok: false;
  error: string;
} {
  if (typeof rawValue === 'string' && rawValue.trim() === '') {
    return { ok: false, error: 'Preencha todos os campos numéricos antes de salvar.' };
  }
  const numeric = parseLocaleNumber(rawValue);
  const parsed = waterGoalSchema.safeParse(numeric);
  if (!parsed.success) {
    return { ok: false, error: parsed.error.issues[0]?.message ?? 'Meta inválida.' };
  }
  return { ok: true, value: Math.round(parsed.data) };
}

export { getHydrationSummary, useHydrationStore };

export { calculateExerciseHydration } from '../domain/rules/exercise-hydration';
export type { ExerciseHydrationInput, ExerciseHydrationEstimate } from '../domain/rules/exercise-hydration';
