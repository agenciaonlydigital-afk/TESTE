import { APP_DAY_KEY } from '@/src/shared/constants/app';
import type { HydrationLogEntry } from '../../domain/entities/hydration-entry';

export const INITIAL_HYDRATION_ENTRIES: HydrationLogEntry[] = [
  { id: 'hyd-seed-1', dateKey: APP_DAY_KEY, amountMl: 450, timeLabel: '08:15' },
  { id: 'hyd-seed-2', dateKey: APP_DAY_KEY, amountMl: 500, timeLabel: '12:40' },
  { id: 'hyd-seed-3', dateKey: APP_DAY_KEY, amountMl: 400, timeLabel: '16:05' },
];
