import assert from 'node:assert/strict';
import {
  MAX_ESTIMATED_1RM_REPS,
  buildOneRepMaxLoadTable,
  calculateWeeklyMuscleSetVolume,
  estimateOneRepMax,
  summarizeExercisePerformance,
  summarizeWorkoutPlan,
  suggestDoubleProgression,
} from '../domain/rules/strength-calculations.ts';

const single = estimateOneRepMax(100, 1, 0);
assert.equal(single.oneRepMaxKg, 100);
assert.equal(single.qualityBand, 'single_rep_observed');
const fiveRep = estimateOneRepMax(100, 5, 0);
const fiveRepWithRir = estimateOneRepMax(100, 5, 2);
const unknownEffort = estimateOneRepMax(100, 5);
assert.equal(fiveRepWithRir.repetitionsToFailureEstimate, 7);
assert.equal(fiveRepWithRir.effortBasis, 'reported_rir');
assert.equal(unknownEffort.qualityBand, 'effort_unverified_estimate');
assert.equal(unknownEffort.effortBasis, 'assumed_to_failure');
assert.equal(unknownEffort.repsInReserveUsed, null);
assert.equal(fiveRep.formulaEstimatesKg.epley, 116.7);
assert.equal(fiveRep.formulaEstimatesKg.brzycki, 112.5);
assert.equal(fiveRep.formulaEstimatesKg.lombardi, 117.5);
assert.ok(fiveRep.minEstimateKg <= fiveRep.oneRepMaxKg && fiveRep.oneRepMaxKg <= fiveRep.maxEstimateKg);
assert.equal(estimateOneRepMax(100, MAX_ESTIMATED_1RM_REPS + 1), null);
assert.throws(() => estimateOneRepMax(100, 0), /inteiro positivo/i);
assert.throws(() => estimateOneRepMax(Infinity, 5), /positiva e finita/i);
assert.throws(() => estimateOneRepMax(100, 5, 6), /RIR/i);

const table = buildOneRepMaxLoadTable(100);
assert.equal(table.length, 11);
assert.deepEqual(table[0], { percent: 100, loadKg: 100 });
assert.deepEqual(table.at(-1), { percent: 50, loadKg: 50 });

const exercise = summarizeExercisePerformance([
  { weightKg: 80, reps: 8, completed: true },
  { weightKg: 80, reps: 7, completed: true },
  { weightKg: 80, reps: 6, completed: false },
  { weightKg: 0, reps: 10, completed: true },
]);
assert.equal(exercise.completedSetCount, 3);
assert.equal(exercise.totalReps, 25);
assert.equal(exercise.volumeLoadKg, 1200);
assert.ok(exercise.estimatedOneRepMaxKg > 0);
const workout = summarizeWorkoutPlan({ exercises: [
  { exerciseSlug: 'bench-press', sets: [{ weightKg: 80, reps: 8, completed: true }] },
  { exerciseSlug: 'push-up', sets: [{ weightKg: 0, reps: 15, completed: true }] },
] });
assert.equal(workout.completedSets, 2);
assert.ok(workout.estimatedOneRepMaxByExercise['bench-press'] > 0);
assert.equal(workout.oneRepMaxEffortBasisByExercise['bench-press'], 'assumed_to_failure');
assert.equal(workout.estimatedOneRepMaxByExercise['push-up'], undefined);

assert.equal(suggestDoubleProgression({
  currentLoadKg: 50, completedSetReps: [10, 10, 10], minimumReps: 8, maximumReps: 10, loadIncrementKg: 2.5,
}).suggestedLoadKg, 52.5);
assert.equal(suggestDoubleProgression({
  currentLoadKg: 50, completedSetReps: [10, 9, 10], minimumReps: 8, maximumReps: 10,
}).action, 'maintain_load');
assert.equal(suggestDoubleProgression({
  currentLoadKg: 0, completedSetReps: [12], minimumReps: 8, maximumReps: 12,
}).action, 'insufficient_data');
assert.equal(suggestDoubleProgression({
  currentLoadKg: 50, completedSetReps: [], minimumReps: 8, maximumReps: 12,
}).action, 'insufficient_data');

const muscles = calculateWeeklyMuscleSetVolume([{
  dateKey: '2026-11-24',
  exercises: [{
    muscles: { primary: ['pectoralis'], secondary: ['triceps', 'anterior_deltoid'] },
    sets: [{ completed: true }, { completed: true }, { completed: false }],
  }],
}, {
  dateKey: '2026-12-01', // End boundary is exclusive.
  exercises: [{ muscles: { primary: ['pectoralis'], secondary: [] }, sets: [{ completed: true }] }],
}], '2026-11-23');
assert.equal(muscles.pectoralis.primarySets, 2);
assert.equal(muscles.pectoralis.effectiveSets, 2);
assert.equal(muscles.triceps.secondarySets, 2);
assert.equal(muscles.triceps.effectiveSets, 1);
assert.equal(muscles.anterior_deltoid.effectiveSets, 1);
assert.equal(Object.keys(muscles).length, 14);
assert.throws(() => calculateWeeklyMuscleSetVolume([], '2026-02-30'), /Data inicial/i);

console.log('PASS calculation engine training: 1RM, load table, volume, progression and 14-muscle weekly sets');
