import { z } from 'zod';

export const setEntrySchema = z.object({
  weightKg: z.number().min(0, 'Carga não pode ser negativa').max(500, 'Carga máxima excedida'),
  reps: z.number().int('Repetições devem ser inteiras').min(1, 'Mínimo 1 repetição').max(100, 'Máximo 100 repetições'),
  repsInReserve: z.number().int('RIR deve ser inteiro').min(0, 'RIR mínimo 0').max(5, 'RIR máximo 5').nullable().optional(),
});

export type SetEntryInput = z.infer<typeof setEntrySchema>;
