import { setWorkoutMuscleHighlights } from '@/src/domains/anatomy/application/anatomy-public';
import { computePlanMuscleHighlights } from '../domain/rules/workout-session';
import { setEntrySchema } from '../schemas/set-entry.schema';
import { useTrainingSessionStore } from '../state/training-session.store';
import { isWorkoutSetTargetValid } from './register-set-validation';

export function registerWorkoutSet(
  exerciseId: string,
  setId: string,
  weightKg: number,
  reps: number,
  repsInReserve: number | null = null,
): { ok: true } | { ok: false; error: string } {
  const parsed = setEntrySchema.safeParse({ weightKg, reps, repsInReserve });
  if (!parsed.success) {
    return { ok: false, error: parsed.error.issues[0]?.message ?? 'Dados inválidos' };
  }

  const store = useTrainingSessionStore.getState();
  const plan = store.plans.find((p) => p.id === store.activePlanId);
  const exercise = plan?.exercises.find((e) => e.id === exerciseId);
  if (!plan || !exercise) {
    return { ok: false, error: 'Exercício não encontrado' };
  }
  if (!isWorkoutSetTargetValid(plan, exerciseId, setId)) {
    return { ok: false, error: 'Série não encontrada ou já registrada.' };
  }

  store.updateSetValues(exerciseId, setId, parsed.data.weightKg, parsed.data.reps, parsed.data.repsInReserve ?? null);
  store.markSetCompleted(exerciseId, setId);
  setWorkoutMuscleHighlights(computePlanMuscleHighlights(plan));

  // Automatic rest starts immediately after logging a set
  store.startRestTimer(exercise.name, exercise.targetRestSeconds);

  return { ok: true };
}
