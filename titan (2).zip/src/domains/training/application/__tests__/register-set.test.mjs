import assert from 'node:assert/strict';
import { isWorkoutSetTargetValid } from '../register-set-validation.ts';

const plan = {
  id: 'upper-a', exercises: [{ id: 'ex-1', sets: [{ id: 's-1', completed: false }] }],
};
assert.equal(isWorkoutSetTargetValid(plan, 'ex-1', 's-1'), true);
assert.equal(isWorkoutSetTargetValid(plan, 'ex-1', 'unknown'), false);
assert.equal(isWorkoutSetTargetValid(plan, 'unknown-exercise', 's-1'), false);
assert.equal(isWorkoutSetTargetValid(undefined, 'ex-1', 's-1'), false);
assert.equal(isWorkoutSetTargetValid({ ...plan, exercises: [{ id: 'ex-1', sets: [{ id: 's-1', completed: true }] }] }, 'ex-1', 's-1'), false);
console.log('Workout set validation tests passed.');
