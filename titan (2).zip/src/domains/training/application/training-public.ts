import { focusWorkoutExercise, startWorkoutSession } from './start-workout';
import { useRestTimerSnapshot } from '../hooks/use-rest-snapshot';
import { useActiveWorkoutProgress } from '../state/selectors';
import { useTrainingSessionStore } from '../state/training-session.store';

export {
  focusWorkoutExercise,
  startWorkoutSession,
  useActiveWorkoutProgress,
  useRestTimerSnapshot,
  useTrainingSessionStore,
};

export {
  computePlanMuscleHighlights,
} from '../domain/rules/workout-session';

export {
  MAX_ESTIMATED_1RM_REPS,
  buildOneRepMaxLoadTable,
  calculateWeeklyMuscleSetVolume,
  estimateOneRepMax,
  summarizeExercisePerformance,
  summarizeWorkoutPlan,
  suggestDoubleProgression,
} from '../domain/rules/strength-calculations';

export { estimateCompletedWorkoutActivityEnergy } from './workout-activity-energy';
export type { CompletedWorkoutEnergyInput, CompletedWorkoutActivityEnergy } from './workout-activity-energy';
