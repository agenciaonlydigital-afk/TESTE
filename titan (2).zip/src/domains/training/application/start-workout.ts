import { setWorkoutMuscleHighlights } from '@/src/domains/anatomy/application/anatomy-public';
import { computePlanMuscleHighlights } from '../domain/rules/workout-session';
import { useTrainingSessionStore } from '../state/training-session.store';

export function startWorkoutSession(planId: string): void {
  useTrainingSessionStore.getState().beginSession(planId);
  const store = useTrainingSessionStore.getState();
  const plan = store.plans.find((p) => p.id === planId);
  const firstPending =
    plan?.exercises.find((ex) => ex.sets.some((s) => !s.completed)) ?? plan?.exercises[0];
  if (firstPending) {
    store.focusExercise(firstPending.id);
  }
  if (plan) {
    setWorkoutMuscleHighlights(computePlanMuscleHighlights(plan));
  }
}

export function focusWorkoutExercise(exerciseId: string): void {
  const store = useTrainingSessionStore.getState();
  store.focusExercise(exerciseId);
  const plan = store.plans.find((p) => p.id === store.activePlanId);
  if (plan) {
    setWorkoutMuscleHighlights(computePlanMuscleHighlights(plan));
  }
}
