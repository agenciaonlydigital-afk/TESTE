import type { MuscleGroupId, MuscleHighlightPayload } from '../../../../shared/types/common';
import type { CompletedWorkoutSession, WorkoutPlan } from '../entities/workout';
import { getLocalDateKey } from '../../../../shared/utils/local-date.ts';

/** Compute deduplicated primary and secondary muscle highlights for an entire workout plan. */
export function computePlanMuscleHighlights(
  plan: WorkoutPlan | undefined,
): MuscleHighlightPayload {
  if (!plan) return { primary: [], secondary: [] };
  const primarySet = new Set<MuscleGroupId>();
  const secondarySet = new Set<MuscleGroupId>();
  for (const exercise of plan.exercises) {
    for (const muscle of exercise.muscles.primary) {
      primarySet.add(muscle);
    }
  }
  for (const exercise of plan.exercises) {
    for (const muscle of exercise.muscles.secondary) {
      if (!primarySet.has(muscle)) secondarySet.add(muscle);
    }
  }
  return {
    primary: [...primarySet],
    secondary: [...secondarySet],
  };
}

/** Reset execution state for a new workout while retaining the last load/reps as progression hints. */
export function resetWorkoutPlanForNextSession(plan: WorkoutPlan): WorkoutPlan {
  return {
    ...plan,
    status: 'in_progress',
    exercises: plan.exercises.map((exercise) => ({
      ...exercise,
      sets: exercise.sets.map(({ completedAtMs: _completedAtMs, ...set }) => ({
        ...set,
        repsInReserve: null,
        completed: false,
      })),
    })),
  };
}

/** Create an immutable snapshot so later plan edits cannot rewrite workout history. */
export function createCompletedWorkoutSession(
  plan: WorkoutPlan,
  startedAtMs: number | null,
  completedAtMs: number,
): CompletedWorkoutSession {
  const sets = plan.exercises.flatMap((exercise) =>
    exercise.sets.filter((set) => set.completed).map((set) => ({
      exerciseId: exercise.id,
      exerciseName: exercise.name,
      setNumber: set.setNumber,
      weightKg: set.weightKg,
      reps: set.reps,
      repsInReserve: set.repsInReserve ?? null,
    })),
  );
  const totalSets = plan.exercises.reduce((total, exercise) => total + exercise.sets.length, 0);
  return {
    id: `session-${plan.id}-${completedAtMs}`,
    planId: plan.id,
    planTitle: plan.title,
    dateKey: getLocalDateKey(new Date(completedAtMs)),
    startedAtMs,
    completedAtMs,
    completedSets: sets.length,
    totalSets,
    sets,
  };
}
