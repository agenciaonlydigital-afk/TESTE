import type { ExerciseCategory, ExerciseLevel, ExerciseMechanic } from '../domain/entities/exercise-item';
import type { MuscleGroupId } from '@/src/shared/types/common';
import { MUSCLE_REGISTRY } from '../../anatomy/application/muscle-catalog-public.ts';
import { EXERCISE_CATALOG } from '../data/repositories/exercise-catalog.ts';
import type { ExerciseLibraryItem } from '../domain/entities/exercise-item';

export interface ExerciseCatalogFilters {
  muscle?: MuscleGroupId | 'all';
  equipment?: string | 'all';
  level?: ExerciseLevel | 'all';
  category?: ExerciseCategory | 'all';
  mechanic?: ExerciseMechanic | 'all';
}

export function normalizeExerciseSearchText(value: string): string {
  return value
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLocaleLowerCase('pt-BR')
    .trim();
}

export function filterExerciseCatalog(
  query: string,
  filters: ExerciseCatalogFilters = {},
): readonly ExerciseLibraryItem[] {
  const normalizedQuery = normalizeExerciseSearchText(query);
  return EXERCISE_CATALOG.filter((item) => {
    if (filters.muscle && filters.muscle !== 'all') {
      const muscleIds = [...item.muscles.primary, ...item.muscles.secondary, ...(item.stabilizers ?? [])];
      if (!muscleIds.includes(filters.muscle)) return false;
    }
    if (filters.equipment && filters.equipment !== 'all' && item.equipment !== filters.equipment) return false;
    if (filters.level && filters.level !== 'all' && item.level !== filters.level) return false;
    if (filters.category && filters.category !== 'all' && item.category !== filters.category) return false;
    if (filters.mechanic && filters.mechanic !== 'all' && item.mechanic !== filters.mechanic) return false;
    if (!normalizedQuery) return true;

    const muscleIds = [...item.muscles.primary, ...item.muscles.secondary, ...(item.stabilizers ?? [])];
    const muscleNames = muscleIds.map((muscleId) => MUSCLE_REGISTRY[muscleId].label);
    const relatedNames = [...(item.progressions ?? []), ...(item.regressions ?? []), ...(item.alternatives ?? [])]
      .map((slug) => EXERCISE_CATALOG.find((candidate) => candidate.slug === slug)?.name ?? slug.replace(/-/g, ' '));
    const searchableFields = [
      item.name,
      item.slug.replace(/-/g, ' '),
      item.equipment,
      item.pattern,
      item.cue,
      item.level ?? '',
      item.force ?? '',
      item.mechanic ?? '',
      item.category ?? '',
      ...(item.aliases ?? []),
      ...(item.instructions ?? []),
      ...(item.tips ?? []),
      ...(item.commonErrors ?? []),
      item.breathing ?? '',
      ...relatedNames,
      ...muscleNames,
      ...muscleIds.flatMap((muscleId) => MUSCLE_REGISTRY[muscleId].aliases ?? []),
    ];
    return searchableFields.some((field) => normalizeExerciseSearchText(field).includes(normalizedQuery));
  });
}

export function listExerciseFilterOptions() {
  return {
    equipment: [...new Set(EXERCISE_CATALOG.map((item) => item.equipment))].sort((a, b) => a.localeCompare(b, 'pt-BR')),
    levels: ['beginner', 'intermediate', 'advanced'] as const,
    categories: [...new Set(EXERCISE_CATALOG.map((item) => item.category).filter((value): value is ExerciseCategory => Boolean(value)))].sort(),
    mechanics: [...new Set(EXERCISE_CATALOG.map((item) => item.mechanic).filter((value): value is ExerciseMechanic => Boolean(value)))].sort(),
  };
}
