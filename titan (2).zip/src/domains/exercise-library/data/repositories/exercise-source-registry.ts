import type { ExerciseSourceRepository } from '../../domain/entities/exercise-item';

export interface ExerciseDataSourceDefinition {
  id: ExerciseSourceRepository;
  starsAtReview: number;
  recordsAdvertised: number | null;
  dataLicense: string;
  mediaLicense: string;
  integration: 'imported-selected-records' | 'schema-reference-only' | 'not-imported-license-review';
  rationale: string;
  url: string;
}

/** GitHub star counts are a dated snapshot, not a quality score. */
export const EXERCISE_DATA_SOURCES: readonly ExerciseDataSourceDefinition[] = [
  {
    id: 'hasaneyldrm/exercises-dataset',
    starsAtReview: 23_979,
    recordsAdvertised: 1_324,
    dataLicense: 'MIT (exercise data and text)',
    mediaLicense: 'Gym visual; separate permission/terms, not included by TITAN',
    integration: 'not-imported-license-review',
    rationale: 'Largest high-star candidate reviewed; broad multilingual metadata. Media is intentionally excluded until direct reuse rights are established.',
    url: 'https://github.com/hasaneyldrm/exercises-dataset',
  },
  {
    id: 'wger-project/wger',
    starsAtReview: 7_312,
    recordsAdvertised: null,
    dataLicense: 'Creative Commons per exercise entry; verify each record',
    mediaLicense: 'Per media item; verify separately',
    integration: 'not-imported-license-review',
    rationale: 'Best integrated workout platform/API reference; TITAN does not embed its AGPL application code.',
    url: 'https://github.com/wger-project/wger',
  },
  {
    id: 'yuhonas/free-exercise-db',
    starsAtReview: 2_170,
    recordsAdvertised: 800,
    dataLicense: 'Unlicense, as declared by the repository',
    mediaLicense: 'Not bundled by TITAN; media provenance is not inferred from the data license',
    integration: 'imported-selected-records',
    rationale: 'Structured exercise records with force, level, mechanic, equipment, primary/secondary muscles and step instructions.',
    url: 'https://github.com/yuhonas/free-exercise-db',
  },
  {
    id: 'wrkout/exercises.json',
    starsAtReview: 650,
    recordsAdvertised: 800,
    dataLicense: 'Unlicense, as declared by the repository',
    mediaLicense: 'Not bundled by TITAN',
    integration: 'schema-reference-only',
    rationale: 'Public-domain-oriented dataset; useful alternative source, but overlaps substantially with other exercise lists.',
    url: 'https://github.com/wrkout/exercises.json',
  },
  {
    id: 'exercemus/exercises',
    starsAtReview: 53,
    recordsAdvertised: null,
    dataLicense: 'Per-exercise license and author metadata; verify each record',
    mediaLicense: 'Per media item',
    integration: 'schema-reference-only',
    rationale: 'Useful model for aliases, variation relationships, tempo, tips and license provenance on each record.',
    url: 'https://github.com/exercemus/exercises',
  },
  {
    id: 'kinetic-place/exercises-db',
    starsAtReview: 5,
    recordsAdvertised: 908,
    dataLicense: 'MIT, declared by repository',
    mediaLicense: 'External YouTube links; no video is bundled by TITAN',
    integration: 'schema-reference-only',
    rationale: 'Lower-star reference, retained only for guide structure: 814 step-by-step guides, tips, errors, 17 groups and 44 equipment types.',
    url: 'https://github.com/kinetic-place/exercises-db',
  },
  {
    id: 'RepDB/exercise-dataset',
    starsAtReview: 152,
    recordsAdvertised: 708,
    dataLicense: 'Attribution required by repository README; no SPDX license declared by GitHub',
    mediaLicense: 'Attribution/terms require separate validation; not bundled by TITAN',
    integration: 'not-imported-license-review',
    rationale: 'Interesting 512px illustration and MET metadata; excluded until redistribution and commercial-use terms are independently confirmed.',
    url: 'https://github.com/RepDB/exercise-dataset',
  },
];

export function getExerciseDataSource(id: ExerciseSourceRepository): ExerciseDataSourceDefinition | undefined {
  return EXERCISE_DATA_SOURCES.find((source) => source.id === id);
}
