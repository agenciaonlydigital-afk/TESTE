import { useMemo } from 'react';
import { ArrowDown, ArrowDownRight, ArrowUp, ArrowUpRight, Minus } from 'lucide-react';
import { calculateBmi, calculateWaistToHeightRatio, estimateRelativeFatMass, useProfileStore } from '@/src/domains/profile/application/profile-public';
import { Surface } from '@/src/shared/ui/Surface';
import {
  computeCumulativeComparison,
  calculateWeightTrend,
  calculateGoalPace,
  computeLatestObservedDeltas,
  sortMeasurementsChronologically,
} from '../domain/rules/evolution-metrics';
import { useEvolutionStore } from '../state/evolution.store';
import { EvolutionTrendChart } from '../components/EvolutionTrendChart';
import { MeasurementEntryForm } from '../components/MeasurementEntryForm';
import { getLocalDateKey } from '@/src/shared/utils/local-date';
import type { BodyMeasurementRecord } from '@/src/shared/types/body-measurement';

type MeasurementField = 'waistCm' | 'armCm' | 'thighCm';

function findLatestRecordWithMeasurement(
  records: readonly BodyMeasurementRecord[],
  field: MeasurementField,
): BodyMeasurementRecord | undefined {
  for (let index = records.length - 1; index >= 0; index -= 1) {
    if (Number.isFinite(records[index]?.[field])) return records[index];
  }
  return undefined;
}

function formatSigned(val: number | null, unit: string): string {
  if (val === null || !Number.isFinite(val)) return '—';
  const prefix = val > 0 ? '+' : '';
  return `${prefix}${val.toFixed(1)} ${unit}`;
}

export function EvolutionScreen() {
  const storedRecords = useEvolutionStore((s) => s.records);
  const records = useMemo(() => sortMeasurementsChronologically(storedRecords), [storedRecords]);
  const reverseChronologicalRecords = useMemo(() => [...records].reverse(), [records]);
  const profile = useProfileStore((s) => s.profile);
  const profileConfigured = useProfileStore((s) => s.profileConfigured);
  const todayKey = getLocalDateKey();

  const latest = useMemo(() => records[records.length - 1] ?? ({
    id: 'profile-reference',
    dateKey: todayKey,
    dateLabel: 'Referência do perfil',
    weightKg: profile.currentWeightKg,
    waistCm: undefined,
    armCm: undefined,
    thighCm: undefined,
  }), [records, todayKey, profile.currentWeightKg]);
  const baseline = records[0] ?? latest;
  const latestWaistRecord = useMemo(() => findLatestRecordWithMeasurement(records, 'waistCm') ?? latest, [records, latest]);
  const latestArmRecord = useMemo(() => findLatestRecordWithMeasurement(records, 'armCm') ?? latest, [records, latest]);
  const latestThighRecord = useMemo(() => findLatestRecordWithMeasurement(records, 'thighCm') ?? latest, [records, latest]);

  const { weightDelta, waistDelta, armDelta, thighDelta } = useMemo(() => computeLatestObservedDeltas(records), [records]);
  const cumulative = useMemo(() => computeCumulativeComparison(records, profile.targetWeightKg), [records, profile.targetWeightKg]);
  const weightTrend = useMemo(() => calculateWeightTrend(records, 30), [records]);
  const goalPace = useMemo(() => calculateGoalPace(latest.weightKg, profile.targetWeightKg, profile.deadlineDateKey, todayKey, weightTrend), [latest.weightKg, profile.targetWeightKg, profile.deadlineDateKey, todayKey, weightTrend]);
  const bmi = useMemo(() => calculateBmi(latest.weightKg, profile.heightCm), [latest.weightKg, profile.heightCm]);
  const waistToHeightRatio = useMemo(() => {
    if (!Number.isFinite(latestWaistRecord.waistCm)) return null;
    try { return calculateWaistToHeightRatio(latestWaistRecord.waistCm!, profile.heightCm); }
    catch { return null; }
  }, [latestWaistRecord, profile.heightCm]);
  const relativeFatMass = useMemo(() => {
    if (!Number.isFinite(latestWaistRecord.waistCm)) return null;
    try {
      return estimateRelativeFatMass({ sex: profile.sex, heightCm: profile.heightCm, waistCm: latestWaistRecord.waistCm!, age: profile.age });
    } catch { return null; }
  }, [latestWaistRecord, profile.heightCm, profile.sex, profile.age]);

  const weightIsGoalAligned =
    profile.goal === 'lose_weight'
      ? cumulative.weightGainKg <= 0
      : profile.goal === 'gain_muscle'
      ? cumulative.weightGainKg >= 0
      : Math.abs(cumulative.weightGainKg) <= 0.5;
  const latestWeightDeltaVal = Number(weightDelta);
  const latestWeightDeltaAligned =
    profile.goal === 'lose_weight'
      ? latestWeightDeltaVal <= 0
      : profile.goal === 'gain_muscle'
      ? latestWeightDeltaVal >= 0
      : Math.abs(latestWeightDeltaVal) <= 0.3;

  return (
    <div className="space-y-6">
      <div className="titan-page-heading">
        <p className="titan-eyebrow">Medições e tendências reais</p>
        <h1 className="text-2xl font-semibold text-[var(--titan-text-primary)]">Evolução</h1>
        <p className="text-xs text-[var(--titan-text-secondary)] mt-0.5">
          {records.length > 0 ? `Comparativo desde ${baseline.dateLabel}` : 'Ainda não há medidas corporais registradas.'}
        </p>
      </div>

      {records.length === 0 && (
        <Surface className="p-4">
          <h2 className="text-sm font-semibold text-[var(--titan-text-primary)]">Comece seu histórico real</h2>
          <p className="mt-1 text-xs text-[var(--titan-text-secondary)]">Registre seu peso e, opcionalmente, circunferências. O TITAN só exibirá tendências e comparativos depois que houver medidas observadas; valores de exemplo não serão tratados como seus dados.</p>
        </Surface>
      )}

      {records.length > 0 && <>
      {/* Resumo comparativo de ganhos em relação à meta */}
      <Surface className="p-4 sm:p-5 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <span className="text-xs text-[var(--titan-text-muted)]">Comparativo até a meta</span>
            <div className="flex items-baseline gap-2.5 mt-0.5">
              <span className="text-lg font-semibold font-mono-metric text-[var(--titan-text-primary)]">
                {baseline.weightKg.toFixed(1)} kg → {latest.weightKg.toFixed(1)} kg
              </span>
              <span
                className={`inline-flex items-center gap-1 text-xs font-semibold font-mono-metric ${
                  weightIsGoalAligned ? 'text-[var(--titan-status-success)]' : 'text-[var(--titan-status-error)]'
                }`}
              >
                {cumulative.weightGainKg > 0 ? (
                  <ArrowUpRight className="w-3.5 h-3.5" />
                ) : cumulative.weightGainKg < 0 ? (
                  <ArrowDownRight className="w-3.5 h-3.5" />
                ) : (
                  <Minus className="w-3.5 h-3.5" />
                )}
                {formatSigned(cumulative.weightGainKg, 'kg')} (
                {cumulative.weightGainPercent > 0 ? '+' : ''}
                {cumulative.weightGainPercent.toFixed(1)}%)
              </span>
            </div>
          </div>

          <div className="text-right font-mono-metric">
            <div className="text-xs text-[var(--titan-text-muted)]">Meta desejada</div>
            <div className="text-sm font-semibold text-[var(--titan-accent)]">
              {profile.targetWeightKg.toFixed(1)} kg ({formatSigned(cumulative.remainingToTargetKg, 'kg')})
            </div>
          </div>
        </div>

        <div className="h-2 w-full rounded-full bg-[var(--titan-track)] border border-[var(--titan-border)]/70 overflow-hidden">
          <div
            className="h-full rounded-full bg-[var(--titan-accent)]"
            style={{ width: `${cumulative.progressPercent}%` }}
          />
        </div>
      </Surface>

      <Surface className="p-4 sm:p-5 space-y-3">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="titan-eyebrow">Planejamento dinâmico</p>
            <h2 className="text-base font-semibold text-[var(--titan-text-primary)]">Ritmo até o peso-alvo</h2>
            <p className="text-xs text-[var(--titan-text-muted)]">Compara o prazo planejado com a tendência observada, não com uma pesagem isolada.</p>
          </div>
          <span className="text-xs font-semibold text-[var(--titan-accent)]">{goalPace.paceStatus === 'on_track' ? 'No ritmo' : goalPace.paceStatus === 'too_fast' ? 'Ritmo acelerado' : goalPace.paceStatus === 'too_slow' ? 'Abaixo do ritmo' : goalPace.paceStatus === 'moving_away' ? 'Distanciando' : goalPace.paceStatus === 'target_reached' ? 'Meta atingida' : goalPace.paceStatus === 'deadline_passed' ? 'Prazo vencido' : 'Aguardando dados'}</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-6 gap-3">
          <div><p className="text-xs text-[var(--titan-text-muted)]">Distância</p><p className="mt-1 text-lg font-semibold font-mono-metric">{Math.abs(goalPace.remainingKg).toFixed(1)} kg</p></div>
          <div><p className="text-xs text-[var(--titan-text-muted)]">Ritmo necessário</p><p className="mt-1 text-lg font-semibold font-mono-metric">{goalPace.requiredKgPerWeek === null ? '—' : `${goalPace.requiredKgPerWeek > 0 ? '+' : ''}${goalPace.requiredKgPerWeek.toFixed(2)} kg/sem`}</p></div>
          <div><p className="text-xs text-[var(--titan-text-muted)]">Ritmo diário necessário</p><p className="mt-1 text-lg font-semibold font-mono-metric">{goalPace.requiredKgPerDay === null ? '—' : `${goalPace.requiredKgPerDay > 0 ? '+' : ''}${goalPace.requiredKgPerDay.toFixed(3)} kg/dia`}</p></div>
          <div><p className="text-xs text-[var(--titan-text-muted)]">Ritmo observado</p><p className="mt-1 text-lg font-semibold font-mono-metric">{goalPace.trendKgPerWeek === null ? '—' : `${goalPace.trendKgPerWeek > 0 ? '+' : ''}${goalPace.trendKgPerWeek.toFixed(2)} kg/sem`}</p></div>
          <div><p className="text-xs text-[var(--titan-text-muted)]">Tendência diária</p><p className="mt-1 text-lg font-semibold font-mono-metric">{goalPace.trendKgPerDay === null ? '—' : `${goalPace.trendKgPerDay > 0 ? '+' : ''}${goalPace.trendKgPerDay.toFixed(3)} kg/dia`}</p></div>
          <div><p className="text-xs text-[var(--titan-text-muted)]">Projeção</p><p className="mt-1 text-lg font-semibold font-mono-metric">{goalPace.projectedTargetDateKey ?? '—'}</p></div>
        </div>
        {goalPace.requiredPercentBodyWeightPerWeek !== null && <p className="text-[11px] text-[var(--titan-text-muted)]">Ritmo requerido: {goalPace.requiredPercentBodyWeightPerWeek.toFixed(2)}% do peso atual por semana. Projeção baseada na tendência; não é promessa nem recomendação clínica.</p>}
      </Surface>

      <EvolutionTrendChart records={records} />

      <Surface elevation={0} className="p-4 sm:p-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          <div>
            <p className="text-xs text-[var(--titan-text-muted)]">IMC estimado</p>
            <p className="mt-1 text-xl font-semibold font-mono-metric text-[var(--titan-text-primary)]">{bmi.toFixed(1)}</p>
            <p className="text-[10px] text-[var(--titan-text-muted)]">Indicador de triagem; não mede diretamente massa muscular ou gordura</p>
          </div>
          <div>
            <p className="text-xs text-[var(--titan-text-muted)]">Cintura / altura</p>
            <p className="mt-1 text-xl font-semibold font-mono-metric text-[var(--titan-text-primary)]">{waistToHeightRatio === null ? '—' : waistToHeightRatio.toFixed(3)}</p>
            <p className="text-[10px] text-[var(--titan-text-muted)]">Relação antropométrica de acompanhamento</p>
          </div>
          <div>
            <p className="text-xs text-[var(--titan-text-muted)]">RFM estimado</p>
            <p className="mt-1 text-xl font-semibold font-mono-metric text-[var(--titan-text-primary)]">{relativeFatMass === null ? '—' : `${relativeFatMass.toFixed(1)}%`}</p>
            <p className="text-[10px] text-[var(--titan-text-muted)]">Estimativa por cintura/altura; não é medição direta nem diagnóstico</p>
          </div>
          <div>
            <p className="text-xs text-[var(--titan-text-muted)]">Tendência de peso · 30 dias</p>
            <p className="mt-1 text-xl font-semibold font-mono-metric text-[var(--titan-text-primary)]">
              {weightTrend ? `${weightTrend.changePerWeekKg > 0 ? '+' : ''}${weightTrend.changePerWeekKg.toFixed(2)} kg/sem` : 'Dados insuficientes'}
            </p>
            <p className="text-[10px] text-[var(--titan-text-muted)]">{weightTrend ? `${weightTrend.uniqueDays} dias · Theil–Sen · confiança ${weightTrend.confidence === 'higher' ? 'maior' : weightTrend.confidence === 'moderate' ? 'moderada' : 'baixa'}` : 'Registre ao menos duas medições com datas válidas'}</p>
          </div>
        </div>
      </Surface>

      {/* Observed KPI Strip com comparativo vs anterior e acumulado */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Surface elevation={0} className="p-4">
          <div className="text-xs text-[var(--titan-text-secondary)]">Peso corporal</div>
          <div className="text-2xl font-semibold font-mono-metric text-[var(--titan-text-primary)] mt-1">
            {latest.weightKg.toFixed(1)} kg
          </div>
          <div
            className={`mt-0.5 flex items-center gap-1 text-xs font-semibold font-mono-metric ${
              records.length < 2 || Math.abs(latestWeightDeltaVal) < 0.05
                ? 'text-[var(--titan-text-secondary)]'
                : latestWeightDeltaAligned
                ? 'text-[var(--titan-status-success)]'
                : 'text-[var(--titan-status-error)]'
            }`}
          >
            {records.length >= 2 && (
              latestWeightDeltaVal > 0.04 ? (
                <ArrowUp className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              ) : latestWeightDeltaVal < -0.04 ? (
                <ArrowDown className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              ) : (
                <Minus className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              )
            )}
            <span>
              {records.length >= 2
                ? `${latestWeightDeltaVal > 0 ? `+${weightDelta}` : weightDelta} kg vs anterior`
                : 'Primeira medição'}
            </span>
          </div>
          <div className="text-xs text-[var(--titan-text-muted)] mt-0.5 font-mono-metric">
            Acumulado: {formatSigned(cumulative.weightGainKg, 'kg')}
          </div>
        </Surface>

        <Surface elevation={0} className="p-4">
          <div className="text-xs text-[var(--titan-text-secondary)]">Cintura</div>
          <div className="text-2xl font-semibold font-mono-metric text-[var(--titan-text-primary)] mt-1">
            {Number.isFinite(latestWaistRecord.waistCm) ? `${latestWaistRecord.waistCm!.toFixed(1)} cm` : '—'}
          </div>
          <div className="text-xs text-[var(--titan-text-secondary)] mt-0.5 font-mono-metric">
            {waistDelta === '—'
              ? 'Sem medição anterior'
              : `${Number(waistDelta) > 0 ? `+${waistDelta}` : waistDelta} cm vs anterior`}
          </div>
          {Number.isFinite(latestWaistRecord.waistCm) && <div className="text-[10px] text-[var(--titan-text-muted)]">Última medição: {latestWaistRecord.dateLabel}</div>}
          <div className="text-xs text-[var(--titan-text-muted)] mt-0.5 font-mono-metric">
            Acumulado: {formatSigned(cumulative.waistDiffCm, 'cm')}
          </div>
        </Surface>

        <Surface elevation={0} className="p-4">
          <div className="text-xs text-[var(--titan-text-secondary)]">Braço</div>
          <div className="text-2xl font-semibold font-mono-metric text-[var(--titan-text-primary)] mt-1">
            {Number.isFinite(latestArmRecord.armCm) ? `${latestArmRecord.armCm!.toFixed(1)} cm` : '—'}
          </div>
          <div className="text-xs text-[var(--titan-text-secondary)] mt-0.5 font-mono-metric">
            {armDelta === '—'
              ? 'Sem medição anterior'
              : `${Number(armDelta) > 0 ? `+${armDelta}` : armDelta} cm vs anterior`}
          </div>
          {Number.isFinite(latestArmRecord.armCm) && <div className="text-[10px] text-[var(--titan-text-muted)]">Última medição: {latestArmRecord.dateLabel}</div>}
          <div className="text-xs text-[var(--titan-text-muted)] mt-0.5 font-mono-metric">
            Acumulado: {formatSigned(cumulative.armDiffCm, 'cm')}
          </div>
        </Surface>

        <Surface elevation={0} className="p-4">
          <div className="text-xs text-[var(--titan-text-secondary)]">Coxa</div>
          <div className="text-2xl font-semibold font-mono-metric text-[var(--titan-text-primary)] mt-1">
            {Number.isFinite(latestThighRecord.thighCm) ? `${latestThighRecord.thighCm!.toFixed(1)} cm` : '—'}
          </div>
          <div className="text-xs text-[var(--titan-text-secondary)] mt-0.5 font-mono-metric">
            {thighDelta === '—'
              ? 'Sem medição anterior'
              : `${Number(thighDelta) > 0 ? `+${thighDelta}` : thighDelta} cm vs anterior`}
          </div>
          {Number.isFinite(latestThighRecord.thighCm) && <div className="text-[10px] text-[var(--titan-text-muted)]">Última medição: {latestThighRecord.dateLabel}</div>}
          <div className="text-xs text-[var(--titan-text-muted)] mt-0.5 font-mono-metric">
            Acumulado: {formatSigned(cumulative.thighDiffCm, 'cm')}
          </div>
        </Surface>
      </div>

      </>}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        <MeasurementEntryForm initialWeightKg={records.length > 0 || profileConfigured ? String(latest.weightKg) : ''} />

        <Surface className="p-5 lg:col-span-7 space-y-3">
          <h2 className="text-base font-semibold text-[var(--titan-text-primary)]">Histórico observado</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[var(--titan-border)]/70 text-[var(--titan-text-secondary)]">
                  <th className="py-2 pr-3 font-medium">Data</th>
                  <th className="py-2 pr-3 font-medium">Peso</th>
                  <th className="py-2 pr-3 font-medium">Cintura</th>
                  <th className="py-2 pr-3 font-medium">Braço</th>
                  <th className="py-2 font-medium">Coxa</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--titan-border)]/45 font-mono-metric">
                {reverseChronologicalRecords.map((r) => (
                  <tr key={r.id}>
                    <td className="py-2.5 pr-3 text-[var(--titan-text-secondary)]">{r.dateLabel}</td>
                    <td className="py-2.5 pr-3 text-[var(--titan-text-primary)]">{r.weightKg.toFixed(1)} kg</td>
                    <td className="py-2.5 pr-3 text-[var(--titan-text-primary)]">{Number.isFinite(r.waistCm) ? `${r.waistCm!.toFixed(1)} cm` : '—'}</td>
                    <td className="py-2.5 pr-3 text-[var(--titan-text-primary)]">{Number.isFinite(r.armCm) ? `${r.armCm!.toFixed(1)} cm` : '—'}</td>
                    <td className="py-2.5 text-[var(--titan-text-primary)]">{Number.isFinite(r.thighCm) ? `${r.thighCm!.toFixed(1)} cm` : '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Surface>
      </div>
    </div>
  );
}
