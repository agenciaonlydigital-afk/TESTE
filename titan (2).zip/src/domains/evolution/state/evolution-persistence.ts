import { isValidLocalDateKey, parseLocalDateKey } from '../../../shared/utils/local-date.ts';

export interface PersistedMeasurementRecord {
  id: string;
  dateKey: string;
  dateLabel: string;
  weightKg: number;
  waistCm?: number;
  armCm?: number;
  thighCm?: number;
  chestCm?: number;
  hipCm?: number;
  neckCm?: number;
  forearmCm?: number;
  calfCm?: number;
}

export interface PersistedEvolutionState {
  records: PersistedMeasurementRecord[];
}

const MONTHS = ['JAN', 'FEV', 'MAR', 'ABR', 'MAI', 'JUN', 'JUL', 'AGO', 'SET', 'OUT', 'NOV', 'DEZ'] as const;
const MEASUREMENT_RANGES = {
  weightKg: [30, 300],
  waistCm: [45, 200],
  armCm: [18, 75],
  thighCm: [30, 110],
  chestCm: [55, 180],
  hipCm: [55, 200],
  neckCm: [25, 65],
  forearmCm: [15, 50],
  calfCm: [25, 75],
} as const;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function isFiniteInRange(value: unknown, min: number, max: number): value is number {
  return typeof value === 'number' && Number.isFinite(value) && value >= min && value <= max;
}

function isMeasurementRecord(value: unknown): value is PersistedMeasurementRecord {
  if (!isRecord(value) || typeof value.id !== 'string' || !value.id.trim()) return false;
  if (typeof value.dateKey !== 'string' || !isValidLocalDateKey(value.dateKey)) return false;
  for (const [field, [min, max]] of Object.entries(MEASUREMENT_RANGES)) {
    const measurement = value[field];
    if (measurement !== undefined && !isFiniteInRange(measurement, min, max)) return false;
    if (field === 'weightKg' && measurement === undefined) return false;
  }
  return true;
}

function formatPersistedDateLabel(dateKey: string): string {
  const parts = parseLocalDateKey(dateKey);
  if (!parts) return '';
  const month = MONTHS[parts.month - 1] ?? '???';
  return `${String(parts.day).padStart(2, '0')} ${month}`;
}

export function mergeEvolutionPersistedState(
  persisted: unknown,
  current: PersistedEvolutionState,
): PersistedEvolutionState {
  if (!isRecord(persisted) || !Array.isArray(persisted.records)) return current;
  const ids = new Set<string>();
  const records: PersistedMeasurementRecord[] = [];
  const legacyDemoIds = new Set(['m-1', 'm-2', 'm-3']);
  for (const candidate of persisted.records) {
    if (!isMeasurementRecord(candidate) || ids.has(candidate.id) || legacyDemoIds.has(candidate.id)) continue;
    ids.add(candidate.id);
    records.push({
      id: candidate.id,
      dateKey: candidate.dateKey,
      dateLabel: formatPersistedDateLabel(candidate.dateKey),
      weightKg: candidate.weightKg,
      ...(candidate.waistCm !== undefined ? { waistCm: candidate.waistCm } : {}),
      ...(candidate.armCm !== undefined ? { armCm: candidate.armCm } : {}),
      ...(candidate.thighCm !== undefined ? { thighCm: candidate.thighCm } : {}),
      ...(candidate.chestCm !== undefined ? { chestCm: candidate.chestCm } : {}),
      ...(candidate.hipCm !== undefined ? { hipCm: candidate.hipCm } : {}),
      ...(candidate.neckCm !== undefined ? { neckCm: candidate.neckCm } : {}),
      ...(candidate.forearmCm !== undefined ? { forearmCm: candidate.forearmCm } : {}),
      ...(candidate.calfCm !== undefined ? { calfCm: candidate.calfCm } : {}),
    });
  }
  return { records };
}
