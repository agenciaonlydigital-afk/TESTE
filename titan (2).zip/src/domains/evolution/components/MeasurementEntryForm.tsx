import { memo, useState } from 'react';
import type { FormEvent } from 'react';
import { Button } from '@/src/shared/ui/Button';
import { Surface } from '@/src/shared/ui/Surface';
import { submitObservedMeasurement } from '../application/log-measurement';

interface MeasurementEntryFormProps {
  initialWeightKg: string;
}

/** Isolates high-frequency form edits from the chart and metric dashboard. */
export const MeasurementEntryForm = memo(function MeasurementEntryForm({ initialWeightKg }: MeasurementEntryFormProps) {
  const [weightKg, setWeightKg] = useState(initialWeightKg);
  const [waistCm, setWaistCm] = useState('');
  const [armCm, setArmCm] = useState('');
  const [thighCm, setThighCm] = useState('');
  const [chestCm, setChestCm] = useState('');
  const [hipCm, setHipCm] = useState('');
  const [neckCm, setNeckCm] = useState('');
  const [forearmCm, setForearmCm] = useState('');
  const [calfCm, setCalfCm] = useState('');
  const [feedback, setFeedback] = useState<string | null>(null);

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const result = submitObservedMeasurement({
      weightKg,
      waistCm,
      armCm,
      thighCm,
      chestCm,
      hipCm,
      neckCm,
      forearmCm,
      calfCm,
    });
    if (result.ok) {
      setWaistCm('');
      setArmCm('');
      setThighCm('');
      setChestCm('');
      setHipCm('');
      setNeckCm('');
      setForearmCm('');
      setCalfCm('');
      setFeedback('Pesagem registrada. Medidas corporais foram salvas somente se preenchidas.');
    } else {
      setFeedback(result.error);
    }
  };

  return (
    <Surface className="p-5 lg:col-span-5">
      <h2 className="text-base font-semibold text-[var(--titan-text-primary)]">Registrar peso e medidas</h2>
      <p className="text-xs text-[var(--titan-text-secondary)] mt-0.5">
        O peso pode ser diário. Circunferências são opcionais e podem ser registradas em dias separados.
      </p>

      <form onSubmit={handleSubmit} className="mt-4 space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <label className="block text-xs text-[var(--titan-text-secondary)] mb-1">
            Peso (kg) · obrigatório
            <input
              type="number"
              inputMode="decimal"
              step="0.1"
              required
              value={weightKg}
              onChange={(event) => setWeightKg(event.target.value)}
              className="mt-1 w-full min-h-[44px] px-3 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] focus:border-[var(--titan-accent)] text-sm font-mono-metric text-[var(--titan-text-primary)]"
            />
          </label>
          <label className="block text-xs text-[var(--titan-text-secondary)] mb-1">
            Cintura (cm) · opcional
            <input type="number" inputMode="decimal" step="0.1" value={waistCm} onChange={(event) => setWaistCm(event.target.value)} className="mt-1 w-full min-h-[44px] px-3 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] focus:border-[var(--titan-accent)] text-sm font-mono-metric text-[var(--titan-text-primary)]" />
          </label>
          <label className="block text-xs text-[var(--titan-text-secondary)] mb-1">
            Braço (cm) · opcional
            <input type="number" inputMode="decimal" step="0.1" value={armCm} onChange={(event) => setArmCm(event.target.value)} className="mt-1 w-full min-h-[44px] px-3 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] focus:border-[var(--titan-accent)] text-sm font-mono-metric text-[var(--titan-text-primary)]" />
          </label>
          <label className="block text-xs text-[var(--titan-text-secondary)] mb-1">
            Coxa (cm) · opcional
            <input type="number" inputMode="decimal" step="0.1" value={thighCm} onChange={(event) => setThighCm(event.target.value)} className="mt-1 w-full min-h-[44px] px-3 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] focus:border-[var(--titan-accent)] text-sm font-mono-metric text-[var(--titan-text-primary)]" />
          </label>
        </div>

        <details className="rounded-xl border border-[var(--titan-border)] p-3">
          <summary className="cursor-pointer text-xs font-semibold text-[var(--titan-text-secondary)]">Medidas adicionais (opcional)</summary>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-3">
            {([
              ['Tórax (cm)', chestCm, setChestCm, '95'],
              ['Quadril (cm)', hipCm, setHipCm, '100'],
              ['Pescoço (cm)', neckCm, setNeckCm, '38'],
              ['Antebraço (cm)', forearmCm, setForearmCm, '29'],
              ['Panturrilha (cm)', calfCm, setCalfCm, '38'],
            ] as const).map(([label, value, setter, placeholder]) => (
              <label key={label} className="block text-xs text-[var(--titan-text-secondary)]">
                {label}
                <input
                  type="number"
                  inputMode="decimal"
                  step="0.1"
                  value={value}
                  onChange={(event) => setter(event.target.value)}
                  placeholder={placeholder}
                  className="mt-1 w-full min-h-[44px] px-3 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] text-[var(--titan-text-primary)] font-mono-metric text-sm focus:outline-none focus:border-[var(--titan-accent)]"
                />
              </label>
            ))}
          </div>
        </details>

        <Button type="submit" variant="primary" fullWidth>Salvar medição</Button>
        {feedback && <p className="text-xs text-[var(--titan-text-secondary)]" role="status">{feedback}</p>}
      </form>
    </Surface>
  );
});
