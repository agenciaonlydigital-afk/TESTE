export interface ObservedBodyInsight {
  id: string;
  title: string;
  evidenceSummary: string;
  inferenceBoundaryNote: string;
}
