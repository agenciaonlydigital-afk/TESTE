import { EXERCISE_CATALOG } from '../../exercise-library/data/repositories/exercise-catalog.ts';
import type { MuscleHighlightPayload } from '@/src/shared/types/common';

/**
 * Compatibility lookup derived from the canonical exercise catalog.
 * Copy arrays so consumers cannot mutate the source-of-truth catalog via this map.
 */
export const EXERCISE_MUSCLE_MAP: Record<string, MuscleHighlightPayload> =
  Object.fromEntries(
    EXERCISE_CATALOG.map(({ slug, muscles }) => [
      slug,
      { primary: [...muscles.primary], secondary: [...muscles.secondary] },
    ] as const),
  );
