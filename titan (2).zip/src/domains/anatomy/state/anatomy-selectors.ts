import { MUSCLE_REGISTRY } from '../mapping/muscle-registry';
import { useAnatomyStore } from './anatomy.store';

export function useSelectedMuscleDetail() {
  const selectedId = useAnatomyStore((s) => s.selectedMuscleId);
  return selectedId ? MUSCLE_REGISTRY[selectedId] : null;
}

export function useActiveMuscleSummary() {
  const primary = useAnatomyStore((s) => s.workoutHighlights.primary);
  const secondary = useAnatomyStore((s) => s.workoutHighlights.secondary);
  return {
    primaryLabels: primary.map((id) => MUSCLE_REGISTRY[id].label),
    secondaryLabels: secondary.map((id) => MUSCLE_REGISTRY[id].label),
  };
}
