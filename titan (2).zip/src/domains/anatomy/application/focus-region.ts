import { useAnatomyStore, type FocusRegion } from '../state/anatomy.store';
import type { AnatomicalView } from '../mapping/muscle-registry';

export function focusAnatomicalRegion(region: FocusRegion, view?: AnatomicalView): void {
  const store = useAnatomyStore.getState();
  store.setFocusRegion(region);
  if (view) {
    store.setCameraView(view);
  }
}
