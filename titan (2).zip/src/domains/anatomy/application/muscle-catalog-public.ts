import type { MuscleGroupId } from '@/src/shared/types/common';
import { MUSCLE_REGISTRY, type MuscleDefinition } from '../mapping/muscle-registry.ts';

/** Read-only muscle catalogue contract for sibling domains. */
export function getMuscleDefinition(id: MuscleGroupId): MuscleDefinition {
  return MUSCLE_REGISTRY[id];
}

export function getMuscleLabelFromCatalog(id: MuscleGroupId): string {
  return MUSCLE_REGISTRY[id].label;
}

export { MUSCLE_REGISTRY };
