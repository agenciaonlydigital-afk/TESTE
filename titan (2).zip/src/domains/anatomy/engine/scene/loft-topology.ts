export interface LoftTopology {
  columns: number;
  vertexCount: number;
  uvs: Float32Array;
  indices: Uint16Array | Uint32Array;
  hasClosedCaps: boolean;
}

/**
 * Build the UV and index streams for a lofted surface.
 * Closed surfaces duplicate the U=0/U=1 seam so texture coordinates never wrap
 * across the seam. The caller builds positions and computes normals for the mesh.
 */
export function createLoftTopology(
  rows: number,
  radialSegments: number,
  closed: boolean,
  capEnds: boolean,
): LoftTopology {
  if (!Number.isInteger(rows) || rows < 2) {
    throw new RangeError(`Loft rows must be an integer >= 2; received ${rows}`);
  }
  if (!Number.isInteger(radialSegments) || radialSegments < 3) {
    throw new RangeError(`Loft radialSegments must be an integer >= 3; received ${radialSegments}`);
  }

  const columns = radialSegments + 1;
  const baseVertexCount = rows * columns;
  const hasClosedCaps = closed && capEnds;
  const vertexCount = baseVertexCount + (hasClosedCaps ? 2 : 0);
  const sideIndexCount = (rows - 1) * radialSegments * 6;
  const capIndexCount = hasClosedCaps ? radialSegments * 6 : 0;
  const IndexArray = vertexCount <= 65_535 ? Uint16Array : Uint32Array;
  const indices = new IndexArray(sideIndexCount + capIndexCount);
  const uvs = new Float32Array(vertexCount * 2);

  let uvOffset = 0;
  for (let row = 0; row < rows; row += 1) {
    const v = row / (rows - 1);
    for (let column = 0; column < columns; column += 1) {
      uvs[uvOffset++] = column / radialSegments;
      uvs[uvOffset++] = v;
    }
  }

  let indexOffset = 0;
  for (let row = 0; row < rows - 1; row += 1) {
    for (let column = 0; column < radialSegments; column += 1) {
      const a = row * columns + column;
      const b = a + 1;
      const d = (row + 1) * columns + column;
      const e = d + 1;
      indices[indexOffset++] = a;
      indices[indexOffset++] = d;
      indices[indexOffset++] = b;
      indices[indexOffset++] = b;
      indices[indexOffset++] = d;
      indices[indexOffset++] = e;
    }
  }

  if (hasClosedCaps) {
    const bottomCenter = baseVertexCount;
    const topCenter = baseVertexCount + 1;
    uvs[bottomCenter * 2] = 0.5;
    uvs[bottomCenter * 2 + 1] = 0;
    uvs[topCenter * 2] = 0.5;
    uvs[topCenter * 2 + 1] = 1;

    for (let column = 0; column < radialSegments; column += 1) {
      indices[indexOffset++] = bottomCenter;
      indices[indexOffset++] = column;
      indices[indexOffset++] = column + 1;
    }

    const topRowStart = (rows - 1) * columns;
    for (let column = 0; column < radialSegments; column += 1) {
      indices[indexOffset++] = topCenter;
      indices[indexOffset++] = topRowStart + column + 1;
      indices[indexOffset++] = topRowStart + column;
    }
  }

  if (indexOffset !== indices.length || uvOffset !== baseVertexCount * 2) {
    throw new Error('Loft topology buffer length mismatch');
  }

  return { columns, vertexCount, uvs, indices, hasClosedCaps };
}


/** Write the two cap-center vertices in the same order used by the cap indices. */
export function writeLoftCapPositions(
  positions: Float32Array,
  offset: number,
  firstCenter: readonly [number, number, number],
  lastCenter: readonly [number, number, number],
  hasClosedCaps: boolean,
): number {
  if (!hasClosedCaps) return offset;
  if (!Number.isInteger(offset) || offset < 0 || offset + 6 > positions.length) {
    throw new RangeError('Loft cap position buffer is too small');
  }
  positions.set(firstCenter, offset);
  positions.set(lastCenter, offset + 3);
  return offset + 6;
}


/** Average the two normals at each duplicated closed-surface seam vertex. */
export function averageClosedLoftSeamNormals(
  normals: Float32Array,
  rows: number,
  radialSegments: number,
): void {
  if (!Number.isInteger(rows) || rows < 2) {
    throw new RangeError(`Loft rows must be an integer >= 2; received ${rows}`);
  }
  if (!Number.isInteger(radialSegments) || radialSegments < 3) {
    throw new RangeError(`Loft radialSegments must be an integer >= 3; received ${radialSegments}`);
  }
  const columns = radialSegments + 1;
  const required = rows * columns * 3;
  if (normals.length < required) {
    throw new RangeError(`Loft normal buffer is too small; expected at least ${required} values`);
  }

  for (let row = 0; row < rows; row += 1) {
    const start = row * columns * 3;
    const end = (row * columns + radialSegments) * 3;
    let nx = normals[start]! + normals[end]!;
    let ny = normals[start + 1]! + normals[end + 1]!;
    let nz = normals[start + 2]! + normals[end + 2]!;
    const length = Math.hypot(nx, ny, nz);
    if (length > 1e-12) {
      nx /= length;
      ny /= length;
      nz /= length;
    } else {
      nx = 0;
      ny = 1;
      nz = 0;
    }
    normals.set([nx, ny, nz], start);
    normals.set([nx, ny, nz], end);
  }
}
