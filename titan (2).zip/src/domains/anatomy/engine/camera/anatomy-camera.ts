import * as THREE from 'three';
import type { AnatomicalView } from '../../mapping/muscle-registry';
import type { FocusRegion } from '../../state/anatomy.store';

export interface CameraPreset {
  position: THREE.Vector3;
  target: THREE.Vector3;
}

const REGION_Y: Record<FocusRegion, { y: number; dist: number; pitchY: number }> = {
  full: { y: 0.82, dist: 3.66, pitchY: 0.50 },
  upper: { y: 1.30, dist: 1.98, pitchY: 0.14 },
  core: { y: 1.05, dist: 1.78, pitchY: 0.12 },
  lower: { y: 0.48, dist: 2.08, pitchY: 0.24 },
};

export function getAnatomyCameraPreset(
  view: AnatomicalView,
  region: FocusRegion,
  zoomScale = 1,
): CameraPreset {
  const { y, dist, pitchY } = REGION_Y[region];
  const clampedZoom = Math.min(1.65, Math.max(0.75, zoomScale));
  const scaledDist = Math.min(4.2, Math.max(1.35, dist / clampedZoom));

  if (view === 'posterior') {
    return {
      position: new THREE.Vector3(0, y + pitchY, -scaledDist),
      target: new THREE.Vector3(0, y, 0),
    };
  }

  if (view === 'lateral') {
    return {
      position: new THREE.Vector3(scaledDist * 0.96, y + pitchY, scaledDist * 0.28),
      target: new THREE.Vector3(0, y, 0),
    };
  }

  return {
    position: new THREE.Vector3(0, y + pitchY, scaledDist),
    target: new THREE.Vector3(0, y, 0),
  };
}
