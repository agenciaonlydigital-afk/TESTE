/** Generate a tangent-space, longitudinal muscle-fiber normal map without external assets. */
export function createMuscleFiberNormalPixels(size = 256): Uint8Array {
  if (!Number.isInteger(size) || size < 16 || (size & (size - 1)) !== 0) {
    throw new RangeError(`Normal-map size must be a power of two >= 16; received ${size}`);
  }

  const hash2 = (ix: number, iy: number, period: number, seed: number): number => {
    const wx = ((ix % period) + period) % period;
    const wy = ((iy % period) + period) % period;
    let h = (wx * 374761393 + wy * 668265263 + seed * 1442695041) | 0;
    h = (h ^ (h >>> 13)) * 1274126177;
    h = h ^ (h >>> 16);
    return (h >>> 0) / 4294967295;
  };
  const periodicNoise = (u: number, v: number, freq: number, seed: number): number => {
    const sx = u * freq;
    const sy = v * freq;
    const x0 = Math.floor(sx);
    const y0 = Math.floor(sy);
    const fx = sx - x0;
    const fy = sy - y0;
    const ux = fx * fx * (3 - 2 * fx);
    const uy = fy * fy * (3 - 2 * fy);
    const n00 = hash2(x0, y0, freq, seed);
    const n10 = hash2(x0 + 1, y0, freq, seed);
    const n01 = hash2(x0, y0 + 1, freq, seed);
    const n11 = hash2(x0 + 1, y0 + 1, freq, seed);
    return (n00 + (n10 - n00) * ux) * (1 - uy) + (n01 + (n11 - n01) * ux) * uy;
  };

  const heights = new Float32Array(size * size);
  const data = new Uint8Array(size * size * 4);
  const tau = Math.PI * 2;
  const heightAt = (u: number, v: number): number => {
    const organicNoise = periodicNoise(u, v, 16, 41) - 0.5;
    const microSheath = periodicNoise(u, v, 48, 97) - 0.5;
    const warp =
      0.036 * Math.sin(tau * v * 3) +
      0.013 * Math.sin(tau * (u * 6 + v * 5)) +
      0.008 * organicNoise;
    // Rounded fascicle bundles separated by recessed perimysium septa
    const perimysiumWave = Math.sin(tau * (u * 10 + warp * 0.72));
    const perimysium = (Math.abs(perimysiumWave) * 0.85 - 0.42) * 1.1;
    const fascicle = Math.sin(tau * (u * 20 + warp));
    const fibril = Math.sin(tau * (u * 32 + warp * 1.25)) * 0.34;
    const sarcomere = Math.sin(tau * (v * 28 + Math.sin(tau * u * 10) * 0.14)) * 0.25;
    const belly = Math.sin(tau * (u * 11 + v * 3)) * 0.24;
    const fiberBellyFalloff = 0.8 + 0.2 * Math.sin(Math.PI * v);
    return (
      fiberBellyFalloff *
      (0.021 * fascicle +
        0.01 * fibril +
        0.015 * perimysium +
        0.01 * sarcomere +
        0.011 * belly +
        0.005 * microSheath)
    );
  };

  for (let y = 0; y < size; y += 1) {
    const v = y / size;
    for (let x = 0; x < size; x += 1) heights[y * size + x] = heightAt(x / size, v);
  }

  const strength = 0.044;
  for (let y = 0; y < size; y += 1) {
    const y0 = (y - 1 + size) % size;
    const y1 = (y + 1) % size;
    for (let x = 0; x < size; x += 1) {
      const x0 = (x - 1 + size) % size;
      const x1 = (x + 1) % size;
      const dx = (heights[y * size + x1]! - heights[y * size + x0]!) * size * 0.5;
      const dy = (heights[y1 * size + x]! - heights[y0 * size + x]!) * size * 0.5;
      let nx = -dx * strength;
      let ny = -dy * strength;
      let nz = 1;
      const length = Math.hypot(nx, ny, nz) || 1;
      nx /= length;
      ny /= length;
      nz /= length;
      const offset = (y * size + x) * 4;
      data[offset] = Math.round((nx * 0.5 + 0.5) * 255);
      data[offset + 1] = Math.round((ny * 0.5 + 0.5) * 255);
      data[offset + 2] = Math.round((nz * 0.5 + 0.5) * 255);
      data[offset + 3] = 255;
    }
  }
  return data;
}
