/**
 * Periodic UV-space multi-Gaussian prefilter for skin albedo.
 *
 * This produces a low-frequency scattering albedo texture once during material setup.
 * It is paired with the shader's thickness/back-lighting term; it is not a full
 * diffusion-profile convolution of incident illumination or path-traced SSS.
 */
export interface SkinScatteringChannelProfile {
  wideSigma: number;
  narrowSigma: number;
  wideWeight: number;
}

export interface SkinScatteringProfile {
  red: SkinScatteringChannelProfile;
  green: SkinScatteringChannelProfile;
  blue: SkinScatteringChannelProfile;
}

export const DEFAULT_SKIN_SCATTERING_PROFILE: Readonly<SkinScatteringProfile> = Object.freeze({
  red: Object.freeze({ wideSigma: 4.8, narrowSigma: 1.55, wideWeight: 0.64 }),
  green: Object.freeze({ wideSigma: 3.25, narrowSigma: 1.15, wideWeight: 0.54 }),
  blue: Object.freeze({ wideSigma: 2.05, narrowSigma: 0.78, wideWeight: 0.42 }),
});

function wrap(value: number, size: number): number {
  return ((value % size) + size) % size;
}

function buildKernel(profile: SkinScatteringChannelProfile): Float32Array {
  const wideSigma = Math.max(0.05, Math.min(32, profile.wideSigma));
  const narrowSigma = Math.max(0.05, Math.min(wideSigma, profile.narrowSigma));
  const wideWeight = Math.max(0, Math.min(1, profile.wideWeight));
  const radius = Math.max(1, Math.ceil(wideSigma * 3));
  const kernel = new Float32Array(radius * 2 + 1);
  let sum = 0;
  for (let offset = -radius; offset <= radius; offset += 1) {
    const d2 = offset * offset;
    const wide = Math.exp(-0.5 * d2 / (wideSigma * wideSigma)) / wideSigma;
    const narrow = Math.exp(-0.5 * d2 / (narrowSigma * narrowSigma)) / narrowSigma;
    const weight = wideWeight * wide + (1 - wideWeight) * narrow;
    kernel[offset + radius] = weight;
    sum += weight;
  }
  if (sum <= 0 || !Number.isFinite(sum)) throw new Error('Invalid skin scattering Gaussian kernel');
  for (let i = 0; i < kernel.length; i += 1) kernel[i] = (kernel[i] ?? 0) / sum;
  return kernel;
}

function srgbByteToLinear(value: number): number {
  const s = Math.max(0, Math.min(255, value)) / 255;
  return s <= 0.04045 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
}

function linearToSrgbByte(value: number): number {
  const linear = Math.max(0, Math.min(1, value));
  const srgb = linear <= 0.0031308 ? linear * 12.92 : 1.055 * Math.pow(linear, 1 / 2.4) - 0.055;
  return Math.max(0, Math.min(255, Math.round(srgb * 255)));
}

function blurChannelPeriodic(
  input: Uint8Array,
  size: number,
  channel: number,
  kernel: Float32Array,
): Float32Array {
  const radius = (kernel.length - 1) >> 1;
  const horizontal = new Float32Array(size * size);
  const output = new Float32Array(size * size);

  for (let y = 0; y < size; y += 1) {
    const row = y * size;
    for (let x = 0; x < size; x += 1) {
      let sum = 0;
      for (let k = -radius; k <= radius; k += 1) {
        const source = (row + wrap(x + k, size)) * 4 + channel;
        sum += srgbByteToLinear(input[source] ?? 0) * (kernel[k + radius] ?? 0);
      }
      horizontal[row + x] = sum;
    }
  }

  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      let sum = 0;
      for (let k = -radius; k <= radius; k += 1) {
        const source = wrap(y + k, size) * size + x;
        sum += (horizontal[source] ?? 0) * (kernel[k + radius] ?? 0);
      }
      output[y * size + x] = sum;
    }
  }
  return output;
}


export function downsampleRgbaForScattering(input: Uint8Array, sourceSize: number, targetSize: number): Uint8Array {
  if (!Number.isInteger(sourceSize) || !Number.isInteger(targetSize) || targetSize < 4 || sourceSize < targetSize || input.length !== sourceSize * sourceSize * 4 || sourceSize % targetSize !== 0) {
    throw new RangeError('Scattering downsample requires divisible square RGBA dimensions');
  }
  if (sourceSize === targetSize) return input.slice();
  const ratio = sourceSize / targetSize;
  const samples = ratio * ratio;
  const output = new Uint8Array(targetSize * targetSize * 4);
  for (let y = 0; y < targetSize; y += 1) {
    for (let x = 0; x < targetSize; x += 1) {
      let red = 0, green = 0, blue = 0, alpha = 0;
      for (let sy = 0; sy < ratio; sy += 1) {
        for (let sx = 0; sx < ratio; sx += 1) {
          const index = (((y * ratio + sy) * sourceSize) + x * ratio + sx) * 4;
          red += srgbByteToLinear(input[index] ?? 0);
          green += srgbByteToLinear(input[index + 1] ?? 0);
          blue += srgbByteToLinear(input[index + 2] ?? 0);
          alpha += input[index + 3] ?? 255;
        }
      }
      const target = (y * targetSize + x) * 4;
      output[target] = linearToSrgbByte(red / samples);
      output[target + 1] = linearToSrgbByte(green / samples);
      output[target + 2] = linearToSrgbByte(blue / samples);
      output[target + 3] = Math.max(0, Math.min(255, Math.round(alpha / samples)));
    }
  }
  return output;
}

export function scaleSkinScatteringProfile(profile: SkinScatteringProfile, scale: number): SkinScatteringProfile {
  const safeScale = Math.max(0.05, Math.min(1, Number.isFinite(scale) ? scale : 1));
  const scaleChannel = (channel: SkinScatteringChannelProfile): SkinScatteringChannelProfile => ({
    wideSigma: Math.max(0.35, channel.wideSigma * safeScale),
    narrowSigma: Math.max(0.25, channel.narrowSigma * safeScale),
    wideWeight: channel.wideWeight,
  });
  return { red: scaleChannel(profile.red), green: scaleChannel(profile.green), blue: scaleChannel(profile.blue) };
}

export function buildMultiGaussianScatteringPixels(
  albedo: Uint8Array,
  size: number,
  profile: SkinScatteringProfile = DEFAULT_SKIN_SCATTERING_PROFILE,
): Uint8Array {
  if (!Number.isInteger(size) || size < 4 || size > 8192 || albedo.length !== size * size * 4) {
    throw new RangeError('Skin scattering input must be an RGBA image whose dimensions match size');
  }

  const channels = [profile.red, profile.green, profile.blue];
  const output = new Uint8Array(albedo.length);
  for (let channel = 0; channel < 3; channel += 1) {
    const kernel = buildKernel(channels[channel]!);
    const blurred = blurChannelPeriodic(albedo, size, channel, kernel);
    for (let pixel = 0; pixel < size * size; pixel += 1) {
      output[pixel * 4 + channel] = linearToSrgbByte(blurred[pixel] ?? 0);
    }
  }
  for (let pixel = 0; pixel < size * size; pixel += 1) output[pixel * 4 + 3] = albedo[pixel * 4 + 3] ?? 255;
  return output;
}
