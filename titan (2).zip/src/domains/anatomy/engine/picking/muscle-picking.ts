import * as THREE from 'three';
import type { MuscleGroupId, MuscleSide } from '@/src/shared/types/common';
import { MUSCLE_SHADER_INDEX_TO_ID } from '../../mapping/anatomy-identifiers';
import { isOccludedByBodySurface } from './picking-occlusion';

export interface PickedMuscleHit {
  muscleId: MuscleGroupId;
  side: MuscleSide;
}

export class MusclePicker {
  private readonly raycaster = new THREE.Raycaster();
  private readonly pointer = new THREE.Vector2();

  constructor() {
    this.raycaster.layers.set(1);
  }

  pick(
    clientX: number,
    clientY: number,
    canvas: HTMLCanvasElement,
    camera: THREE.Camera,
    targets: THREE.Object3D[],
    occlusionTargets: THREE.Object3D[] = [],
  ): PickedMuscleHit | null {
    const rect = canvas.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return null;

    this.pointer.x = ((clientX - rect.left) / rect.width) * 2 - 1;
    this.pointer.y = -((clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.pointer, camera);
    // Muscle patches are a separate render batch. Check the visible body shell as
    // an occluder so a ray cannot select a posterior patch through the torso.
    this.raycaster.layers.enable(0);
    const occluders = occlusionTargets.filter((target) => {
      let ancestor: THREE.Object3D | null = target;
      while (ancestor) {
        if (!ancestor.visible) return false;
        ancestor = ancestor.parent;
      }
      return true;
    });
    const firstOccluder = this.raycaster.intersectObjects(occluders, false)[0];
    // A small tolerance allows the deliberately raised muscle relief to remain
    // selectable while rejecting surfaces genuinely behind the body shell.
    const occlusionDistance = firstOccluder?.distance ?? Number.POSITIVE_INFINITY;
    // A hidden anatomical layer must not remain tappable through the visible layer.
    const visibleTargets = targets.filter((target) => {
      let ancestor: THREE.Object3D | null = target;
      while (ancestor) {
        if (!ancestor.visible) return false;
        ancestor = ancestor.parent;
      }
      return true;
    });
    const hits = this.raycaster.intersectObjects(visibleTargets, false);
    const firstHit = hits[0];
    if (!firstHit || !(firstHit.object instanceof THREE.Mesh) || !firstHit.face) return null;
    if (isOccludedByBodySurface(occlusionDistance, firstHit.distance)) return null;

    // All selectable groups are merged into one surface. Each triangle retains
    // its stable group ID and anatomical side in per-vertex attributes.
    const geometry = firstHit.object.geometry;
    const idAttribute = geometry.getAttribute('aMuscleId');
    const sideAttribute = geometry.getAttribute('aMuscleSide');
    if (!idAttribute || !sideAttribute) return null;

    let resolvedVertex = firstHit.face.a;
    let numericId = Math.round(idAttribute.getX(resolvedVertex));
    if (!numericId) {
      for (const candidate of [firstHit.face.b, firstHit.face.c]) {
        const candidateId = Math.round(idAttribute.getX(candidate));
        if (candidateId > 0) {
          resolvedVertex = candidate;
          numericId = candidateId;
          break;
        }
      }
    }
    const muscleId = MUSCLE_SHADER_INDEX_TO_ID[numericId] as MuscleGroupId | undefined;
    if (!muscleId) return null;

    const numericSide = Math.round(sideAttribute.getX(resolvedVertex));
    const side: MuscleSide = numericSide > 0 ? 'left' : numericSide < 0 ? 'right' : 'center';
    return { muscleId, side };
  }
}
