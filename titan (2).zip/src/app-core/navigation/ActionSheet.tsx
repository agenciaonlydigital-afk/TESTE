import { Droplets, Dumbbell, BookOpen, Ruler, Download, Upload } from 'lucide-react';
import { useRef, useState } from 'react';
import { toast } from 'sonner';
import { BottomSheet } from '@/src/shared/ui/BottomSheet';
import { useHydrationStore } from '@/src/domains/hydration/state/hydration.store';
import { useNutritionStore } from '@/src/domains/nutrition/state/nutrition.store';
import { startWorkoutSession } from '@/src/domains/training/application/start-workout';
import { useTrainingSessionStore } from '@/src/domains/training/state/training-session.store';
import { useNavigationStore } from './navigation.store';
import { safeStorageAdapter } from '@/src/infrastructure/storage/local-storage';
import { createTitanBackup, parseTitanBackup, restoreTitanBackup, type TitanBackupEnvelope } from '../backup/titan-backup';
import { getLocalDateKey } from '@/src/shared/utils/local-date';

export function ActionSheet() {
  const open = useNavigationStore((s) => s.actionSheetOpen);
  const setActionSheetOpen = useNavigationStore((s) => s.setActionSheetOpen);
  const openSubView = useNavigationStore((s) => s.openSubView);
  const setTab = useNavigationStore((s) => s.setTab);
  const logWater = useHydrationStore((s) => s.logWater);
  const activeDateKey = useNutritionStore((s) => s.activeDateKey);
  const activePlanId = useTrainingSessionStore((s) => s.activePlanId);
  const backupInputRef = useRef<HTMLInputElement>(null);
  const [backupFeedback, setBackupFeedback] = useState<string | null>(null);
  const [pendingBackup, setPendingBackup] = useState<{ fileName: string; envelope: TitanBackupEnvelope } | null>(null);

  const close = () => {
    setPendingBackup(null);
    setActionSheetOpen(false);
  };

  const exportBackup = () => {
    try {
      const backup = createTitanBackup(safeStorageAdapter);
      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `titan-backup-${getLocalDateKey()}.json`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1_000);
      setBackupFeedback('Backup exportado. Guarde o arquivo fora deste dispositivo.');
      toast.success('Backup JSON exportado');
    } catch (error) {
      setBackupFeedback(error instanceof Error ? error.message : 'Falha ao exportar backup.');
      toast.error('Falha ao exportar backup');
    }
  };

  const importBackup = async (file: File) => {
    // The storage adapter intentionally falls back to memory when localStorage is blocked.
    // A restore must not report durable success in that mode, because the next reload would lose it.
    try {
      const probeKey = `titan:backup-probe:${Date.now()}`;
      window.localStorage.setItem(probeKey, '1');
      window.localStorage.removeItem(probeKey);
    } catch {
      setPendingBackup(null);
      setBackupFeedback('Este navegador não permite armazenamento local persistente. A restauração foi cancelada para evitar perda dos dados após atualizar a página.');
      return;
    }
    const parsed = parseTitanBackup(await file.text());
    if (!parsed.ok) {
      setPendingBackup(null);
      setBackupFeedback(parsed.error);
      return;
    }
    setBackupFeedback(null);
    setPendingBackup({ fileName: file.name, envelope: parsed.value });
  };

  const confirmRestoreBackup = () => {
    if (!pendingBackup) return;
    const restored = restoreTitanBackup(pendingBackup.envelope, safeStorageAdapter);
    if (!restored.ok) {
      setPendingBackup(null);
      setBackupFeedback(restored.error);
      return;
    }
    setPendingBackup(null);
    setBackupFeedback('Backup restaurado. Atualizando os dados…');
    window.location.reload();
  };

  const primaryActions = [
    {
      id: 'water',
      icon: Droplets,
      title: '+250 ml Água',
      subtitle: 'Registro rápido',
      accentClass: 'text-[#38D9D2]',
      onClick: () => {
        logWater(250, activeDateKey);
        toast.success('+250 ml adicionados à hidratação');
        close();
      },
    },
    {
      id: 'workout',
      icon: Dumbbell,
      title: 'Treinar agora',
      subtitle: 'Sessão e descanso',
      accentClass: 'text-[var(--titan-accent)]',
      onClick: () => {
        startWorkoutSession(activePlanId);
        setTab('treino');
        openSubView('active-workout');
      },
    },
    {
      id: 'library',
      icon: BookOpen,
      title: 'Biblioteca 3D',
      subtitle: 'Movimentos e alvos',
      accentClass: 'text-[var(--titan-champagne)]',
      onClick: () => {
        setTab('treino');
        openSubView('exercise-library');
      },
    },
    {
      id: 'evolution',
      icon: Ruler,
      title: 'Nova medição',
      subtitle: 'Peso e medidas',
      accentClass: 'text-[var(--titan-info)]',
      onClick: () => {
        setTab('evolucao');
        close();
      },
    },
  ];

  return (
    <BottomSheet
      open={open}
      onClose={close}
      eyebrow="Comando rápido"
      title="Ação rápida"
      subtitle="Atalhos contextuais e portabilidade local"
    >
      <div className="space-y-4">
        <input
          ref={backupInputRef}
          type="file"
          accept="application/json,.json"
          className="hidden"
          onChange={(event) => {
            const file = event.currentTarget.files?.[0];
            if (file) void importBackup(file).catch(() => setBackupFeedback('Não foi possível ler o arquivo de backup.'));
            event.currentTarget.value = '';
          }}
        />

        <div className="grid grid-cols-2 gap-2.5">
          {primaryActions.map((action) => {
            const Icon = action.icon;
            return (
              <button
                key={action.id}
                type="button"
                onClick={action.onClick}
                className="titan-luxury-tile min-h-[88px] p-3.5 flex flex-col justify-between text-left"
              >
                <div className="w-9 h-9 rounded-xl bg-[#0A0E0C] border border-[rgba(193,204,196,0.12)] flex items-center justify-center">
                  <Icon className={`w-4 h-4 ${action.accentClass}`} />
                </div>
                <div className="mt-2.5 min-w-0">
                  <div className="text-sm font-semibold text-[var(--titan-text-primary)] truncate">
                    {action.title}
                  </div>
                  <div className="text-[11px] text-[var(--titan-text-muted)] truncate mt-0.5">
                    {action.subtitle}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Portabilidade Local */}
        <div className="space-y-2">
          <span className="titan-eyebrow block px-0.5">Portabilidade local</span>
          <div className="titan-luxury-group grid grid-cols-2 divide-x divide-[rgba(193,204,196,0.10)]">
            <button
              type="button"
              onClick={exportBackup}
              className="min-h-[54px] px-3.5 py-2.5 flex items-center gap-2.5 text-left hover:bg-[rgba(241,240,232,0.03)] transition-colors"
            >
              <Download className="w-4 h-4 text-[var(--titan-champagne)] shrink-0" />
              <div className="min-w-0">
                <div className="text-xs font-semibold text-[var(--titan-text-primary)] truncate">Exportar JSON</div>
                <div className="text-[10px] text-[var(--titan-text-muted)] truncate">Salvar dados</div>
              </div>
            </button>
            <button
              type="button"
              onClick={() => backupInputRef.current?.click()}
              className="min-h-[54px] px-3.5 py-2.5 flex items-center gap-2.5 text-left hover:bg-[rgba(241,240,232,0.03)] transition-colors"
            >
              <Upload className="w-4 h-4 text-[var(--titan-text-secondary)] shrink-0" />
              <div className="min-w-0">
                <div className="text-xs font-semibold text-[var(--titan-text-primary)] truncate">Restaurar JSON</div>
                <div className="text-[10px] text-[var(--titan-text-muted)] truncate">Substituir local</div>
              </div>
            </button>
          </div>
        </div>

        {pendingBackup && (
          <div
            role="alertdialog"
            aria-label="Confirmar restauração de backup"
            className="rounded-2xl border border-[var(--titan-status-warning)]/45 bg-[var(--titan-bg-canvas)] p-3.5 space-y-2.5"
          >
            <p className="text-xs leading-relaxed text-[var(--titan-text-primary)]">
              Restaurar <strong>{pendingBackup.fileName}</strong> substituirá os registros TITAN salvos neste navegador. Continuar?
            </p>
            <div className="flex flex-wrap gap-2 justify-end">
              <button
                type="button"
                onClick={() => {
                  setPendingBackup(null);
                  setBackupFeedback('Restauração cancelada.');
                }}
                className="min-h-[40px] px-3 rounded-xl border border-[var(--titan-border)] text-xs font-medium text-[var(--titan-text-secondary)]"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={confirmRestoreBackup}
                className="min-h-[40px] px-3.5 rounded-xl bg-[var(--titan-accent)] text-xs font-semibold text-[var(--titan-bg-canvas)]"
              >
                Confirmar restauração
              </button>
            </div>
          </div>
        )}
        {backupFeedback && <p className="px-1 pt-0.5 text-xs text-[var(--titan-text-secondary)]" role="status">{backupFeedback}</p>}
        <p className="px-1 text-[10px] text-[var(--titan-text-muted)]">Armazenamento local e privado no dispositivo.</p>
      </div>
    </BottomSheet>
  );
}
