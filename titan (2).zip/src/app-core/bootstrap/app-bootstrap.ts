import { reportError } from '@/src/infrastructure/monitoring/error-reporter';

let bootstrapped = false;

export function bootstrapApplication(): void {
  if (bootstrapped) return;
  bootstrapped = true;

  if (typeof window !== 'undefined') {
    window.addEventListener('error', (event) => {
      reportError(event.error ?? event.message, { source: 'bootstrap' });
    });
    window.addEventListener('unhandledrejection', (event) => {
      reportError(event.reason, { source: 'bootstrap' });
    });
  }
}
