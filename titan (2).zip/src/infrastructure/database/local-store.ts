export interface LocalCollection<T> {
  readAll: () => T[];
  replaceAll: (items: T[]) => void;
}

export function createMemoryCollection<T>(seed: T[]): LocalCollection<T> {
  let items = [...seed];
  return {
    readAll: () => [...items],
    replaceAll: (next) => {
      items = [...next];
    },
  };
}
