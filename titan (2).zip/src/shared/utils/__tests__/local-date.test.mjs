import assert from 'node:assert/strict';
import {
  buildRecentLocalDayDescriptors,
  formatLocalDateLabel,
  getLocalDateKey,
  isValidLocalDateKey,
  shiftLocalDateKey,
} from '../local-date.ts';

assert.equal(getLocalDateKey(new Date(2026, 10, 23, 9, 30)), '2026-11-23');
assert.equal(shiftLocalDateKey('2024-02-28', 1), '2024-02-29');
assert.equal(shiftLocalDateKey('2024-02-29', 1), '2024-03-01');
assert.equal(shiftLocalDateKey('2026-12-31', 1), '2027-01-01');
assert.equal(shiftLocalDateKey('2026-01-01', -1), '2025-12-31');
assert.equal(isValidLocalDateKey('2024-02-29'), true);
assert.equal(isValidLocalDateKey('2025-02-29'), false);
assert.equal(isValidLocalDateKey('2026-13-01'), false);
assert.equal(isValidLocalDateKey('2026-11-31'), false);
assert.equal(isValidLocalDateKey('21/11/2026'), false);
assert.deepEqual(formatLocalDateLabel('2026-11-23'), {
  shortLabel: 'Seg · 23',
  fullLabel: 'Segunda, 23 nov',
});
assert.deepEqual(
  buildRecentLocalDayDescriptors(new Date(2026, 10, 23, 12), 3).map((day) => day.key),
  ['2026-11-21', '2026-11-22', '2026-11-23'],
);
console.log('Local date tests passed.');
