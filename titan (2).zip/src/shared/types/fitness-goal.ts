/** Goal vocabulary shared by profile targets and evolution interpretation. */
export type FitnessGoalType = 'gain_muscle' | 'lose_weight' | 'recomposition' | 'maintain';
