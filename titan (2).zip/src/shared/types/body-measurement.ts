/**
 * Shared, observed body-measurement contract. It is intentionally independent
 * of Zustand and persistence so domain rules and UI components do not import
 * their data shape from a store implementation.
 */
export interface BodyMeasurementRecord {
  id: string;
  dateKey: string;
  dateLabel: string;
  weightKg: number;
  waistCm?: number;
  armCm?: number;
  thighCm?: number;
  chestCm?: number;
  hipCm?: number;
  neckCm?: number;
  forearmCm?: number;
  calfCm?: number;
}
