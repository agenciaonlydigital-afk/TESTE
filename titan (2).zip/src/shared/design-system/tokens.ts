/**
 * TITAN design tokens — Obsidian / Mineral / Champagne.
 *
 * Keep semantic UI colors separate from the anatomy renderer palette.
 * GPU shader colors live with the renderer because they have a different
 * material/color-management contract.
 */
export const colorTokens = {
  canvas: '#0E1412',
  surface: '#171E1B',
  surfaceRaised: '#202925',
  surfaceElevated: '#29332D',
  surfaceInset: '#0A100E',
  border: '#39463F',
  borderSubtle: 'rgba(193, 204, 196, 0.12)',
  borderStrong: 'rgba(193, 204, 196, 0.22)',

  ceramic: '#F1F0E8',
  mist: '#B7C1BA',
  muted: '#9DA9A1',
  disabled: '#6F7B73',
  onAccent: '#0E1412',

  sage: '#A0B7A8',
  sageDeep: '#30493E',
  sageLight: '#C6D4C9',
  champagne: '#C8AD7A',
  champagneLight: '#E0CEA5',
  mineralBlue: '#91AFBE',
  copper: '#B89579',

  success: '#8FB69F',
  warning: '#C8AD7A',
  error: '#D28F87',
  info: '#91AFBE',

  macroProtein: '#A0B7A8',
  macroCarbs: '#91AFBE',
  macroFat: '#B89579',
  macroEnergy: '#F1F0E8',
  hydrationWater: '#91AFBE',
  waterDeep: '#0A171B',
  waterMid: '#18303A',
  waterLight: '#B7D2DC',
  waterEdge: '#86B6C8',

  track: '#0A100E',
  focus: '#C8AD7A',

  // Dedicated 3D palette; do not reuse these values for 2D UI.
  holoShellCore: '#172923',
  holoShellRim: '#8FAF9D',
  holoResting: '#355346',
  holoPrimary: '#7FAE93',
  holoSecondary: '#819EAA',
  holoSelected: '#C8AD7A',
  holoSkeleton: '#667E70',
} as const;

export const typographyTokens = {
  display: '"Plus Jakarta Sans", -apple-system, BlinkMacSystemFont, sans-serif',
  body: '"DM Sans", -apple-system, BlinkMacSystemFont, sans-serif',
  mono: '"JetBrains Mono", ui-monospace, SFMono-Regular, monospace',
} as const;

export const typographyScale = {
  micro: '11px',
  caption: '12px',
  bodySmall: '13px',
  body: '14px',
  bodyLarge: '16px',
  titleSmall: '18px',
  title: '22px',
  displaySmall: '28px',
  display: '36px',
} as const;

export const spacingTokens = {
  xxs: 2,
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  '2xl': 32,
  '3xl': 40,
  '4xl': 48,
} as const;

export const radiusTokens = {
  xs: '6px',
  sm: '10px',
  md: '14px',
  lg: '18px',
  xl: '22px',
  sheet: '26px',
  pill: '999px',
} as const;

export const elevationTokens = {
  flat: '0 0 0 transparent',
  resting: '0 8px 24px rgba(0, 0, 0, 0.18)',
  raised: '0 16px 34px rgba(0, 0, 0, 0.24)',
  floating: '0 24px 56px rgba(0, 0, 0, 0.34)',
  inset: 'inset 0 1px 0 rgba(241, 240, 232, 0.045)',
} as const;

export const motionTokens = {
  pressMs: 100,
  fastMs: 140,
  standardMs: 190,
  enterMs: 240,
  maxUiMs: 300,
  hydrationMs: 420,
  cameraMs: 380,
  cameraDamp: 6.8,
  easing: 'cubic-bezier(0.2, 0.72, 0.2, 1)',
  easingEnter: 'cubic-bezier(0.16, 1, 0.3, 1)',
} as const;

export const componentTokens = {
  cardRadius: radiusTokens.xl,
  sheetRadius: radiusTokens.sheet,
  touchMin: 44,
  inputMin: 16,
  contentMax: 1440,
  mobileNavHeight: 68,
  anatomyStageMobile: 370,
  anatomyStageDesktop: 520,
} as const;

export const designSystemTokens = {
  color: colorTokens,
  typography: typographyTokens,
  typographyScale,
  spacing: spacingTokens,
  radius: radiusTokens,
  elevation: elevationTokens,
  motion: motionTokens,
  component: componentTokens,
} as const;
