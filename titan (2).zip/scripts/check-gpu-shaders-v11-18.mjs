import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { execFileSync } from 'node:child_process';

const fluid = readFileSync(new URL('../src/shared/graphics/fluid-shader-engine.ts', import.meta.url), 'utf8');
const compositor = readFileSync(new URL('../src/domains/anatomy/engine/renderer/dual-body-compositor.ts', import.meta.url), 'utf8');
const constants = new Map([...fluid.matchAll(/const\s+([A-Z0-9_]+)\s*=\s*`([\s\S]*?)`\s*;/g)].map(m => [m[1], m[2]]));
function resolve(name, stack = []) {
  assert.ok(constants.has(name), `missing GLSL source ${name}`);
  assert.ok(!stack.includes(name), `cyclic GLSL interpolation ${[...stack, name].join(' -> ')}`);
  return constants.get(name).replace(/\$\{([A-Z0-9_]+)\}/g, (_m, dep) => resolve(dep, [...stack, name]));
}
const fragmentNames = [
  'DROPLET_FRAGMENT_300', 'TANK_FRAGMENT_300', 'CARD_DROPLETS_FRAGMENT_300',
  'LIQUID_GLASS_FRAGMENT_300', 'HDR_TONEMAP_FRAGMENT_300',
  'ENERGY_FRAGMENT_300', 'METAL_FRAGMENT_300'
];
const fluidFragments = Object.fromEntries(fragmentNames.map(n => [n, resolve(n)]));
const compositorFragment = compositor.match(/fragmentShader:\s*`([\s\S]*?)`\s*,\s*transparent:/)?.[1];
assert.ok(compositorFragment, 'could not extract dual-body compositor fragment shader');

const payload = { fluidFragments, compositorFragment };
const html = `<!doctype html><meta charset="utf-8"><title>shader compile</title><pre id="result">pending</pre>
<script>
const payload = ${JSON.stringify(payload)};
const results = [];
function compile(gl, type, source, label) {
  const shader = gl.createShader(type);
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw new Error(label + ': ' + gl.getShaderInfoLog(shader));
  return shader;
}
function link(gl, vs, fs, label) {
  const program = gl.createProgram(); gl.attachShader(program, vs); gl.attachShader(program, fs); gl.linkProgram(program);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error(label + ': link: ' + gl.getProgramInfoLog(program));
  return program;
}
try {
  const canvas = document.createElement('canvas');
  const gl2 = canvas.getContext('webgl2', {antialias:false, alpha:true});
  if (!gl2) throw new Error('WebGL2 context unavailable in headless Chromium');
  const vs2 = compile(gl2, gl2.VERTEX_SHADER, '#version 300 es\\nprecision highp float;\\nout vec2 v_uv;\\nvoid main(){ vec2 p=vec2(float((gl_VertexID<<1)&2),float(gl_VertexID&2)); v_uv=p*0.5; gl_Position=vec4(p*2.0-1.0,0.0,1.0); }', 'WebGL2 vertex');
  for (const [name, fsSource] of Object.entries(payload.fluidFragments)) {
    const fs = compile(gl2, gl2.FRAGMENT_SHADER, fsSource, name);
    link(gl2, vs2, fs, name);
    results.push({name, status:'compiled'});
  }
  const gl1 = canvas.getContext('webgl', {antialias:false, alpha:true});
  if (!gl1) throw new Error('WebGL1 context unavailable for compositor');
  const vs1 = compile(gl1, gl1.VERTEX_SHADER, 'precision highp float; attribute vec2 position; varying vec2 vUv; void main(){ vUv=position*0.5+0.5; gl_Position=vec4(position,0.0,1.0); }', 'WebGL1 compositor vertex');
  const fs1 = compile(gl1, gl1.FRAGMENT_SHADER, 'precision highp float;\\n' + payload.compositorFragment, 'dual-body compositor');
  link(gl1, vs1, fs1, 'dual-body compositor');
  results.push({name:'dual-body compositor', status:'compiled'});
  document.getElementById('result').textContent = JSON.stringify({ok:true,results});
} catch (e) {
  document.getElementById('result').textContent = JSON.stringify({ok:false,error:String(e),results});
}
</script>`;
const dir = join(tmpdir(), `titan-shader-check-${process.pid}`);
const file = join(dir, 'index.html');
import { mkdirSync } from 'node:fs';
mkdirSync(dir, {recursive:true}); writeFileSync(file, html);
try {
  const chromePath = process.env.CHROME_BIN || 'chromium';
  const output = execFileSync(chromePath, [
    '--headless=new', '--no-sandbox', '--disable-dev-shm-usage', '--enable-webgl',
    '--ignore-gpu-blocklist', '--enable-unsafe-swiftshader', '--use-gl=angle', '--use-angle=swiftshader',
    '--disable-background-networking', '--disable-extensions', '--disable-sync', '--dump-dom', `file://${file}`
  ], {encoding:'utf8', timeout:18000, stdio:['ignore','pipe','pipe']});
  const match = output.match(/<pre id="result">([\s\S]*?)<\/pre>/);
  assert.ok(match, 'Chromium did not return shader compilation result');
  const result = JSON.parse(match[1].replace(/&quot;/g, '"').replace(/&amp;/g, '&'));
  assert.equal(result.ok, true, JSON.stringify(result));
  assert.equal(result.results.length, 8);
  console.log(`V11.18 GPU shader compilation passed: ${result.results.map(x => x.name).join(', ')}`);
} catch (error) {
  if (error?.code === 'ETIMEDOUT' || error?.code === 'ENOENT' || /WebGL2 context unavailable|WebGL1 context unavailable/.test(String(error))) {
    console.log('SKIPPED: esta máquina não conseguiu inicializar WebGL/SwiftShader no Chromium headless; execute em um browser/runner com WebGL habilitado.');
  } else {
    throw error;
  }
} finally { rmSync(dir, {recursive:true, force:true}); }
