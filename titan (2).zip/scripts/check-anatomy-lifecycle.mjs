import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const renderer = readFileSync(new URL('../src/domains/anatomy/engine/renderer/anatomy-renderer.ts', import.meta.url), 'utf8');
const observerCleanupStart = renderer.indexOf('private releaseViewportObservers(');
const observerCleanupEnd = renderer.indexOf('private releaseRendererToFallback(', observerCleanupStart);
assert.ok(observerCleanupStart >= 0 && observerCleanupEnd > observerCleanupStart, 'shared observer cleanup must exist for failures with or without a WebGL context');
const observerCleanup = renderer.slice(observerCleanupStart, observerCleanupEnd);
for (const contract of ["window.removeEventListener('resize'", "document.removeEventListener('visibilitychange'", 'this.motionQuery?.removeEventListener', 'this.resizeObserver?.disconnect()', 'this.intersectionObserver?.disconnect()']) assert.ok(observerCleanup.includes(contract), `viewport cleanup missing ${contract}`);
assert.match(renderer, /new THREE\.WebGLRenderer\([\s\S]*?catch \{[\s\S]*?this\.releaseViewportObservers\(\)/, 'WebGL constructor failure must release observers and page listeners');
const cleanupStart = renderer.indexOf('private releaseRendererToFallback(');
const cleanupEnd = renderer.indexOf('private getEffectivePixelRatio(', cleanupStart);
assert.ok(cleanupStart >= 0 && cleanupEnd > cleanupStart, 'central fallback cleanup must exist');
const cleanup = renderer.slice(cleanupStart, cleanupEnd);
for (const contract of [
  'cancelAnimationFrame(this.rafId)',
  'this.controls.dispose()',
  'this.releaseViewportObservers()',
  "canvas.removeEventListener('webglcontextlost'",
  'this.bodyRig.dispose()',
  'this.materials.dispose()',
  'this.environmentTarget?.dispose()',
  'this.scene.clear()',
  'renderer.dispose()',
  'renderer.forceContextLoss()',
]) assert.ok(cleanup.includes(contract), `fallback cleanup missing ${contract}`);
assert.match(renderer, /compileAsync\(this\.scene, this\.camera\)[\s\S]*?releaseRendererToFallback\(renderer\)/, 'shader compile failure must release WebGL instead of leaving a dead canvas');
assert.match(renderer, /this\.renderer !== renderer[\s\S]*?this\.bodyRig !== bodyRig[\s\S]*?this\.materials !== materials/, 'stale RAF callbacks must not render with disposed renderer resources');
assert.match(renderer, /if \(!this\.initializationAttempted\) this\.pendingVisualInput = next/, 'failed initialization must not retain stale UI snapshots forever');
console.log('Anatomy lifecycle tests passed (fallback cleanup, context release, listener disposal, and stale RAF protection).');
