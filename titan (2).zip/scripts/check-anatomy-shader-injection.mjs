import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { applyAnatomyMaterialEnhancements } from '../src/domains/anatomy/engine/shaders/anatomy-material-shader.ts';

const color = { value: {} };
const uniforms = {
  uActiveMusclesMask: { value: 0 },
  uPrimaryMusclesMask: { value: 0 },
  uSecondaryMusclesMask: { value: 0 },
  uSelectedMuscleIndex: { value: 0 },
  uSelectedMuscleSide: { value: 0 },
  uSelectedSideAny: { value: 1 },
  uHasSelection: { value: 0 },
  uMuscleRestingColor: color,
  uMuscleDimmedColor: color,
  uMusclePrimaryColor: color,
  uMuscleSecondaryColor: color,
  uMuscleSelectedColor: color,
  uSweepY: { value: 2.05 },
  uHologramMode: { value: 1 },
  uHologramTint: color,
  uHologramAccent: color,
  uSkinScatteringMap: { value: {} },
  uKeyLightDirection: { value: { x: -0.5, y: 0.65, z: 0.57 } },
};

function makeMaterial() {
  return { onBeforeCompile: null, customProgramCacheKey: null };
}
function makeShader() {
  return {
    uniforms: {},
    vertexShader: [
      '#include <common>',
      '#include <begin_vertex>',
      '#include <morphtarget_vertex>',
      '#include <skinning_vertex>',
      '#include <displacementmap_vertex>',
      '#include <project_vertex>',
    ].join('\n'),
    fragmentShader: [
      '#include <common>',
      '#include <color_fragment>',
      '#include <normal_fragment_begin>',
      '#include <emissivemap_fragment>',
    ].join('\n'),
  };
}

for (const role of ['body', 'muscle']) {
  const material = makeMaterial();
  applyAnatomyMaterialEnhancements(material, uniforms, role);
  const shader = makeShader();
  material.onBeforeCompile(shader);
  assert.doesNotMatch(shader.vertexShader, /uMorphFactor|transformed \+= objectNormal/);
  assert.match(shader.vertexShader, /titanWorldPos4 = modelMatrix \* vec4\(transformed, 1\.0\);\s*vAnatomyWorldY = titanWorldPos4\.y/);
  assert.doesNotMatch(shader.vertexShader, /worldPosition\.y/);
  assert.match(shader.fragmentShader, /if \(uHologramMode > 0\.5\)/);
  assert.match(shader.fragmentShader, /titanHoloFresnel/);
  assert.match(shader.fragmentShader, /titanHoloScanSignal/);
  assert.equal(shader.uniforms.uHologramMode, uniforms.uHologramMode);
  assert.equal(shader.uniforms.uSweepY, uniforms.uSweepY);
  assert.equal(shader.uniforms.uSkinScatteringMap, uniforms.uSkinScatteringMap, 'UV-filtered skin reflectance is bound for both material roles');
  assert.equal(shader.uniforms.uKeyLightDirection, uniforms.uKeyLightDirection, 'custom shading uses the active studio key direction');
  assert.match(shader.fragmentShader, /texture2D\(uSkinScatteringMap, vMapUv\)/, 'skin scattering reflectance is sampled in UV space');
  assert.equal((shader.fragmentShader.match(/float titanHoloFresnel/g) ?? []).length, 1, 'hologram fragment must be injected once per material');
  assert.match(material.customProgramCacheKey(), new RegExp(`titan-anatomy-${role}-pbr-v11\.3-single-pass-worldy`));
  if (role === 'muscle') {
    assert.match(shader.vertexShader, /uActiveMusclesMask >> titanMuscleId/);
    assert.equal(shader.uniforms.uActiveMusclesMask, uniforms.uActiveMusclesMask);
    assert.equal(shader.uniforms.uSelectedMuscleIndex, uniforms.uSelectedMuscleIndex);
  }
}

const broken = makeMaterial();
applyAnatomyMaterialEnhancements(broken, uniforms, 'body');
const brokenShader = makeShader();
brokenShader.vertexShader = brokenShader.vertexShader.replace('#include <project_vertex>', '');
assert.throws(() => broken.onBeforeCompile(brokenShader), /expected exactly one vertex <project_vertex> chunk; found 0/);

const ambiguous = makeMaterial();
applyAnatomyMaterialEnhancements(ambiguous, uniforms, 'body');
const ambiguousShader = makeShader();
ambiguousShader.vertexShader += '\n#include <project_vertex>';
assert.throws(() => ambiguous.onBeforeCompile(ambiguousShader), /expected exactly one vertex <project_vertex> chunk; found 2/);

const brokenFragment = makeMaterial();
applyAnatomyMaterialEnhancements(brokenFragment, uniforms, 'body');
const brokenFragmentShader = makeShader();
brokenFragmentShader.fragmentShader += '\n#include <common>';
assert.throws(
  () => brokenFragment.onBeforeCompile(brokenFragmentShader),
  /expected exactly one fragment <common> chunk; found 2/,
  'fragment injection diagnostics must identify the fragment shader stage',
);

const shaderSource = readFileSync(new URL('../src/domains/anatomy/engine/shaders/anatomy-material-shader.ts', import.meta.url), 'utf8');
const patchCalls = (shaderSource.match(/replaceShaderChunk\(/g) ?? []).length - 1; // Exclude the helper declaration.
const stageArguments = shaderSource.match(/^\s*'(?:vertex|fragment)',\s*$/gm) ?? [];
assert.equal(patchCalls, 9, 'all shader chunk injections must remain explicit and enumerable');
assert.equal(stageArguments.length, patchCalls, 'every vertex and fragment patch must provide its diagnostic stage argument');
assert.equal(stageArguments.filter((stage) => stage.includes('vertex')).length, 3, 'three vertex shader patches must identify the vertex stage');
assert.equal(stageArguments.filter((stage) => stage.includes('fragment')).length, 6, 'six fragment shader patches must identify the fragment stage');
console.log('Anatomy shader injection tests passed (both material roles, all 9 explicit stage contracts, uniform binding, world-Y source, and fail-fast diagnostics).');
