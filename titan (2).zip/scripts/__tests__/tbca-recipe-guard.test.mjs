import assert from 'node:assert/strict';
import fs from 'node:fs';

const store = fs.readFileSync('src/domains/nutrition/state/nutrition.store.ts', 'utf8');
const recipeEngine = fs.readFileSync('src/domains/nutrition/domain/rules/recipe-engine.ts', 'utf8');
const catalog = fs.readFileSync('src/domains/nutrition/data/recipes/recipe-catalog.ts', 'utf8');
const highsSolver = fs.readFileSync('src/domains/nutrition/application/highs-nutrition-solver.ts', 'utf8');
const composerEngine = fs.readFileSync('src/domains/nutrition/domain/rules/cardapio-composer-engine.ts', 'utf8');
const recipeScaleModel = fs.readFileSync('src/domains/nutrition/domain/rules/recipe-scale-model.ts', 'utf8');

assert.match(store, /!isEligibleRecipeIngredient\(food\)/, 'store ingredient addition must enforce the policy server-side/domain-side');
assert.match(store, /validateFoodMacroComposition\(food\)\.valid && isEligibleRecipeIngredient\(food\)/, 'composite replacement must reject ineligible replacements');
assert.match(recipeEngine, /isEligibleRecipeTemplate\(recipe\)/, 'substitution search must exclude templates containing ineligible ingredients');
assert.match(store, /!isEligibleRecipeTemplate\(catalogRecipe\)/, 'direct store add/swap must reject ineligible templates');
assert.match(store, /recipeId && \(!catalogRecipe \|\| !isEligibleRecipeTemplate\(catalogRecipe\)\)/, 'new meal slots must reject explicit ineligible catalog templates');
assert.match(store, /!catalogRecipe \|\| !isEligibleRecipeTemplate\(catalogRecipe\)/, 'automatic proposal application must reject ineligible templates');
assert.match(catalog, /Modelos legados com preparações compostas são preservados para históricos/, 'legacy template policy is documented at source');
assert.match(highsSolver, /RECIPE_CATALOG\s*\.filter\(\(r\) => isEligibleRecipeTemplate\(r\)/, 'HiGHS MIP solver must filter RECIPE_CATALOG by isEligibleRecipeTemplate');
assert.match(composerEngine, /for \(const catalogRecipe of RECIPE_CATALOG\)\s*\{\s*if \(!isEligibleRecipeTemplate\(catalogRecipe\)\) continue;/, 'proposeDiscreteSubstitutions must skip ineligible catalog templates');
assert.match(recipeScaleModel, /validateFoodMacroComposition\(food\)\.valid/, 'recipe scale model must reject foods with invalid macro composition');

const matrixPath = 'src/domains/nutrition/components/cardapio-composer/composer/RecipeProportionMatrix.tsx';
if (fs.existsSync(matrixPath)) {
  const matrix = fs.readFileSync(matrixPath, 'utf8');
  assert.match(matrix, /purpose: 'recipe-ingredient'/, 'matrix ingredient search uses recipe-specific policy');
  assert.match(matrix, /RECIPE_CATALOG\.filter\(isEligibleRecipeTemplate\)/, 'RecipeProportionMatrix inline picker must filter RECIPE_CATALOG by isEligibleRecipeTemplate');
  assert.doesNotMatch(matrix, /RECIPE_CATALOG\.map\(/, 'RecipeProportionMatrix inline picker must not render unfiltered RECIPE_CATALOG templates');
}

const railPath = 'src/domains/nutrition/components/cardapio-composer/composer/ProportionRail.tsx';
if (fs.existsSync(railPath)) {
  const rail = fs.readFileSync(railPath, 'utf8');
  assert.match(rail, /purpose: 'recipe-ingredient'/, 'composite decomposition search uses recipe-specific policy');
}

const drawerPath = 'src/domains/nutrition/components/cardapio-composer/composer/IntegratedCatalogDrawer.tsx';
if (fs.existsSync(drawerPath)) {
  const drawer = fs.readFileSync(drawerPath, 'utf8');
  assert.match(drawer, /disabled={!validGrams \|\| !ingredientEligibility\.eligible}/, 'drawer must disable recipe addition but preserve separate diary action');
  assert.match(drawer, /onLogFoodToDiary\(food\.food_id/, 'general diary logging remains available');
  assert.match(drawer, /RECIPE_CATALOG\.filter\(isEligibleRecipeTemplate\)/, 'integrated recipe selection only indexes eligible templates');
}

const recipeBrowserPath = 'src/domains/nutrition/components/RecipeCatalogBrowser.tsx';
if (fs.existsSync(recipeBrowserPath)) {
  const recipeBrowser = fs.readFileSync(recipeBrowserPath, 'utf8');
  assert.match(recipeBrowser, /RECIPE_CATALOG\.filter\(isEligibleRecipeTemplate\)/, 'standalone recipe catalog only indexes eligible templates');
}

const mealLanesPath = 'src/domains/nutrition/components/cardapio-composer/composer/MealCompositionLanes.tsx';
if (fs.existsSync(mealLanesPath)) {
  const mealLanes = fs.readFileSync(mealLanesPath, 'utf8');
  assert.match(mealLanes, /RECIPE_CATALOG\.filter\(isEligibleRecipeTemplate\)/, 'MealCompositionLanes must filter new slot template picker by isEligibleRecipeTemplate');
  assert.doesNotMatch(mealLanes, /RECIPE_CATALOG\.map\(/, 'MealCompositionLanes must not render unfiltered RECIPE_CATALOG templates');
}

console.log('TBCA recipe store/UI guard contract: PASS');
