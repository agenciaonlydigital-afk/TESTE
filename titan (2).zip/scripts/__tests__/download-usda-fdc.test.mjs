import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdtemp, readFile, readdir, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fetchUsdaFdcArchive, persistUsdaArchiveImmutable, USDA_FDC_DOWNLOADS } from '../lib/usda-fdc-download.mjs';

const zipMagic = Buffer.from([0x50, 0x4b, 0x03, 0x04]);
function response(body, { status = 200, contentType = 'application/zip', contentLength = body.length, url = '', stream = false } = {}) {
  return {
    ok: status >= 200 && status < 300,
    status,
    url,
    headers: { get(name) { return name.toLowerCase() === 'content-type' ? contentType : name.toLowerCase() === 'content-length' ? String(contentLength) : null; } },
    ...(stream ? { body: new ReadableStream({ start(controller) { controller.enqueue(body); controller.close(); } }) } : {}),
    async arrayBuffer() { return body.buffer.slice(body.byteOffset, body.byteOffset + body.byteLength); },
  };
}

let calls = 0;
const foundation = USDA_FDC_DOWNLOADS.Foundation;
const downloaded = await fetchUsdaFdcArchive({
  dataType: 'Foundation',
  fetchImpl: async (url, options) => {
    calls += 1;
    assert.equal(url, foundation.url);
    assert.equal(options.redirect, 'error');
    return response(zipMagic, { stream: true });
  },
});
assert.equal(calls, 1);
assert.equal(downloaded.releaseVersion, foundation.releaseVersion);
assert.equal(downloaded.sourceUrl, foundation.url);
assert.equal(downloaded.sha256, createHash('sha256').update(zipMagic).digest('hex'));
assert.deepEqual(downloaded.bytes, zipMagic);

await assert.rejects(() => fetchUsdaFdcArchive({ dataType: 'Branded', fetchImpl: async () => response(zipMagic) }), /tipo.*não.*disponível|not.*allowlisted/i);
await assert.rejects(() => fetchUsdaFdcArchive({ dataType: 'Foundation', fetchImpl: async () => response(zipMagic, { status: 403 }) }), /HTTP 403/i);
await assert.rejects(() => fetchUsdaFdcArchive({ dataType: 'Foundation', fetchImpl: async () => response(zipMagic, { contentType: 'text/html' }) }), /Content-Type/i);
await assert.rejects(() => fetchUsdaFdcArchive({ dataType: 'Foundation', maxBytes: 3, fetchImpl: async () => response(zipMagic) }), /limite|limit/i);
await assert.rejects(() => fetchUsdaFdcArchive({ dataType: 'Foundation', maxBytes: 8, fetchImpl: async () => response(Buffer.alloc(16), { contentLength: 1 }) }), /limite|limit/i);
await assert.rejects(() => fetchUsdaFdcArchive({ dataType: 'Foundation', fetchImpl: async () => response(zipMagic, { url: 'https://fdc.nal.usda.gov.attacker.example/evil.zip' }) }), /host|domínio|origem/i);
await assert.rejects(() => fetchUsdaFdcArchive({ dataType: 'Foundation', fetchImpl: async () => response(Buffer.from('not zip'), { stream: true }) }), /ZIP/i);
await assert.rejects(() => fetchUsdaFdcArchive({ dataType: 'Foundation', fetchImpl: async () => response(zipMagic) }), /stream|corpo|body/i, 'unbounded arrayBuffer fallback must not be used');
await assert.rejects(() => fetchUsdaFdcArchive({ dataType: 'Foundation', maxBytes: 8, fetchImpl: async () => response(Buffer.alloc(16), { contentLength: 1, stream: true }) }), /limite|limit/i, 'stream chunks must be capped even if Content-Length lies');

const temporaryDirectory = await mkdtemp(path.join(os.tmpdir(), 'titan-usda-download-'));
try {
  const target = path.join(temporaryDirectory, 'foundation.zip');
  const firstBytes = Buffer.from('immutable archive bytes');
  const firstHash = createHash('sha256').update(firstBytes).digest('hex');
  const concurrent = await Promise.all([
    persistUsdaArchiveImmutable({ destination: target, bytes: firstBytes, sha256: firstHash }),
    persistUsdaArchiveImmutable({ destination: target, bytes: firstBytes, sha256: firstHash }),
  ]);
  assert.equal(concurrent.filter((result) => result.created).length, 1, 'exactly one concurrent writer must create the archive');
  assert.deepEqual(await readFile(target), firstBytes);
  const idempotent = await persistUsdaArchiveImmutable({ destination: target, bytes: firstBytes, sha256: firstHash });
  assert.equal(idempotent.created, false, 'same bytes must be recognized without rewriting');
  const conflictingBytes = Buffer.from('different archive bytes');
  await assert.rejects(() => persistUsdaArchiveImmutable({
    destination: target, bytes: conflictingBytes, sha256: createHash('sha256').update(conflictingBytes).digest('hex'),
  }), /conflito|conflict/i);
  await assert.rejects(() => persistUsdaArchiveImmutable({ destination: target, bytes: firstBytes, sha256: '0'.repeat(64) }), /SHA-256|hash/i);
  assert.deepEqual(await readFile(target), firstBytes, 'conflicting writes must preserve the original archive');
  assert.deepEqual(await readdir(temporaryDirectory), ['foundation.zip'], 'temporary files must be removed after promotion');
} finally {
  await rm(temporaryDirectory, { recursive: true, force: true });
}

const cliTemp = await mkdtemp(path.join(os.tmpdir(), 'titan-usda-cli-'));
try {
  const { runDownloadUsdaCli } = await import('../download-usda-fdc.mjs');
  const out = [];
  const err = [];
  const res = await runDownloadUsdaCli(['--', '--type', 'Foundation'], {
    outputDirectory: cliTemp,
    stdout: { write: (s) => out.push(s) },
    stderr: { write: (s) => err.push(s) },
    fetchImpl: async (url, options) => {
      assert.equal(url, foundation.url);
      assert.equal(options.redirect, 'error');
      return response(zipMagic, { stream: true });
    },
  });
  assert.equal(res, 0, `expected CLI exit code 0, stderr: ${err.join('')}`);
  assert.match(out.join(''), /Tipo: Foundation; release:/);
} finally {
  await rm(cliTemp, { recursive: true, force: true });
}

process.stdout.write('USDA FDC pinned download tests passed.\n');
