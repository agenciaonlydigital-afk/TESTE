import assert from 'node:assert/strict';
import { deflateRawSync } from 'node:zlib';
import { extractSingleJsonFromUsdaArchive } from '../lib/usda-fdc-archive.mjs';

const crcTable = Uint32Array.from({ length: 256 }, (_, value) => {
  let current = value;
  for (let bit = 0; bit < 8; bit += 1) current = (current & 1) ? (0xedb88320 ^ (current >>> 1)) : (current >>> 1);
  return current >>> 0;
});
function crc32(buffer) {
  let crc = 0xffffffff;
  for (const byte of buffer) crc = crcTable[(crc ^ byte) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}
function zip(entries, overrides = {}) {
  const localParts = [];
  const centralParts = [];
  let localOffset = 0;
  for (const entry of entries) {
    const name = Buffer.from(entry.name, 'utf8');
    const raw = Buffer.from(entry.content);
    const method = entry.method ?? 8;
    const compressed = method === 0 ? raw : deflateRawSync(raw);
    const checksum = entry.crcOverride ?? crc32(raw);
    const hasDescriptor = entry.descriptor === true;
    const flags = entry.flags ?? (0x800 | (hasDescriptor ? 0x0008 : 0));
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(flags, 6);
    local.writeUInt16LE(method, 8);
    local.writeUInt32LE(hasDescriptor ? 0 : checksum, 14);
    local.writeUInt32LE(hasDescriptor ? 0 : compressed.length, 18);
    local.writeUInt32LE(hasDescriptor ? 0 : raw.length, 22);
    local.writeUInt16LE(name.length, 26);
    local.writeUInt16LE(0, 28);
    localParts.push(local, name, compressed);
    if (hasDescriptor) {
      const signatureLength = entry.descriptorSignature === false ? 0 : 4;
      const descriptor = Buffer.alloc(12 + signatureLength);
      if (signatureLength) descriptor.writeUInt32LE(0x08074b50, 0);
      descriptor.writeUInt32LE(entry.descriptorCrcOverride ?? checksum, signatureLength);
      descriptor.writeUInt32LE(entry.descriptorCompressedSizeOverride ?? compressed.length, signatureLength + 4);
      descriptor.writeUInt32LE(entry.descriptorUncompressedSizeOverride ?? raw.length, signatureLength + 8);
      localParts.push(descriptor);
    }

    const central = Buffer.alloc(46);
    central.writeUInt32LE(0x02014b50, 0);
    central.writeUInt16LE(0x0314, 4);
    central.writeUInt16LE(20, 6);
    central.writeUInt16LE(flags, 8);
    central.writeUInt16LE(method, 10);
    central.writeUInt32LE(checksum, 16);
    central.writeUInt32LE(compressed.length, 20);
    central.writeUInt32LE(raw.length, 24);
    central.writeUInt16LE(name.length, 28);
    central.writeUInt16LE(0, 30);
    central.writeUInt16LE(0, 32);
    central.writeUInt16LE(0, 34);
    central.writeUInt32LE(0, 38);
    central.writeUInt32LE(entry.localOffsetOverride ?? localOffset, 42);
    centralParts.push(central, name);
    localOffset += local.length + name.length + compressed.length + (hasDescriptor ? 12 + (entry.descriptorSignature === false ? 0 : 4) : 0);
  }
  const localBytes = Buffer.concat(localParts);
  const centralBytes = Buffer.concat(centralParts);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(overrides.diskNumber ?? 0, 4);
  eocd.writeUInt16LE(overrides.centralDisk ?? 0, 6);
  eocd.writeUInt16LE(entries.length, 8);
  eocd.writeUInt16LE(entries.length, 10);
  eocd.writeUInt32LE(centralBytes.length, 12);
  eocd.writeUInt32LE(localBytes.length, 16);
  eocd.writeUInt16LE(0, 20);
  if (overrides.zip64) {
    eocd.writeUInt16LE(0xffff, 8);
    eocd.writeUInt16LE(0xffff, 10);
  }
  return Buffer.concat([localBytes, centralBytes, eocd]);
}

const payload = Buffer.from(JSON.stringify({ FoundationFoods: [{ fdcId: 1, description: 'Example' }] }));
const stored = extractSingleJsonFromUsdaArchive(zip([{ name: 'foods.json', content: payload, method: 0 }]));
assert.equal(stored.entryName, 'foods.json');
assert.deepEqual(stored.jsonBytes, payload);
const compressed = extractSingleJsonFromUsdaArchive(zip([{ name: 'release/foods.json', content: payload }]));
assert.deepEqual(compressed.jsonBytes, payload);
const withDescriptor = extractSingleJsonFromUsdaArchive(zip([{ name: 'foods.json', content: payload, descriptor: true }]));
assert.deepEqual(withDescriptor.jsonBytes, payload, 'a valid ZIP data descriptor must be checked against the central directory');
const withoutDescriptorSignature = extractSingleJsonFromUsdaArchive(zip([{ name: 'foods.json', content: payload, descriptor: true, descriptorSignature: false }]));
assert.deepEqual(withoutDescriptorSignature.jsonBytes, payload, 'ZIP data descriptors without optional signatures must be supported');
assert.throws(() => extractSingleJsonFromUsdaArchive(zip([{ name: 'foods.json', content: payload, descriptor: true, descriptorCrcOverride: 0 }])), /descriptor|descritor|CRC/i);
assert.throws(() => extractSingleJsonFromUsdaArchive(zip([{ name: 'foods.json', content: payload, descriptor: true, descriptorCompressedSizeOverride: 1 }])), /descriptor|descritor|size|tamanho/i);

assert.throws(() => extractSingleJsonFromUsdaArchive(zip([{ name: '../foods.json', content: payload }])), /path|caminho|seguro/i);
assert.throws(() => extractSingleJsonFromUsdaArchive(zip([
  { name: 'foods-a.json', content: payload }, { name: 'foods-b.json', content: payload },
])), /único|ambígu|json/i);
assert.throws(() => extractSingleJsonFromUsdaArchive(zip([{ name: 'foods.json', content: payload, flags: 0x801 }])), /criptograf|encrypted/i);
assert.throws(() => extractSingleJsonFromUsdaArchive(zip([{ name: 'foods.json', content: payload, flags: 0x100 }])), /flags|não suportadas/i);
assert.throws(() => extractSingleJsonFromUsdaArchive(zip([{ name: 'foods.json', content: payload, method: 99 }])), /compress|método|method/i);
assert.throws(() => extractSingleJsonFromUsdaArchive(zip([{ name: 'foods.json', content: payload, crcOverride: 1 }])), /CRC/i);
assert.throws(() => extractSingleJsonFromUsdaArchive(zip([{ name: 'foods.json', content: payload }]), { maxUncompressedBytes: 8 }), /limite|limit|tamanho/i);
assert.throws(() => extractSingleJsonFromUsdaArchive(zip([{ name: 'foods.json', content: 'A'.repeat(4096) }]), { maxCompressionRatio: 1 }), /razão|ratio|compress/i);
assert.throws(() => extractSingleJsonFromUsdaArchive(zip([{ name: 'foods.json', content: payload }], { diskNumber: 1 })), /multi.?disk|disco/i);
assert.throws(() => extractSingleJsonFromUsdaArchive(zip([{ name: 'foods.json', content: payload }], { zip64: true })), /ZIP64/i);
const truncated = zip([{ name: 'foods.json', content: payload }]).subarray(0, 24);
assert.throws(() => extractSingleJsonFromUsdaArchive(truncated), /ZIP|EOCD|central/i);

process.stdout.write('USDA ZIP archive safety tests passed.\n');
