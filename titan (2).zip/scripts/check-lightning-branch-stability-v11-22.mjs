import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/shared/graphics/fluid-shader-engine.ts', import.meta.url), 'utf8');
const start = source.indexOf('float nodePhase =');
assert.ok(start >= 0, 'the volumetric arc contains a branch node phase');
const block = source.slice(start, source.indexOf('float plasmaDens', start));
assert.match(block, /float nodePhase = pos3D\.x \* 3\.4;/, 'branch node coordinate is derived only from the spatial sample');
assert.match(block, /float nodeId = floor\(nodePhase\);/, 'branch identity is a stable spatial cell');
assert.match(block, /float nodeLocalX = fract\(nodePhase\) - 0\.5;/, 'branch origin remains fixed inside its spatial cell');
assert.match(block, /float nodeSeed = energyHash31\(vec3\(nodeId, 4\.1, 2\.3\)\);/, 'each stable spatial branch has a deterministic seed');
assert.match(block, /float nodeCycleRate = mix\(0\.72, 1\.20, nodeSeed\);/, 'each node has an independently seeded discharge cadence');
assert.match(block, /float nodeCycle = fract\(t \* nodeCycleRate \+ nodeSeed\);/, 'node pulse varies in time without moving its spatial identity');
assert.match(block, /float branchGate = nodeHeat \* invSmooth/, 'branch birth/death remains driven by the continuous return-stroke envelope');
assert.doesNotMatch(block, /nodePhase\s*=\s*[^;]*\bt\b/, 'time must not drift the branch identity or origin');
console.log('PASS: spatially stable plasma branch topology with independent continuous pulse envelopes');
