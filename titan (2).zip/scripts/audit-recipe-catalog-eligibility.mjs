import { RECIPE_CATALOG } from '../src/domains/nutrition/data/recipes/recipe-catalog.ts';
import {
  evaluateRecipeTemplateEligibility,
} from '../src/domains/nutrition/domain/rules/recipe-engine.ts';

const rows = RECIPE_CATALOG.map((recipe) => ({
  id: recipe.id,
  name: recipe.name,
  ...evaluateRecipeTemplateEligibility(recipe),
}));
const eligible = rows.filter((row) => row.eligible);
const blocked = rows.filter((row) => !row.eligible);

console.log(`Recipe catalog eligibility: ${eligible.length}/${rows.length} templates selectable; ${blocked.length} legacy/invalid templates hidden from new selection.`);
for (const row of blocked) {
  console.log(`BLOCKED ${row.id}: ${row.blockedFoodIds.join(', ') || '(empty recipe)'}`);
}
if (eligible.length === 0) {
  throw new Error('No recipe template has a complete set of eligible ingredients.');
}
