#!/usr/bin/env node
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdir, mkdtemp, readFile, rm, symlink, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const TEMP = await mkdtemp(path.join(ROOT, '.tmp-usda-import-cli-'));
const loader = path.join(ROOT, 'scripts/ts-extension-loader.mjs');
const importer = path.join(ROOT, 'scripts/import-usda-fdc.mjs');
const output = path.join(TEMP, 'catalog.generated.ts');
const input = path.join(TEMP, 'foundation.fixture.json');
const invalidInput = path.join(TEMP, 'invalid.fixture.json');
const zipInput = path.join(TEMP, 'foundation.fixture.zip');
const fixture = {
  FoundationFoods: [{
    fdcId: 7000001,
    description: 'USDA synthetic integration fixture',
    dataType: 'Foundation',
    foodNutrients: [
      { nutrient: { id: 1003, number: '203', name: 'Protein', unitName: 'g' }, amount: 8 },
      { nutrient: { id: 1004, number: '204', name: 'Total lipid (fat)', unitName: 'g' }, amount: 3 },
      { nutrient: { id: 1005, number: '205', name: 'Carbohydrate, by difference', unitName: 'g' }, amount: 14 },
      { nutrient: { id: 2048, number: '958', name: 'Energy (Atwater Specific Factors)', unitName: 'kcal' }, amount: 115 },
      { nutrient: { id: 1087, number: '301', name: 'Calcium, Ca', unitName: 'mg' }, amount: 42 },
      { nutrient: { id: 999999, number: '99999', name: 'Novel compound', unitName: 'mg' }, amount: 3 },
    ],
  }, { fdcId: 7000002 }],
};

const CRC_TABLE = Uint32Array.from({ length: 256 }, (_, value) => {
  let current = value;
  for (let bit = 0; bit < 8; bit += 1) current = (current & 1) ? (0xedb88320 ^ (current >>> 1)) : (current >>> 1);
  return current >>> 0;
});
function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) crc = CRC_TABLE[(crc ^ byte) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}
function makeStoredZip(entryName, content) {
  const name = Buffer.from(entryName, 'utf8');
  const raw = Buffer.from(content);
  const checksum = crc32(raw);
  const local = Buffer.alloc(30);
  local.writeUInt32LE(0x04034b50, 0);
  local.writeUInt16LE(20, 4);
  local.writeUInt16LE(0x800, 6);
  local.writeUInt16LE(0, 8);
  local.writeUInt32LE(checksum, 14);
  local.writeUInt32LE(raw.length, 18);
  local.writeUInt32LE(raw.length, 22);
  local.writeUInt16LE(name.length, 26);
  const central = Buffer.alloc(46);
  central.writeUInt32LE(0x02014b50, 0);
  central.writeUInt16LE(0x0314, 4);
  central.writeUInt16LE(20, 6);
  central.writeUInt16LE(0x800, 8);
  central.writeUInt16LE(0, 10);
  central.writeUInt32LE(checksum, 16);
  central.writeUInt32LE(raw.length, 20);
  central.writeUInt32LE(raw.length, 24);
  central.writeUInt16LE(name.length, 28);
  const localBytes = Buffer.concat([local, name, raw]);
  const centralBytes = Buffer.concat([central, name]);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(1, 8);
  eocd.writeUInt16LE(1, 10);
  eocd.writeUInt32LE(centralBytes.length, 12);
  eocd.writeUInt32LE(localBytes.length, 16);
  return Buffer.concat([localBytes, centralBytes, eocd]);
}

function run(args) {
  return spawnSync(process.execPath, [
    '--experimental-strip-types', '--loader', loader, importer, ...args,
  ], { cwd: ROOT, encoding: 'utf8' });
}

function importArgs(sourceUrl, target = output, release = 'synthetic-fixture-v1') {
  return ['--input', input, '--type', 'Foundation', '--release', release, '--source-url', sourceUrl, '--output', target];
}

try {
  const inputBytes = Buffer.from(JSON.stringify(fixture));
  await writeFile(input, inputBytes);
  const success = run([
    '--input', input,
    '--type', 'Foundation',
    '--release', 'synthetic-fixture-v1',
    '--source-url', 'https://fdc.nal.usda.gov/download-datasets/',
    '--output', output,
  ]);
  assert.equal(success.status, 0, `USDA CLI import failed:\n${success.stderr}\n${success.stdout}`);
  assert.match(success.stdout, /USDA FDC importado: 1 alimentos/);
  const generated = await readFile(output, 'utf8');
  assert.match(generated, /"status": "imported"/);
  assert.match(generated, /USDA_FDC_FOUNDATION_CATALOG/);
  assert.match(generated, /"dataType": "Foundation"/);
  assert.match(generated, /"releaseVersion": "synthetic-fixture-v1"/);
  assert.match(generated, new RegExp(createHash('sha256').update(inputBytes).digest('hex')));
  assert.match(generated, /usda-fdc:7000001/);
  const auditReference = generated.match(/\"auditFile\": \"([^\"]+)\"/);
  assert.ok(auditReference, 'generated manifest must link the immutable audit artifact');
  const auditPath = path.join(ROOT, auditReference[1]);
  const audit = JSON.parse(await readFile(auditPath, 'utf8'));
  assert.equal(audit.inputSha256, createHash('sha256').update(inputBytes).digest('hex'));
  assert.ok(audit.rejectedFoods.some((food) => food.reason === 'missing_fdc_id_or_description'));
  assert.ok(audit.quarantinedNutrients.some((nutrient) => nutrient.nutrientId === 999999 && nutrient.reason === 'unknown_nutrient'));
  assert.equal(audit.acceptedFoodCount, 1);

  const conflictingAudit = run([
    '--input', input,
    '--type', 'Foundation',
    '--release', 'synthetic-fixture-v1',
    '--source-url', 'https://fdc.nal.usda.gov/faq/',
    '--output', output,
  ]);
  assert.notEqual(conflictingAudit.status, 0, 'same content-addressed audit identity must not be overwritten with divergent provenance');
  assert.match(conflictingAudit.stderr, /Conflito: .*já existe com outro conteúdo/i);
  assert.equal(await readFile(output, 'utf8'), generated, 'conflicting audit provenance must not replace the generated catalog');

  const zipBytes = makeStoredZip('release/foods.json', inputBytes);
  await writeFile(zipInput, zipBytes);
  const zipped = run([
    '--input', zipInput,
    '--type', 'Foundation',
    '--release', 'synthetic-fixture-zip-v1',
    '--source-url', 'https://fdc.nal.usda.gov/download-datasets/',
    '--output', output,
  ]);
  assert.equal(zipped.status, 0, `USDA ZIP import failed:\n${zipped.stderr}\n${zipped.stdout}`);
  assert.match(zipped.stdout, /JSON no ZIP: release\/foods\.json/);
  const zippedGenerated = await readFile(output, 'utf8');
  assert.match(zippedGenerated, new RegExp(createHash('sha256').update(zipBytes).digest('hex')));
  assert.match(zippedGenerated, /"archiveEntry": "release\/foods\.json"/);

  await writeFile(invalidInput, JSON.stringify({ FoundationFoods: [] }));
  const rejected = run([
    '--input', invalidInput,
    '--type', 'Foundation',
    '--release', 'synthetic-empty-v1',
    '--source-url', 'https://fdc.nal.usda.gov/download-datasets/',
    '--output', output,
  ]);
  assert.notEqual(rejected.status, 0, 'empty/invalid source must not produce a replacement catalog');
  assert.match(rejected.stderr, /Nenhum alimento válido foi importado/);
  assert.equal(await readFile(output, 'utf8'), zippedGenerated, 'failed import must preserve the previous generated catalog');

  const untrustedSource = run(importArgs('https://fdc.nal.usda.gov.attacker.example/dataset.zip'));
  assert.notEqual(untrustedSource.status, 0, 'provenance URL on a lookalike hostname must be rejected');
  assert.match(untrustedSource.stderr, /domínio oficial https:\/\/fdc\.nal\.usda\.gov/);
  assert.equal(await readFile(output, 'utf8'), zippedGenerated, 'an untrusted source URL must not replace the previous catalog');

  const escaped = path.resolve(TEMP, '..', '..', 'usda-outside-test.ts');
  const pathRejected = run([
    '--input', input,
    '--type', 'Foundation',
    '--release', 'synthetic-fixture-v1',
    '--source-url', 'https://fdc.nal.usda.gov/download-datasets/',
    '--output', escaped,
  ]);
  assert.notEqual(pathRejected.status, 0, 'output outside repository must be rejected');
  assert.match(pathRejected.stderr, /Diretório real.*fora do diretório real do projeto/i);

  const outsideDirectory = path.resolve(ROOT, '..', 'usda-import-cli-symlink-escape');
  const symlinkDirectory = path.join(TEMP, 'symlink-output');
  const escapedViaSymlink = path.join(symlinkDirectory, 'catalog.generated.ts');
  await mkdir(outsideDirectory, { recursive: true });
  await symlink(outsideDirectory, symlinkDirectory, 'dir');
  const symlinkRejected = run([
    '--input', input,
    '--type', 'Foundation',
    '--release', 'synthetic-symlink-escape-v1',
    '--source-url', 'https://fdc.nal.usda.gov/download-datasets/',
    '--output', escapedViaSymlink,
  ]);
  assert.notEqual(symlinkRejected.status, 0, 'output parent symlink escaping the repository must be rejected');
  assert.match(symlinkRejected.stderr, /Diretório real.*fora do diretório real do projeto/i);
  await assert.rejects(readFile(path.join(outsideDirectory, 'catalog.generated.ts')));

  process.stdout.write('USDA FDC CLI integration tests passed (synthetic fixture only; no production dataset imported).\n');
} finally {
  await rm(TEMP, { recursive: true, force: true });
  await rm(path.resolve(ROOT, '..', 'usda-import-cli-symlink-escape'), { recursive: true, force: true });
  await rm(path.resolve(ROOT, '..', 'usda-outside-test.ts'), { force: true });
}
