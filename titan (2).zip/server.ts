import 'dotenv/config';
import express, { type NextFunction, type Request, type Response } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { z } from 'zod';
import { validateAndNormalizeGtin, matchesExactGtin } from './src/domains/nutrition/domain/rules/gtin.ts';
import type { FoodSourceItem, NutrientId, ProductIdentity, SourceFoodObservation } from './src/domains/nutrition/domain/entities/nutrient.ts';
import { buildSourceObservationFromFoodItem } from './src/domains/nutrition/domain/rules/hybrid-composition-resolver.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const APP_VERSION = '11.35.0';
const OFF_USER_AGENT = `TITAN-Nutrition/${APP_VERSION} (dietary-composition-audit; https://titan-nutrition.local)`;
const OFF_ALLOWED_FIELDS = [
  'code',
  'product_name',
  'product_name_pt',
  'brands',
  'serving_size',
  'serving_quantity',
  'serving_quantity_unit',
  'nutrition_data_per',
  'ingredients_text',
  'ingredients_analysis_tags',
  'nutriments',
  'states_tags',
].join(',');

const PORT = Number(process.env.PORT ?? 3000);
const CACHE_TTL_FOUND_MS = 15 * 60 * 1000;
const CACHE_TTL_MISS_MS = 2 * 60 * 1000;

interface CachedLookupEntry<T> {
  expiresAt: number;
  statusCode: number;
  etag?: string | null;
  payload: T;
}

const offCache = new Map<string, CachedLookupEntry<unknown>>();
const fdcBrandedCache = new Map<string, CachedLookupEntry<unknown>>();

// Sliding window per-IP rate limiting for external API proxies (30 req/min).
const RATE_LIMIT_WINDOW_MS = 60 * 1000;
const RATE_LIMIT_MAX_REQUESTS = 30;
const ipHits = new Map<string, number[]>();

function nutritionRateLimiter(req: Request, res: Response, next: NextFunction): void {
  const ip = req.ip || 'local';
  const now = Date.now();
  const recent = (ipHits.get(ip) ?? []).filter((ts) => now - ts < RATE_LIMIT_WINDOW_MS);
  if (recent.length >= RATE_LIMIT_MAX_REQUESTS) {
    res.status(429).json({
      status: 'rate_limited',
      error: 'Limite de consultas por minuto atingido; aguarde alguns segundos antes de tentar novamente.',
    });
    return;
  }
  recent.push(now);
  ipHits.set(ip, recent);
  next();
}

const offResponseSchema = z.object({
  code: z.string().optional(),
  status: z.union([z.number(), z.string()]).optional(),
  status_verbose: z.string().optional(),
  product: z
    .object({
      code: z.string().optional(),
      product_name: z.string().optional(),
      product_name_pt: z.string().optional(),
      brands: z.string().optional(),
      serving_size: z.string().optional(),
      serving_quantity: z.union([z.number(), z.string()]).nullable().optional(),
      serving_quantity_unit: z.string().nullable().optional(),
      nutrition_data_per: z.string().optional(),
      ingredients_text: z.string().optional(),
      nutriments: z.record(z.string(), z.unknown()).optional(),
    })
    .optional(),
});

function readFiniteNumber(value: unknown): number | null {
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value === 'string' && value.trim()) {
    const parsed = Number(value.replace(',', '.'));
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}

function readOffNutriment100(
  nutriments: Record<string, unknown>,
  keyBase: string,
  preferredUnit: 'g' | 'mg' | 'µg' | 'kcal',
): { value: number | null; unit: string; originalValue: number | null; originalUnit: string } {
  const unitVal = nutriments[`${keyBase}_unit`];
  const rawUnit = typeof unitVal === 'string' && unitVal.trim() ? unitVal.trim() : preferredUnit;
  const val100g = readFiniteNumber(nutriments[`${keyBase}_100g`]);
  const valDirect = readFiniteNumber(nutriments[keyBase]);
  const rawValue = val100g ?? valDirect;
  if (rawValue === null || rawValue < 0) {
    return { value: null, unit: preferredUnit, originalValue: null, originalUnit: rawUnit };
  }

  let converted = rawValue;
  const uLower = rawUnit.toLowerCase();
  if (preferredUnit === 'mg') {
    if (uLower === 'g') converted = rawValue * 1000;
    else if (uLower === 'µg' || uLower === 'ug' || uLower === 'mcg') converted = rawValue / 1000;
  } else if (preferredUnit === 'µg') {
    if (uLower === 'mg') converted = rawValue * 1000;
    else if (uLower === 'g') converted = rawValue * 1_000_000;
  } else if (preferredUnit === 'g') {
    if (uLower === 'mg') converted = rawValue / 1000;
  }

  return {
    value: Number(converted.toFixed(6)),
    unit: preferredUnit,
    originalValue: rawValue,
    originalUnit: rawUnit,
  };
}

function buildObservationFromOffProduct(
  gtin: string,
  gtin14: string,
  format: ProductIdentity['format'],
  product: NonNullable<z.infer<typeof offResponseSchema>['product']>,
): SourceFoodObservation {
  const nutriments = product.nutriments ?? {};
  const name = (product.product_name_pt || product.product_name || `Produto GTIN ${gtin}`).trim();
  const brand = product.brands?.split(',')[0]?.trim();
  const dataPerRaw = (product.nutrition_data_per ?? '100g').toLowerCase();
  const basisUnit: 'g' | 'ml' = dataPerRaw === '100ml' ? 'ml' : 'g';

  const energy = readOffNutriment100(nutriments, 'energy-kcal', 'kcal');
  const protein = readOffNutriment100(nutriments, 'proteins', 'g');
  const carbs = readOffNutriment100(nutriments, 'carbohydrates', 'g');
  const fat = readOffNutriment100(nutriments, 'fat', 'g');
  const fiber = readOffNutriment100(nutriments, 'fiber', 'g');
  const satFat = readOffNutriment100(nutriments, 'saturated-fat', 'g');

  const sodiumRaw = readOffNutriment100(nutriments, 'sodium', 'mg');
  const saltRaw = readOffNutriment100(nutriments, 'salt', 'g');
  const sodiumMg =
    sodiumRaw.value !== null
      ? sodiumRaw.value
      : saltRaw.value !== null
        ? Number(((saltRaw.value * 1000) / 2.5).toFixed(2))
        : null;

  const kcal = energy.value ?? 0;
  const pG = protein.value ?? 0;
  const cG = carbs.value ?? 0;
  const fG = fat.value ?? 0;

  const micronutrients: FoodSourceItem['micronutrients'] = {};
  const microMap: Array<{ nutrientId: NutrientId; offKey: string; unit: 'mg' | 'µg'; conv?: 'direct_rae' }> = [
    { nutrientId: 'calcium', offKey: 'calcium', unit: 'mg' },
    { nutrientId: 'iron', offKey: 'iron', unit: 'mg' },
    { nutrientId: 'potassium', offKey: 'potassium', unit: 'mg' },
    { nutrientId: 'magnesium', offKey: 'magnesium', unit: 'mg' },
    { nutrientId: 'zinc', offKey: 'zinc', unit: 'mg' },
    { nutrientId: 'vitamin_c', offKey: 'vitamin-c', unit: 'mg' },
    { nutrientId: 'vitamin_d', offKey: 'vitamin-d', unit: 'µg' },
    { nutrientId: 'vitamin_e', offKey: 'vitamin-e', unit: 'mg' },
    { nutrientId: 'vitamin_b1', offKey: 'vitamin-b1', unit: 'mg' },
    { nutrientId: 'vitamin_b2', offKey: 'vitamin-b2', unit: 'mg' },
    { nutrientId: 'vitamin_b6', offKey: 'vitamin-b6', unit: 'mg' },
    { nutrientId: 'vitamin_b12', offKey: 'vitamin-b12', unit: 'µg' },
  ];

  for (const m of microMap) {
    const parsed = readOffNutriment100(nutriments, m.offKey, m.unit);
    if (parsed.value !== null) {
      micronutrients[m.nutrientId] = {
        original_value: parsed.originalValue,
        original_unit: parsed.originalUnit,
        normalized_value: parsed.value,
        normalized_unit: m.unit,
        basis_quantity: 100,
        data_status: 'quantified',
        conversion_method: m.conv ?? 'direct',
      };
    }
  }

  if (sodiumMg !== null) {
    micronutrients.sodium = {
      original_value: sodiumRaw.originalValue ?? saltRaw.originalValue,
      original_unit: sodiumRaw.originalValue !== null ? sodiumRaw.originalUnit : 'g (sal)',
      normalized_value: sodiumMg,
      normalized_unit: 'mg',
      basis_quantity: 100,
      data_status: 'quantified',
      conversion_method: sodiumRaw.originalValue !== null ? 'direct' : 'unit_scale',
    };
  }

  const warnings: string[] = [];
  if (basisUnit === 'ml') {
    warnings.push('Tabela nutricional do rótulo expressa por 100 ml; informe densidade para converter para gramas.');
  }
  if (energy.value === null || protein.value === null || carbs.value === null || fat.value === null) {
    warnings.push('Rótulo OFF incompleto: revise ou complete calorias e macronutrientes ausentes.');
  }

  const foodItem: FoodSourceItem = {
    food_id: `off-gtin:${gtin}`,
    name: brand ? `${name} (${brand})` : name,
    source_id: 'OPEN_FOOD_FACTS',
    source_record_id: gtin,
    source_version: 'OFF API v3 live',
    quality_status:
      energy.value !== null && protein.value !== null && carbs.value !== null && fat.value !== null
        ? 'label_partial'
        : 'unverified',
    source_url: `https://world.openfoodfacts.org/product/${gtin}`,
    food_type: 'MULTI_INGREDIENT',
    state: 'as_sold',
    search_text: [gtin, gtin14, brand, product.ingredients_text].filter(Boolean).join(' ').toLowerCase(),
    macros: {
      kcalPerBasis: kcal,
      proteinGPerBasis: pG,
      carbsGPerBasis: cG,
      fatGPerBasis: fG,
      basisQuantityG: 100,
      fiberGPerBasis: fiber.value,
      saturatedFatGPerBasis: satFat.value,
      sodiumMgPerBasis: sodiumMg,
    },
    micronutrients,
  };

  const servingQuantity = readFiniteNumber(product.serving_quantity);
  const identity: ProductIdentity = {
    gtin,
    gtin14,
    format,
    brand,
    product_name: name,
    serving_size_text: product.serving_size,
    serving_quantity: servingQuantity,
    serving_unit: product.serving_quantity_unit === 'ml' ? 'ml' : product.serving_quantity_unit === 'g' ? 'g' : null,
    nutrition_data_per: dataPerRaw === '100ml' ? '100ml' : dataPerRaw === 'serving' ? 'serving' : '100g',
    preparation_state: 'as_sold',
  };

  return buildSourceObservationFromFoodItem(foodItem, {
    productIdentity: identity,
    basisUnit,
    sourceTierOverride: 'current_label',
    warnings,
  });
}

const fdcSearchResponseSchema = z.object({
  foods: z
    .array(
      z.object({
        fdcId: z.number(),
        description: z.string(),
        dataType: z.string().optional(),
        gtinUpc: z.string().optional(),
        brandOwner: z.string().optional(),
        brandName: z.string().optional(),
        servingSize: z.number().optional(),
        servingSizeUnit: z.string().optional(),
        publishedDate: z.string().optional(),
        modifiedDate: z.string().optional(),
        foodNutrients: z
          .array(
            z.object({
              nutrientId: z.number().optional(),
              nutrientNumber: z.string().optional(),
              nutrientName: z.string().optional(),
              unitName: z.string().optional(),
              value: z.number().optional(),
            }),
          )
          .optional(),
      }),
    )
    .optional(),
});

function buildObservationFromFdcBrandedFood(
  gtin: string,
  gtin14: string,
  format: ProductIdentity['format'],
  food: NonNullable<z.infer<typeof fdcSearchResponseSchema>['foods']>[number],
): SourceFoodObservation {
  const nutrients = food.foodNutrients ?? [];
  const findVal = (numbers: string[]) => {
    const match = nutrients.find((n) => n.nutrientNumber && numbers.includes(n.nutrientNumber));
    return typeof match?.value === 'number' && Number.isFinite(match.value) && match.value >= 0 ? match.value : null;
  };
  const kcal = findVal(['208', '957', '958']) ?? 0;
  const proteinG = findVal(['203']) ?? 0;
  const fatG = findVal(['204']) ?? 0;
  const carbsG = findVal(['205']) ?? 0;
  const fiberG = findVal(['291']);
  const satFatG = findVal(['606']);
  const sodiumMg = findVal(['307']);
  const calciumMg = findVal(['301']);
  const ironMg = findVal(['303']);
  const potassiumMg = findVal(['306']);

  const micronutrients: FoodSourceItem['micronutrients'] = {};
  if (sodiumMg !== null) {
    micronutrients.sodium = {
      original_value: sodiumMg,
      original_unit: 'mg',
      normalized_value: sodiumMg,
      normalized_unit: 'mg',
      basis_quantity: 100,
      data_status: 'quantified',
      conversion_method: 'direct',
    };
  }
  if (calciumMg !== null) {
    micronutrients.calcium = {
      original_value: calciumMg,
      original_unit: 'mg',
      normalized_value: calciumMg,
      normalized_unit: 'mg',
      basis_quantity: 100,
      data_status: 'quantified',
      conversion_method: 'direct',
    };
  }
  if (ironMg !== null) {
    micronutrients.iron = {
      original_value: ironMg,
      original_unit: 'mg',
      normalized_value: ironMg,
      normalized_unit: 'mg',
      basis_quantity: 100,
      data_status: 'quantified',
      conversion_method: 'direct',
    };
  }
  if (potassiumMg !== null) {
    micronutrients.potassium = {
      original_value: potassiumMg,
      original_unit: 'mg',
      normalized_value: potassiumMg,
      normalized_unit: 'mg',
      basis_quantity: 100,
      data_status: 'quantified',
      conversion_method: 'direct',
    };
  }

  const brand = food.brandName || food.brandOwner;
  const basisUnit: 'g' | 'ml' = food.servingSizeUnit?.toLowerCase() === 'ml' ? 'ml' : 'g';

  const item: FoodSourceItem = {
    food_id: `usda-branded:${food.fdcId}`,
    name: brand ? `${food.description} (${brand})` : food.description,
    source_id: 'USDA_FDC',
    source_record_id: String(food.fdcId),
    source_version: `USDA FDC Branded ${food.modifiedDate || food.publishedDate || 'API v1'}`,
    quality_status: 'label_complete',
    source_url: `https://fdc.nal.usda.gov/food-details/${food.fdcId}/nutrients`,
    food_type: 'Branded',
    state: 'as_sold',
    search_text: [gtin, gtin14, food.gtinUpc, brand].filter(Boolean).join(' ').toLowerCase(),
    macros: {
      kcalPerBasis: kcal,
      proteinGPerBasis: proteinG,
      carbsGPerBasis: carbsG,
      fatGPerBasis: fatG,
      basisQuantityG: 100,
      fiberGPerBasis: fiberG,
      saturatedFatGPerBasis: satFatG,
      sodiumMgPerBasis: sodiumMg,
    },
    micronutrients,
  };

  return buildSourceObservationFromFoodItem(item, {
    productIdentity: {
      gtin,
      gtin14,
      format,
      brand,
      product_name: food.description,
      serving_quantity: food.servingSize ?? null,
      serving_unit: basisUnit,
      nutrition_data_per: basisUnit === 'ml' ? '100ml' : '100g',
      preparation_state: 'as_sold',
    },
    basisUnit,
    sourceTierOverride: 'usda_fdc_branded_exact_gtin',
  });
}

async function createServer(): Promise<void> {
  const app = express();
  app.use(express.json({ limit: '64kb' }));

  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
  });

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, service: 'titan-nutrition-engine', version: APP_VERSION });
  });

  app.get('/api/nutrition/barcode/:gtin', nutritionRateLimiter, async (req, res) => {
    const check = validateAndNormalizeGtin(req.params.gtin);
    if (!check.valid || !check.normalized || !check.gtin14 || !check.format) {
      res.status(400).json({
        status: 'invalid_gtin',
        error: check.reason ?? 'GTIN inválido.',
      });
      return;
    }

    const gtin = check.normalized;
    const cached = offCache.get(gtin);
    if (cached && cached.expiresAt > Date.now()) {
      res.status(cached.statusCode).json(cached.payload);
      return;
    }

    // Fixed origin + validated digit-only GTIN prevents SSRF / path traversal.
    const url = `https://world.openfoodfacts.org/api/v3/product/${encodeURIComponent(gtin)}.json?fields=${encodeURIComponent(OFF_ALLOWED_FIELDS)}`;
    try {
      const headers: Record<string, string> = {
        'User-Agent': OFF_USER_AGENT,
        Accept: 'application/json',
      };
      if (cached?.etag) {
        headers['If-None-Match'] = cached.etag;
      }

      const upstream = await fetch(url, {
        method: 'GET',
        headers,
        signal: AbortSignal.timeout(8000),
      });

      if (upstream.status === 304 && cached) {
        cached.expiresAt = Date.now() + CACHE_TTL_FOUND_MS;
        res.status(cached.statusCode).json(cached.payload);
        return;
      }
      if (upstream.status === 429) {
        res.status(429).json({
          status: 'rate_limited',
          gtin,
          error: 'Open Food Facts atingiu limite temporário de taxa (429).',
        });
        return;
      }
      if (upstream.status === 404) {
        const missPayload = {
          status: 'not_found',
          gtin,
          gtin14: check.gtin14,
          observation: null,
        };
        offCache.set(gtin, { expiresAt: Date.now() + CACHE_TTL_MISS_MS, statusCode: 404, payload: missPayload });
        res.status(404).json(missPayload);
        return;
      }
      if (!upstream.ok) {
        res.status(503).json({
          status: 'upstream_unavailable',
          gtin,
          error: `Open Food Facts indisponível (HTTP ${upstream.status}).`,
        });
        return;
      }

      const parsedJson = offResponseSchema.safeParse(await upstream.json());
      if (!parsedJson.success || !parsedJson.data.product) {
        const missPayload = {
          status: 'not_found',
          gtin,
          gtin14: check.gtin14,
          observation: null,
        };
        offCache.set(gtin, { expiresAt: Date.now() + CACHE_TTL_MISS_MS, statusCode: 404, payload: missPayload });
        res.status(404).json(missPayload);
        return;
      }

      const observation = buildObservationFromOffProduct(gtin, check.gtin14, check.format, parsedJson.data.product);
      const okPayload = {
        status: 'found',
        gtin,
        gtin14: check.gtin14,
        observation,
      };
      offCache.set(gtin, {
        expiresAt: Date.now() + CACHE_TTL_FOUND_MS,
        statusCode: 200,
        etag: upstream.headers.get('etag'),
        payload: okPayload,
      });
      res.status(200).json(okPayload);
    } catch {
      res.status(503).json({
        status: 'upstream_unavailable',
        gtin,
        error: 'Falha de rede ou timeout ao consultar Open Food Facts v3.',
      });
    }
  });

  app.get('/api/nutrition/fdc-branded/:gtin', nutritionRateLimiter, async (req, res) => {
    const check = validateAndNormalizeGtin(req.params.gtin);
    if (!check.valid || !check.normalized || !check.gtin14 || !check.format) {
      res.status(400).json({
        status: 'invalid_gtin',
        error: check.reason ?? 'GTIN inválido.',
      });
      return;
    }

    const gtin = check.normalized;
    const apiKey = (process.env.USDA_FDC_API_KEY ?? '').trim();
    if (!apiKey || apiKey === 'MY_USDA_FDC_API_KEY') {
      res.status(200).json({
        status: 'not_configured',
        configured: false,
        gtin,
        observations: [],
        message: 'USDA_FDC_API_KEY não configurada no servidor; fallback FDC Branded em espera.',
      });
      return;
    }

    const cached = fdcBrandedCache.get(gtin);
    if (cached && cached.expiresAt > Date.now()) {
      res.status(cached.statusCode).json(cached.payload);
      return;
    }

    try {
      const upstream = await fetch('https://api.nal.usda.gov/fdc/v1/foods/search', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Api-Key': apiKey,
        },
        body: JSON.stringify({
          query: gtin,
          dataType: ['Branded'],
          pageSize: 10,
        }),
        signal: AbortSignal.timeout(8000),
      });

      if (upstream.status === 429) {
        res.status(429).json({
          status: 'rate_limited',
          configured: true,
          gtin,
          error: 'Limite de taxa da API USDA FoodData Central atingido.',
        });
        return;
      }
      if (!upstream.ok) {
        res.status(503).json({
          status: 'upstream_unavailable',
          configured: true,
          gtin,
          error: `USDA FDC indisponível (HTTP ${upstream.status}).`,
        });
        return;
      }

      const parsed = fdcSearchResponseSchema.safeParse(await upstream.json());
      if (!parsed.success) {
        res.status(503).json({
          status: 'upstream_unavailable',
          configured: true,
          gtin,
          error: 'Resposta inesperada da API USDA FDC.',
        });
        return;
      }

      // Mandatory exact gtinUpc verification — FDC search query performs broad text match!
      const exactMatches = (parsed.data.foods ?? [])
        .filter((item) => item.gtinUpc && matchesExactGtin(item.gtinUpc, gtin))
        .sort((a, b) => {
          const dateA = a.modifiedDate || a.publishedDate || '';
          const dateB = b.modifiedDate || b.publishedDate || '';
          return dateB.localeCompare(dateA) || b.fdcId - a.fdcId;
        });

      const observations = exactMatches.map((item) =>
        buildObservationFromFdcBrandedFood(gtin, check.gtin14!, check.format!, item),
      );
      const payload = {
        status: observations.length > 0 ? 'found' : 'not_found',
        configured: true,
        gtin,
        gtin14: check.gtin14,
        observations,
      };
      const statusCode = observations.length > 0 ? 200 : 404;
      fdcBrandedCache.set(gtin, {
        expiresAt: Date.now() + (observations.length > 0 ? CACHE_TTL_FOUND_MS : CACHE_TTL_MISS_MS),
        statusCode,
        payload,
      });
      res.status(statusCode).json(payload);
    } catch {
      res.status(503).json({
        status: 'upstream_unavailable',
        configured: true,
        gtin,
        error: 'Falha de rede ou timeout ao consultar USDA FoodData Central.',
      });
    }
  });

  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('/{*splat}', (_req, res) => {
      const indexHtml = path.join(distDir, 'index.html');
      if (fs.existsSync(indexHtml)) {
        res.sendFile(indexHtml);
      } else {
        res.status(404).send('Build dist/index.html not found. Run npm run build.');
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`TITAN Nutrition Engine server listening on http://0.0.0.0:${PORT}`);
  });
}

void createServer();
